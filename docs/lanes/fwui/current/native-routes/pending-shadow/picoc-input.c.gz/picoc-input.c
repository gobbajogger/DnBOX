/* SPDX-License-Identifier: GPL-3.0-only
 * Generated, isolated C input for the pending-shadow startup evidence.
 * Storage, recovery and graphics use DnBOX firmware sources.
 * Graphics and sample slots include code originally by Leo Kuroshita
 * (@kurogedelic), Hugelton Instruments. Barlow glyphs are licensed under
 * the SIL Open Font License in assets/fonts/Barlow-OFL.txt.
 * See the accompanying README for modeled services and stripped qualifiers.
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
void bad(int n){printf("BAD %d\n",n);exit(n);}
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef short int16_t;
typedef unsigned int uint32_t;
#define ST_SECTOR 4096
typedef struct {
    uint32_t off;
    uint32_t n;
    uint32_t ls;
    uint32_t le;     /* byte offset (from the slot data), samples, loop start / end */
    uint32_t rate;               /* source rate / 44100, Q16 */
    int16_t root16;
    int16_t pred;
    uint8_t idx;
    uint8_t lo;
    uint8_t hi;
    uint8_t looped;
} smp_zone_t;
typedef struct {
    uint32_t magic;
    uint16_t version;
    uint8_t nz;
    uint8_t rsv;
    char name[8];
    uint32_t data_len; uint32_t crc; uint32_t rsv2[2];
    smp_zone_t zone[16];
} smp_user_hdr_t;
#define SMP_USER_SLOTS 3
#define SMP_USER_OFF(k) ((k) == 0u ? 0xC2000u : (k) == 1u ? 0xD6000u : 0xB3000u)
#define SMP_USER_SIZE(k) ((k) == 0u ? 0x14000u : (k) == 1u ? 0x1E000u : 0x8000u)
#define SMP_SEC0_BACKUP_OFF(k) (0xB0000u + (uint32_t)(k) * 0x1000u)
#define SMP_USER_DATA 512u
#define SMP_USER_MAGIC 0x504D5346u                  /* "FSMP" */
static uint32_t X0X_CRC32_NIBBLE_T[16] = {
    0x00000000u, 0x1DB71064u, 0x3B6E20C8u, 0x26D930ACu, 0x76DC4190u, 0x6B6B51F4u, 0x4DB26158u, 0x5005713Cu,
    0xEDB88320u, 0xF00F9344u, 0xD6D6A3E8u, 0xCB61B38Cu, 0x9B64C2B0u, 0x86D3D2D4u, 0xA00AE278u, 0xBDBDF21Cu};
static uint32_t x0x_crc32_upd(uint32_t c, uint8_t *p, uint32_t n)
{
    while (n--) {
        c ^= *p++;
        c = (c >> 4) ^ X0X_CRC32_NIBBLE_T[c & 15u];
        c = (c >> 4) ^ X0X_CRC32_NIBBLE_T[c & 15u];
    }
    return c;
};
static uint32_t x0x_crc32(void *p, uint32_t n)
{
    return ~x0x_crc32_upd(0xFFFFFFFFu, (uint8_t *)p, n);
};

uint8_t usr_nz[SMP_USER_SLOTS];
uint8_t sector0[3][4096];
uint8_t shadow[3][4096];
uint8_t prev[4096];
uint8_t ed_smp_buf[256]; uint8_t smp_sec0_erased[3], smp_importing[3];
uint8_t *smp_user_xip(uint32_t k) { return &sector0[k][0]; };
smp_user_hdr_t *smp_hdr(uint8_t *p){ return (smp_user_hdr_t *)p; };
uint8_t boot0[4096];uint8_t boot1[4096];
uint8_t *fm1_xip_ptr(uint32_t off){if(off==0xAB000u)return boot0;if(off==0xAC000u)return boot1; unsigned int i; for(i=0;i<3;i++) if(off==SMP_SEC0_BACKUP_OFF(i))return &shadow[i][0]; bad(77); return NULL; };
int write_count;
int erase_live;
int erase_shadow;
int flushes;
int before_bind;
int ed_silence_erase4k(uint32_t off, uint32_t *t) {
 unsigned int i; for(i=0;i<3;i++) {
 if(off==SMP_USER_OFF(i)) {memset(sector0[i],255,4096);erase_live++;return 0;}
 if(off==SMP_SEC0_BACKUP_OFF(i)) {memset(shadow[i],255,4096);erase_shadow++;return 0;}
 } return 1;
};
int fl_write(uint32_t off, void *src,uint32_t n) {
 if(n!=256||off!=SMP_USER_OFF(0)+write_count*256)return 1;
 memcpy(&sector0[0][write_count*256],src,n);write_count++;return 0;
};
void fm1_wdt_feed(void){}; void ed_smp_inval(uint32_t k){if(k!=0)bad(74);};
static int smp_header_valid(smp_user_hdr_t *h, uint32_t k)
{
    uint32_t i;
    if (h->magic != SMP_USER_MAGIC || h->version != 1 || !h->nz || h->nz > 16u ||
        h->data_len > SMP_USER_SIZE(k) - SMP_USER_DATA)
        return 0;
    for (i = 0; i < h->nz; i++) {
        smp_zone_t *z = &h->zone[i];
        if (z->off > h->data_len || z->n > 2u * SMP_USER_SIZE(k) || z->off + (z->n + 1u) / 2u > h->data_len ||
            z->idx > 88u || !z->rate || z->rate > 4u << 16)
            return 0;
    }
    return 1;
};
static void smp_user_scan(uint32_t k)
{
    smp_user_hdr_t *h = smp_hdr(smp_user_xip(k));
    usr_nz[k] = 0;
    if (!smp_header_valid(h, k))
        return;
    if (x0x_crc32(smp_user_xip(k) + SMP_USER_DATA, h->data_len) != h->crc)
        return;
    usr_nz[k] = h->nz;
};
typedef struct { int slot_a; int slot_b; } brkpart_t;
typedef struct { brkpart_t brk; } pattern_t;
struct { pattern_t *pat; int ppat[1]; } seq;
pattern_t owned;
struct { int preview_epoch; } brk;
typedef struct { uint8_t *adpcm; uint32_t nsamples; uint32_t rate; int bars; int slices; } brk_loop_t;
int brk_preview_slot=-1,brk_preview_pattern,nloops=2,loop_slot[3],loop_zone[3];
#define TRK_BRK 0
#define C_BRK 1
void cq_put(int a,int b,int c,int d){}; void breaks_preview_restore(void *b){};
int builtin_count(void){return 2;}; void scan_loops(void){if(seq.pat == NULL){before_bind++;printf("PATTERN_UNBOUND\n");bad(42);}};
void breaks_flush(void *b){}; unsigned int plat_cq_lock(void){return 1;}; void plat_cq_unlock(uint32_t n){};
uint8_t *plat_slot(int k,int z,uint32_t *n,uint32_t *rate,char *name){return NULL;};
int loop_bars(uint32_t n,uint32_t r){return 1;}; brk_loop_t *brk_builtin(int slot){return NULL;};
int brk_slice_count(brkpart_t *b,unsigned int w){return 1;};
void breaks_set_loop_request(void *b,int w,brk_loop_t *L,int epoch){flushes++;};

void engine_brk_loops(void)
{
    /* Boot can restore a sample before engine_init binds the pattern table.
     * fm1_main publishes the recovered loops after loading the project. */
    if (seq.pat == NULL)
        return;
    if (brk_preview_slot >= 0 && brk_preview_pattern != seq.ppat[TRK_BRK]) {
        cq_put(C_BRK, 32, 0, 1);
        brk_preview_slot = -1;
        breaks_preview_restore(&brk);
    }
    brkpart_t *bp = &seq.pat[seq.ppat[TRK_BRK]].brk;
    brk_loop_t L[2];
    int w, audition = brk_preview_slot, nb_before = builtin_count();
    int audition_slot = -1, audition_zone = -1;
    if (audition >= nb_before && audition < nloops) {
        audition_slot = loop_slot[audition];
        audition_zone = loop_zone[audition];
    }
    scan_loops();                                       /* an upload may have changed the user loops */
    /* An addition/restoration can renumber an audition without retiring its
     * storage. Validate its physical identity before publishing any new loop.
     * The table is main-loop-owned; audio may only cancel the captured intent. */
    if (audition >= nb_before && brk_preview_slot == audition &&
        (audition_slot < 0 || audition >= nloops || loop_slot[audition] != audition_slot ||
         loop_zone[audition] != audition_zone)) {
        cq_put(C_BRK, 32, 0, 1);
        brk_preview_slot = -1;
        breaks_preview_restore(&brk);
    }
    /* No mute. The voice that is already sounding keeps its snapshot, and the
     * new loop is published for the next trigger. Skipping the break here used
     * to drop a whole buffer. */
    breaks_flush(&brk);                                /* a change that waited for a free snapshot */
    for (w = 0; w < 2; w++) {
        uint32_t irq = plat_cq_lock();
        int preview = brk_preview_slot;
        int epoch = preview >= 0 ? brk.preview_epoch : -1;
        int slot = (!w && preview >= 0) ? preview : w ? bp->slot_b : bp->slot_a;
        plat_cq_unlock(irq);
        uint32_t ns = 0, rate = 0;
        char name[9];
        int nb = builtin_count();
        uint8_t *d = (slot >= nb && slot < nloops)
                               ? plat_slot(loop_slot[slot], loop_zone[slot], &ns, &rate, name) : 0;
        if (d != NULL) {
            L[w].adpcm = d;
            L[w].nsamples = ns;
            L[w].rate = rate;
            L[w].bars = loop_bars(ns, rate);
        } else {
            brk_loop_t *builtin = brk_builtin(slot < nb ? slot : 0);
            if (builtin != NULL) L[w] = *builtin;
            else memset(&L[w], 0, sizeof L[w]);
        }
        L[w].slices = (!w && preview >= 0) ? 1 : (uint8_t)brk_slice_count(bp, (unsigned)w);
        breaks_set_loop_request(&brk, w, &L[w], epoch);
    }
};
static uint32_t ed_smp_slot(uint32_t k) { return SMP_USER_OFF(k); };
static int ed_smp_copy_4k(uint32_t dst, uint8_t *src)
{
    uint32_t i;
    if (ed_silence_erase4k(dst, 0))
        return 1;
    for (i = 0; i < 0x1000u; i += 256u) {
        uint32_t n = 0x1000u - i;
        if (n > 256u)
            n = 256u;
        memcpy(ed_smp_buf, src + i, n);
        if (fl_write(dst + i, ed_smp_buf, n))
            return 1;
        fm1_wdt_feed();
    }
    return 0;
};
static int ed_smp_backup_present(uint32_t k)
{
    smp_user_hdr_t *h = smp_hdr(fm1_xip_ptr(SMP_SEC0_BACKUP_OFF(k)));
    return h->magic == SMP_USER_MAGIC && h->version == 1 && h->nz && h->nz <= 16u;
};
static void ed_smp_clear_backup(uint32_t k)
{
    if (!ed_smp_backup_present(k))
        return;
    ed_silence_erase4k(SMP_SEC0_BACKUP_OFF(k), 0);
};
static int ed_smp_restore_sec0(uint32_t k)
{
    uint32_t dst = ed_smp_slot(k);
    uint8_t *src;
    if (!ed_smp_backup_present(k))
        return 1;
    src = fm1_xip_ptr(SMP_SEC0_BACKUP_OFF(k));
    if (ed_smp_copy_4k(dst, src))
        return 1;
    ed_smp_inval(k);
    smp_user_scan(k);
    smp_sec0_erased[k] = 0;
    smp_importing[k] = 0;
    ed_smp_clear_backup(k);
    engine_brk_loops();
    return usr_nz[k] ? 0 : 1;
};
static void ed_smp_try_restore(uint32_t k)
{
    if (usr_nz[k]) {
        ed_smp_clear_backup(k);
        return;
    }
    if (ed_smp_backup_present(k))
        ed_smp_restore_sec0(k);
};
void ed_smp_recover(void)
{
    uint32_t k;
    for (k = 0; k < SMP_USER_SLOTS; k++)
        ed_smp_try_restore(k);
};
void seed(uint8_t *s,uint8_t fill) {
 smp_user_hdr_t *h=(smp_user_hdr_t *)s;memset(s,fill,4096);memset(h,0,sizeof(smp_user_hdr_t));
 h->magic=SMP_USER_MAGIC;h->version=1;h->nz=1;memcpy(h->name,"RECOVER",7);h->data_len=128;h->zone[0].rate=65536;h->zone[0].n=256;h->zone[0].hi=127;
 h->crc=x0x_crc32(s+SMP_USER_DATA,128);
};

#define BOOT_MAGIC 0x42583058u              /* "X0XB" */
#define BOOT_VERSION 1u
#define BOOT_KIND_CUSTOM 1u
#define BOOT_KIND_FACTORY 2u
#define BOOT_F_PIC 1u
#define BOOT_LINE0_MAX 12u
#define BOOT_LINE1_MAX 21u
#define BOOT_PIC_W 240u
#define BOOT_PIC_H 96u
#define BOOT_PIC_STRIDE (BOOT_PIC_W / 8u)
#define BOOT_PIC_BYTES (BOOT_PIC_STRIDE * BOOT_PIC_H)   /* 2880 */
#define BOOT_PAY_FIXED 44u
#define BOOT_REC_MAX (BOOT_PAY_FIXED + BOOT_PIC_BYTES)  /* 2924 */
#define BOOT_PAY_OFF 32u
#define BOOT_FACTORY_0 "DnBOX"
#define BOOT_FACTORY_1 "909 808 CHICAGO MIAMI"
#define BOOT_SEC0 0x000AB000u
#define BOOT_SEC1 0x000AC000u
static uint32_t boot_u16(uint8_t *p)
{
    return (uint32_t)p[0] | (uint32_t)p[1] << 8;
};
static uint32_t boot_u32(uint8_t *p)
{
    return (uint32_t)p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24;
};
static void boot_p16(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)v;
    p[1] = (uint8_t)(v >> 8);
};
static void boot_p32(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)v;
    p[1] = (uint8_t)(v >> 8);
    p[2] = (uint8_t)(v >> 16);
    p[3] = (uint8_t)(v >> 24);
};
static int boot_pix(uint8_t *bits, uint32_t x, uint32_t y)
{
    return (bits[y * BOOT_PIC_STRIDE + (x >> 3)] >> (7u - (x & 7u))) & 1;
};
static void boot_lines(uint8_t *pay, char *a, char *b)
{
    uint32_t i;
    uint32_t n0;
    uint32_t n1;
    char *f0 = BOOT_FACTORY_0, *f1 = BOOT_FACTORY_1;
    if (pay == NULL || pay[0] != BOOT_KIND_CUSTOM) {
        for (i = 0; f0[i]; i++)
            a[i] = f0[i];
        a[i] = 0;
        for (i = 0; f1[i]; i++)
            b[i] = f1[i];
        b[i] = 0;
        return;
    }
    n0 = pay[2];
    n1 = pay[3];
    for (i = 0; i < n0; i++)
        a[i] = (char)pay[4u + i];
    a[i] = 0;
    for (i = 0; i < n1; i++)
        b[i] = (char)pay[16u + i];
    b[i] = 0;
};
static int boot_payload_ok(uint8_t *p, uint32_t n)
{
    uint32_t i;
    uint32_t n0;
    uint32_t n1;
    uint32_t kind;
    uint32_t flags;
    uint32_t w;
    uint32_t h;
    if (p == NULL || n < BOOT_PAY_FIXED || n > BOOT_REC_MAX)
        return 0;
    kind = p[0];
    flags = p[1];
    n0 = p[2];
    n1 = p[3];
    if (p[37] || p[38] || p[39])
        return 0;
    w = boot_u16(p + 40);
    h = boot_u16(p + 42);
    if (kind == BOOT_KIND_FACTORY) {
        if (flags || n0 || n1 || w || h || n != BOOT_PAY_FIXED)
            return 0;
        for (i = 4; i < 37u; i++)
            if (p[i])
                return 0;
        return 1;
    }
    if (kind != BOOT_KIND_CUSTOM || (flags & ~BOOT_F_PIC))
        return 0;
    if (n0 < 1u || n0 > BOOT_LINE0_MAX || n1 < 1u || n1 > BOOT_LINE1_MAX)
        return 0;
    for (i = 0; i < BOOT_LINE0_MAX; i++) {
        if (i < n0) {
            if (p[4u + i] < 32u || p[4u + i] > 126u)
                return 0;
        } else if (p[4u + i])
            return 0;
    }
    for (i = 0; i < BOOT_LINE1_MAX; i++) {
        if (i < n1) {
            if (p[16u + i] < 32u || p[16u + i] > 126u)
                return 0;
        } else if (p[16u + i])
            return 0;
    }
    if (flags & BOOT_F_PIC)
        return w == BOOT_PIC_W && h == BOOT_PIC_H && n == BOOT_PAY_FIXED + BOOT_PIC_BYTES;
    return !w && !h && n == BOOT_PAY_FIXED;
};
static int boot_image_state(uint8_t *sec, uint32_t *seq_out)
{
    uint32_t len;
    if (sec == NULL || boot_u32(sec) != BOOT_MAGIC || boot_u16(sec + 4) != BOOT_VERSION)
        return 0;
    if (boot_u32(sec + 24) || boot_u32(sec + 28))
        return 0;
    if (x0x_crc32(sec, 20) != boot_u32(sec + 20))
        return 0;
    len = boot_u32(sec + 12);
    if (len < BOOT_PAY_FIXED || len > BOOT_REC_MAX)
        return 0;
    if (x0x_crc32(sec + BOOT_PAY_OFF, len) != boot_u32(sec + 16))
        return 0;
    if (!boot_payload_ok(sec + BOOT_PAY_OFF, len))
        return 0;
    if (seq_out != NULL)
        *seq_out = boot_u32(sec + 8);
    return 1;
};
static int boot_pick(uint8_t *sec0, uint8_t *sec1)
{
    uint32_t a = 0, b = 0;
    int va = boot_image_state(sec0, &a);
    int vb = boot_image_state(sec1, &b);
    if (va && (!vb || a >= b))
        return 0;
    if (vb)
        return 1;
    return -1;
};

typedef int int32_t;
typedef signed char int8_t;
typedef unsigned int uintptr_t;
typedef struct { int8_t top; int8_t bot; } capm_t;
typedef struct {uint8_t h;uint8_t pad;uint8_t first;uint8_t last;uint8_t *adv;uint8_t *bw;uint16_t *off;uint8_t *data;capm_t cap;} felucca_font_t;
/* SPDX-License-Identifier: GPL-3.0-only */
/* Splash-only crop-LZ glyphs unpacked from the distributed 94197fc8 Elite build.
 * DnBOX and STILL plus the H cap-height metrics. Other glyphs have zero width. */
static uint8_t FONT_B_DATA[576] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 63, 255, 252, 64, 0, 0, 63,
    253, 239, 226, 0, 0, 63, 224, 12, 247, 0, 0, 63, 224, 8, 249, 0, 0, 63, 224, 8,
    249, 0, 0, 63, 224, 8, 249, 0, 0, 63, 224, 8, 249, 0, 0, 63, 224, 8, 249, 0,
    0, 63, 224, 12, 248, 0, 0, 63, 253, 239, 242, 0, 0, 63, 255, 252, 64, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 95, 219, 235, 16, 0, 0, 95, 254, 255, 144, 0, 0, 95,
    224, 127, 192, 0, 0, 95, 192, 79, 192, 0, 0, 95, 192, 79, 192, 0, 0, 95, 192, 79,
    192, 0, 0, 95, 192, 79, 192, 0, 0, 95, 192, 79, 192, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 63, 255, 235, 48, 0, 0, 63, 253, 239, 225, 0, 0, 63, 224, 12,
    245, 0, 0, 63, 224, 9, 247, 0, 0, 63, 224, 45, 244, 0, 0, 63, 255, 255, 160, 0,
    0, 63, 253, 223, 210, 0, 0, 63, 224, 10, 248, 0, 0, 63, 224, 10, 249, 0, 0, 63,
    253, 223, 245, 0, 0, 63, 255, 252, 96, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 174, 235, 48, 0, 0, 12, 254, 239, 225, 0, 0, 79, 225, 12, 247, 0, 0, 111,
    176, 8, 249, 0, 0, 111, 176, 8, 249, 0, 0, 111, 176, 8, 249, 0, 0, 111, 176, 8,
    249, 0, 0, 111, 176, 8, 249, 0, 0, 79, 225, 12, 247, 0, 0, 12, 254, 239, 225, 0,
    0, 1, 174, 235, 48, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 111, 192, 7,
    251, 0, 0, 30, 244, 30, 244, 0, 0, 8, 251, 111, 192, 0, 0, 1, 239, 239, 80, 0,
    0, 0, 159, 253, 0, 0, 0, 0, 63, 248, 0, 0, 0, 0, 143, 252, 0, 0, 0, 1,
    239, 239, 80, 0, 0, 7, 251, 111, 192, 0, 0, 30, 244, 30, 244, 0, 0, 111, 192, 7,
    251, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 63, 208, 8, 248, 0, 0, 63,
    224, 8, 249, 0, 0, 63, 224, 8, 249, 0, 0, 63, 224, 8, 249, 0, 0, 63, 224, 8,
    249, 0, 0, 63, 255, 255, 249, 0, 0, 63, 253, 222, 249, 0, 0, 63, 224, 8, 249, 0,
    0, 63, 224, 8, 249, 0, 0, 63, 224, 8, 249, 0, 0, 63, 208, 8, 249, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};
static uint16_t FONT_B_OFF[95] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 192, 0, 0, 0, 0, 0,
    480, 0, 0, 0, 0, 0, 0, 288, 0, 0, 0, 0, 0, 0, 0, 0, 384, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 96, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};
static uint8_t FONT_B_ADV[95] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 8, 0, 0, 0,
    8, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};
static uint8_t FONT_B_BW[95] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 0, 12, 0, 0, 0,
    12, 0, 0, 0, 0, 0, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 12, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};
felucca_font_t FONT_B;
static uint8_t FONT_S_DATA[448] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 190, 216, 0, 0, 0, 30,
    181, 127, 128, 0, 0, 79, 48, 10, 208, 0, 0, 63, 96, 3, 96, 0, 0, 10, 248, 16,
    0, 0, 0, 0, 126, 229, 0, 0, 0, 0, 1, 175, 80, 0, 0, 38, 0, 11, 208, 0,
    0, 95, 32, 8, 208, 0, 0, 30, 197, 110, 144, 0, 0, 3, 190, 233, 16, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 127, 255, 255, 241, 0, 0, 36, 79, 148, 64, 0,
    0, 0, 15, 112, 0, 0, 0, 0, 15, 112, 0, 0, 0, 0, 15, 112, 0, 0, 0, 0,
    15, 112, 0, 0, 0, 0, 15, 112, 0, 0, 0, 0, 15, 112, 0, 0, 0, 0, 15, 112,
    0, 0, 0, 0, 15, 112, 0, 0, 0, 0, 14, 112, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 14, 128, 0, 0, 14, 128, 0, 0, 14, 128, 0, 0, 14, 128, 0, 0, 14, 128, 0,
    0, 14, 128, 0, 0, 14, 128, 0, 0, 14, 128, 0, 0, 14, 128, 0, 0, 14, 128, 0,
    0, 14, 128, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 128, 0, 0, 0, 0, 14, 128, 0, 0, 0,
    0, 14, 128, 0, 0, 0, 0, 14, 128, 0, 0, 0, 0, 14, 128, 0, 0, 0, 0, 14,
    128, 0, 0, 0, 0, 14, 128, 0, 0, 0, 0, 14, 128, 0, 0, 0, 0, 14, 128, 0,
    0, 0, 0, 14, 165, 85, 64, 0, 0, 14, 255, 255, 240, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 14, 128, 1, 245, 0, 0, 14, 128, 1, 245, 0, 0, 14, 128, 1,
    245, 0, 0, 14, 128, 1, 245, 0, 0, 14, 129, 18, 245, 0, 0, 14, 255, 255, 245, 0,
    0, 14, 148, 69, 245, 0, 0, 14, 128, 1, 245, 0, 0, 14, 128, 1, 245, 0, 0, 14,
    128, 1, 245, 0, 0, 14, 128, 1, 245, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
};
static uint16_t FONT_S_OFF[95] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    352, 192, 0, 0, 256, 0, 0, 0, 0, 0, 0, 0, 96, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};
static uint8_t FONT_S_ADV[95] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    8, 4, 0, 0, 7, 0, 0, 0, 0, 0, 0, 8, 8, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};
static uint8_t FONT_S_BW[95] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    12, 8, 0, 0, 11, 0, 0, 0, 0, 0, 0, 12, 12, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};
felucca_font_t FONT_S;

void fonts(void){
FONT_S.h=16;
FONT_S.pad=2;
FONT_S.first=32;
FONT_S.last=126;
FONT_S.adv=FONT_S_ADV;
FONT_S.bw=FONT_S_BW;
FONT_S.off=FONT_S_OFF;
FONT_S.data=FONT_S_DATA;
FONT_S.cap.top=2;
FONT_S.cap.bot=12;
FONT_B.h=16;
FONT_B.pad=2;
FONT_B.first=32;
FONT_B.last=126;
FONT_B.adv=FONT_B_ADV;
FONT_B.bw=FONT_B_BW;
FONT_B.off=FONT_B_OFF;
FONT_B.data=FONT_B_DATA;
FONT_B.cap.top=2;
FONT_B.cap.bot=12;};

uint16_t *cv_px;
uint16_t *fb;
uint32_t cv_w;
uint32_t cv_h;
int32_t cv_oy,cv_y0,cv_y1;
#define CV_MAX 33120
#define RGB(r,g,b) ((uint16_t)((((r)>>3)<<11)|(((g)>>2)<<5)|((b)>>3)))
uint16_t pal[5];
uint16_t baseColor;
#define C_BLACK baseColor
#define C_HI pal[4]
#define C_GRAY pal[2]
#define C_DIM pal[1]
void palette_set(uint32_t i){if(i!=1)bad(83);baseColor=RGB(5,10,13);pal[4]=RGB(255,184,70);pal[2]=RGB(156,170,168);pal[1]=RGB(128,146,148);};
void lcd_sync(void){};
void lcd_blit(uint32_t x,uint32_t y,uint32_t w,uint32_t h,uint16_t *buf){uint32_t j;if(x+w>240||y+h>240)bad(66);for(j=0;j<h;j++)memcpy(fb+(y+j)*240+x,buf+j*w,w*2);};
static uint32_t font_bitmap_width(felucca_font_t *f, uint32_t gi)
{
    uint32_t advance = f->adv[gi];
    return f->bw != NULL ? f->bw[gi] : advance ? advance + 2u * f->pad : 0u;
};
static uint16_t swap16(uint32_t c) { return (uint16_t)(((c >> 8) & 0xFFu) | ((c & 0xFFu) << 8)); };
static uint32_t cv_div15(uint32_t x) { return (x * 0x8889u) >> 19; };
static void cv_begin(uint32_t w, uint32_t h, uint16_t bg)
{
    uint32_t i;
    uint32_t n;
    uint32_t fill = swap16(bg);
    if (w * h > CV_MAX)
        h = CV_MAX / w;
    lcd_sync();                     /* the last blit may still read cv_px */
    cv_w = w;
    cv_h = h;
    cv_oy = cv_y0 = 0;
    cv_y1 = (int32_t)h;
    n = w * h;
    i = 0;
    if (n && ((uintptr_t)cv_px & 3u))
        cv_px[i++] = (uint16_t)fill;
    fill |= fill << 16;
    /* Copy object bytes: the host unity build strips type attributes. */
    for (; i + 1u < n; i += 2u)
        memcpy(cv_px + i, &fill, sizeof fill);
    if (i < n)
        cv_px[i] = (uint16_t)fill;
};
static void cv_blit(uint32_t x, uint32_t y) { lcd_blit(x, y, cv_w, cv_h, cv_px); };
static void cv_pset(int32_t x, int32_t y, uint16_t c)
{
    y += cv_oy;
    if ((uint32_t)x < cv_w && y >= cv_y0 && y < cv_y1)
        cv_px[(uint32_t)y * cv_w + (uint32_t)x] = swap16(c);
};
static uint32_t glyph(felucca_font_t *f, uint32_t ch)
{
    if (ch >= 'a' && ch <= 'z' && f->last < 'a')
        ch -= 32u;
    if (ch < f->first || ch > f->last || (ch >= 127u && ch < 160u))
        ch = '?';
    return ch - f->first;
};
static int32_t cv_text_clip(int32_t x, int32_t y, felucca_font_t *f, char *s, uint16_t c, int32_t clip_left, int32_t clip_right)
{
    uint32_t r = c >> 11, g = (c >> 5) & 63u, b = c & 31u;
    uint16_t sc = swap16(c);
    for (; *s; s++) {
        uint32_t gi = glyph(f, (uint8_t)*s), gx, gy, w, height = f->h;
        uint32_t crop_x = 0, crop_y = 0;
        uint32_t bpr;
        uint8_t *gd;
        gd = f->data + f->off[gi];
        w = font_bitmap_width(f, gi);
        bpr = (w + 1u) / 2u;
        for (gy = 0; gy < height; gy++)
            for (gx = 0; gx < w; gx++) {
                uint32_t a;
                a = gd[gy * bpr + gx / 2u];
                int32_t px = x - f->pad + (int32_t)(gx + crop_x), py = y + (int32_t)(gy + crop_y) + cv_oy;
                a = (gx & 1u) ? (a & 15u) : (a >> 4);
                if (!a || px < clip_left || px >= clip_right || (uint32_t)px >= cv_w || py < cv_y0 || py >= cv_y1)
                    continue;
                if (a == 15u) {
                    cv_px[(uint32_t)py * cv_w + (uint32_t)px] = sc;
                } else {
                    uint32_t bg = swap16(cv_px[(uint32_t)py * cv_w + (uint32_t)px]);
                    uint32_t br = bg >> 11, bgg = (bg >> 5) & 63u, bb = bg & 31u;
                    uint32_t nr = cv_div15(r * a + br * (15u - a)), ng = cv_div15(g * a + bgg * (15u - a)),
                             nb = cv_div15(b * a + bb * (15u - a));
                    cv_px[(uint32_t)py * cv_w + (uint32_t)px] = swap16((nr << 11) | (ng << 5) | nb);
                }
            }
        x += f->adv[gi];
    }
    return x;
};
static int32_t cv_text(int32_t x, int32_t y, felucca_font_t *f, char *s, uint16_t c)
{ return cv_text_clip(x,y,f,s,c,0,(int32_t)cv_w); };
static int32_t text_w(felucca_font_t *f, char *s)
{
    int32_t w = 0;
    for (; *s; s++)
        w += f->adv[glyph(f, (uint8_t)*s)];
    return w;
};
static void draw_text_box(uint32_t x, uint32_t y, uint32_t w, felucca_font_t *f, char *s,
                          uint16_t c, int align)
{
    int32_t tw = text_w(f, s), tx = 0;
    cv_begin(w, f->h, C_BLACK);
    if (align == 1)
        tx = ((int32_t)w - tw) / 2;
    else if (align == 2)
        tx = (int32_t)w - tw;
    cv_text(tx, 0, f, s, c);
    cv_blit(x, y);
    lcd_sync();                     /* one-shots (boot, crash, UBOOT, update) finish here */
};
static void draw_boot_screen(uint8_t *pay)
{
    char title[13], subtitle[22];
    int custom = pay != NULL && pay[0] == BOOT_KIND_CUSTOM;
    int picture = custom && (pay[1] & BOOT_F_PIC);
    boot_lines(pay,title,subtitle);
    for (int band=0; band<2; ++band) {
        cv_begin(240,120,C_BLACK);
        if (picture) for (unsigned y=0; y<BOOT_PIC_H; ++y)
            for (unsigned x=0; x<BOOT_PIC_W; ++x)
                if (boot_pix(pay+BOOT_PAY_FIXED,x,y)) cv_pset((int)x,(int)y+20-band*120,C_HI);
        cv_blit(0,(uint32_t)band*120u);
    }
    /* B supports lowercase; M deliberately contains capitals/numbers only. */
    draw_text_box(0,picture?137:96,240,&FONT_B,title,C_HI,1);
    draw_text_box(0,picture?164:134,240,&FONT_S,subtitle,C_GRAY,1);
    if (!custom) draw_text_box(0,154,240,&FONT_S,"BREAK",C_DIM,1);
};

int flash_ok;
uint8_t ownertag[16];
static uint32_t fl_jedec_ram(void){return 0xeb6014;};
uint32_t irq_save(void){return 1;};void irq_restore(uint32_t r){if(r!=1)bad(103);};
void fl_plain_window_init(void){if(!flash_ok)bad(104);};
#define FELUCCA_DATA_FAMILY "X0X"
#define FELUCCA_DATA_UNTAGGED_OK 0
#define ST_SMK_BASE 0x9D000u
#define ST_OWNER_SECTOR 0xAF000u
#define OTA_AREA 0x000BB000u                     /* staged loader, 5 x 4 KiB */
#define OTA_RES (OTA_AREA + OTA_AREA_LEN - 0x100u)  /* 0xBFF00 = 4K boundary - 256: SPL scan */
#define OTA_AREA_LEN 0x5000u
int st_owner_cleared;
int st_read(uint32_t off,void *dst,uint32_t n){if(off!=ST_OWNER_SECTOR||n!=16)bad(105);memcpy(dst,ownertag,16);return 0;};
void st_erase(uint32_t off){bad(106);};void st_prog(uint32_t off,void *src,uint32_t n){bad(107);};
void ST_IDLE(void) {};
int ota_fread(uint32_t off,void *dst,uint32_t n){memset(dst,255,n);return 0;};
void ota_unstage(void){bad(108);};
static void st_owner_check(void)
{
    static char FAM[4] = "X0X"; static char PREFIX[10]="SMK37DATA";
    uint8_t tag[16], want[16];
    uint32_t i, erased = 1, ours = 1, s;
    for (i = 0; i < 16u; i++)
        if(i<9u)want[i]=PREFIX[i];else if(i-9u<sizeof(FAM)-1u)want[i]=FAM[i-9u];else want[i]=0;
    if (st_read(ST_OWNER_SECTOR, tag, 16))
        return;
    for (i = 0; i < 16u; i++) {
        erased &= tag[i] == 0xFFu;
        ours &= tag[i] == want[i];
    }
    if (ours)
        return;
    if (!erased || !FELUCCA_DATA_UNTAGGED_OK) {     /* another firmware's store (or unknown): clear it */
        for (s = ST_SMK_BASE; s <
             ST_OWNER_SECTOR
             ; s += ST_SECTOR) {
            st_erase(s);
            ST_IDLE();
        }
        st_owner_cleared = 1;
    }
    st_erase(ST_OWNER_SECTOR);
    st_prog(ST_OWNER_SECTOR, want, 16);
};
static int ota_boot_cleanup(void)
{
    uint8_t a[4], r[8];
    uint32_t i, used = 0;
    if (ota_fread(OTA_AREA, a, 4) || ota_fread(OTA_RES, r, 8))
        return -1;
    for (i = 0; i < 4u; i++)
        used |= a[i] != 0xFFu;
    for (i = 0; i < 8u; i++)
        used |= r[i] != 0xFFu;
    if (used)
        ota_unstage();
    return (int)used;
};
static uint8_t *boot_shown(void)
{
    uint8_t *a, *b;
    int w;
    if (!flash_ok)
        return 0;
    a = fm1_xip_ptr(BOOT_SEC0);
    b = fm1_xip_ptr(BOOT_SEC1);
    w = boot_pick(a, b);
    return w < 0 ? (uint8_t *)0 : (w ? b : a);
};
void lcd_init(void){if(usr_nz[0]!=1||write_count!=16||erase_live!=1||erase_shadow!=1||flushes||memcmp(sector0[0],prev,4096))bad(71);unsigned int i;for(i=0;i<4096;i++)if(shadow[0][i]!=255)bad(71);};
static void fm1_main(void)
{
    int32_t knob = 512 * 16;
    int ota_pending;
    uint32_t last_frame = 0, k;
    uint8_t last_pat = 0xFF;
    {
        uint32_t f = irq_save();
        flash_ok = (fl_jedec_ram()==0xeb6014u || fl_jedec_ram()==0x856014u);   /* the expected 1 MiB part, else RAM only */
        irq_restore(f);
        if (flash_ok) {
            fl_plain_window_init();                 /* user sample slots read as plaintext through XIP */
            st_owner_check();                       /* SMK: never parse another ported firmware's store (storage.c) */
            for (k = 0; k < SMP_USER_SLOTS; k++)
                smp_user_scan(k);
            ed_smp_recover();                       /* mid-WRITE power loss: put sector 0 back from FL_SMPV */
            ota_boot_cleanup();
        }
    }
    lcd_init();
    palette_set(1);
    {
        uint8_t *record = boot_shown();
        draw_boot_screen(record != NULL ? record + BOOT_PAY_OFF : 0);
    }
};

static void seed_splash(int picture) {
    uint8_t *record=boot0,*pay=record+BOOT_PAY_OFF;
    int length=picture?BOOT_REC_MAX:BOOT_PAY_FIXED;
    memset(record,0,BOOT_PAY_OFF+length);
    pay[0]=BOOT_KIND_CUSTOM;pay[2]=pay[3]=5;memcpy(pay+4,"DnBOX",5);memcpy(pay+16,"STILL",5);
    if(picture) { pay[1]=BOOT_F_PIC;boot_p16(pay+40,240);boot_p16(pay+42,96);pay[BOOT_PAY_FIXED]=128; }
    boot_p32(record,BOOT_MAGIC);boot_p16(record+4,BOOT_VERSION);boot_p32(record+8,1);
    boot_p32(record+12,length);boot_p32(record+16,x0x_crc32(pay,length));boot_p32(record+20,x0x_crc32(record,20));
    if(!boot_image_state(record,NULL))bad(72);
};
int main(void){
    FILE *f;
    cv_px=malloc(33120*2);fb=malloc(240*240*2);
    memset(fb,0xEE,240*240*2);fonts();
    memset(sector0,255,sizeof(sector0));memset(shadow,255,sizeof(shadow));
    memset(boot0,255,sizeof boot0);memset(boot1,255,sizeof boot1);
    memcpy(ownertag,"SMK37DATAX0X",12);
    seed(prev,54);memcpy(shadow[0],prev,4096);seed_splash(0);
    fm1_main();
    f=fopen("screen.bin","wb");
    if(f==NULL)return 82;
    if(fwrite(fb,2,240*240,f)!=240*240)return 81;
    fclose(f);
    printf("SPLASH writes=%d restored=%d bytes=115200\n",write_count,usr_nz[0]);
    return 0;
};
