uint8_t smk_clip_lcd_draw(uint32_t w, uint32_t h)
{
    static uint32_t last_ms, last_sig;
    uint32_t sig = 2166136261u, note;
    uint8_t pad, in_view[SMK_APC40_CLIP_COUNT];
    if (ck_page_on()) {                             /* the SCALE / CHORD / ARP page is over the grid */
        if (fm1_ms - last_ms < SMK_CLIP_LCD_MIN_MS)
            return 0u;
        last_ms = fm1_ms;
        was_on = 0u;                                /* (the grid draws at once when the page closes) */
        cv_begin(w, h, C_BLACK);
        cv_band(0, (int32_t)h);
        ck_page_draw();
        return 1u;
    }
    for (note = 0; note < SMK_APC40_CLIP_COUNT; note++) {
        in_view[note] = 0u;
        sig = (sig ^ apc_led_velocity[note]) * 16777619u;
        sig = (sig ^ (apc_cell_flags[note] & SMK_APC40_CELL_QUEUED)) * 16777619u;
    }
    for (pad = 0; pad < SMK_APC40_PAD_COUNT; pad++) {
        uint8_t n = smk_apc40_note_for_pad_view(apc_cols, apc_rows, apc_origin_col,
                                                apc_origin_row, apc_view, pad);
        if (n < SMK_APC40_CLIP_COUNT)
            in_view[n] = 1u;
    }
    for (note = 0; note < SMK_APC40_CLIP_COUNT; note++)
        sig = (sig ^ in_view[note]) * 16777619u;
    sig = (sig ^ ((uint32_t)apc_cols | (uint32_t)apc_rows << 8 | (uint32_t)apc_origin_col << 16 |
                  (uint32_t)apc_origin_row << 24)) * 16777619u;
    sig = (sig ^ apc_view_has_clips) * 16777619u;
    if (was_on && sig == last_sig && fm1_ms - last_ms < 1000u)
        return 0u;                                  /* nothing changed (1 s refresh anyway) */
    if (was_on && fm1_ms - last_ms < SMK_CLIP_LCD_MIN_MS)
        return 0u;                                  /* rate limit */
    was_on = 1u;
    last_sig = sig;
    last_ms = fm1_ms;
    cv_begin(w, h, C_BLACK);
    cv_band(0, (int32_t)h);
    {
        smk_apc40_lcd_map_t m = smk_apc40_lcd_map(apc_cols, apc_rows, apc_origin_col, apc_origin_row,
                                                  apc_view_has_clips, (uint16_t)w, (uint16_t)h);
        int32_t p = m.pitch, gap = p >= 24 ? 3 : 2;
        uint8_t col, row;
        for (row = 0u; row < m.nrows; row++)
            for (col = 0u; col < m.ncols; col++) {
                /* The highest APC row is the top Loopy row: draw it on top. */
                int32_t x = m.x0 + (int32_t)col * p, y = m.y0 + (int32_t)smk_apc40_lcd_screen_row(&m, (uint8_t)(m.row0 + row)) * p;
                uint8_t n = (uint8_t)((m.row0 + row) * SMK_APC40_SOURCE_COLS + m.col0 + col);
                uint8_t v = apc_led_velocity[n];
                /* The Akai colour as plain RGB565. An idle shade: half of the full shade (CLP-05). */
                uint16_t c = smk_clip_lcd565(v);
                int32_t q = p / 4;
                if (in_view[n])
                    cv_rect(x, y, p, p, C_WHITE);
                cv_rect(x + gap, y + gap, p - 2 * gap, p - 2 * gap, C_BLACK);
                if (v)
                    cv_rect(x + gap + 1, y + gap + 1, p - 2 * gap - 2, p - 2 * gap - 2, c);
                else
                    cv_rect(x + p / 2 - 2, y + p / 2 - 2, 4, 4, C_DIM);
                if (apc_cell_flags[n] & SMK_APC40_CELL_QUEUED)
                    cv_rect(x + p / 2 - q / 2, y + p / 2 - q / 2, q, q, C_WHITE);
            }
    }
    return 1u;
}
