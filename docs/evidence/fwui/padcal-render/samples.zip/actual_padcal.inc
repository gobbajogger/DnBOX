uint8_t smk_padcal_draw(uint32_t w, uint32_t h)
{
    uint8_t e = smk_padcal_entry(padcal.page, padcal.sel), i, s = padcal.real ? 0u : smk_padcal_boost_shift(APC40_LCD565[e]);
    uint32_t sig = smk_padcal_word(&padcal, e) ^ (uint32_t)(padcal.sel | padcal.page << 4) << 25 ^
                   (uint32_t)(padcal.tl | padcal.orient << 4 | padcal.real << 5) * 2654435761u;
    char t[32], *q;
    if (sig == padcal_sig)                        /* only the selected entry, the pad and the page change */
        return 0u;
    padcal_sig = sig;
    cv_begin(w, h, C_BLACK);
    cv_band(0, (int32_t)h);
    if (padcal.orient) {
        cv_text(4, 70, &FONT_S, "pad 1 top-left?", C_WHITE);
        return 1u;
    }
    for (i = 0; i < SMK_PADCAL_PADS; i++) {
        int32_t x = (int32_t)(i & 7u) * 30, y = (int32_t)(i >> 3) * 30;
        uint8_t n = smk_padcal_entry(padcal.page, i);
        uint16_t c = i == padcal.sel ? smk_padcal_boost565(APC40_LCD565[n], s) : APC40_LCD565[n];
        if (i == padcal.sel)
            cv_rect(x, y, 30, 30, C_WHITE);
        cv_rect(x + 3, y + 3, 24, 24, c);
        if (smk_padcal_is_ok(&padcal, n))
            cv_rect(x + 12, y + 12, 6, 6, smk_padcal_dot565(c));   /* black on a light square */
    }
    q = put_s(put_s(put_s(put_i(put_s(t, "#"), e), " "), PADCAL_HUE[PADCAL_NAME[e] >> 3]), " ");
    put_s(q, PADCAL_SHADE[PADCAL_NAME[e] & 7u]);
    cv_text(4, 70, &FONT_S, t, C_WHITE);
    put_i(put_s(t, "BOOST X"), 1u << s);
    cv_text(4, 92, &FONT_S, padcal.real ? "REAL LEVEL" : t, C_WHITE);   /* SEQ REC toggles */
    return 1u;
}
