from pathlib import Path
import json,subprocess,sys,os
d=Path(__file__).resolve().parent
root=d.parents[2]
r=Path(os.environ['DNBX_REPO']).resolve();build=Path(os.environ['FACTORY_BUILD']).resolve()
fixture=r/'tests/fixtures/synthone-factory/fullfx'
s=(fixture/'source_fx.hpp').read_text()
a=s.index('        // REVERB INPUT HIPASS FILTER');b=s.index('        // MASTER COMPRESSOR/LIMITER',a)
block=s[a:b]
mix=block[block.index('        float reverbMixFactor'):block.index('        revCrossfadeL->pos')]
block=block.replace(mix,'').replace('        float reverbCrossfadeOutL = 0.f;','').replace('        float reverbCrossfadeOutR = 0.f;','')
block=block.replace('        // crossfade wet reverb with wet+dry delay','        running->wet[0]=reverbWetL;running->wet[1]=reverbWetR;\n        // crossfade wet reverb with wet+dry delay')
s=s[:a]+mix+'''        float reverbCrossfadeOutL=0.f,reverbCrossfadeOutR=0.f;
        running->input[0]=mixedDelayL;running->input[1]=mixedDelayR;
        if(running->candidate) {
            test_room(parameters.data(),mixedDelayL,mixedDelayR,lfo1_1_0,lfo2_1_0,
                &reverbCrossfadeOutL,&reverbCrossfadeOutR,running->wet);
        } else {
'''+block+'        }\n'+s[b:]
(d/'capture_fx.hpp').write_text(s)
s=(d/'source-driver.cpp').read_text()
a=s.index('extern "C" int capture_bits;');b=s.index('#define S1FX_EXISTING_PARAMETERS',a)
s=s[:a]+'''extern "C" int test_begin(void);
extern "C" void test_finish(void);
extern "C" void test_configure(const float*);
extern "C" void test_room(const float*,float,float,float,float,float*,float*,float*);
constexpr unsigned rate=44100;
struct Measurement { unsigned candidate;float input[2]{},wet[2]{}; };
static Measurement* running;
'''+s[b:]
s=s.replace('fx[3]{SourceFx(rate),SourceFx(rate),SourceFx(rate)}','fx[2]{SourceFx(rate),SourceFx(rate)}').replace('measures[3]{{original},{multirate},{shortened}}','measures[2]{{0},{1}}')
a=s.index('        for (unsigned k = 1; k < 3;');b=s.index('    static void trace',a)
s=s[:a]+'        CHECK(test_begin());\n    }\n'+s[b:]
s=s.replace('outputs[3][4]','outputs[2][4]').replace('k < 3;','k < 2;')
s=s.replace('    for (unsigned row = 0; row < 694; ++row) {','    float factory[150]{};\n    for (unsigned row = 0; row < 694; ++row) {')
s=s.replace('if (row == selected) CHECK(render.controls.set_parameter(id, value));','if (row == selected) { CHECK(render.controls.set_parameter(id,value));factory[id]=value; }')
s=s.replace('    render.pair.o.resetSequencer();','    test_configure(factory);\n    render.pair.o.resetSequencer();')
s=s.replace('    CHECK(std::fclose(out) == 0);','    test_finish();CHECK(std::fclose(out) == 0);')
(d/'probe.cpp').write_text(s)
cmds=json.loads((build/'factory-build-commands.json').read_text())
cmd=next(c for c in cmds if any(a.endswith('/preset_audio.cpp') for a in c)).copy()
for opt,file in [('-c','probe.cpp'),('-o','runner.o'),('-MF','runner.d')]:cmd[cmd.index(opt)+1]=str(d/file)
cmd.insert(1,'-I'+str(d));subprocess.run(cmd,check=True)
subprocess.run(['cc','-DX0X_S1_ROOM_BITS=9','-std=c11','-O2','-ffp-contract=off','-ffunction-sections','-fdata-sections','-I'+str(r/'firmware/src/app'),'-I'+str(r/'firmware/src'),'-I'+str(r/'experiments/original_synth'),'-c',d/'host.c','-o',d/'host.o'],check=True)
subprocess.run(['cc','-std=c11','-O2','-ffunction-sections','-fdata-sections','-I'+str(r/'firmware/src'),'-c',r/'firmware/src/dsp/s1_dry_voice.c','-o',d/'voice.o'],check=True)
subprocess.run(['cc','-std=c11','-O2','-ffunction-sections','-fdata-sections','-I'+str(r/'firmware/src'),'-c',r/'firmware/src/dsp/dnbx_s1_envelope.c','-o',d/'envelope.o'],check=True)
cmd=cmds[-1].copy();cmd.insert(1,str(d/'voice.o'));cmd.insert(1,str(d/'envelope.o'));cmd[cmd.index(str(build/'factory-6.o'))]=str(d/'runner.o');cmd.insert(1,str(d/'host.o'));cmd.insert(1,'-Wl,--gc-sections');cmd[cmd.index('-o')+1]=str(d/'probe');subprocess.run(cmd,check=True)
