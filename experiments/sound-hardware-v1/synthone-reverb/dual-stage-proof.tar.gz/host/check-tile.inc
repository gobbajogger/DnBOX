enum { ROOM_TILE=32 };
typedef struct {
    float states[8][ROOM_TILE], junction[ROOM_TILE], feedback[ROOM_TILE],wet[ROOM_TILE], in[2][ROOM_TILE];
    uint16_t start[8];
} room_tile;
static uint32_t work_timing[6];
static void read_lines(s1_room *s,room_tile *w,unsigned first,unsigned end,unsigned size)
{
    for(unsigned n=first;n<end;++n){
        s1_room_line *line=s->line+n;unsigned pos=line->write;w->start[n]=(uint16_t)pos;
        float before=line->filtered;unsigned remaining=line->remaining;
        for(unsigned j=0;j<size;++j){
            w->states[n][j]=before;
            if(++pos==room_geometry[n].samples)pos=0;
            float x=room_read(s,line,n)*w->feedback[j];before=(before-x)*0x1.5f619ap-3f+x;
            if(!--remaining){line->write=(uint16_t)pos;room_next(line,n);remaining=line->remaining;}
        }
        line->filtered=before;line->remaining=remaining;line->write=w->start[n];
    }
}
static void wet_tile(s1_dry_part *p,room_tile *w,float *l,float *r,unsigned size)
{
    for(unsigned j=0;j<size;++j){
        float join=0.f,raw[2]={0};
        for(unsigned n=0;n<8;++n){
            join+=w->states[n][j];
            raw[n&1u]+=j+1u==size?p->room.line[n].filtered:w->states[n][j+1];
        }
        w->junction[j]=join*.25f;
        float wl=room_compress(&p->room_wet,0,raw[0]*.35f),wr=room_compress(&p->room_wet,1,raw[1]*.35f),wet=w->wet[j];l[j]=wl*wet+l[j]*(1.f-wet);r[j]=wr*wet+r[j]*(1.f-wet);
    }
}
static void write_lines(s1_room *s,room_tile *w,unsigned first,unsigned end,unsigned size)
{
    for(unsigned n=first;n<end;++n){
        s1_room_line *line=s->line+n;const float *in=w->in[n&1u];
        for(unsigned j=0;j<size;++j){
            room_write(s,line,n,(in[j]+w->junction[j])-w->states[n][j]);
        }
    }
}
static room_tile slab;
