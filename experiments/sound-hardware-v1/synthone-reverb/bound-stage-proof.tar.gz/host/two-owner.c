/* SPDX-License-Identifier: GPL-3.0-only */
#define main simulator_main
#include "../../host/x0x_host.c"
#undef main
#include "../../firmware/src/app/s1_reverb.h"
static unsigned checks, supply[2]={1,1}, binds[2];
#define CHECK(x) do{++checks;if(!(x)){fprintf(stderr,"FAIL %d %s\n",__LINE__,#x);exit(1);}}while(0)
static struct {uint8_t before[7],data[S1_ROOM_EXTERNAL_BLOCKS*S1_ROOM_BLOCK_BYTES],after[7];} room_test_store[2];
unsigned s1_board_room_spans(unsigned owner,s1_room_buffer out[S1_ROOM_MAX_SPANS-1])
{
    ++binds[owner];if(!supply[owner])return 0;
    unsigned part=487*S1_ROOM_BLOCK_BYTES;
    out[0]=(s1_room_buffer){room_test_store[owner].data,part};
    out[1]=(s1_room_buffer){room_test_store[owner].data+part,sizeof room_test_store[owner].data-part-(supply[owner]==2)};
    return 2;
}
static void render(unsigned n)
{int32_t stereo[512];for(unsigned i=0;i<n;++i)engine_render(stereo,256);}
static void select_bank(unsigned owner,unsigned kind)
{
    CHECK(engine_bass_select_preset(owner,kind,0,&proj.sound)==0);
    for(unsigned i=0;i<4096 && (engine_bass_bank(owner)!=(int)kind || engine_bass_preset_pending(owner));++i)render(1);
    CHECK(!engine_bass_preset_pending(owner) && engine_bass_bank(owner)==(int)kind);
}
static uint32_t data_hash(unsigned voice)
{
    uint32_t h=2166136261u;
    for(unsigned i=0;i<sizeof room_test_store[voice].data;++i)h=(h^room_test_store[voice].data[i])*16777619u;
    return h;
}
static void event(unsigned v,unsigned note,unsigned velocity)
{
    unsigned status=(velocity?0x92:0x82)+v;
    min_q[mi_w++%MQ]=(status>>4)|status<<8|note<<16|velocity<<24;
}
static void cold(void)
{
    engine_project_hold(1);engine_init(proj.pat,&proj.arr.song,proj.arr.lane,&proj.sound);
    engine_apply_sound(&proj.sound);
    seq.ch[PART_909]=9;seq.ch[PART_808]=10;seq.ch[PART_BRK]=11;
    seq.ch[PART_303A]=2;seq.ch[PART_303B]=3;engine_project_release();
}
static void historical_aux(void)
{
    uint8_t cell[32],row[32];memset(row,0xc9,sizeof row);
    CHECK(original_sound_init(cell,ORIGINAL_SOUND_SYNTHONE,0));
    CHECK(original_master_valid(cell,row) && original_sound_ext_bytes(cell,row)==0);
    CHECK(original_sound_set_extended(cell,row,ORIGINAL_SYNTHONE_MASTER_MAKEUP,61));
    CHECK(row[0]==1 && original_sound_ext_bytes(cell,row)==7 && row[7]==0xc9);
    CHECK(original_master_valid(cell,row));
    CHECK(original_sound_set_extended(cell,row,ORIGINAL_SYNTHONE_ROOM_MIX,78));
    CHECK(row[0]==3 && original_master_display(cell,row,ORIGINAL_SYNTHONE_MASTER_MAKEUP)==61);
    CHECK(original_master_display(cell,row,ORIGINAL_SYNTHONE_ROOM_MIX)==78);
    row[13]=0xff;CHECK(!original_master_valid(cell,row));
    row[0]=1;CHECK(original_master_valid(cell,row));
    CHECK(original_sound_set_extended(cell,row,ORIGINAL_SYNTHONE_ROOM_LFO,85));
    CHECK(original_master_display(cell,row,ORIGINAL_SYNTHONE_ROOM_WET_COMP)==0);
}
int main(void)
{
    historical_aux();
    load_force=0;boot();render(12);
    for(unsigned v=0;v<2;++v){
        memset(room_test_store[v].before,0xa7,7);memset(room_test_store[v].after,0xc1,7);
        select_bank(v,ORIGINAL_SOUND_SYNTHONE);
    }
    cold();render(2);
    for(unsigned v=0;v<2;++v){
        ui.view=V_PART;ui.part=PART_303A+v;ui.overlay=0;build_pages();
        unsigned found=0;
        for(unsigned p=0;p<pg.n;++p)for(unsigned j=0;j<4;++j){
            pref_t ref=pg.r[p][j];if(ref.kind==R_ENG && ref.a==T_303 && ref.b==(int)v && ref.c>=ORIGINAL_SYNTHONE_ROOM_ON)found|=1u<<(ref.c-ORIGINAL_SYNTHONE_ROOM_ON);
        }
        CHECK(found==127u);
        static const unsigned position[7]={127,110,98,103,0,79,71};
        for(unsigned slot=0;slot<7;++slot){
            pref_t ref=PR(R_ENG,T_303,v,ORIGINAL_SYNTHONE_ROOM_ON+slot);
            pref_set(ref,position[slot]);CHECK(pref_get(ref)==(int)position[slot]);
        }
        CHECK(proj.sound.v[T_303][NBASS+v][0]==2);
        pref_t sel=PR(R_ENG,T_303,v,ORIGINAL_SYNTHONE_ROOM_IN_COMP);
        CHECK(original_switch_turn(sel,pref_get(sel),1,1)==95);
        pref_t wet=PR(R_ENG,T_303,v,ORIGINAL_SYNTHONE_ROOM_WET_COMP);
        CHECK(original_switch_turn(wet,pref_get(wet),-1,1)==56);
    }
    render(4);
    pref_t mix=PR(R_ENG,T_303,0,ORIGINAL_SYNTHONE_ROOM_MIX);
    undo_start();pref_set(mix,42);render(4);undo_commit_stable();
    do_undo(0);render(4);CHECK(pref_get(mix)==110);
    do_undo(1);render(4);CHECK(pref_get(mix)==42);
    for(unsigned v=0;v<2;++v){
        pref_set(PR(R_ENG,T_303,v,ORIGINAL_SYNTHONE_MASTER_MAKEUP),53);render(2);
        CHECK(proj.sound.v[T_303][NBASS+v][0]==3);
        engine_note_lock_capture(1);
        CHECK(engine_bass_note_capture(proj.arr.lane,0,v,11,&proj.sound)==0);
        int k=bass_note_find(proj.arr.lane,0,v,11);
        CHECK(k>=0 && !engine_bass_note_validate(&proj.arr.lane[k]));
        CHECK(!memcmp(proj.arr.lane[k].val+BASS_NOTE_USED,proj.sound.v[T_303][NBASS+v],S1_MASTER_EXT_SIZE));
        proj.arr.lane[k].used=0;engine_note_lock_capture(0);
    }
    for(unsigned v=0;v<2;++v){
        uint32_t before=data_hash(v),other=data_hash(1-v);
        event(v,60,110);render(24);CHECK(data_hash(v)!=before);
        if(v==0)CHECK(data_hash(1-v)==other);
        event(v,60,0);render(32);
    }
    engine_project_hold(1);project_capture_stage();CHECK(project_validate_stage()==0);
    CHECK(project_save()==0 && project_load_stage()==0);CHECK(!memcmp(&proj.sound,&project_stage.sound,sizeof proj.sound));engine_project_release();
    for(unsigned v=0;v<2;++v){
        select_bank(v,ORIGINAL_SOUND_MIAMI);supply[v]=v?0:2;
        memset(room_test_store[v].data,0xb9,sizeof room_test_store[v].data);
        select_bank(v,ORIGINAL_SOUND_SYNTHONE);
        CHECK(proj.sound.v[T_303][v][26]=='O');
        pref_set(PR(R_ENG,T_303,v,ORIGINAL_SYNTHONE_ROOM_MIX),117);
        uint32_t sentinel=data_hash(v);event(v,64,90);render(48);event(v,64,0);render(32);
        CHECK(sentinel==data_hash(v));CHECK(binds[v]>=2);
        select_bank(v,ORIGINAL_SOUND_MIAMI);supply[v]=1;select_bank(v,ORIGINAL_SOUND_SYNTHONE);
        for(unsigned j=0;j<7;++j)CHECK(room_test_store[v].before[j]==0xa7 && room_test_store[v].after[j]==0xc1);
    }
    printf("PASS %u checks. Ordinary two-owner pages and selector detents, independent histories, project save/load, undo/redo, recorder, historical spare rows, switches, absent/short allocations and canaries.\n",checks);
}
