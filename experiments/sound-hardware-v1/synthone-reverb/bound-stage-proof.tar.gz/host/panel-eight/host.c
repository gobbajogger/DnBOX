#include "s1_dry_part.c"
static s1_dry_part owner;
static uint8_t hist[S1_ROOM_EXTERNAL_BLOCKS*S1_ROOM_BLOCK_BYTES];
static float previous[2][5];
static unsigned ready;
int test_begin(void) {
    unsigned first=443*S1_ROOM_BLOCK_BYTES, second=623*S1_ROOM_BLOCK_BYTES;
    s1_room_buffer spans[]={{hist,first},{hist+first,second},{hist+first+second,sizeof hist-first-second}};
    return s1_room_bind(&owner.room,spans,3);
}
static unsigned nearest_position(const float *values,unsigned select)
{
    float best=1.e30f;unsigned found=0;
    for(unsigned q=0;q<=127;++q){
        float v=select==0 ? (float)q/127.f : select==1 ? (q<=64u ? (float)q/128.f : .5f+(float)(q-64u)/126.f) : room_highpass_hz(q);
        float d=fm_fabsf(v-*values);
        if(d<best){best=d;found=q;}
    }
    return found;
}
void test_configure(const float *factory)
{
    unsigned q[7]={(factory[37]>=.5f)?127u:0u,nearest_position(factory+40,0),nearest_position(factory+38,1),
            nearest_position(factory+39,2),(unsigned)(factory[51]*127.f/3.f+.5f),0,0};
    for(unsigned wet=0;wet<2;++wet){
        float v[5];for(unsigned j=0;j<5;++j)v[j]=factory[123+wet+3*j];
        if(v[0]<1)v[0]=1;if(v[4]<.5f)v[4]=.5f;
        const float (*table)[5]=wet?room_wet_presets:room_input_presets;
        unsigned count=wet?10:9,idx=0;
        while(idx<count && memcmp(table[idx],v,sizeof v))++idx;
        if(idx==count)__builtin_trap();q[5+wet]=(idx*127+(count-1)/2)/(count-1);
    }
    for(unsigned slot=0;slot<7;++slot){if(!s1_part_param(&owner,ORIGINAL_SYNTHONE_ROOM_ON+slot,(float)q[slot]/127.f))__builtin_trap();}
}
void test_room(const float *parameters,float l,float r,float env1,float env2,float *ol,float *or_,float *raw)
{
    (void)parameters;
    s1_room *s=&owner.room;
    s->highpass=pan_port(s->highpass,s->target_highpass);
    s->feedback=pan_port(s->feedback,s->target_feedback);
    s->on=pan_port(s->on,s->target_on);s->mix=pan_port(s->mix,s->target_mix);
    float mix=s->on*s->mix;
    if(s->route)mix*=s->route==1?env1:s->route==2?env2:.5f*(env1+env2);
    room_frame(&owner,l,r,s->highpass,s->feedback,mix,ol,or_,raw);
}
