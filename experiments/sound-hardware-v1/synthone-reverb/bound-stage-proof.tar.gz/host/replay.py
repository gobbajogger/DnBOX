import numpy as np
def spectrum(x):
    frames = np.lib.stride_tricks.sliding_window_view(x,512)[::128]
    return np.sqrt(np.mean(abs(np.fft.rfft(frames * np.hanning(512),axis=1))**2,axis=0))


def compare(reference, candidate):
    ref, trial = reference.astype(float), candidate.astype(float)
    ref_spectrum, trial_spectrum = spectrum(ref), spectrum(trial)
    floor = max(ref_spectrum.max()*1e-4, 1e-12)
    keep = (ref_spectrum>floor) | (trial_spectrum>floor)
    spectral = np.sqrt(np.mean((20*np.log10(np.maximum(trial_spectrum[keep],floor)/np.maximum(ref_spectrum[keep],floor)))**2)) if keep.any() else 0.
    rms = 10*np.log10(max(1e-20,np.mean(trial*trial)) / max(1e-20,np.mean(ref*ref)))
    return {'signed_rms_db':float(rms),'spectral_rms_db':float(spectral),'peak_error':float(np.abs(trial-ref).max()),'pass':bool(abs(rms)<=1.0 and spectral<=3.0)}


