import json,subprocess,sys,os
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import numpy as np
d=Path(__file__).resolve().parent
sys.path.insert(0,str(d.parent))
from replay import compare
build=Path(os.environ['FACTORY_BUILD']).resolve();data=build/'factory-inputs'
programs=json.loads((build/'commands/ORIGINAL-PRESET-COMMANDS.json').read_text())['cases']
indices=list(dict.fromkeys([308,309,339,361,362,384,386,456,459]+list(range(694))))
dest=d/'rows';dest.mkdir(exist_ok=True)
def run(idx):
 out=dest/f'{idx}.json'
 if out.exists():return
 tmp=dest/f'{idx}.f32'
 result=subprocess.run([d/'probe',data/'public-morphs.f32',data/'compact.bin',build/'commands/preset-commands.bin',str(idx),'/dev/stdout'],check=True,stdout=subprocess.PIPE)
 a=np.frombuffer(result.stdout,'<f4').reshape(-1,2,4);assert len(a)==132300 and np.isfinite(a).all()
 row=programs[idx]; vals=dict(row['commands'])
 result={'flat':idx,'bank':row['bank'],'name':row['name'],'original':{str(i):vals[i] for i in [37,38,39,40,51,123,126,129,132,135,124,127,130,133,136]},'scores':{label:compare(a[:,0,k],a[:,1,k]) for k,label in enumerate(['wet_l','wet_r','final_l','final_r'])}}
 out.write_text(json.dumps(result)+'\n')
 print(idx,flush=True)
with ThreadPoolExecutor(max_workers=4) as pool:
 for task in as_completed([pool.submit(run,i) for i in indices]):task.result()
