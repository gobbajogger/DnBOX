#!/bin/bash
set -e
r="${DNBX_REPO:?}";d="$PWD/owner-build";mkdir -p "$d";cd "$r"
u=$(python -c 'import tools.build as b;print(" ".join(["firmware/src/"+n for n in b.O2_UNITS if n!="dsp/bass303.c"]+["firmware/src/app/factory_banks.c"]+b.ORIGINAL_SYNTH_UNITS+b.ORIGINAL_SYNTH_BACKENDS))')
mkdir -p "$d/engine-objs"
flags=(-O1 -std=c99 -Wno-attributes -D_POSIX_C_SOURCE=200809L -D_DARWIN_C_SOURCE -DX0X_HOST -DX0X_ORIGINAL_SYNTH=1 -DX0X_DEV_WOBBLE=0 -DX0X_WOBBLE=0 -DORIGINAL_USE_SOFT_FMA -DMIAMI_FX_NO_HOST_FENV -fno-fast-math -ffp-contract=off -Ifirmware/src -Ifirmware/src/app -Ifirmware/src/dsp -Ibuild/gen -Iexperiments/original_synth -Iexperiments/wobble)
for path in $u; do
  obj="$d/engine-objs/$(echo "$path" | tr / _).o"
  [ -f "$obj" ] && [ "$obj" -nt "$path" ] && [ "$obj" -nt firmware/src/app/s1_reverb.h ] || cc "${flags[@]}" -c "$path" -o "$obj" || exit 1
done
cc "${flags[@]}" tests/host/synthone_reverb_owner_test.c "$d"/engine-objs/*.o -lm -o "$d/engine"
cd "$d"; ./engine
