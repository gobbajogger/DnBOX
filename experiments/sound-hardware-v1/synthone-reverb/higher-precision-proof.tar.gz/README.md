# Higher-precision full-rate reverb

All modes use the authentic AudioKit Synth One factory command stream and the full restored musical graph. Each program covers 132,300 original-rate frames. Every pre-reverb stereo sample is asserted identical. The two output comparisons distinguish the eight-line RevSC return and the final stereo mix following the original dynamics, motion and widening. Both channels must satisfy the existing unity-gain, 1 dB level and 3 dB spectral rule separately.

The literal adapter changes only the original delay-line reads and writes. The optimized source additionally uses one four-neighbour fetch, binary32 cubic arithmetic and the original Synth One Nyquist damping constant. These kernels have independent captures. The native isolated runs time forty 256-frame stereo blocks, without voices or the two stereo dynamics stages. Program-level hashes and per-channel numerical differences are under `receipts`.

Restore the factory source and build the host runner using the preceding reverb packet. In these examples `repo` is that restored checkout, `build` is the factory-build directory, `here` is this expanded packet and `out` is a writable directory. The native replay uses the pinned Jieli PI32v2 compiler and strict 360 MHz emulator from the full-rate receipt.

```sh
for mode in higher fast-host; do
    OPENBLAS_NUM_THREADS=1 python3 "$here/$mode/replay.py" "$repo" "$build" "$out/$mode"
    for band in full other; do
        OPENBLAS_NUM_THREADS=1 python3 "$here/$mode/sweep.py" "$build" "$out/$mode" "$out/$mode-$band" "$band"
    done
done
bash "$here/target/run.sh" "$repo" "$out/target"
bash "$here/additional-target/run.sh" "$repo" "$out/additional-target"
OPENBLAS_NUM_THREADS=1 python3 "$here/packed-match/check.py" "$repo" "$build" "$out/byte-exact"
for mode in capacity escape lpc7; do
    OPENBLAS_NUM_THREADS=1 python3 "$here/$mode/replay.py" "$repo" "$build" "$out/$mode"
done
```

The capacity case chooses the shortest signed-predictive Rice representation or raw original eight-bit codes for each 16-frame block. It records live compressed payload as physical ring slots are overwritten, including a one-byte representation for all-zero blocks. Extra indexes, codec state, allocator slack and native FX handles are excluded. The escape case stores full eight-bit codes when a fixed slice permits and falls back to five or six bits otherwise. In its inherited focused receipt the `block_4bit` label represents five-bit base and `block_5bit` six-bit base. The seven-pole model derives eight-bit reflection coefficients for each 128-sample input group and scales sixteen residuals at a time. These last three modes are targeted diagnostics.
