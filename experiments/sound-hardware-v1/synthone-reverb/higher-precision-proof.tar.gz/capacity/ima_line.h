/* A sixteen-sample block chooses its residual scale before publication; the
 * original four-point reader is thousands of frames behind the writer. */
#include <stdint.h>
#include <math.h>
#include <string.h>
extern int capture_bits;
enum { RBLOCK = 16 };
typedef struct { float previous, older; } prediction;
typedef struct { prediction w,r; float pending[RBLOCK], cache[4], read_scale; int last,cursor,valid; } s1_rev_ima_line;
static unsigned stride(void){ return 1+RBLOCK*(unsigned)capture_bits/8; }
static unsigned s1_rev_ima_bytes(unsigned samples){return (sizeof(s1_rev_ima_line)+((samples+RBLOCK-1)/RBLOCK)*stride()+1u+3u)&~3u;}
static float predicted(prediction s){return s.previous+.95f*(s.previous-s.older);}
static float advance(prediction* p,float delta){float y=predicted(*p)+delta;p->older=p->previous;p->previous=y;return y;}
static float scale_value(unsigned code){union{uint32_t u;float f;}x={(uint32_t)((code>>2)+64)<<23 | ((code&3u)<<21)};return x.f;}
static unsigned scale_code(float step){union{float f;uint32_t u;}x={step};int n=(int)((x.u+0x1fffffu)>>21)-64*4;return n<0?0u:n>255?255u:(unsigned)n;}
static int cp(const int8_t*q,unsigned n,unsigned mode){int a=n?q[n-1]:0,b=n>=2?q[n-2]:0,c=n>=3?q[n-3]:0;static const int cf[]={512,496,464,416,352,256,128,0};
 if(mode==0)return 0;if(mode==1)return a;if(mode==2)return 3*(a-b)+c;return (a*cf[mode-3])/256-b;}
static unsigned zig(int z){return z<0?(unsigned)(-2*z-1):(unsigned)(2*z);}
static struct {void *owner; unsigned live,max,space[280];} meter[8];
static unsigned tot,most,alllines; static unsigned long long counted,small[32];static unsigned last_c;
void capture_capacity(){unsigned per=0;for(int l=0;l<8;++l)per+=meter[l].max;
 printf("encoded8_rice_peak=%u partitioned_peak=%u last=%u blocks=%llu hist=",most,per,tot,counted);
 for(int i=0;i<32;++i)printf("%llu,",small[i]);putchar('\n');}
static void mark(sp_revsc_dl*line,const uint8_t*data,unsigned n){
 unsigned l=0;for(;l<8;++l){if(meter[l].owner==line)break;if(meter[l].owner==NULL){meter[l].owner=line;unsigned nb=((unsigned)line->bufferSize+15u)/16u;meter[l].live=meter[l].max=nb;tot+=nb;for(unsigned m=0;m<nb;++m)meter[l].space[m]=1;break;}}
 unsigned group=(unsigned)line->writePos/16u,limit=n+1u;const int8_t *q=(const int8_t*)data;int hit=0;for(unsigned i=0;i<n;++i)hit|=q[i];if(!hit)limit=1u;
 else for(unsigned mode=0;mode<11;++mode){unsigned v[16];for(unsigned i=0;i<n;++i)v[i]=zig((int8_t)((int)q[i]-cp(q,i,mode)));
   for(unsigned k=0;k<8;++k){unsigned bits=n*(1+k);for(unsigned i=0;i<n;++i)bits+=v[i]>>k;
     /* Scale plus mode/parameter; raw storage's special mode lives in its length. */
     unsigned sz=(bits+7u)/8u+2u;if(sz<limit)limit=sz;}}
 tot-=meter[l].space[group];meter[l].live-=meter[l].space[group];tot+=limit;meter[l].live+=limit;meter[l].space[group]=limit;
 if(meter[l].live>meter[l].max)meter[l].max=meter[l].live;if(tot>most)most=tot;++counted;++small[limit];
}

static void s1_rev_ima_write(sp_revsc_dl* line,float value,float unused) {
    (void)unused; s1_rev_ima_line *s=(s1_rev_ima_line*)line->buf;unsigned pos=(unsigned)line->writePos,within=pos%RBLOCK;
    s->pending[within]=value;
    if(within!=RBLOCK-1 && pos+1u!=(unsigned)line->bufferSize)return;
    unsigned bits=capture_bits,n=within+1u,limit=(1u<<(bits-1))-1u;
    uint8_t *block=(uint8_t*)(s+1)+(pos/RBLOCK)*stride(),*data=block+1;
    prediction ideal=s->w;float peak=0.f;
    for(unsigned j=0;j<n;++j){float sample=s->pending[j],error=sample-predicted(ideal);peak=fmaxf(peak,fabsf(error));ideal.older=ideal.previous;ideal.previous=sample;}
    block[0]=(uint8_t)scale_code(peak/(float)limit);float step=scale_value(block[0]),inv=1.f/step;
    for(unsigned j=0;j<n;++j){float d=(s->pending[j]-predicted(s->w))*inv;int q=d<0?(int)(d-.5f):(int)(d+.5f);q=q<-(int)limit?-(int)limit:q>(int)limit?(int)limit:q;
        unsigned code=q&(2*limit+1u),off=j*bits;uint8_t *dst=data+off/8u;unsigned shift=off&7u,mask=2*limit+1u,word=(unsigned)dst[0]|((unsigned)dst[1]<<8);
        word=(word&~(mask<<shift))|(code<<shift);dst[0]=(uint8_t)word;dst[1]=(uint8_t)(word>>8);advance(&s->w,(float)q*step);
    }
    if(capture_bits==8)mark(line,data,n);
}
static float s1_rev_ima_read(sp_revsc_dl* line,int pos,float unused) {
    (void)unused; s1_rev_ima_line *s=(s1_rev_ima_line*)line->buf;unsigned bits=capture_bits;
    int behind=s->last-pos;if(behind<0)behind+=line->bufferSize;if(behind<s->valid)return s->cache[(s->cursor-behind)&3];
    int next=s->valid?s->last+1:pos;
    for(;;){if(next==line->bufferSize)next=0;unsigned in=(unsigned)next%RBLOCK;
        const uint8_t *head=(const uint8_t*)(s+1)+((unsigned)next/RBLOCK)*stride();unsigned bit=in*bits;
        if(!in || !s->valid)s->read_scale=scale_value(head[0]);
        const uint8_t *p=head+1u+bit/8u;unsigned mask=(1u<<bits)-1u;int code=(((unsigned)p[0]|((unsigned)p[1]<<8))>>(bit&7u))&mask;
        if(code & (1u<<(bits-1)))code-=(int)(1u<<bits);
        s->cursor=(s->cursor+1)&3;s->cache[s->cursor]=advance(&s->r,code*s->read_scale);
        if(s->valid<4)++s->valid;s->last=next;if(next==pos)break;++next;
    }
    return s->cache[s->cursor];
}
