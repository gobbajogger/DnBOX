from pathlib import Path
import re
import shutil
from subprocess import check_output


def once(text,before,after):
    assert text.count(before)==1,before
    return text.replace(before,after)


def prepare(repo,out):
    fx=repo/'tests/fixtures/synthone-factory/fullfx'
    shutil.copyfile(repo/'firmware/src/dsp/ima_adpcm.h',out/'ima_adpcm.h')
    shutil.copyfile(Path(__file__).with_name('ima_line.h'),out/'ima_line.h')
    shutil.copyfile(Path(__file__).with_name('reverb.cpp'),out/'reverb.cpp')
    s=(fx/'upstream/AudioKit/Core/Soundpipe/modules/revsc.c').read_text().replace('sp_revsc_', 'sp_compact_').replace('sp_compact_dl','sp_revsc_dl')
    s=once(s,'#define DEFAULT_SRATE','#define X0X_IMA_TABLES_DEFINE\n#include "ima_line.h"\nfloat capture_scale=1.f; int capture_bits=4;\n#define DEFAULT_SRATE')
    s=once(s,'(delay_line_max_samples(sr, iPitchMod, n) * (int) sizeof(SPFLOAT))','(int)s1_rev_ima_bytes(delay_line_max_samples(sr,iPitchMod,n))')
    s=once(s,'sizeof(SPFLOAT) * lp->bufferSize','s1_rev_ima_bytes(lp->bufferSize)')
    s=once(s,'lp->buf[lp->writePos] = (SPFLOAT) ((n & 1 ? ainR : ainL)\n                                 - lp->filterState);','s1_rev_ima_write(lp,(n & 1 ? ainR : ainL)-lp->filterState,capture_scale);')
    s,n=re.subn(r'lp->buf\[(readPos(?: [+-] [12])?)\]',r's1_rev_ima_read(lp,\1,1.f/capture_scale)',s); assert n==8
    (out/'compact.c').write_text(s)
    s=(fx/'source_fx.hpp').read_text();(out/'capture_fx.hpp').write_text(once(s,'        sp_revsc_compute(sp, reverbCostello,','        measure_revsc(sp, reverbCostello,'))
