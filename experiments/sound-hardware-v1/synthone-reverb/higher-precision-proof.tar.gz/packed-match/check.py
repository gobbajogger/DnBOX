import json,subprocess,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from replay import prepare,compile_probe
repo,build,out=map(lambda x:Path(x).resolve(),sys.argv[1:4]);out.mkdir(exist_ok=True,parents=True)
prepare(repo,out);compile_probe(build,out)
stream=build/'commands/preset-commands.bin';pd=build/'factory-inputs'
results={}
def case(n):
 q=subprocess.run([out/'probe',pd/'public-morphs.f32',pd/'compact.bin',stream,str(n),'/dev/null'],check=True,stdout=subprocess.DEVNULL)
 return n
with ThreadPoolExecutor(max_workers=4) as pool:
 for f in as_completed([pool.submit(case,n) for n in range(694)]):
  n=f.result();results[n]=True;print(n,flush=True)
(out/'exact.json').write_text(json.dumps({'flat_indices':sorted(results),'stereo_frames_per_program':132300,'wet_and_final_float_bits_equal':True},indent=2)+'\n')
