static unsigned s1_rev_ima_bytes(unsigned n){return sizeof(float)*n;}
static void s1_rev_ima_write(sp_revsc_dl* lp,float v,float unused){(void)unused;lp->buf[lp->writePos]=v;}
static void s1_rev_read4(sp_revsc_dl* lp,int i,float* a,float*b,float*c,float*d){
 const float* ring=lp->buf;int n=lp->bufferSize;
 if(i>0&&i<n-2){*a=ring[i-1];*b=ring[i];*c=ring[i+1];*d=ring[i+2];}
 else {int j=i-1;if(j<0)j+=n;*a=ring[j];*b=ring[i];if(++i==n)i=0;*c=ring[i];if(++i==n)i=0;*d=ring[i];}
}
