#include <stdint.h>
#include "soundpipe.h"
#include "fm1_time.h"
extern int capture_bits;
int sp_compact_init(sp_data*,sp_revsc*);
int sp_compact_compute(sp_data*,sp_revsc*,float*,float*,float*,float*);
static sp_data ctx; static sp_revsc room; static uint32_t history[25000];
static float input[2][256], output[2][256];
static volatile uint32_t *const receipt=(volatile uint32_t*)0x01c07f00;
int sp_auxdata_alloc(sp_auxdata *aux,size_t bytes) { aux->ptr=history; aux->size=bytes; return bytes<=sizeof(history) ? SP_OK : SP_NOT_OK; }
void bench(void) {
    ctx.sr=44100;capture_bits=8;fm1_time_init();receipt[0]=0x54345256;
    sp_compact_init(&ctx,&room);receipt[1]=room.aux.size;room.feedback=.835f; room.lpfreq=22050.f;
    uint32_t checksum=0; uint32_t seed=123;float l=0.f,r=0.f;
    for(unsigned block=0;block<40;++block){
        for(unsigned i=0;i<256;++i){seed=1664525*seed+1013904223u;l+=.07f*((float)(int)(seed>>16)/32768.f-1.f-l);seed=1664525*seed+1013904223u;r+=.11f*((float)(int)(seed>>16)/32768.f-1.f-r);input[0][i]=l;input[1][i]=r;}
        uint32_t t=fm1_ticks();
        for(unsigned i=0;i<256;++i)sp_compact_compute(&ctx,&room,&input[0][i],&input[1][i],&output[0][i],&output[1][i]);
        receipt[4+block]=fm1_ticks()-t;
        for(unsigned ch=0;ch<2;++ch)for(unsigned i=0;i<256;++i){union{float f;uint32_t u;}v={output[ch][i]};checksum=(checksum^v.u)*16777619u;}
        receipt[2]=block+1;receipt[3]=checksum;
    }
    for(;;)__asm__ volatile("nop");
}
