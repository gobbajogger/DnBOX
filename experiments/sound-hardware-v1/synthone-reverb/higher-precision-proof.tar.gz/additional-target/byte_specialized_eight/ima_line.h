/* A sixteen-sample block chooses its residual scale before publication; the
 * original four-point reader is thousands of frames behind the writer. */
#include <stdint.h>
#include <math.h>
#include <string.h>
#define BITS 8
enum { RBLOCK = 16 };
typedef struct { float previous, older; } prediction;
typedef struct { prediction w,r; float pending[RBLOCK], cache[4], read_scale; int last,cursor,valid; } s1_rev_ima_line;
static unsigned stride(void){ return 1+RBLOCK*(unsigned)BITS/8; }
static unsigned s1_rev_ima_bytes(unsigned samples){return (sizeof(s1_rev_ima_line)+((samples+RBLOCK-1)/RBLOCK)*stride()+1u+3u)&~3u;}
static float predicted(prediction s){return s.previous+.95f*(s.previous-s.older);}
static float advance(prediction* p,float delta){float y=predicted(*p)+delta;p->older=p->previous;p->previous=y;return y;}
static float scale_value(unsigned code){union{uint32_t u;float f;}x={(uint32_t)((code>>2)+64)<<23 | ((code&3u)<<21)};return x.f;}
static unsigned scale_code(float step){union{float f;uint32_t u;}x={step};int n=(int)((x.u+0x1fffffu)>>21)-64*4;return n<0?0u:n>255?255u:(unsigned)n;}
static float reciprocal_scale(unsigned code){
    union{uint32_t u;float f;}x;
    static const uint32_t raw[4]={0,0x4ccccd,0x2aaaab,0x124925};
    unsigned f=code&3u; x.u=(uint32_t)(190-(code>>2)-(f!=0))<<23 | raw[f];return x.f;
}
static void s1_rev_ima_write(sp_revsc_dl* line,float value,float unused) {
    (void)unused;s1_rev_ima_line* s=(s1_rev_ima_line*)line->buf;unsigned pos=(unsigned)line->writePos,j=pos&15u;
    s->pending[j]=value;if(j!=15u && pos+1u!=(unsigned)line->bufferSize)return;
    prediction w=s->w;float older=w.older,previous=w.previous,peak=0.f;
    for(unsigned i=0;i<=j;++i){float x=s->pending[i];float d=fabsf(x-(previous+.95f*(previous-older)));if(d>peak)peak=d;older=previous;previous=x;}
    uint8_t* d=(uint8_t*)(s+1)+(pos>>4)*17u;unsigned sc=scale_code(peak/127.f);*d++=(uint8_t)sc;float amp=scale_value(sc),inv=reciprocal_scale(sc);
    for(unsigned i=0;i<=j;++i){float p=predicted(w),relative=(s->pending[i]-p)*inv;union{float f;uint32_t u;}v={relative},rnd={.5f};rnd.u|=v.u&0x80000000u;
        int q=(int)(relative+rnd.f);q=q< -127?-127:q>127?127:q;d[i]=(uint8_t)q;w.older=w.previous;w.previous=p+(float)q*amp;}
    s->w=w;
}
static void s1_rev_read4(sp_revsc_dl* line,int centre,float* xm,float* x0,float* x1,float* x2) {
    s1_rev_ima_line* s=(s1_rev_ima_line*)line->buf;int newest=centre+2;if(newest>=line->bufferSize)newest-=line->bufferSize;
    int next=s->last+1;if(!s->valid){next=centre-1;if(next<0)next+=line->bufferSize;s->valid=1;}
    else if(newest==s->last)goto done;
    for(;;){if(next==line->bufferSize)next=0;unsigned i=(unsigned)next;const uint8_t* d=(const uint8_t*)(s+1)+i+(i>>4);
       if(!(i&15u) || s->read_scale==0.f)s->read_scale=scale_value(d[-(int)(i&15u)]);
       int q=(int8_t)d[1];float sample=advance(&s->r,(float)q*s->read_scale);
       s->cache[0]=s->cache[1];s->cache[1]=s->cache[2];s->cache[2]=s->cache[3];s->cache[3]=sample;
       if(next==newest)break;++next;
    }
    s->last=newest;
done: *xm=s->cache[0];*x0=s->cache[1];*x1=s->cache[2];*x2=s->cache[3];
}
