#include <stdint.h>
#include <math.h>
#include <string.h>
extern int capture_bits;
enum { RBLOCK=16 };
typedef struct {float previous,older;} H;
typedef struct {H w,r;float pending[16],cache[4],read_scale;int last,cursor,valid;int8_t codes[16];} L;
static unsigned bits(void){return (unsigned)capture_bits+1u;}
static unsigned stride(void){return 2u+2u*bits();}
static unsigned s1_rev_ima_bytes(unsigned n){return (sizeof(L)+((n+15)/16)*stride()+1u+3u)&~3u;}
static float val(unsigned code){union{uint32_t u;float f;}x={(uint32_t)((code>>2)+64)<<23 | ((code&3u)<<21)};return x.f;}
static unsigned ep(float f){union{float f;uint32_t u;}x={f};int n=(int)((x.u+0x1fffffu)>>21)-64*4;return n<0?0u:n>255?255u:(unsigned)n;}
static float pred(H s){return s.previous+.95f*(s.previous-s.older);}
static float step(H*p,float delta){float y=pred(*p)+delta;p->older=p->previous;p->previous=y;return y;}
static int qround(float d,int lim){int q=d<0.f?(int)(d-.5f):(int)(d+.5f);return q< -lim? -lim:q>lim?lim:q;}
static unsigned encode(const float*x,unsigned n,H* h,float peak,unsigned b,int8_t* code){int lim=(1u<<(b-1))-1u;unsigned exp=ep(peak/(float)lim);float s=val(exp),inv=1.f/s;
 for(unsigned i=0;i<n;++i){int q=qround((x[i]-pred(*h))*inv,lim);step(h,q*s);code[i]=(int8_t)q;}return exp;}
static int cp(const int8_t*q,unsigned n,unsigned mode){int a=n?q[n-1]:0,b=n>=2?q[n-2]:0,c=n>=3?q[n-3]:0;static const int cf[]={512,496,464,416,352,256,128,0};
 if(mode==0)return 0;if(mode==1)return a;if(mode==2)return 3*(a-b)+c;return (a*cf[mode-3])/256-b;}
static unsigned zig(int z){return z<0?(unsigned)(-2*z-1):(unsigned)(2*z);}
static unsigned wrbit(uint8_t*p,unsigned o,unsigned x){p[o/8]|=(uint8_t)((x&1u)<<(o&7));return o+1;}
static unsigned rdbit(const uint8_t*p,unsigned*o){unsigned i=(*o)++;return (p[i/8]>>(i&7))&1u;}
static unsigned pack(uint8_t*d,const int8_t*q,unsigned n,unsigned cap){unsigned mind=cap+1,best=0;
 for(unsigned mode=0;mode<11;++mode){unsigned z[16];for(unsigned i=0;i<n;++i)z[i]=zig((int8_t)((int)q[i]-cp(q,i,mode)));
  for(unsigned k=0;k<8;++k){unsigned cost=n*(1+k);for(unsigned i=0;i<n;++i)cost+=z[i]>>k;if(cost<mind){mind=cost;best=1+8*mode+k;}}}
 if(mind>cap)return 0;memset(d,0,cap/8);unsigned k=(best-1)%8,mode=(best-1)/8,o=0;
 for(unsigned i=0;i<n;++i){unsigned z=zig((int8_t)((int)q[i]-cp(q,i,mode)));unsigned run=z>>k;while(run--)o=wrbit(d,o,0);o=wrbit(d,o,1);for(unsigned b=0;b<k;++b)o=wrbit(d,o,z>>b);}
 return best;
}
static unsigned long long esc_count,all_count;
static void s1_rev_ima_write(sp_revsc_dl* line,float value,float ignored){(void)ignored;L*s=(L*)line->buf;unsigned pos=line->writePos,n=pos%16+1;s->pending[n-1]=value;if(n!=16&&pos+1u!=(unsigned)line->bufferSize)return;
 H raw=s->w,selected=s->w;float peak=0.f;for(unsigned j=0;j<n;++j){float x=s->pending[j];peak=fmaxf(peak,fabsf(x-pred(raw)));raw.older=raw.previous;raw.previous=x;}
 int8_t code[16];unsigned exp=encode(s->pending,n,&selected,peak,8,code);uint8_t*d=(uint8_t*)(s+1)+(pos/16)*stride();
 unsigned mode=pack(d+2,code,n,16*bits());++all_count;if(mode)++esc_count;
 if(!mode){selected=s->w;exp=encode(s->pending,n,&selected,peak,bits(),code);memset(d+2,0,2*bits());unsigned o=0;for(unsigned i=0;i<n;++i)for(unsigned b=0;b<bits();++b)o=wrbit(d+2,o,((uint8_t)code[i])>>b);}
 d[0]=exp;d[1]=mode;s->w=selected;
}
static void unpack(const uint8_t*d,int8_t*code,unsigned n){unsigned b=bits(),o=0;if(!d[1]){for(unsigned j=0;j<n;++j){unsigned u=0;for(unsigned k=0;k<b;++k)u|=rdbit(d+2,&o)<<k;code[j]=(int8_t)((int)(u^ (1u<<(b-1)))-(int)(1u<<(b-1)));}return;}
 unsigned mode=(d[1]-1)/8,k=(d[1]-1)%8;for(unsigned j=0;j<n;++j){unsigned run=0;while(!rdbit(d+2,&o))++run;unsigned z=run<<k;for(unsigned i=0;i<k;++i)z|=rdbit(d+2,&o)<<i;int diff=(z&1u)?-(int)((z+1)/2):(int)(z/2);code[j]=(int8_t)(cp(code,j,mode)+diff);}
}
static float s1_rev_ima_read(sp_revsc_dl*line,int pos,float ignored){(void)ignored;L*s=(L*)line->buf;int behind=s->last-pos;if(behind<0)behind+=line->bufferSize;if(behind<s->valid)return s->cache[(s->cursor-behind)&3];
 int next=s->valid?s->last+1:pos;for(;;){if(next==line->bufferSize)next=0;unsigned in=(unsigned)next%16,block=(unsigned)next/16;const uint8_t*d=(const uint8_t*)(s+1)+block*stride();if(!in||!s->valid){unsigned n=(unsigned)line->bufferSize-block*16;if(n>16)n=16;s->read_scale=val(d[0]);unpack(d,s->codes,n);}
 s->cursor=(s->cursor+1)&3;s->cache[s->cursor]=step(&s->r,s->codes[in]*s->read_scale);if(s->valid<4)++s->valid;s->last=next;if(next==pos)break;++next;}
 return s->cache[s->cursor];
}
