from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib, json, sys, subprocess
from pathlib import Path
import numpy as np
from replay import compare

build,tools,out=(Path(s).resolve() for s in sys.argv[1:4]);out.mkdir(exist_ok=True,parents=True)
rows=json.loads((build/'commands/ORIGINAL-PRESET-COMMANDS.json').read_text())['cases']
which=sys.argv[4];targets=[]
for ix,v in enumerate(rows):
    c=dict(v['commands']);mix=c[37]*c[40]
    if which=='full' and mix==1. or which=='other' and mix!=1.: targets.append(ix)

def run(ix):
    target=out/f'{ix}.json'
    if target.is_file(): return ix,json.loads(target.read_text())
    f=out/f'{ix}.f32';inp=build/'factory-inputs'
    subprocess.run([tools/'probe',inp/'public-morphs.f32',inp/'compact.bin',build/'commands/preset-commands.bin',str(ix),f],check=True,stdout=subprocess.DEVNULL)
    a=np.fromfile(f,dtype='<f4').reshape(-1,3,4); assert np.isfinite(a).all() and len(a)==132300
    ref_hash=hashlib.sha256(a[:,0,:].tobytes()).hexdigest();cand_hash=hashlib.sha256(a[:,1,:].tobytes()).hexdigest();f.unlink()
    j={'index':ix,'bank':rows[ix]['bank'],'position':rows[ix]['preset_index'],'name':rows[ix]['name'],'original_sha256':ref_hash,'candidate_sha256':cand_hash,'frames':len(a),'modes':{str(bits):{key:compare(a[:,0,k],a[:,mode,k]) for k,key in enumerate(['wet_left','wet_right','final_left','final_right'])} for mode,bits in [(1,4),(2,5)]}}
    target.write_text(json.dumps(j)+'\n');return ix,j
with ThreadPoolExecutor(max_workers=2) as pool:
    for f in as_completed([pool.submit(run,ix) for ix in targets]):
        ix,j=f.result();print(ix,j['name'],[all(v['pass'] for k,v in a.items() if k.startswith('final')) for a in j['modes'].values()],flush=True)
