#include <stdint.h>
#include <math.h>
#include <string.h>
extern int capture_bits;
enum { ORDER=7, GROUP=128, SUB=16 };
typedef struct {float x[ORDER];} H;
typedef struct {H w,r;float pending[GROUP], rcoef[ORDER],sample[4],rscale;int last,cursor,valid;} L;
static unsigned substride(void){return 1u+SUB*(unsigned)capture_bits/8;}
static unsigned stride(void){return ORDER+(GROUP/SUB)*substride();}
static unsigned s1_rev_ima_bytes(unsigned n){return (sizeof(L)+((n+GROUP-1)/GROUP)*stride()+1u+3u)&~3u;}
static float val(unsigned code){union{uint32_t u;float f;}x={(uint32_t)((code>>2)+64)<<23 | ((code&3u)<<21)};return x.f;}
static unsigned expcode(float f){union{float f;uint32_t u;}x={f};int n=(int)((x.u+0x1fffffu)>>21)-64*4;return n<0?0u:n>255?255u:(unsigned)n;}
static float predict(const H*h,const float*c){float a=0.f;for(int i=0;i<ORDER;++i)a-=h->x[i]*c[i];return a;}
static void remember(H*h,float x){for(int k=ORDER-1;k>0;--k)h->x[k]=h->x[k-1];h->x[0]=x;}
static int roundlim(float q,int l){int z=q<0.f?(int)(q-.5f):(int)(q+.5f);return z< -l? -l:z>l?l:z;}
static void stepup(float* a,int n,float k){float old[ORDER];for(int i=0;i<n;++i)old[i]=a[i];for(int i=0;i<n;++i)a[i]=old[i]+k*old[n-1-i];a[n]=k;}
static void model(const float*x,int n,uint8_t* encoded,float*c){
 float f[GROUP],b[GROUP];memcpy(f,x,(size_t)n*sizeof(float));memcpy(b,x,(size_t)n*sizeof(float));
 for(int m=0;m<ORDER;++m){float e=0.f,v=0.f;for(int i=m+1;i<n;++i){e+=f[i]*b[i-1];v+=f[i]*f[i]+b[i-1]*b[i-1];}
    float k=v>1.e-33f ? -2.f*e/v : 0.f;
    int code=roundlim(k*128.f,m<2?124:95);encoded[m]=(uint8_t)(int8_t)code;k=(float)code*(1.f/128.f);
    for(int i=n-1;i>=m+1;--i){float z=f[i];f[i]+=k*b[i-1];b[i]=b[i-1]+k*z;}
    stepup(c,m,k);
 }
}
static void taper(float*c){float b=.94f;for(int j=0;j<ORDER;++j){c[j]*=b;b*=.94f;}}
static void put(uint8_t* d,unsigned j,unsigned bits,int v){unsigned off=j*bits,bit=off&7u;d+=off/8;unsigned m=(1u<<bits)-1u;unsigned w=(unsigned)d[0]|((unsigned)d[1]<<8);w=(w&~(m<<bit))|(((unsigned)v&m)<<bit);d[0]=(uint8_t)w;d[1]=(uint8_t)(w>>8);}
static int get(const uint8_t*d,unsigned j,unsigned bits){unsigned o=j*bits;d+=o/8;unsigned v=(((unsigned)d[0]|((unsigned)d[1]<<8))>>(o&7))&((1u<<bits)-1u);return (v&(1u<<(bits-1)))?(int)v-(int)(1u<<bits):(int)v;}
static void s1_rev_ima_write(sp_revsc_dl* line,float value,float ignored){
 (void)ignored;L*s=(L*)line->buf;unsigned pos=line->writePos,n=pos%GROUP+1u;s->pending[n-1]=value;if(n!=GROUP&&pos+1u!=(unsigned)line->bufferSize)return;
 uint8_t*d=(uint8_t*)(s+1)+(pos/GROUP)*stride();float c[ORDER]={};model(s->pending,n,d,c);taper(c);
 unsigned bits=capture_bits,limit=(1u<<(bits-1))-1u;for(unsigned beg=0;beg<n;beg+=SUB){unsigned end=beg+SUB;if(end>n)end=n;H h=s->w;float peak=0.f;
    for(unsigned j=beg;j<end;++j){float x=s->pending[j];peak=fmaxf(peak,fabsf(x-predict(&h,c)));remember(&h,x);}
    uint8_t* q=d+ORDER+(beg/SUB)*substride();q[0]=expcode(peak/(float)limit);H start=s->w;unsigned tries=0;
    for(;;){float amp=val(q[0]),inv=1.f/amp;unsigned clipped=0;s->w=start;
      for(unsigned j=beg;j<end;++j){float p=predict(&s->w,c),err=(s->pending[j]-p)*inv;
        clipped|=fabsf(err)>(float)limit+.5f;int code=roundlim(err,(int)limit);put(q+1,j-beg,bits,code);remember(&s->w,p+code*amp);}
      if(!clipped||q[0]==255||++tries==16)break; ++q[0];
    }
 }
}
static float s1_rev_ima_read(sp_revsc_dl*line,int pos,float ignored){
 (void)ignored;L*s=(L*)line->buf;int behind=s->last-pos;if(behind<0)behind+=line->bufferSize;if(behind<s->valid)return s->sample[(s->cursor-behind)&3];
 int next=s->valid?s->last+1:pos;
 for(;;){if(next==line->bufferSize)next=0;unsigned in=(unsigned)next%GROUP;const uint8_t*d=(const uint8_t*)(s+1)+((unsigned)next/GROUP)*stride();
  if(!in||!s->valid){for(int m=0;m<ORDER;++m)stepup(s->rcoef,m,(float)(int8_t)d[m]*(1.f/128.f));taper(s->rcoef);}
  d+=ORDER+(in/SUB)*substride();if(in%SUB==0||!s->valid)s->rscale=val(d[0]);
  float sample=predict(&s->r,s->rcoef)+s->rscale*get(d+1,in%SUB,capture_bits);remember(&s->r,sample);
  s->cursor=(s->cursor+1)&3;s->sample[s->cursor]=sample;if(s->valid<4)++s->valid;s->last=next;if(next==pos)break;++next;
 }return s->sample[s->cursor];
}
