# Nine- and ten-bit original reverb return comparisons

Each complete original program runs through the same two independently restored source graphs and finite-control note schedule as the full-rate and higher-precision receipts. Every stereo input to RevSC must match. The coded history keeps the full 44.1 kHz time base, original eight circular lengths and original interpolator. In this trial the sixteen-sample residuals occupy nine or ten bits. A three-byte load covers a packed code that crosses a sixteen-bit boundary. The bytes after each line permit the last such access.

The per-program gzip records both the final stereo output and the original-input module's wet return, including its level and spectrum. `candidate_sha256` hashes nine-bit wet and final channels, `tenbit_sha256` hashes all four ten-bit channels, and `original_sha256` hashes the four original channels. The native isolated test uses deterministic inputs, fixed feedback and 40 guest TIMER4 measurements per variant. The literal source-form calculations are the ones exercised across the full musical corpus. The optimized kernels also combine the four lookups and use binary32 cubic arithmetic. Each receives its own component timing and sound checksum.

Restore the pinned factory harness from the parent reverb README. With its checkout in `repo`, its host build in `build`, this packet in `here`, and a new writable directory in `out`, run

```sh
OPENBLAS_NUM_THREADS=1 python3 "$here/host/replay.py" "$repo" "$build" "$out/host"
for group in full other; do
    OPENBLAS_NUM_THREADS=1 python3 "$here/host/sweep.py" "$build" "$out/host" "$out/$group" "$group"
done
# Set JIELI_TOOLCHAIN and FM1_LIVE to the versions in the higher-precision receipt.
bash "$here/target/run.sh" "$repo" "$out/target"
```
