/* A sixteen-sample block chooses its residual scale before publication; the
 * original four-point reader is thousands of frames behind the writer. */
#include <stdint.h>
#include <math.h>
#include <string.h>
#define BITS 5
enum { RBLOCK = 16 };
typedef struct { float previous, older; } prediction;
typedef struct { prediction w,r; float pending[RBLOCK], cache[4], read_scale; int last,cursor,valid; } s1_rev_ima_line;
static unsigned stride(void){ return 1+RBLOCK*(unsigned)BITS/8; }
static unsigned s1_rev_ima_bytes(unsigned samples){return (sizeof(s1_rev_ima_line)+((samples+RBLOCK-1)/RBLOCK)*stride()+1u+3u)&~3u;}
static float predicted(prediction s){return s.previous+.95f*(s.previous-s.older);}
static float advance(prediction* p,float delta){float y=predicted(*p)+delta;p->older=p->previous;p->previous=y;return y;}
static float scale_value(unsigned code){union{uint32_t u;float f;}x={(uint32_t)((code>>2)+64)<<23 | ((code&3u)<<21)};return x.f;}
static unsigned scale_code(float step){union{float f;uint32_t u;}x={step};int n=(int)((x.u+0x1fffffu)>>21)-64*4;return n<0?0u:n>255?255u:(unsigned)n;}
static void s1_rev_ima_write(sp_revsc_dl* line,float value,float unused) {
    (void)unused; s1_rev_ima_line *s=(s1_rev_ima_line*)line->buf;unsigned pos=(unsigned)line->writePos,within=pos%RBLOCK;
    s->pending[within]=value;
    if(within!=RBLOCK-1 && pos+1u!=(unsigned)line->bufferSize)return;
    unsigned bits=BITS,n=within+1u,limit=(1u<<(bits-1))-1u;
    uint8_t *block=(uint8_t*)(s+1)+(pos/RBLOCK)*stride(),*data=block+1;
    prediction ideal=s->w;float peak=0.f;
    for(unsigned j=0;j<n;++j){float sample=s->pending[j],error=sample-predicted(ideal);peak=fmaxf(peak,fabsf(error));ideal.older=ideal.previous;ideal.previous=sample;}
    block[0]=(uint8_t)scale_code(peak/(float)limit);float step=scale_value(block[0]),inv=1.f/step;
    for(unsigned j=0;j<n;++j){float d=(s->pending[j]-predicted(s->w))*inv;int q=d<0?(int)(d-.5f):(int)(d+.5f);q=q<-(int)limit?-(int)limit:q>(int)limit?(int)limit:q;
        unsigned code=q&(2*limit+1u),off=j*bits;uint8_t *dst=data+off/8u;unsigned shift=off&7u,mask=2*limit+1u,word=(unsigned)dst[0]|((unsigned)dst[1]<<8);
        word=(word&~(mask<<shift))|(code<<shift);dst[0]=(uint8_t)word;dst[1]=(uint8_t)(word>>8);advance(&s->w,(float)q*step);
    }
}
static void s1_rev_read4(sp_revsc_dl* line,int centre,float* xm,float* x0,float* x1,float* x2) {
    s1_rev_ima_line* s=(s1_rev_ima_line*)line->buf;
    int newest=centre+2; if(newest>=line->bufferSize)newest-=line->bufferSize;
    int next=s->last+1;
    if(!s->valid){next=centre-1; if(next<0)next+=line->bufferSize; s->valid=1;} 
    else if(newest==s->last)goto complete;
    for(;;){
        if(next==line->bufferSize)next=0;
        unsigned in=(unsigned)next%RBLOCK;
        const uint8_t* head=(const uint8_t*)(s+1)+((unsigned)next/RBLOCK)*stride();
        unsigned bit=in*BITS;
        if(!in || s->read_scale==0.f)s->read_scale=scale_value(head[0]);
        const uint8_t* p=head+1u+bit/8u;
        unsigned word=(unsigned)p[0]|((unsigned)p[1]<<8);
        int code=(int)((word>>(bit&7u))&31u);if(code&16)code-=32;
        s->cursor=(s->cursor+1)&3;
        s->cache[s->cursor]=advance(&s->r,code*s->read_scale);
        if(next==newest)break;++next;
    }
    s->last=newest;
complete:
    *xm=s->cache[(s->cursor-3)&3];*x0=s->cache[(s->cursor-2)&3];
    *x1=s->cache[(s->cursor-1)&3];*x2=s->cache[s->cursor];
}
