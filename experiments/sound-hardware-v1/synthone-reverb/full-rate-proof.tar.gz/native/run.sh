#!/bin/bash
# Run from any directory after the block replay has generated compact.c.
set -eu
here=$(cd "$(dirname "$0")" && pwd)
repo=$(realpath "$1"); generated=$(realpath "$2"); out=$(realpath -m "$3")
tc="$JIELI_TOOLCHAIN/pi32v2";sp="$repo/firmware/src/dsp/synthone/experiment/audiokit-4.9.2/AudioKit/Core/Soundpipe"
mkdir -p "$out"; flags=(-target pi32v2 -mcpu=r3 -mfprev1 -O2 -fno-fast-math -ffp-contract=off -ffunction-sections -fdata-sections -idirafter "$tc/include" -I"$repo/firmware/hal" -I"$sp" -I"$sp/lib/dr_wav" -DNO_LIBSNDFILE)
for variant in literal fast; do
    d="$out/$variant";mkdir -p "$d/work";cd "$d";export TMPDIR="$d"
    if [ "$variant" = literal ]; then
        sed 's/float capture_scale=1.f; int capture_bits=4;/float capture_scale; int capture_bits;/' "$generated/compact.c" >compact.c
        cp "$generated/ima_line.h" .
    else cp "$here/compact.c" "$here/ima_line.h" .; fi
    "$tc/bin/clang" "${flags[@]}" -c "$here/start.S" -o start.o
    "$tc/bin/clang" "${flags[@]}" -c "$here/driver.c" -o driver.o
    "$tc/bin/clang" "${flags[@]}" -c compact.c -o core.o
    "$tc/bin/ld" --gc-sections -e _start -T "$here/native.ld" -o probe.elf start.o driver.o core.o --start-group "$tc/lib/r3/libc.a" "$tc/lib/r3/libm.a" "$tc/lib/r3/libcompiler-rt.a" --end-group
    "$tc/bin/objcopy" -O binary -j .text probe.elf probe.bin
    FM1_STRICT=1 FM1_DUMPRAM="$d/ram.bin" "$FM1_LIVE" --bin probe.bin --entry 02000000 --mhz 360 --shot 500 --lcd-only
    python3 - <<'PY'
import struct
from pathlib import Path
v=struct.unpack_from('<44I',Path('ram.bin').read_bytes(),0x7f00)
assert v[0]==0x54345256 and v[1]==17944 and v[2]==40
print('checksum',v[3],'TIMER4 ticks',v[4:])
PY
done
