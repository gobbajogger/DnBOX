# Full-rate Synth One reverb comparisons

The five-bit predictive block representation passed both final channels for 690 of 694 fully restored original factory programs, including all 34 programs whose reverb is on at full mix. Its 17,944-byte per-owner allocation contains the ring payloads, encoder pending blocks and the sequential decoder's four-sample windows. The original eight-line structure requires another 364 bytes per owner. Input and wet stereo dynamics, filters and control storage are additional. The four-bit version used 14,848 bytes and passed 682 complete final stereo comparisons. These counts measure substituting a reverb module into the genuine host graph. Both designs remain experimental.

For every factory record, the actual ordered setters, original note scheduler, oscillator, filter and complete preceding effects rendered the same musical stimulus for three seconds at 44,100 Hz. Original, four-bit and five-bit graphs checked incoming left and right words at every RevSC frame. Independent post-reverb dynamics, wet mix, LFO routes, master and width produced the final stereo outputs. The scoring used the parent reverb packet's 1 dB level and 3 dB spectral contract at unity, 512-point FFTs, 128-frame hops and a −80 dB amplitude floor. The per-program file identifies original capture hashes over four channels (wet return and final stereo). It also records all eight numerical comparisons for each bitrate. The measured 694-program audio totals 91,816,200 stereo frames per graph.

Each original full-rate circular line stores 16-frame blocks. The peak second-order prediction residual sets the step shared by a block. Packed signed codes drive the same predictor in the reader and the writer. The 44.1 kHz modulation, wrap, fractional positions, cubic interpolation, coupling and filters remain active. The independent checked build stores an additional full-precision shadow array of the encoder's reconstruction and asserts exact agreement at every neighbour access. All twelve focused three-second comparisons completed, including wrap and modulation.

## Native component measurement

A freestanding PI32v2 R3 image ran 40 consecutive blocks of 256 stereo frames in the strict 360 MHz emulator. The guest timed only the reverb call loop using TIMER4 at 24 MHz. Deterministic nonzero input and a feedback setting of 0.835 were applied. The original-form calculation with the compressed reader took about 7.4 ms per 256 frames. The fixed five-bit implementation uses one four-neighbour load, the constant Nyquist damping value and binary32 cubic arithmetic. It took about 3.0 ms for the same block length. `receipts/native.json` includes every time, hash and result checksum. The fast image produced a different output hash and has no separate 694-program scoring result. The measurement excludes both compressors, high-pass filters, voices and the other populated instruments.

## Replay

First restore the pinned factory harness as described in `experiments/sound-hardware-v1/synthone-reverb/README.md`. The commands below use the repository root in `repo`, its factory build in `build`, a new writable output directory in `out`, and this packet in `here`. The checked and native comparisons use the same UI-independent source adapter. The C symbols containing `ima` in the experimental header are inherited fixture names. This block codec uses a per-block scale and a second-order predictor.

```sh
OPENBLAS_NUM_THREADS=1 python3 "$here/block/replay.py" "$repo" "$build" "$out/blocks"
OPENBLAS_NUM_THREADS=1 python3 "$here/block/sweep.py" "$build" "$out/blocks" "$out/full" full
OPENBLAS_NUM_THREADS=1 python3 "$here/block/sweep.py" "$build" "$out/blocks" "$out/other" other
cp -r "$here/block" "$out/checked-code"
cp "$here/checked/ima_line.h" "$out/checked-code/ima_line.h"
OPENBLAS_NUM_THREADS=1 python3 "$out/checked-code/replay.py" "$repo" "$build" "$out/checked"
# Set JIELI_TOOLCHAIN and FM1_LIVE to the matching native compiler and strict emulator.
bash "$here/native/run.sh" "$repo" "$out/blocks" "$out/native"
```
