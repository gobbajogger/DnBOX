/* SPDX-License-Identifier: GPL-3.0-only */
/* 44.1 kHz Soundpipe/Csound RevSC topology (Sean Costello and Istvan Varga).
 * The 16-frame signed residual representation has an independent owner and
 * preserves each modulated line's four original interpolation neighbours. */
static const struct {
    uint16_t samples,first_block,nominal,seed;
    float variation,speed;
} room_geometry[S1_ROOM_LINES]={
    {2539,0,2473,1966,.0010f,3.100f}, {2838,159,2767,29491,.0011f,3.500f},
    {3317,337,3217,22937,.0017f,1.110f}, {3603,545,3557,9830,.0006f,3.973f},
    {3973,771,3907,20643,.0010f,2.341f}, {4198,1020,4127,22937,.0011f,1.897f},
    {2243,1283,2143,29491,.0017f,.891f}, {1979,1424,1933,14417,.0006f,3.221f}
};
#define ROOM_FRAC (UINT32_C(1)<<28)
static float room_delay(unsigned n,int seed)
{
    return room_geometry[n].nominal/44100.f+(float)seed*room_geometry[n].variation/32768.f;
}
/* Source expressions round a positive float with a double 0.5 literal.
 * Testing the fractional part also avoids a software double helper on R3. */
static unsigned room_round(float value)
{
    unsigned whole=(unsigned)value;
    return whole+(value-(float)whole>=.5f);
}
static void room_next(s1_room_line *line,unsigned n)
{
    line->seed=(int16_t)((uint16_t)line->seed*15625u+1u);
    line->remaining=room_round(44100.f/room_geometry[n].speed);
    float previous=(float)line->write-((float)line->read+(float)line->fraction/(float)ROOM_FRAC);
    if(previous<0.f) previous+=(float)room_geometry[n].samples;
    float next=room_delay(n,line->seed);
    float phase=(previous/44100.f-next)/(float)line->remaining;
    phase=phase*44100.f+1.f;
    line->increment=room_round(phase*(float)ROOM_FRAC);
}
void s1_room_clear(s1_room *room)
{
    room->active_frames=0;
    memset(room->line,0,sizeof room->line);
    room->junction_sum=0.f;
    memset(room->hp_state,0,sizeof room->hp_state);
    for(unsigned s=0;s<room->bound;++s) {
        const s1_room_segment *p=&room->segment[s];
        memset(p->data,0,(size_t)(p->end-p->begin)*S1_ROOM_BLOCK_BYTES);
    }
    for(unsigned n=0;n<S1_ROOM_LINES;++n) {
        s1_room_line *line=room->line+n;
        line->seed=(int16_t)room_geometry[n].seed;
        float start=(float)room_geometry[n].samples-room_delay(n,line->seed)*44100.f;
        line->read=(uint16_t)start;
        line->fraction=room_round((start-line->read)*(float)ROOM_FRAC);
        room_next(line,n);
    }
}
int s1_room_bind(s1_room *room,const s1_room_buffer *spans,unsigned count)
{
    if(!room || count>=S1_ROOM_MAX_SPANS || (count && !spans)) return 0;
    if(!count) { room->bound=0; return 1; }
    s1_room_segment parts[S1_ROOM_MAX_SPANS];
    unsigned used=1,blocks=S1_ROOM_PRIVATE_BLOCKS;
    parts[0]=(s1_room_segment){room->private_storage,0,S1_ROOM_PRIVATE_BLOCKS};
    for(unsigned i=0;i<count && blocks<S1_ROOM_BLOCKS;++i) {
        unsigned take=spans[i].bytes/S1_ROOM_BLOCK_BYTES;
        if(!take)continue;
        if(!spans[i].data)return 0;
        if(take>S1_ROOM_BLOCKS-blocks)take=S1_ROOM_BLOCKS-blocks;
        uintptr_t lo=(uintptr_t)spans[i].data,hi=lo+take*S1_ROOM_BLOCK_BYTES;
        if(hi<lo)return 0;
        for(unsigned j=0;j<used;++j) {
            uintptr_t p=(uintptr_t)parts[j].data,q=p+(parts[j].end-parts[j].begin)*S1_ROOM_BLOCK_BYTES;
            if(lo<q && p<hi)return 0;
        }
        parts[used++]=(s1_room_segment){spans[i].data,(uint16_t)blocks,(uint16_t)(blocks+take)};
        blocks+=take;
    }
    if(blocks!=S1_ROOM_BLOCKS)return 0;
    memcpy(room->segment,parts,used*sizeof *parts);room->bound=used;
    s1_room_clear(room);
    return 1;
}
static uint8_t *room_block(s1_room *room,unsigned n,unsigned pos)
{
    unsigned block=room_geometry[n].first_block+(pos>>4);
    const s1_room_segment *s=room->segment;
    while(block>=s->end)++s;
    return s->data+(block-s->begin)*S1_ROOM_BLOCK_BYTES;
}
static unsigned room_scale_code(float step)
{
    fm_bits_t x={.f=step};
    int code=(int)((x.u+0x1fffffu)>>21)-256;
    return code<0?0u:code>255?255u:(unsigned)code;
}
static float room_scale(unsigned code)
{
    fm_bits_t x={.u=((code/4+64u)<<23)|((code&3u)<<21)};return x.f;
}
static float room_inverse(unsigned code)
{
    static const uint32_t mantissa[4]={0,0x4ccccd,0x2aaaab,0x124925};
    unsigned frac=code&3u;
    fm_bits_t x={.u=((190u-code/4-(frac!=0u))<<23)|mantissa[frac]};return x.f;
}
static void room_write(s1_room *room,s1_room_line *line,unsigned n,float sample)
{
    unsigned pos=line->write,within=pos&15u;
    line->pending[within]=sample;
    if(within==15u || pos+1u==room_geometry[n].samples) {
        float prev=line->write_previous,older=line->write_older,peak=0.f;
        for(unsigned i=0;i<=within;++i) {
            float x=line->pending[i],error=fm_fabsf(x-(prev+.95f*(prev-older)));
            if(error>peak)peak=error;
            older=prev;prev=x;
        }
        /* Even an impulse between silent output frames can still be inside a
         * line. Retain ownership through one full turn of the longest ring
         * after the last energetic predictor block. */
        if(peak>0x1p-31f || fm_fabsf(prev)>0x1p-28f || fm_fabsf(older)>0x1p-28f)
            room->active_frames=4198+16;
        uint8_t *code=room_block(room,n,pos);
        enum { limit=(1<<(X0X_S1_ROOM_BITS-1))-1 };
        unsigned scale=room_scale_code(peak/(float)limit);
        *code++=(uint8_t)scale;
#if X0X_S1_ROOM_BITS == 9
        unsigned signs=0;
#endif
        float step=room_scale(scale),inverse=room_inverse(scale);
        prev=line->write_previous;older=line->write_older;
        for(unsigned i=0;i<=within;++i) {
            float predicted=prev+.95f*(prev-older);
            fm_bits_t delta={.f=(line->pending[i]-predicted)*inverse};
            fm_bits_t half={.u=0x3f000000u|(delta.u&0x80000000u)};
            int v=(int)(delta.f+half.f);
            if(v>limit)v=limit;
            if(v< -limit)v= -limit;
#if X0X_S1_ROOM_BITS == 9
            signs |= ((unsigned)v >> 31) << i;
#endif
            code[i]=(uint8_t)v;older=prev;prev=predicted+(float)v*step;
        }
#if X0X_S1_ROOM_BITS == 9
        code[16]=(uint8_t)signs;code[17]=(uint8_t)(signs>>8);
#endif
        line->write_previous=prev;line->write_older=older;
    }
    line->write=(uint16_t)(pos+1u==room_geometry[n].samples?0u:pos+1u);
}
static inline __attribute__((always_inline)) void room_decode(s1_room_line *line,unsigned at)
{
    float value=line->window[3]+.95f*(line->window[3]-line->window[2]);
#if X0X_S1_ROOM_BITS == 9
            int code=line->read_block[1u+at];
            unsigned high=(line->read_block[17+(at>>3)]>>(at&7u))&1u;
            code-=(int)(high<<8);
#else
            int code=(int8_t)line->read_block[1u+at];
#endif
            value+=(float)code*line->read_scale;
            line->window[0]=line->window[1];line->window[1]=line->window[2];
            line->window[2]=line->window[3];line->window[3]=value;
}
static float room_read(s1_room *room,s1_room_line *line,unsigned n)
{
    int size=room_geometry[n].samples;
    unsigned frac=line->fraction;
    int position=line->read+(int)(frac>>28);
    if(position>=size)position-=size;
    line->read=(uint16_t)position;
    frac&=ROOM_FRAC-1;
    float f=(float)frac*(1.f/(float)ROOM_FRAC);
    line->fraction=frac+line->increment;
    int newest=position+2;if(newest>=size)newest-=size;
    if(line->valid && newest==(int)line->last+1 && (newest&15)) {
        room_decode(line,(unsigned)newest&15u);
        line->last=(uint16_t)newest;
    } else if(!line->valid||newest!=line->last) {
        int next=line->valid?line->last+1:position-1;
        if(next<0)next+=size;
        for(;;) {
            if(next==size)next=0;
            unsigned at=(unsigned)next&15u;
            if(!at||!line->valid) {
                line->read_block=room_block(room,n,(unsigned)next);
                line->read_scale=room_scale(line->read_block[0]);
                line->valid=1;
            }
            room_decode(line,at);
            if(next==newest)break;
            ++next;
        }
        line->last=(uint16_t)newest;
    }
    float a2=(f*f-1.f)*(1.f/6.f),a1=(f+1.f)*.5f,am1=a1-1.f;
    float a0=3.f*a2;a1-=a0;am1-=a2;a0-=f;
    const float *w=line->window;
    return (am1*w[0]+a0*w[1]+a1*w[2]+a2*w[3])*f+w[1];
}
static inline __attribute__((always_inline)) float room_line_frame(s1_room *room,unsigned n,float input,float feedback)
{
        s1_room_line *line=room->line+n;
        room_write(room,line,n,input-line->filtered);
        float x=room_read(room,line,n)*feedback;
        line->filtered=(line->filtered-x)*0x1.5f619ap-3f+x;
        if(!--line->remaining)room_next(line,n);
    return line->filtered;
}
static void room_core(s1_room *room,float left,float right,float feedback,float out[2])
{
    if(room->active_frames)--room->active_frames;
    float junction=room->junction_sum*.25f;
    float next_junction=0.f;
    left+=junction;right+=junction;
    float sum_l=0.f,sum_r=0.f;
    for(unsigned n=0;n<S1_ROOM_LINES;n+=2) {
        float l=room_line_frame(room,n,left,feedback);
        float r=room_line_frame(room,n+1,right,feedback);
        sum_l+=l;sum_r+=r;
        next_junction+=l;next_junction+=r;
    }
    out[0]=sum_l;out[1]=sum_r;
    room->junction_sum=next_junction;
    out[0]*=.35f;out[1]*=.35f;
}
