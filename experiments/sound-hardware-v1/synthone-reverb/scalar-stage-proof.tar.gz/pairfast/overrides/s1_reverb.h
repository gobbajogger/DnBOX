/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
#include <stdint.h>

#ifndef X0X_S1_ROOM_BITS
#define X0X_S1_ROOM_BITS 8
#endif
#if X0X_S1_ROOM_BITS != 8 && X0X_S1_ROOM_BITS != 9
#error Unsupported Synth One reverb storage precision
#endif
enum { S1_ROOM_LINES=8, S1_ROOM_BLOCK_BYTES=1+2*X0X_S1_ROOM_BITS, S1_ROOM_BLOCKS=1548,
       S1_ROOM_PRIVATE_BLOCKS=1020/S1_ROOM_BLOCK_BYTES, S1_ROOM_EXTERNAL_BLOCKS=S1_ROOM_BLOCKS-S1_ROOM_PRIVATE_BLOCKS,
       S1_ROOM_MAX_SPANS=10 };

typedef struct { uint8_t *data; unsigned bytes; } s1_room_buffer;
typedef struct { uint8_t *data; uint16_t begin,end; } s1_room_segment;
typedef struct {
    float write_previous,write_older;
    float pending[16],window[4],read_scale,filtered;
    uint8_t *read_block;
    uint16_t write,read,last;
    int16_t seed;
    uint32_t fraction,increment,remaining;
    uint8_t valid;
} s1_room_line;
typedef struct {
    s1_room_line line[S1_ROOM_LINES];
    s1_room_segment segment[S1_ROOM_MAX_SPANS];
    float hp_state[2][2],hp[3],hp_last,junction_sum;
    float feedback,highpass,mix,on,target_feedback,target_highpass,target_mix,target_on;
    unsigned bound,authored,route,active_frames;
    uint8_t private_storage[S1_ROOM_BLOCK_BYTES*S1_ROOM_PRIVATE_BLOCKS];
} s1_room;
/* Spans belong exclusively to one selected part. Whole coded blocks can
 * cross any chip-bank boundary between blocks. A failed bind leaves the old
 * binding intact. A zero-count bind drops the current history. */
int s1_room_bind(s1_room *room,const s1_room_buffer *spans,unsigned count);
void s1_room_clear(s1_room *room);
/* The board provider returns exclusive mutable history for this owner. Zero
 * means the selected configuration has no storage available. */
unsigned s1_board_room_spans(unsigned owner,s1_room_buffer spans[S1_ROOM_MAX_SPANS-1]);
