#include "s1_dry_part.c"
static s1_dry_part owner;
static uint8_t hist[S1_ROOM_EXTERNAL_BLOCKS*S1_ROOM_BLOCK_BYTES];
static float previous[2][5];
static unsigned ready;
int check_begin(void) {
    unsigned first=443*S1_ROOM_BLOCK_BYTES, second=623*S1_ROOM_BLOCK_BYTES;
    s1_room_buffer spans[]={{hist,first},{hist+first,second},{hist+first+second,sizeof hist-first-second}};
    return s1_room_bind(&owner.room,spans,3);
}
void check_room(const float *parameters,float l,float r,float wet,float *ol,float *or_,float *raw)
{
    for(unsigned stage=0;stage<2;++stage) {
        float p[5];for(unsigned i=0;i<5;++i)p[i]=parameters[123+stage+i*3];
        if(!ready || memcmp(previous[stage],p,sizeof p)) {
            memcpy(previous[stage],p,sizeof p);s1_part_room_dynamics(&owner,stage,p);
        }
    }
    ready=1;
    room_frame(&owner,l,r,parameters[39],parameters[38],wet,ol,or_,raw);
}
