from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import subprocess,os
d=Path(__file__).resolve().parent;build=Path(os.environ['FACTORY_BUILD']).resolve();p=build/'factory-inputs'
def check(i):
 subprocess.run([d/'probe',p/'public-morphs.f32',p/'compact.bin',build/'commands/preset-commands.bin',str(i),'/dev/null'],check=True)
 print(i,flush=True)
with ThreadPoolExecutor(max_workers=5)as pool:
 for t in as_completed([pool.submit(check,i) for i in range(694)]):t.result()
