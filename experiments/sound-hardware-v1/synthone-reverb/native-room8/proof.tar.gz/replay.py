"""Stage saved stock projects and factory-459 room control projects, then run the calibrated eight-second guest."""
import argparse
import json
from pathlib import Path
import shlex
import subprocess
import sys
from types import SimpleNamespace
p=argparse.ArgumentParser(description=__doc__)
for name in ('repo','emulator','elf','fwsc','out'): p.add_argument('--'+name,required=True,type=lambda s:Path(s).resolve())
p.add_argument('--model',choices=['elite','pro'],required=True)
p.add_argument('--scene',choices=['cm','poly','wet','dual'],required=True)
a=p.parse_args()
source=a.repo/'experiments/sound-hardware-v1';selected=source/'selected-native'
sys.path.insert(0,str(source/'strict-timing'))
def seed_capture():
    import importlib.util
    spec=importlib.util.spec_from_file_location('strict_replay',source/'strict-timing/replay.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    g=SimpleNamespace(emulator=a.emulator,elf=a.elf,fwsc=a.fwsc,output=a.out)
    mod.run(g,mod.read_symbols(g.elf),[],'seed',2000,0)
a.out.mkdir(parents=True,exist_ok=True)
seed=a.out/'seed/flash.bin'
if not seed.is_file():seed_capture()
wet=a.scene in ('wet','dual')
owner={'elite':{'cm':(0,1),'poly':(3,2),'wet':(3,2),'dual':(2,2)},
       'pro':{'cm':(1,0),'poly':(2,3),'wet':(2,3),'dual':(2,2)}}[a.model][a.scene]
fixture=a.out/('wet-project' if wet else 'ordinary-project')
if not fixture.is_file():
    src=Path(__file__).resolve().with_name('wet_project.c') if wet else selected/'project.c'
    flags,sources=subprocess.check_output(['sh','-c','. tests/host/original_build.sh; echo "$ORIGINAL_FLAGS"; echo "$ORIGINAL_SOURCES"'],cwd=a.repo,text=True).splitlines()
    cmd=['cc','-std=c11','-O1','-DX0X_HOST','-D_POSIX_C_SOURCE=200809L','-I.','-Ifirmware/src','-Ifirmware/src/app','-Ifirmware/src/dsp','-Ibuild/gen',*shlex.split(flags),src,*shlex.split(sources),'-lm','-o',fixture]
    subprocess.run(cmd,cwd=a.repo,check=True)
stage=a.out/(a.scene+'-stage');heavy=a.out/(a.scene+'-heavy')
if not (stage/'flash.bin').is_file():
    subprocess.run([sys.executable,selected/'run.py','--ensemble','--stage-only',a.emulator,a.elf,a.fwsc,seed,fixture,stage,*map(str,owner)],check=True)
if (heavy/'results.json').is_file():
    sys.exit(not json.loads((heavy/'results.json').read_text())['passed'])
sys.exit(subprocess.run([sys.executable,selected/'heavy.py','--elf',a.elf,'--fwsc',a.fwsc,'--emulator',a.emulator,'--seed',stage/'flash.bin','--output',heavy,'--owners',*map(str,owner)]).returncode)
