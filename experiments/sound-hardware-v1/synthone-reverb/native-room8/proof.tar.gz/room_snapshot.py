"""Read independent owner RevSC histories and both initialized stack watermarks from a native guest dump."""
import argparse
import gzip
import hashlib
import json
import re
import struct
import subprocess
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument("build",type=Path);p.add_argument("shots",nargs="+",type=Path);p.add_argument("--block-bytes",type=int,default=17)
a=p.parse_args()
base=0x1c00000
offsets={k:int(v) for k,v in re.findall(r'@(\w+) = constant i16 (\d+)',Path(__file__).with_name("room_offsets.ll").read_text())}
def read_dump(path):
    return path.read_bytes() if path.is_file() else gzip.decompress(path.with_name(path.name+".gz").read_bytes())
def row(receipt):
    rr=json.loads(receipt.read_bytes());m=receipt.parent.parent.name
    elf=a.build/m/'x0x.elf'
    assert rr['elf_sha256']==hashlib.sha256(elf.read_bytes()).hexdigest()
    syms={w[3]:(int(w[0],16),int(w[1],16)) for ln in subprocess.check_output(['nm','-S',elf],stderr=subprocess.DEVNULL,text=True).splitlines() if len(w:=ln.split())==4}
    vals={w[2]:int(w[0],16) for ln in subprocess.check_output(['nm','-n',elf],stderr=subprocess.DEVNULL,text=True).splitlines() if len(w:=ln.split())==3}
    data=read_dump(receipt.parent/"heavy/ram.bin")
    unpack=lambda pat,addr:struct.unpack_from('<'+pat,data,addr-base)
    def watermark(lo,hi,mark):
        addr=lo
        while addr<hi and unpack('I',addr)[0]==mark: addr+=4
        return dict(capacity=hi-lo,used=hi-addr,remaining=addr-lo)
    stacks={
        "irq0":watermark(vals['_sstack_lo'],vals['_sstack_top'],0x49525153),
        "worker_user":watermark(vals['_c1_ustack'],vals['_c1_ustack_top'],0x43314d4b),
    }
    owners=[];spans=[]; wet='wet' in receipt.parents[2].name
    for i,kind in enumerate(rr['guest']['bass_kinds']):
        if kind!=2:continue
        part=vals['original_bass']+i*offsets['sizeof_part']; room=part+offsets['offset_room']
        assert kind==unpack('B',part+offsets['offset_s1_kind'])[0]
        get=lambda name,fmt:unpack(fmt,room+offsets['offset_'+name])[0]
        count=get("bound",'I')
        assert count==5, (receipt,count)
        prior=0;seg=[]
        for j,n in enumerate(('private','pool','cache','bss','low')):
            at=room+offsets['offset_segment']+j*offsets['sizeof_segment']
            lo,beg,end=unpack('IHH',at)
            assert beg==prior<end;prior=end;size=(end-beg)*a.block_bytes
            if n!='private':
                b,s=syms['room_'+n]; assert size==s//2 and lo==b+i*size
            else: assert part<=lo and lo+size<=part+offsets['sizeof_part']
            hi=lo+size;assert all(hi<=l or h<=lo for l,h in spans);spans.append((lo,hi))
            touched=sum(v!=0 for v in data[lo-base:hi-base]) if lo>=base and hi-base<=len(data) else None
            seg.append(dict(name=n,begin_block=beg,end_block=end,addr=hex(lo),bytes=size,nonzero_dump_bytes=touched))
        assert prior==1548
        writes=[unpack('H',room+offsets['sizeof_line']*k+offsets['offset_write'])[0] for k in range(8)]
        reads=[unpack('I',room+offsets['sizeof_line']*k+offsets['offset_read_block'])[0] for k in range(8)]
        params={n:get(n,'f' if n in ('on','mix','feedback') else 'I') for n in ('authored','on','mix','feedback','route')}
        if wet:
            assert params['authored']==1 and min(params[n] for n in ('on','mix','feedback'))>.98,(receipt,params)
            assert all(writes) and all(any(lo<=ptr<hi for lo,hi in spans[-5:]) for ptr in reads),(receipt,writes,reads)
            assert all(q['nonzero_dump_bytes']>0 for q in seg if q['nonzero_dump_bytes'] is not None),(receipt,seg)
        owners.append(dict(owner=i,**params,segments=seg,line_write=writes,line_read_block=[hex(r) for r in reads]))
    return dict(elf=rr['elf_sha256'],pcm=rr['shot']['pcm_sha256'],all_active=rr['all_active'],max_us=rr['shot']['max_us'],late=rr['shot']['raw_late'],xruns=rr['shot']['audio_xruns'],stacks=stacks,room=owners)
records={}
for s in a.shots:
    for r in sorted(s.glob('*/heavy*/results.json')):records[str(r.parent)]=row(r)
print(json.dumps(records,indent=2))
