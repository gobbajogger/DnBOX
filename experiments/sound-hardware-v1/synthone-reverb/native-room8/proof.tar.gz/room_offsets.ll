; ModuleID = '/workspace/scratch/3849744ef45b/s4bench/display/proof/room_offsets.c'
source_filename = "/workspace/scratch/3849744ef45b/s4bench/display/proof/room_offsets.c"
target datalayout = "e-m:e-p:32:32-i1:32-i64:32:32-f64:32:32-n8:16:32-a:0:32"
target triple = "pi32v2"

@offset_room = constant i16 1364, align 2
@offset_bound = constant i16 1200, align 2
@offset_authored = constant i16 1204, align 2
@offset_feedback = constant i16 1168, align 2
@offset_mix = constant i16 1176, align 2
@offset_on = constant i16 1180, align 2
@offset_route = constant i16 1208, align 2
@offset_line = constant i16 0, align 2
@offset_segment = constant i16 1056, align 2
@offset_write = constant i16 108, align 2
@offset_read_block = constant i16 104, align 2
@offset_s1_kind = constant i16 5180, align 2
@sizeof_line = constant i16 132, align 2
@sizeof_part = constant i16 5184, align 2
@sizeof_segment = constant i16 8, align 2

!llvm.ident = !{!0}

!0 = !{!"clang version 4.0.1 () ()"}
