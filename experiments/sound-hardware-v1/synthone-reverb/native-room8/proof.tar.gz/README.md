# Full-rate Synth One room on SMK-37

The patch links two independent 44.1 kHz RevSC reverbs alongside the existing 430 ms private 808 echo on SMK-37 Elite and Pro. The populated Juno + Synth One scenes meet deadline with the room idle. With full factory #459 room settings, both models miss deadline. The Pro Chicago + Miami run also missed once. This historical patch blocks idle undo after room edits because a tail remains asserted. A subsequent candidate tracks energetic blocks to expire the tail and guards the selector.

| 922-event scene | Elite maximum, raw late | Pro maximum, raw late |
|---|---:|---:|
| Chicago + Miami | 11,473 µs, 0 | 11,634 µs, 1 |
| Juno + Synth One INIT | 10,067 µs, 0 | 10,763 µs, 0 |
| Juno + one full room | 14,041 µs, 64 | 14,298 µs, 97 |
| Two Synth Ones, both full room | 15,910 µs, 133 | 15,915 µs, 132 |

All eight strict captures have full duration, a complete PCM stream, five active parts and a clear guest crash record. The 2,000 ms baseline and 8,000 ms shot use the same disposable populated flash and calibrated scene. Each core's runtime high-water mark appears in the receipt. The deepest worker used 2,572 of 4,352 bytes and IRQ0 used 3,180 of 7,936 bytes. A separate 256-frame native call to the 909 moving-mix helper, including all six gain/send envelopes, used 1,104 bytes. Its probe source and linked trace receipt are in `evidence/stack909`.

**Build and replay**

Use a separate checkout of `bf48ce83bea6f8d332dddff11e5407c4fd744fc6`. The manifest lists every modified source hash and both linked product pairs. The ordinary toolchain and SDK paths use the repository's normal build prerequisites. Package paths below are relative to the directory containing this readme.

```sh
git apply /path/to/full-rate-room8.patch
BOARD=smk37 MODEL=elite X0X_DEV_PADCAL=1 sh build.sh
BOARD=smk37 MODEL=pro X0X_DEV_PADCAL=1 sh build.sh
sh host/build_host.sh --generate-only
python3 /path/to/replay.py --repo "$PWD" --emulator "$EMULATOR" \
  --elf build/smk37-elite/x0x.elf --fwsc build/x0x-smk37-elite.fwsc \
  --model elite --scene wet --out /tmp/room8-elite
```

The supported scene arguments are `cm`, `poly`, `wet` and `dual`. Use the Pro ELF in `build/smk37` and `build/x0x-smk37.fwsc` for `--model pro`. Use the observer-enabled fm1-live emulator pinned by the selected-native README. The runner writes a receipt even if a timing gate returns failure. The 14,076-byte upper SRAM layout from the base commit remains active. Seven data-cache ways provide 28,672 more bytes, with all eight instruction ways still active. The DAC-half overlay, native 909 moving-mix helper, low SRAM and BSS provide the rest. Each owner receives 1,548 distinct 17-byte codec blocks, including 60 private blocks in its own selected engine state. All 16 lines advanced on the dual wet runs. Both models also booted the real optional BLE controller from a disposable flash image with BLE enabled. Its startup mailbox, settings and audio counters are retained separately. Wireless links and physical hardware cache/audio performance remain unmeasured.

The normal saved project builder uses factory #459's seven room controls on the ordinary Synth One INIT instrument. The controls are on, mix, feedback, high-pass, LFO source, input compressor preset and wet compressor preset. The two destination owners each receive the complete control tuple in the dual scene. Project reload matches those controls and guest state confirms that their actual gains reached their targets.

The physical-control host study of this room graph uses 694 original factory rows. Both final channels pass for all 694, while the isolated wet return passes for 692. The host build precedes a mathematically equivalent single-precision positive-rounding helper needed by the native image. Each result belongs to the original program's room graph. The 694 dry factory programs are external test data. The product still exposes the seven authored room controls through the native project format. The complete per-program scores and their originating continuous controls are in `evidence/original-physical-694.json.gz`.
