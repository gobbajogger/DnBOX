#!/usr/bin/env python3
import argparse, concurrent.futures, hashlib, json, os, shlex, subprocess
from pathlib import Path
p=argparse.ArgumentParser()
for arg in ('repo','baseline','out'): p.add_argument(arg,type=Path)
a=p.parse_args(); repo=a.repo.resolve(); out=a.out.resolve(); baseline=a.baseline.resolve()
out.mkdir(exist_ok=True,parents=True)
src=Path(__file__).resolve().with_name('panel.c')
forced=out/'mask.h';forced.write_text('extern unsigned test_worker_mask;\n#define X0X_CORE_PLAN test_worker_mask\n')
sets=subprocess.check_output(['sh','-c','set -eu; . tests/host/original_build.sh; echo "$ORIGINAL_FLAGS"; echo "$ORIGINAL_SOURCES"'],cwd=repo,text=True).splitlines()
flags=['cc','-O2','-ffp-contract=off','-fstrict-aliasing','-std=c99','-D_POSIX_C_SOURCE=200809L','-DX0X_HOST',*shlex.split(sets[0]),'-I.','-Ifirmware/src','-Ifirmware/src/app','-Ifirmware/src/dsp','-I'+str(repo/'build/gen'),'-include',str(forced)]
sources=[repo/f for f in shlex.split(sets[1]) if f!='firmware/src/app/engine.c']
real=repo/'firmware/src/app/engine.c'
def compile(src,extra=()):
    dst=out/(hashlib.sha1(src.read_bytes()+' '.join(extra).encode()).hexdigest()+'-'+src.stem+'.o')
    if not dst.exists(): subprocess.run([*flags,*extra,'-c',src,'-o',dst],cwd=repo,check=True)
    return dst
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool: common=list(pool.map(compile,sources))
binaries={}
for name,eng,defs in [('baseline',baseline,[]),('generic',real,[]),('dma',real,['-DVERIFY_DMA_PATH'])]:
    binary=out/name
    subprocess.run(['cc',compile(src,defs),compile(eng),*common,'-lm','-o',binary],check=True)
    binaries[name]=binary
results={}
for pair in range(3):
 for route in range(3):
    digests={}
    for mask in (0,1,5,21,31):
      got={}
      for name,binary in binaries.items():
        trace=out/(name+'.bin')
        subprocess.run([binary,str(pair),str(mask),str(route),trace],check=True)
        got[name]=hashlib.sha256(trace.read_bytes()).hexdigest()
      assert len(set(got.values()))==1,(pair,route,mask,got)
      digests[str(mask)]=got['dma']
    results[f'{pair}/{route}']=digests
    print(pair,route,flush=True)
(out/'comparison.json').write_text(json.dumps(results,indent=2)+'\n')
