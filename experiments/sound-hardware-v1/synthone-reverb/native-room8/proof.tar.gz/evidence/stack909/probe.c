extern float dry_l[256],dry_r[256],rev[256],dly[256],mix_glide[][2],mix_level[];
extern void measured(unsigned n);
static volatile unsigned *const result=(volatile unsigned *)0x1c07f00;
void bench(void)
{
    mix_level[0]=1.f;
    for(unsigned j=0;j<6;++j) {
        mix_glide[j][0]=.125f;
        mix_glide[j][1]=.875f;
    }
    for(unsigned i=0;i<256;++i) {
        dry_l[i]=(i%2u?1.f:-1.f)*.25f;
        dry_r[i]=.125f;
        rev[i]=.0625f;dly[i]=.03125f;
    }
    result[0]=1;
    measured(256);
    result[1]=dry_l[0]<0.f && dry_l[255]>0.f;
    result[2]=rev[127]>.0625f && dly[127]>.03125f;
    result[3]=16*mix_glide[0][0];
}
