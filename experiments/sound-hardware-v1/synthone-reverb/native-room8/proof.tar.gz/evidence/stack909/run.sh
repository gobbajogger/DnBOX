#!/bin/bash
set -euo pipefail
elf=$(realpath "${1:?ELF}")
native=$(realpath "${2:?built linked_probe.rs using the pinned fm1_core CPU}")
tool="${JIELI_TOOLCHAIN:?}/pi32v2/bin"
cd "$(dirname "$0")"
python3 prepare.py "$elf"
"$tool/clang" -target pi32v2 -mcpu=r3 -mfprev1 -ffp-contract=off -fno-builtin -ffunction-sections -fdata-sections -Os -c entry.S -o entry.o
"$tool/clang" -target pi32v2 -mcpu=r3 -mfprev1 -ffp-contract=off -fno-builtin -ffunction-sections -fdata-sections -Os -c probe.c -o probe.o
"$tool/ld" --gc-sections -e _start -T probe.ld -o probe.elf entry.o probe.o
"$tool/objcopy" -j .text -O binary probe.elf probe.bin
measure=$(nm probe.elf | awk '$3=="measured"{print $1}')
sha256sum "$elf"
"$native" segments.bin probe.bin "$measure"
