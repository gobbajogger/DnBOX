"""Lay the exact ordinary ELF sections in simulator memory and link only the caller at 0x02090000."""
from pathlib import Path
import struct,sys
b=Path(sys.argv[1]).read_bytes()
shoff,=struct.unpack_from('<I',b,32);shent,num,shstr=struct.unpack_from('<3H',b,46)
sec=[struct.unpack_from('<10I',b,shoff+i*shent) for i in range(num)]
sym={}
with open('segments.bin','wb') as out:
 for s in sec:
  if s[1]==1 and s[2]&2 and s[3]:out.write(struct.pack('<II',s[3],s[5])+b[s[4]:s[4]+s[5]])
  if s[1]==2:
   ns=sec[s[6]];names=b[ns[4]:ns[4]+ns[5]]
   for i in range(s[4],s[4]+s[5],s[9]):
    j,val=struct.unpack_from('<II',b,i)
    if val:sym[names[j:names.index(b'\0',j)].decode()]=val
spec="""MEMORY { XIP (rx) : ORIGIN = 0x02090000, LENGTH = 0x70000 }
SECTIONS { .text : { KEEP(*(.text.start)) *(.text*) *(.rodata*) . = ALIGN(4); } > XIP }
"""
for name in 'mix_909_moving dry_l dry_r rev dly mix_glide mix_level'.split():
 spec+=f'{name} = 0x{sym[name]:08x};\n'
Path('probe.ld').write_text(spec)
