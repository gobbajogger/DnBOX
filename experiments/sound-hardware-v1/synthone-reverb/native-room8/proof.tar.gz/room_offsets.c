#include <stddef.h>
#include "original_runtime.h"
#define REPORT(name,value) const unsigned short name = value;
REPORT(offset_room, offsetof(original_runtime_part,dsp.synthone.room))
REPORT(offset_bound, offsetof(s1_room,bound))
REPORT(offset_authored, offsetof(s1_room,authored))
REPORT(offset_feedback, offsetof(s1_room,feedback))
REPORT(offset_mix, offsetof(s1_room,mix))
REPORT(offset_on, offsetof(s1_room,on))
REPORT(offset_route, offsetof(s1_room,route))
REPORT(offset_line, offsetof(s1_room,line))
REPORT(offset_segment, offsetof(s1_room,segment))
REPORT(offset_write, offsetof(s1_room_line,write))
REPORT(offset_read_block, offsetof(s1_room_line,read_block))
REPORT(offset_s1_kind, offsetof(original_runtime_part,kind))
REPORT(sizeof_line, sizeof(s1_room_line))
REPORT(sizeof_part, sizeof(original_runtime_part))
REPORT(sizeof_segment, sizeof(s1_room_segment))
