/* Adapt the bounded DnBOX history to one instance in the original test graph. */
#include <stdlib.h>
#include "soundpipe.h"
#include "widen.h"

static sp_delay *candidate;
void use_bounded_widen(sp_delay *p)
{
    /* Only used by this serial two-renderer comparison fixture. */
    if (!p || p->bufsize != 2205 || p->bufpos || p->feedback != 0) abort();
    size_t bytes = (TEST_HISTORY_BITS / 8) * S1_WIDEN_FRAMES;
    void *words = calloc(bytes, 1);
    if (!words) abort();
    free(p->buf.ptr);
    p->buf.ptr = words;
    p->buf.size = bytes;
    candidate = p;
}
int __real_sp_delay_compute(sp_data *, sp_delay *, SPFLOAT *, SPFLOAT *);
int __wrap_sp_delay_compute(sp_data *sp, sp_delay *p, SPFLOAT *input, SPFLOAT *out)
{
    if (p != candidate) return __real_sp_delay_compute(sp, p, input, out);
    unsigned pos = p->bufpos;
#if TEST_HISTORY_BITS == 16
    /* Two-byte candidate. See the precision and range description in README.md. */
    uint16_t *history = p->buf.ptr;
    uint32_t u;memcpy(&u,input,sizeof u);
    uint16_t old=history[pos];uint32_t sign=(u>>16)&0x8000u,mag=(u&0x7fffffffu)+0x1fffu+((u>>14)&1u);
    uint32_t exponent=mag>>23,mant=(mag>>14)&0x1ffu;
    history[pos]=(uint16_t)(exponent<=96u?sign:exponent>=159u?(sign|0x7fffu):(sign|((exponent-96u)<<9)|mant));
    uint32_t prior=((uint32_t)old&0x8000u)<<16;if(old&0x7fffu)prior|=(((uint32_t)old&0x7fffu)<<14)+(96u<<23);
    memcpy(out, &prior, sizeof prior);
    pos = pos + 1u == S1_WIDEN_FRAMES ? 0u : pos + 1u;
#elif TEST_HISTORY_BITS == 24
    uint8_t *storage = p->buf.ptr;
    *out = s1_widen_tap(storage, 1365, storage + 4095, &pos, *input);
#else
#error unsupported history width
#endif
    p->bufpos = pos;
    return SP_OK;
}
