import numpy as np
def channel_score(reference, candidate, rate, band):
    """Use the factory comparison's 2048-sample Hann windows, hop and floor."""
    a, b = reference.astype(np.float64), candidate.astype(np.float64)
    if not np.any(a) or not np.any(b):
        return (0.0, 0.0) if np.array_equal(a, b) else (None, None)
    window = np.hanning(2048)

    def spectrum(x):
        windows = np.lib.stride_tricks.sliding_window_view(x, len(window))[::512]
        return np.sqrt(np.mean(abs(np.fft.rfft(windows * window)) ** 2, axis=0))

    sa, sb = spectrum(a), spectrum(b)
    freq = np.fft.rfftfreq(len(window), 1.0 / rate)
    floor = max(1e-12, np.max(sa) * 0.0001)
    use = (freq >= band[0]) & (freq <= band[1]) & ((sa > floor) | (sb > floor))
    level = 10 * np.log10(np.mean(b * b) / np.mean(a * a))
    if not np.any(use):
        return float(level), None
    difference = 20 * np.log10(np.maximum(sb[use], floor) / np.maximum(sa[use], floor))
    return float(level), float(np.sqrt(np.mean(difference * difference)))
