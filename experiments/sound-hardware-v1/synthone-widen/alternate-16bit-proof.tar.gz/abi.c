#include "original_runtime.h"
char s1_owner[sizeof(s1_dry_part)],chicago_owner[sizeof(original_chicago_backend)],miami_owner[sizeof(original_miami_backend)],juno_owner[sizeof(((original_runtime_backend*)0)->juno)],backend_union[sizeof(original_runtime_backend)], runtime_part[sizeof(original_runtime_part)];
