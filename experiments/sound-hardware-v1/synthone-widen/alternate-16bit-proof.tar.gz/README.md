# Two-byte Synth One final widening history

The production three-byte history stores the sign, the complete binary32 exponent and 15 fraction bits. The first two-byte experiment used the upper 16 bits, including only seven fraction bits. It exceeded the source spectral limit on BASS - Dubchill and JEC Alarming! Round-to-nearest in the same 16-bit format also exceeded the limit on both. The second format in this comparison stores a sign, six exponent bits and nine fraction bits, with round-to-nearest-even before packing. Its absolute floor is approximately 2^-30. It represents levels greater than unity and bounds extreme large inputs. These are DSP history formats. Project cells store controls and carry no audio history.

The musical comparison uses the existing full factory widening test exactly, including its 44.1 kHz clock, 2,205-frame right tap, 88,200-frame captures, 144 ordered setters per program, source note schedule and 20 Hz–16 kHz level/spectral rule. Every original stereo capture digest matches the existing 24-bit receipt. The ABI trial changes the split from 1,365/840 three-byte frames to 2,047/158 two-byte frames; its 4,094-byte first span fits the selected owner's existing 4,095-byte Chicago arena, and the remaining 316 bytes stay in the backend union. All other backend members retain their source layouts.

On the checked PI32v2 target layout from 42ae56e1, selected Synth One state decreases from 3,564 to 1,360 bytes. Miami still determines the 3,720-byte backend union and the complete owner remains 5,184 bytes. The 2,204-byte saving per selected Synth One part can hold new private effects. It does not add common pool capacity with the runtime unchanged. The shipped firmware retains its qualified three-byte width.

Set the factory build directory in `build` and extract this packet into `here`. The upstream fixture source and restoration steps are in the original widening experiment.

```sh
OPENBLAS_NUM_THREADS=1 python3 "$here/e6m9/replay.py" "$build" "$out/e6m9" --history-bits 16
OPENBLAS_NUM_THREADS=1 python3 "$here/r16/replay.py" "$build" "$out/r16-focused" --history-bits 16 --indices 251 339
```

The second command exits with status 1 because its two focused source scores exceed tolerance. To reproduce the ABI probe with the pinned JieLi R3 compiler, compile `abi.c` against the 42ae56e1 app and original-synth headers with `-target pi32v2 -mcpu=r3 -mfprev1 -DBOARD_SMK37=1`, read COMMON symbol sizes with the target objdump, then change `S1_WIDTH_FIRST_FRAMES` and `S1_WIDTH_TAIL_BYTES` to 2047 and 316 in an isolated copy and recompile. Native full images, callback time and project lifecycle were not tested for this diagnostic.
