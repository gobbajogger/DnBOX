double f(double x) { return x * x + 0.25; }
