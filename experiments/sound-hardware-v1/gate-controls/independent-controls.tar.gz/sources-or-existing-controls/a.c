extern double f(double x);
#include <stdio.h>
int main(void) { printf("%.8g\n",f(3.25)); return 0; }
