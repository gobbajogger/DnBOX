#!/usr/bin/env python3
"""Run ordinary host GCC on the same ordered TUs in two workers. No cached objects."""
import concurrent.futures
import os
from pathlib import Path
import subprocess
import sys
import tempfile
cc = "/usr/bin/cc"
args = sys.argv[1:]
sources = [a for a in args if a.endswith(".c") and not a.startswith("-")]
def ordinary():
    os.execv(cc, [cc, *args])
if len(sources) < 2 or args.count("-o") != 1 or args.index("-o") + 2 != len(args):
    ordinary()
out = Path(args[-1])
args = args[:-2]
safe_flags = {"-g","-std=c99","-O1","-O2","-Wall","-Wextra","-Werror","-ffp-contract=off",
              "-fno-fast-math","-fstack-usage","-fsanitize=address,undefined","-fno-sanitize-recover=all"}
for arg in args:
    if arg in sources or arg in safe_flags or arg == "-lm" or arg.startswith(("-Wno-","-I","-D")):
        continue
    ordinary()
if len(set(sources)) != len(sources):
    ordinary()
flags = [a for a in args if a not in sources]
with tempfile.TemporaryDirectory(prefix="ordered-cc-", dir=out.parent) as tmp:
    objects = {s:Path(tmp)/str(i)/(out.name+"-"+Path(s).stem+".o") for i,s in enumerate(sources)}
    def compile_one(s):
        obj=objects[s]
        obj.parent.mkdir()
        p=subprocess.run([cc,*flags,"-c",s,"-o",str(obj)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        return p
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        results=list(executor.map(compile_one,sources))
    for source,result in zip(sources,results):
        stack=objects[source].with_suffix(".su")
        if stack.is_file():
            stack.replace(out.parent/stack.name)
        sys.stderr.buffer.write(result.stdout)
    failure=next((p.returncode for p in results if p.returncode),0)
    if failure:
        sys.exit(failure)
    linked=[str(objects[a]) if a in objects else a for a in args]
    sys.exit(subprocess.call([cc,*linked,"-o",str(out)]))
