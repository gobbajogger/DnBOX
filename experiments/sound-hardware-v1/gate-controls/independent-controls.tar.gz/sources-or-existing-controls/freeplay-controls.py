"""Supplementary negatives only; older author-patch candidate has its own identity."""
import hashlib
import json
import os
import subprocess
from pathlib import Path
g = Path(__file__).resolve().parent
r = g/"focus-runner"
o = g/"receipts"
sha = subprocess.check_output(["git","-C",r,"rev-parse","HEAD"],text=True).strip()
old = g/"focused/author-predecessor/firmware/src/app/ui.c"
native = (r/"firmware/src/app/ui.c").read_text()
anch = "&& ui.freeplay[bidx()] && !ui.rec"
assert native.count(anch) == 1
bad = g/"focused/always-free.c"
bad.write_text(native.replace(anch,"&& !ui.rec"))
report = {"gate_sha": sha, "required_historical_ref":"6c418a43ff6fc5f4e1fad3bbf71e63cfd64a1987 (still absent)", "trials":[]}
for label,file,marker in [("authored-v1",old,"FREE_PLAY_MODE_CUE_MISSING"),("always-free",bad,"FREE_PLAY_MODE_CUE_UNEXPECTED")]:
    env = dict(os.environ,CC=str(g/"parallel-cc.py"),TMPDIR=str(g/"tmp"),SMC_UI_TEST_FILE="tests/host/ui_freeplay_state_test.c",SMC_UI_OUT=str(r/"build/host"/("freeplay-supplement-"+label)),X0X_HOST_DEFS='-DX0X_HOST_UI_SOURCE="'+str(file)+'"')
    try:
        p = subprocess.run(["sh","tests/host/smc_ui_test.sh"],cwd=r,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=100,text=True)
        rc,txt = p.returncode,p.stdout
    except subprocess.TimeoutExpired as e:
        rc,txt = None,(e.stdout or b"").decode(errors="replace")
    (o/("freeplay-"+label+".log")).write_text(txt)
    oid = subprocess.check_output(["git","hash-object",file],text=True).strip()
    report["trials"].append({"label":label,"blob":oid,"return_code":rc,"runtime_marker":marker in txt,"intended_rejection":rc not in (None,0) and marker in txt and "FAIL " in txt})
(o/"freeplay-supplement.json").write_text(json.dumps(report,indent=2)+"\n")
