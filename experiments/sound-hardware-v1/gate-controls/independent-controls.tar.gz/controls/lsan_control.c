#include <stdlib.h>
int main(void) {
    char *storage=malloc(8);
    if (!storage) return 3;
    *(volatile char*)storage=42;
    free(storage);
    return 0;
}
