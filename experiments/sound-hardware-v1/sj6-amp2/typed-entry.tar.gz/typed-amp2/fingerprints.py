"""Measure identity and content collisions across all twelve authentic SuperJ6 banks."""
import argparse, collections, hashlib, json, struct, zipfile
from pathlib import Path


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("banks",type=Path)
    ap.add_argument("repo",type=Path)
    ap.add_argument("--amp2-payload",type=Path)
    args=ap.parse_args()
    payload=bytearray()
    digest=lambda b:hashlib.sha256(b).hexdigest()
    assert digest(args.banks.read_bytes())=="ab702e00b4cc425c9406b9b2b44e68ba0f40e1125d591fcaa422cc6a8c6272b8"
    cat=args.repo/"experiments/sound-hardware-v1/mapping/results/implementer_brief/public_control_catalog.json"
    assert digest(cat.read_bytes())=="e1be22d91887954da614cf197ef98680d0f21dfc8b9ca9bec1dba0a304f6e711"
    controls={c["id"]:c["identifier"] for c in json.loads(cat.read_text())["controls"]}
    cols=collections.defaultdict(collections.Counter)
    amp2_info=collections.defaultdict(list)
    inputs=0
    with zipfile.ZipFile(args.banks) as z:
        for path in sorted(f for f in z.namelist() if f.startswith("J6presets/") and f.endswith(".bank.json")):
            bank=json.loads(z.read(path))
            for ordinal,p in enumerate(bank["presets"]):
                inputs+=1
                entries=p["parameterValues"]
                fields={e["identifier"]:struct.pack("<f",e["value"]) for e in entries}
                assert len(fields)==len(entries)
                keyed=b"".join(k.encode()+b"\0"+fields[k] for k in sorted(fields))
                amp=b"".join(fields[controls[id]] for id in range(119,123))
                payload.extend(amp)
                for kind,value in dict(bank_uid_and_record_uid=(bank["uuid"],p["uid"]),record_uid=p["uid"],
                    bank_uid_and_name=(bank["uuid"],p["name"]),name=p["name"],all_field_digest=digest(keyed),
                    amp2_words=digest(amp),bank_MIDI_and_program=(bank["midiBankChangeNumber"],p["programChangeNumber"])).items():
                    cols[kind][value]+=1
                amp2_info[digest(amp)].append((bank["name"],p["name"],p["uid"]))
    assert inputs==640
    if args.amp2_payload: args.amp2_payload.write_bytes(payload)
    print(json.dumps(dict(programs=inputs,amp2_payload_sha256=digest(payload),collision_counts={key:dict(unique_keys=len(counts),
        ambiguous_keys=sum(n>1 for n in counts.values()),
        programs_in_ambiguous_keys=sum(n for n in counts.values() if n>1),
        largest_group=max(counts.values())) for key,counts in cols.items()},
        example_same_amp2=list(next(v for v in amp2_info.values() if len(v)>1))[:3]),indent=2))

if __name__=="__main__": main()
