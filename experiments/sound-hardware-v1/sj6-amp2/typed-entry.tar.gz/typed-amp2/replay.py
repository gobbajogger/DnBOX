"""Compile the full app and verify typed AMP2 boundary edits via stereo PCM."""
import argparse, array, hashlib, json, os, subprocess, sys
from pathlib import Path


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("repo",type=Path)
    ap.add_argument("out",type=Path)
    ap.add_argument("--banks-zip",type=Path,required=True)
    args=ap.parse_args()
    repo,out=args.repo.resolve(),args.out.resolve()
    out.mkdir(parents=True,exist_ok=False)
    env=dict(os.environ,SMC_UI_TEST_FILE=str(Path(__file__).resolve().with_name("entry.c")),
             SMC_UI_OUT=str(out/"binary"),X0X_HOST_DEFS="-Itests/host -Wl,--wrap=original_runtime_param")
    def case(owner,field,level,sounding,build=False):
        f=out/f"{owner}-{field}-{level}-{sounding}.pcm"
        e=dict(env,AMP2_OWNER=str(owner),AMP2_FIELD=str(field),AMP2_LEVEL=str(level),
               AMP2_SOUNDING=str(sounding),AMP2_PCM=str(f))
        cmd=["sh","tests/host/smc_ui_test.sh"] if build else [str(out/"binary/test")]
        with (out/("build.log" if build else "run.log")).open("a") as log:
            subprocess.run(cmd,cwd=repo,env=e,stdout=log,stderr=subprocess.STDOUT,check=True)
        return f.read_bytes()
    ref=case(0,119,-1,3,True)
    assert len(ref)==32768*8 and any(ref)
    assert ref==case(0,119,-2,3)
    payload=out/"amp2-fields.f32"
    with (out/"fingerprints.json").open("w") as f:
        subprocess.run([sys.executable,Path(__file__).resolve().with_name("fingerprints.py"),
            args.banks_zip.resolve(),repo,"--amp2-payload",payload],stdout=f,check=True)
    fenv=dict(env,AMP2_OWNER="0",AMP2_FIELD="119",AMP2_LEVEL="-1",AMP2_SOUNDING="3",
              AMP2_PCM=str(out/"unused"),AMP2_FACTORY_DATA=str(payload))
    with (out/"factory.log").open("w") as f:
        subprocess.run([str(out/"binary/test")],cwd=repo,env=fenv,stdout=f,stderr=subprocess.STDOUT,check=True)
    pairs=[]
    for owner in (0,1):
        for field in range(119,123):
            low=case(owner,field,0,3);high=case(owner,field,1,3)
            assert high==case(owner,field,2,3)
            a,b=array.array("i",low),array.array("i",high)
            diff=[i for i,(x,y) in enumerate(zip(a,b)) if x!=y]
            assert diff,(owner,field)
            peer=1<<(1-owner)
            peerlow=case(owner,field,0,peer)
            assert peerlow==case(owner,field,1,peer) and any(peerlow)
            pairs.append(dict(owner=owner,original_field=field,changed_stereo_words=len(diff),
                              first_changed_frame=diff[0]//2,unchanged_sounding_peer_words=len(peerlow)//4,
                              low_sha256=hashlib.sha256(low).hexdigest(),high_sha256=hashlib.sha256(high).hexdigest()))
    (out/"results.json").write_text(json.dumps(dict(frames_per_comparison=32768,sample_rate=44100,
        factory_programs=640,bitwise_factory_field_reads=2560,stereo_owners_per_factory_boundary=2,
        rejected_inputs_and_control_same_pcm=True,last_same_frame_edit_wins=True,rows=pairs),indent=2)+"\n")


if __name__=="__main__": main()
