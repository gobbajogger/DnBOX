/* Host test of the public control submission, slot selector, project cells and full audio block. */
#define SMC_UI_MAIN retained_ui_test
#include "smc_ui_test.c"
#include <math.h>
#include "app/original_runtime.h"
static void flush_block(void) {
    int32_t lr[512]; engine_render(lr,256);
}
/* Link-time observation of the real consumer's calls, with the real function
 * running unchanged. No test hooks are added to the candidate. */
static original_runtime_part *observed[2];
static unsigned calls;
int __real_original_runtime_param(original_runtime_part *,unsigned,float);
int __wrap_original_runtime_param(original_runtime_part *part,unsigned id,float value) {
    if(id>=JUNO6_APP_PARAM_BASE) {
        if(!observed[0]) observed[0]=part;
        else if(part!=observed[0]) observed[1]=part;
        ++calls;
    }
    return __real_original_runtime_param(part,id,value);
}
static void factory(const char *path) {
    FILE *input=fopen(path,"rb"); CHECK(input);
    for(unsigned owner=0;owner<2;++owner)
        CHECK(engine_superj6_edit(owner,ENGINE_SJ6_AMP2_ATTACK,.25f));
    CHECK(calls==0);
    flush_block();
    CHECK(calls==2 && observed[0] && observed[1] && observed[0]!=observed[1]);
    sound_t saved=proj.sound;
    original_runtime_part before0=*observed[0],before1=*observed[1];
    CHECK(!engine_superj6_edit(0,(enum engine_superj6_field)255,.2f));
    CHECK(!engine_superj6_edit(1,(enum engine_superj6_field)118,.2f));
    CHECK(!engine_superj6_edit(1,ENGINE_SJ6_AMP2_RELEASE,NAN));
    CHECK(!memcmp(observed[0],&before0,sizeof before0) && !memcmp(observed[1],&before1,sizeof before1));
    for(unsigned pair=0;pair<320;++pair) {
        float value[2][4];
        CHECK(fread(value,sizeof(float),8,input)==8);
        for(unsigned owner=0;owner<2;++owner)
            for(unsigned slot=0;slot<4;++slot)
                CHECK(engine_superj6_edit(owner,(enum engine_superj6_field)(119+slot),value[owner][slot]));
        unsigned previous=calls;
        /* With no frames processed all eight raw controls remain staged. */
        int32_t lr[2];engine_render(lr,0);
        CHECK(calls==previous);
        engine_render(lr,1); CHECK(calls==previous+8);
        for(unsigned owner=0;owner<2;++owner)
            for(unsigned slot=0;slot<4;++slot) {
                float got;
                CHECK(dnbx_read_raw(&observed[owner]->dsp.juno.synth.core,119+slot,&got)==DNBX_OK);
                CHECK(!memcmp(&got,&value[owner][slot],sizeof got));
            }
    }
    CHECK(fgetc(input)==EOF && !ferror(input) && fclose(input)==0);
    CHECK(memcmp(&saved,&proj.sound,sizeof saved)==0);
    CHECK(engine_superj6_edit(0,ENGINE_SJ6_AMP2_RELEASE,.1234567f));
    CHECK(engine_bass_select_preset(0,ORIGINAL_SOUND_JUNO,2,&proj.sound)==0);
    for(unsigned n=0;n<1024 && engine_bass_preset_pending(0);++n) flush_block();
    CHECK(!engine_bass_preset_pending(0) && engine_bass_preset_index(0)==2);
    float got;
    CHECK(dnbx_read_raw(&observed[0]->dsp.juno.synth.core,122,&got)==DNBX_E_ABSENT);
    CHECK(observed[0]->dsp.juno.synth.pending_amp2_mask==0);
    CHECK(dnbx_read_raw(&observed[1]->dsp.juno.synth.core,122,&got)==DNBX_OK);
    puts("640 original AMP2 tuples; 2560 bitwise field reads after 320 real audio boundaries; invalid whole-owner memcmp; project bytes stable; cold reselect expires owner edits.");
}
int main(void) {
    const char *output=getenv("AMP2_PCM");
    CHECK(output);
    unsigned chosen=(unsigned)atoi(getenv("AMP2_OWNER"));
    unsigned id=(unsigned)atoi(getenv("AMP2_FIELD"));
    int level=atoi(getenv("AMP2_LEVEL"));
    unsigned sounding=(unsigned)atoi(getenv("AMP2_SOUNDING"));
    CHECK(chosen<2 && id>=119 && id<=122 && sounding<=3);
    setup(V_PART,PART_303A);
    CHECK(!engine_superj6_edit(chosen,(enum engine_superj6_field)id,.5f));
    for(unsigned owner=0;owner<2;++owner) {
        CHECK(engine_bass_select_preset(owner,ORIGINAL_SOUND_JUNO,owner,&proj.sound)==0);
        for(unsigned b=0;b<1024 && engine_bass_preset_pending(owner);++b) flush_block();
        CHECK(!engine_bass_preset_pending(owner) && engine_bass_bank(owner)==ORIGINAL_SOUND_JUNO);
    }
    if(getenv("AMP2_FACTORY_DATA")) { factory(getenv("AMP2_FACTORY_DATA")); return 0; }
    sound_t saved=proj.sound;
    if(level==-2) {
        CHECK(!engine_superj6_edit(2,(enum engine_superj6_field)id,.1f));
        CHECK(!engine_superj6_edit(chosen,(enum engine_superj6_field)118,.1f));
        CHECK(!engine_superj6_edit(chosen,(enum engine_superj6_field)123,.1f));
        CHECK(!engine_superj6_edit(chosen,(enum engine_superj6_field)-1,.1f));
        CHECK(!engine_superj6_edit(chosen,(enum engine_superj6_field)id,NAN));
        CHECK(!engine_superj6_edit(chosen,(enum engine_superj6_field)id,-.01f));
        CHECK(!engine_superj6_edit(chosen,(enum engine_superj6_field)id,1.01f));
        engine_project_hold(1);
        CHECK(!engine_superj6_edit(chosen,(enum engine_superj6_field)id,.1f));
        engine_project_hold(0);
    } else if(level>=0) {
        /* Set up unmasked comparisons. The exact edits always precede the
         * queued notes at this audio boundary. */
        const float stage[]={0,.125f,.5f,.125f};
        for(unsigned owner=0;owner<2;++owner)
            for(unsigned i=0;i<4;++i)
                CHECK(engine_superj6_edit(owner,(enum engine_superj6_field)(119+i),stage[i]));
        float value=level==0 ? .0312500037f : .750000060f;
        if(level==2) CHECK(engine_superj6_edit(chosen,(enum engine_superj6_field)id,.0312500037f));
        CHECK(engine_superj6_edit(chosen,(enum engine_superj6_field)id,value));
    }
    CHECK(memcmp(&saved,&proj.sound,sizeof saved)==0);
    for(unsigned owner=0;owner<2;++owner)
        if(sounding & (1u<<owner)) engine_bass_on_velocity(owner,60+7*owner,0,0,105-13*owner);
    FILE *f=fopen(output,"wb"); CHECK(f);
    unsigned nonzero=0;
    for(unsigned block=0;block<128;++block) {
        if(block==64) engine_bass_off(0);
        if(block==96) engine_bass_off(1);
        int32_t lr[512];engine_render(lr,256);
        for(unsigned i=0;i<512;++i) nonzero+=lr[i]!=0;
        CHECK(fwrite(lr,sizeof *lr,512,f)==512);
    }
    CHECK(fclose(f)==0 && nonzero>1000);
    CHECK(memcmp(&saved,&proj.sound,sizeof saved)==0);
}
