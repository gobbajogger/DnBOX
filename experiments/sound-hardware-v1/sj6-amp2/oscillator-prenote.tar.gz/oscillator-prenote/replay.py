"""Replay six original controls on an isolated compact instrument."""
import argparse,array,collections,hashlib,json,os,struct,subprocess,zipfile
from pathlib import Path

def load_cases(archive,output):
    assert hashlib.sha256(archive.read_bytes()).hexdigest()=="ab702e00b4cc425c9406b9b2b44e68ba0f40e1125d591fcaa422cc6a8c6272b8"
    payload=bytearray()
    counts=[collections.Counter(),collections.Counter()]
    forced=[]
    with zipfile.ZipFile(archive) as z:
        for path in sorted(n for n in z.namelist() if n.startswith("J6presets/") and n.endswith(".bank.json")):
            bank=json.loads(z.read(path))
            for case in bank["presets"]:
                v={r["identifier"]:struct.unpack("<f",struct.pack("<f",r["value"]))[0] for r in case["parameterValues"]}
                both=True; missing=False
                for layer in range(2):
                    prefix="neonlayer"+str(layer+1)
                    w=v[prefix+"Waveform"]; a=v.get(prefix+"PWM",-1); e=v.get(prefix+"PWMEnable",-1)
                    assert (a<0)==(e<0)
                    t=int(3.0*w); c=counts[layer]; c["tag"+str(t)]+=1
                    c["explicit PWM"]+=e>=0
                    c["missing PWM, square"]+=e<0 and t==3
                    c["missing PWM, nonsquare"]+=e<0 and t!=3
                    c["square, PWM enabled, nonzero amount"]+=t==3 and e>.5 and a>0
                    both&=(t==3 and e>.5 and a>0)
                    missing|=e<0 and t==3
                    payload.extend(struct.pack("<3f",w,a,e))
                if both: forced.append([bank["name"],case["name"],case["uid"]])
    assert len(payload)==640*2*3*4
    output.write_bytes(payload)
    return dict(layers=counts,authored_nonzero_pwm_on_both_layers=forced)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("repo",type=Path);ap.add_argument("out",type=Path);ap.add_argument("archive",type=Path)
    args=ap.parse_args();repo=args.repo.resolve();out=args.out.resolve();out.mkdir(parents=True,exist_ok=False)
    source=Path(__file__).resolve().with_name("entry.c")
    coverage=load_cases(args.archive,out/"bank.f32")
    env=dict(os.environ,SMC_UI_TEST_FILE=str(source),SMC_UI_OUT=str(out/"bin"),
             X0X_HOST_DEFS="-Itests/host -Wl,--wrap=juno6_init -Wl,--wrap=juno6_render_stereo")
    with (out/"build.log").open("w") as log:
        subprocess.run(["sh","tests/host/smc_ui_test.sh"],cwd=repo,env=dict(env,W_BANK=str(out/"bank.f32")),
                       stdout=log,stderr=subprocess.STDOUT,check=True)
    summary=[]
    for owner in (0,1):
      for layer in (0,1):
        def render(key,w,a,e):
            f=out/f"{owner}-{layer}-{key}"
            subprocess.run([out/"bin/test"],cwd=repo,env=dict(env,W_OWNER=str(owner),W_LAYER=str(layer),
                W_SELECTOR=str(w),W_AMOUNT=str(a),W_ENABLE=str(e),W_PCM=str(f)),check=True)
            data=[]
            for i in (0,1):
                raw=array.array("f");raw.frombytes(Path(str(f)+"."+str(i)).read_bytes())
                assert len(raw)==20480 and all(x==x for x in raw)
                data.extend((raw[0::2],raw[1::2]))
            return data
        reference=render("sine",0,0,0)
        target=owner*2+layer
        def compare(a,b):
            changed=[sum(x!=y for x,y in zip(aa,bb)) for aa,bb in zip(a,b)]
            assert all(changed[i]==0 for i in range(4) if i!=target) and any(a[3-target])
            return changed[target]
        waves=[reference]+[render(name,val,0,0) for name,val in [("triangle",.334),("saw",.667),("square",1)]]
        distances=[compare(waves[a],waves[b]) for a in range(4) for b in range(a+1,4)]
        assert all(x>0 for x in distances)
        off=render("half",1,.5043136477470398,.5); just=render("above",1,.5043136477470398,.5000000596046448)
        small=render("small",1,.12632030248641968,1)
        assert compare(off,waves[3])==0
        assert compare(render("inactive-amount",.667,.99,1),waves[2])==0
        change_gate=compare(off,just);change_amount=compare(small,just)
        assert change_gate and change_amount
        summary.append(dict(owner=owner,layer=layer,wave_pair_changes=distances,
            enabled_changes=change_gate,amount_changes=change_amount,inactive_pwm_changes=0,untargeted_channels_changed=0))
    (out/"results.json").write_text(json.dumps(dict(factory=coverage,frames_per_case=10240,
        scalar_results=(out/"build.log").read_text().splitlines()[-1],musical=summary),indent=2)+"\n")

if __name__=="__main__":main()
