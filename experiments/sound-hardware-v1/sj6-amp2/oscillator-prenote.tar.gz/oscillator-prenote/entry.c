/* Isolated host fixture. Both slots use the actual production selector/render. */
#define SMC_UI_MAIN retained_ui_tests
#include "smc_ui_test.c"
#include "app/original_runtime.h"
#include <math.h>
static juno6_t *slots[2];
static FILE *capture[2];
static unsigned initialized;
void __real_juno6_init(juno6_t *,float);
void __wrap_juno6_init(juno6_t *s,float rate) {
    __real_juno6_init(s,rate);
    if(initialized<2) slots[initialized++]=s;
}
int __real_juno6_render_stereo(juno6_t *,float *,float *,unsigned);
int __wrap_juno6_render_stereo(juno6_t *s,float *l,float *r,unsigned n) {
    int ok=__real_juno6_render_stereo(s,l,r,n);
    for(unsigned o=0;o<2;++o) if(s==slots[o] && capture[o])
        for(unsigned i=0;i<n;++i) { float lr[]={l[i],r[i]}; CHECK(fwrite(lr,4,2,capture[o])==2); }
    return ok;
}
static void block(unsigned n) { int32_t lr[512]; engine_render(lr,n); }
static void open_slots(void) {
    setup(V_PART,PART_303A);
    for(unsigned o=0;o<2;++o) {
        CHECK(engine_bass_select_preset(o,ORIGINAL_SOUND_JUNO,o,&proj.sound)==0);
        for(unsigned b=0;b<1024 && engine_bass_preset_pending(o);++b) block(256);
        CHECK(!engine_bass_preset_pending(o)&&engine_bass_bank(o)==ORIGINAL_SOUND_JUNO);
    }
    CHECK(initialized==2 && slots[0]!=slots[1]);
}
static int tag(float f) { return (int)(3.0*(double)f); }
static double worst;
static unsigned accepted,missing_square;
static void observe(unsigned o,unsigned l,float w,const engine_superj6_pwm *pwm) {
    dnbx_part *s=&slots[o]->core;
    dnbx_layer_params params;
    CHECK(dnbx_get_layer(s,l,&params)==DNBX_OK);
    float raw;
    CHECK(dnbx_read_raw(s,82+l,&raw)==DNBX_OK && !memcmp(&raw,&w,4));
    int t=tag(w);
    CHECK((double)params.waveform*3.0>=t && (unsigned)(3.f*params.waveform)==(unsigned)t);
    CHECK(params.waveform*3.f==(float)t);
    double width=t==3 && pwm && pwm->enable>.5f ? .5-.47*pwm->amount : .5;
    double error=fabs(width-params.pulse_width);
    worst=fmax(worst,error);
    CHECK(error<=6e-8);
    if(pwm) {
        CHECK(dnbx_read_raw(s,78+l,&raw)==DNBX_OK && !memcmp(&raw,&pwm->amount,4));
        CHECK(dnbx_read_raw(s,210+l,&raw)==DNBX_OK && !memcmp(&raw,&pwm->enable,4));
    }
}
static void bank(const char *path) {
    FILE *f=fopen(path,"rb");CHECK(f);sound_t project_before=proj.sound;
    for(unsigned k=0;k<320;++k) {
        float values[2][2][3]; CHECK(fread(values,4,12,f)==12);
        for(unsigned o=0;o<2;++o) for(unsigned l=0;l<2;++l) {
            float *v=values[o][l];
            engine_superj6_pwm pwm={v[1],v[2]}; const engine_superj6_pwm *p=v[2]<0?NULL:&pwm;
            int safe=tag(v[0])!=3||p!=NULL;
            juno6_t before=*slots[o];
            CHECK(engine_superj6_pre_note_wave(o,l,v[0],p)==safe);
            if(safe) ++accepted;
            else { ++missing_square; CHECK(!memcmp(&before,slots[o],sizeof before)); }
        }
        block(1);
        for(unsigned o=0;o<2;++o) for(unsigned l=0;l<2;++l) {
            float *v=values[o][l]; engine_superj6_pwm pwm={v[1],v[2]};
            if(v[2]>=0 || tag(v[0])!=3) observe(o,l,v[0],v[2]<0?NULL:&pwm);
        }
    }
    CHECK(fgetc(f)==EOF && !ferror(f) && fclose(f)==0);
    float edges[]={0,nextafterf(1.f/3.f,0),1.f/3.f,nextafterf(1.f/3.f,1),
                   nextafterf(2.f/3.f,0),2.f/3.f,nextafterf(2.f/3.f,1),nextafterf(1,0),1};
    const float amounts[]={0,.12632030248641968f,.5043136477470398f,.925f,1};
    const float enables[]={nextafterf(.5f,0),.5f,nextafterf(.5f,1)};
    unsigned n=0;
    for(unsigned o=0;o<2;++o) for(unsigned l=0;l<2;++l) {
        for(unsigned i=0;i<sizeof edges/sizeof *edges;++i)
        for(unsigned a=0;a<sizeof amounts/sizeof *amounts;++a)
        for(unsigned e=0;e<sizeof enables/sizeof *enables;++e) {
            engine_superj6_pwm p={amounts[a],enables[e]};
            CHECK(engine_superj6_pre_note_wave(o,l,edges[i],&p)); block(1);
            observe(o,l,edges[i],&p); ++n;
        }
    }
    juno6_t before=*slots[0];engine_superj6_pwm invalid={NAN,1};
    CHECK(!engine_superj6_pre_note_wave(0,0,1,&invalid));
    CHECK(!engine_superj6_pre_note_wave(0,2,0,NULL));
    CHECK(!engine_superj6_pre_note_wave(2,0,0,NULL));
    CHECK(!engine_superj6_pre_note_wave(0,0,NAN,NULL));
    CHECK(!memcmp(&before,slots[0],sizeof before));
    CHECK(!memcmp(&project_before,&proj.sound,sizeof project_before));
    printf("factory_accepted=%u missing_square_rejected=%u boundary_combinations=%u maximum_duty_error=%.12g\n",
           accepted,missing_square,n,worst);
}
static void music(void) {
    const unsigned o=(unsigned)atoi(getenv("W_OWNER")),l=(unsigned)atoi(getenv("W_LAYER"));
    engine_superj6_pwm p={strtof(getenv("W_AMOUNT"),NULL),strtof(getenv("W_ENABLE"),NULL)};
    float select=strtof(getenv("W_SELECTOR"),NULL);
    /* Calibration only. Separate the true core's layers at its stereo output
     * and neutralize stock LFO modulation so base duty is independently observable. */
    for(unsigned i=0;i<2;++i) for(unsigned j=0;j<2;++j) {
        dnbx_layer_params params; CHECK(dnbx_get_layer(&slots[i]->core,j,&params)==DNBX_OK);
        params.pan=j?1:-1; params.lfo_pwm_depth=0;
        CHECK(dnbx_set_layer(&slots[i]->core,j,&params)==DNBX_OK);
    }
    CHECK(engine_superj6_pre_note_wave(o,l,select,&p));
    for(unsigned i=0;i<2;++i) {
        char path[512];snprintf(path,sizeof path,"%s.%u",getenv("W_PCM"),i);
        capture[i]=fopen(path,"wb");CHECK(capture[i]);
        engine_bass_on_velocity(i,48+7*i,0,0,103-10*i);
    }
    for(unsigned i=0;i<40;++i) {
        if(i==12) {
            juno6_t before=*slots[o];
            CHECK(!engine_superj6_pre_note_wave(o,l,select,&p));
            CHECK(!memcmp(&before,slots[o],sizeof before));
        }
        if(i==24) { engine_bass_off(0);engine_bass_off(1); }
        block(256);
    }
    for(unsigned i=0;i<2;++i) CHECK(!fclose(capture[i]));
}
int main(void) {
    open_slots();
    if(getenv("W_BANK")) bank(getenv("W_BANK")); else music();
}
