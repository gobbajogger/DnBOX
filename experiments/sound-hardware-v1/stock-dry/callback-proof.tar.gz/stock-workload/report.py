#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
import array
import csv
import datetime as dt
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import statistics
import subprocess as sp
import sys
fixture = Path(__file__).resolve().parent
build = Path(sys.argv[1]).resolve()
protocol = json.loads((fixture/'protocol.json').read_text())
rate = protocol['sample_rate']
frames = protocol['frames_per_callback']
blocks = protocol['callbacks_per_scene']
budget_num = frames*10**9
def utc(): return dt.datetime.now(dt.timezone.utc).isoformat()
def stats(v):
    a = sorted(v)
    return dict(min=a[0], median=statistics.median(a), p99=a[math.ceil(.99*len(a))-1],
                p999=a[math.ceil(.999*len(a))-1], max=a[-1], mean=statistics.fmean(a))
def audio(path):
    raw = path.read_bytes()
    assert len(raw) == blocks*frames*2*4
    words = array.array('i')
    words.frombytes(raw)
    assert words.itemsize == 4
    assert min(words) >= -8388608 and max(words) <= 8388607
    summary = {}
    for ch, seq in [('left',words[::2]),('right',words[1::2])]:
        peak = max(abs(min(seq)),abs(max(seq)))/8388608.0
        rms = math.sqrt(sum(int(x)*x for x in seq)/len(seq))/8388608.0
        assert math.isfinite(rms) and rms >= protocol['minimum_rms']
        summary[ch] = dict(peak_fs=peak,rms_fs=rms,peak_dbfs=20*math.log10(peak),rms_dbfs=20*math.log10(rms))
    return {'sha256':hashlib.sha256(raw).hexdigest(),'stereo_frames':len(words)//2,'levels':summary}
cpu_lines = Path('/proc/cpuinfo').read_text().splitlines()
report = {
    'source_commit': 'fcf82f607cd35a263c9923071aaa25066ff6d60f',
    'protocol_sha256': hashlib.sha256((fixture/'protocol.json').read_bytes()).hexdigest(),
    'build_inputs_manifest': 'build.json',
    'platform': dict(kernel=platform.release(), arch=platform.machine(), cpu=next(s.split(':',1)[1].strip() for s in cpu_lines if s.startswith('model name')),
                     affinity=sorted(os.sched_getaffinity(0)), scheduler=os.sched_getscheduler(0),
                     byteorder=sys.byteorder),
    'start_utc':utc(), 'loadavg_start':os.getloadavg(), 'scenes':[]}
for ident, name in enumerate(protocol['scenes']):
    base = build/name
    base.mkdir(exist_ok=True)
    statsfile, pcm = base/'timing.csv', base/'render.s32'
    record = dict(scene=name,start_utc=utc(),loadavg_start=os.getloadavg())
    cp = sp.run([str(build/'timed'),str(ident),'1',str(statsfile),str(pcm)],cwd=base,capture_output=True,text=True)
    if cp.returncode:
        raise RuntimeError((name,cp.returncode,cp.stdout,cp.stderr))
    record.update(json.loads(cp.stdout.splitlines()[-1]))
    record.update(end_utc=utc(),loadavg_end=os.getloadavg())
    with statsfile.open() as f:
        rows = [[int(x) for x in row] for row in csv.reader(f)]
    assert len(rows) == blocks
    cpu,wall,start_delay,scheduled = zip(*rows)
    record.update(callback_cpu_ns=stats(cpu),callback_wall_ns=stats(wall),
                  wake_lateness_ns=stats(start_delay),max_scheduled_finish_lateness_ns=max(scheduled),
                  callback_cpu_misses=sum(x*rate>budget_num for x in cpu),
                  callback_wall_misses=sum(x*rate>budget_num for x in wall),
                  scheduled_finish_misses=sum(x>0 for x in scheduled),
                  missed_scheduled_blocks=[i for i,d in enumerate(scheduled) if d])
    record['audio'] = audio(pcm)
    record['host_timing_pass'] = not any(record[k] for k in ('callback_cpu_misses','callback_wall_misses','scheduled_finish_misses'))
    (base/'timing.csv.gz').write_bytes(gzip.compress(statsfile.read_bytes(),mtime=0))
    report['scenes'].append(record)
    print(name,'TIMED',record['host_timing_pass'], record['callback_cpu_misses'],record['callback_wall_misses'],record['scheduled_finish_misses'], flush=True)
report['timing_end_utc'] = utc()
for ident, r in enumerate(report['scenes']):
    base = build/r['scene']
    cp = sp.run([str(build/'finite'),str(ident),'0',str(base/'finite.csv'),str(base/'finite.s32')],cwd=base,capture_output=True,text=True)
    if cp.returncode: raise RuntimeError((r['scene'],cp.returncode,cp.stderr))
    raw = (base/'finite.s32').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == r['audio']['sha256']
    r.update(preconversion_nonfinite_samples=0, timed_pcm_matches_finite_check=True)
report['end_utc'] = utc()
report['pass'] = all(r['host_timing_pass'] for r in report['scenes'])
(build/'report.json').write_text(json.dumps(report,indent=2)+'\n')
sys.exit(0 if report['pass'] else 1)
