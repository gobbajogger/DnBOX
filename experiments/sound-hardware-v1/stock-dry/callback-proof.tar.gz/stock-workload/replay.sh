#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
set -eu
fixture=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
repo=$(CDPATH= cd -- "$1" && pwd)
mkdir -p "$2"
out=$(CDPATH= cd -- "$2" && pwd)
python3 "$fixture/build.py" "$repo" "$out"
python3 - "$fixture/build.json" "$out/build.json" <<'PY'
import json,sys
expected, actual = [json.load(open(p)) for p in sys.argv[1:]]
a, b = expected['inputs_sha256'], actual['inputs_sha256']
changed = [k for k in sorted(set(a)|set(b)) if a.get(k)!=b.get(k)]
if changed: raise SystemExit('Qualified source differs: '+', '.join(changed))
PY
python3 "$fixture/report.py" "$out"
