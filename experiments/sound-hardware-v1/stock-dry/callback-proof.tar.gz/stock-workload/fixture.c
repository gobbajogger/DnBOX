/* SPDX-License-Identifier: GPL-3.0-only */
#define main simulator_main
#include "host/x0x_host.c"
#undef main
#include <assert.h>
#include <errno.h>

#ifndef FS
#define FS 44100u
#endif
#define fm1_ticks plat_ticks24
#define FM1_TICKS_PER_US 24u
#define audio_cpu_pct cpu_pct
#define audio_peak_pct cpu_peak
#include "callback.inc"

extern unsigned check_owner(unsigned owner, const unsigned char expected[6]);
enum { BLOCKS = 2048, RATE = 44100 };
static uint64_t ticks(clockid_t id)
{
    struct timespec t;
    assert(clock_gettime(id, &t) == 0);
    return (uint64_t)t.tv_sec * 1000000000ull + t.tv_nsec;
}
static void sleep_until(uint64_t ns)
{
    const struct timespec t = { ns / 1000000000ull, ns % 1000000000ull };
    int rc;
    do { rc = clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &t, NULL); } while (rc == EINTR);
    assert(rc == 0);
}
static void midi(unsigned source, unsigned channel, unsigned key, unsigned vel)
{
    unsigned type = vel ? 9 : 8;
    assert(mi_w - mi_r < MQ);
    min_q[mi_w++ % MQ] = type | source << 4 | (type * 16u + channel) << 8 | key << 16 | vel << 24;
}
static const unsigned char chords[2][2][6] = {
    {{36,43,48,52,55,59}, {38,45,50,53,57,60}},
    {{61,65,68,72,77,80}, {62,66,69,73,78,81}}
};
static void chord(unsigned group, int release)
{
    for (unsigned owner = 0; owner < 2; ++owner)
        for (unsigned key = 0; key < 6; ++key)
            midi(owner, 2 + owner, chords[owner][group][key], release ? 0u : 76u + 3u * key + 5u * owner);
}
static unsigned groove(unsigned step)
{
    unsigned hits = 1;
    midi(0, 9, (step % 4 == 2) ? 46 : 42, step & 1 ? 60 : 90);  /* 909 hat */
    if (step % 4 == 0) { midi(1, 10, 36, 120); ++hits; }        /* 808 kick */
    if (step % 8 == 4) { midi(0, 9, 38, 100); ++hits; }         /* 909 snare */
    if (step % 8 == 6) { midi(1, 10, 39, 83); ++hits; }         /* 808 clap */
    if (step % 16 == 15) { midi(0, 9, 49, 82); ++hits; }       /* 909 crash */
    return hits;
}
int main(int argc, char **argv)
{
    assert(argc == 5);
    const int mixed = atoi(argv[1]), paced = atoi(argv[2]);
    FILE *stats = fopen(argv[3], "w"), *audio = fopen(argv[4], "wb");
    assert(stats && audio);
    boot();
    plat_cpu2_set(1);
    engine_guard_enable(0);
    master = 3072;
    engine_usb_full(1);
    seq.ch[PART_909] = 9; seq.ch[PART_808] = 10;
    seq.ch[PART_303A] = 2; seq.ch[PART_303B] = 3; seq.ch[PART_BRK] = 12;
    for (unsigned owner = 0; owner < 2; ++owner)
        assert(engine_bass_select_preset(owner, ORIGINAL_SOUND_SYNTHONE, 0, &proj.sound) == 0);
    int32_t output[1024];
    for (int i = 0; i < 8; ++i) render_block(output);
    for (unsigned owner = 0; owner < 2; ++owner)
        assert(engine_bass_bank(owner) == ORIGINAL_SOUND_SYNTHONE && engine_bass_preset_index(owner) == 0);
    unsigned group = 0, hits = 0, changes = 0;
    int previous_step = -1;
    static uint64_t times[BLOCKS][4];
    unsigned owned_callbacks = 0, meter_or[4] = {0};
    uint64_t start = ticks(CLOCK_MONOTONIC) + 20000000u;
    for (unsigned block = 0; block < BLOCKS; ++block) {
        uint64_t frame = (uint64_t)block * 512u;
        uint64_t due = start + frame * 1000000000ull / RATE;
        uint64_t deadline = start + (frame + 512u) * 1000000000ull / RATE;
        now_ms = (uint32_t)(frame * 1000u / RATE);
        int step = (int)(frame * 8u / RATE);  /* 120 BPM sixteenths */
        if (step != previous_step) {
            if (!(step % 16)) {
                if (step) { chord(group, 1); group ^= 1; }
                chord(group, 0);
                ++changes;
            }
            if (mixed) hits += groove((unsigned)step);
            previous_step = step;
        }
        for (int p = 0; p < 4; ++p) eng_peak[p] = 0;
        if (paced) sleep_until(due);
        uint64_t t0 = ticks(CLOCK_MONOTONIC), c0 = ticks(CLOCK_THREAD_CPUTIME_ID);
        render_block(output);
        uint64_t c1 = ticks(CLOCK_THREAD_CPUTIME_ID), t1 = ticks(CLOCK_MONOTONIC);
        times[block][0] = c1 - c0;
        times[block][1] = t1 - t0;
        times[block][2] = paced ? t0 - due : 0;
        times[block][3] = paced && t1 > deadline ? t1 - deadline : 0;
        assert(check_owner(0, chords[0][group]) + check_owner(1, chords[1][group]) == 12);
        assert(!plat_midi_pending());
        ++owned_callbacks;
        for (int p = 0; p < 4; ++p) meter_or[p] |= eng_peak[p];
        assert(fwrite(output, sizeof *output, 1024, audio) == 1024);
    }
    assert(owned_callbacks == BLOCKS && meter_or[2] && meter_or[3]);
    assert(mixed ? (meter_or[0] && meter_or[1]) : !(meter_or[0] || meter_or[1]));
    for (unsigned i = 0; i < BLOCKS; ++i)
        fprintf(stats, "%llu,%llu,%llu,%llu\n", (unsigned long long)times[i][0],
                (unsigned long long)times[i][1], (unsigned long long)times[i][2], (unsigned long long)times[i][3]);
    printf("{\"callbacks_observed_with_correct_12_voices\":%u,\"chord_onsets\":%u,"
           "\"drum_hits\":%u,\"audible_part_mask\":%u}\n", owned_callbacks, changes, hits,
           !!meter_or[0] | (!!meter_or[1] << 1) | (!!meter_or[2] << 2) | (!!meter_or[3] << 3));
    assert(!fclose(stats) && !fclose(audio));
    return 0;
}
