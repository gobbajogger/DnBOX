#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess as sp
import sys
root, out = (Path(a).resolve() for a in sys.argv[1:3])
fixture = Path(__file__).resolve().parent
out.mkdir(parents=True, exist_ok=True)
cc = os.environ.get('CC', 'cc')
def run(args, **kwargs):
    return sp.run(args, cwd=root, check=True, **kwargs)
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
src = (root / 'firmware/src/app/main_fm1.c').read_bytes()
(out/'callback.inc').write_bytes(src[src.index(b'#define HALF_FRAMES'):src.index(b'\nvoid fm1_alnk0_irq')])
eng = (root/'firmware/src/app/engine.c').read_bytes()
needle = b'float l = out_l[i], r = out_r[i];'
assert eng.count(needle) == 1
(out/'engine-finite.c').write_bytes(eng.replace(needle, needle + b' if (!__builtin_isfinite(l) || !__builtin_isfinite(r)) __builtin_abort();'))
run(['sh', 'host/build_host.sh', '--generate-only'])
closure = run(['sh','-c','. tests/host/original_build.sh && printf "%s\\n" "$ORIGINAL_FLAGS" "$ORIGINAL_SOURCES"'], capture_output=True, text=True).stdout.splitlines()
flags, sources = map(shlex.split, closure)
flags = ['-O2','-std=c99','-DX0X_HOST','-Wno-unused-function','-Wno-unused-parameter',
         *flags,'-I.','-Ifirmware/src','-Ifirmware/src/app','-Ifirmware/src/dsp','-Ibuild/gen','-I'+str(out)]
objects = []
deps = set()
def compile(path, ident, extra=()):
    obj, dep = out/(ident+'.o'), out/(ident+'.d')
    run([cc,*flags,*extra,'-MMD','-MF',str(dep),'-c',str(path),'-o',str(obj)])
    deps.update((root/x).resolve() for x in shlex.split(dep.read_text().replace('\\\n',' ').split(':',1)[1]))
    return str(obj)
for source in sources:
    if source != 'firmware/src/app/engine.c':
        objects.append(compile(source,source.replace('/','_')))
objects.append(compile(fixture/'fixture.c','fixture'))
for ident, path in [('timed',root/'firmware/src/app/engine.c'),('finite',out/'engine-finite.c')]:
    engine = compile(fixture/'observer.c','observer-'+ident,['-DENGINE_SOURCE="'+str(path)+'"'])
    run([cc,*objects,engine,'-lm','-o',str(out/ident)])
def label(path):
    for base,prefix in ((fixture,'fixture/'),(out,'build/'),(root,'')):
        if path.is_relative_to(base): return prefix+str(path.relative_to(base))
    return str(path)
pins = {label(p):digest(p) for p in sorted(deps)}
for p in ['firmware/src/app/main_fm1.c','host/build_host.sh','tests/host/original_build.sh','tools/build.py']:
    pins[p] = digest(root/p)
for p in ['protocol.json','build.py','report.py']:
    pins['fixture/'+p] = digest(fixture/p)
(out/'build.json').write_text(json.dumps({'flags':flags[:-1]+['-I<build>'],'compiler':run([cc,'--version'],capture_output=True,text=True).stdout.splitlines()[0],
    'inputs_sha256':pins,'binaries_sha256':{p:digest(out/p) for p in ('timed','finite')}},indent=2,sort_keys=True)+'\n')
