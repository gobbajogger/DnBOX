/* SPDX-License-Identifier: GPL-3.0-only */
/* The timing executable compiles the engine source without inserting sample checks. */
#include ENGINE_SOURCE
#include <assert.h>

unsigned check_owner(unsigned owner, const unsigned char expected[6])
{
    const original_runtime_part *part = &original_bass[owner];
    const s1_dry_part *synth = &part->dsp.synthone;
    unsigned found = 0;
    assert(part->kind == ORIGINAL_SOUND_SYNTHONE && part->status == ORIGINAL_RUNTIME_OK);
    for (unsigned slot = 0; slot < S1_CORE_VOICES; ++slot) {
        assert(synth->voice[slot].started && synth->voice[slot].gate && synth->down[slot]);
        for (unsigned i = 0; i < 6; ++i)
            if (synth->note[slot] == expected[i]) found |= 1u << i;
    }
    assert(found == 63);
    return S1_CORE_VOICES;
}
