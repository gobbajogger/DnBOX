"""Verify every reference digest and produce the component report from completed comparisons."""
import argparse,collections,hashlib,json,re,subprocess
from pathlib import Path
ap=argparse.ArgumentParser()
for name in ('rows','commands','historical','contract','binary','out'):ap.add_argument(name,type=Path)
a=ap.parse_args()
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ordered=[json.loads(line) for line in a.rows.read_text().splitlines()]
assert len(ordered)==694 and [x['index'] for x in ordered]==list(range(694))
records=read(a.commands)['cases'];historical={r['file']:r for r in read(a.historical)['files']}
assert len(records)==694 and len(historical)==1388
count=collections.defaultdict(list)
for r,source in zip(ordered,records):
 for name in ('bank','preset_index','uid','name'):assert r[name]==source[name]
 assert len(source['commands'])==144 and r['frames']==96000
 for kind in ('compact','original'):
  ref=historical['preset-%02d-%s.f32le.pcm'%(r['index'],kind)]
  assert ref['bytes']==768000 and r['original_sha256']==ref['sha256']
 assert r['bit_identical']==(r['original_sha256']==r['alternative_sha256'])
 assert r['passed']==all(r[ch]['passed'] for ch in ('left','right'))
 count[r['bank']].append(r)
def summary(group):
 result=dict(programs=len(group),both_channels_passed=sum(r['passed'] for r in group),bit_identical=sum(r['bit_identical'] for r in group),reference_frames=sum(r['frames'] for r in group))
 for key in ('level_db','spectral_rms_db'):
  candidates=[(abs(r[ch][key]),r['index'],r['name'],ch,r[ch][key]) for r in group for ch in ('left','right') if r[ch][key] is not None]
  v,i,name,ch,signed=max(candidates)
  result['worst_'+key]=dict(absolute=v,signed=signed,index=i,preset=name,channel=ch)
 return result
binary_calls=[];fn=''
for line in subprocess.check_output(['objdump','-d','-C','--no-show-raw-insn',a.binary],text=True).splitlines():
 m=re.match(r'([\da-f]+) <(.*)>:$',line)
 if m:fn=m[2]
 elif re.search(r'\b(?:callq?|jmpq?)\b.*<__wrap_sp_moogladder_compute>$',line):
  binary_calls.append(dict(caller=fn,instruction=line.strip()))
assert len(binary_calls)==5 and sum(r['caller'].startswith('SourceFx::frame') for r in binary_calls)==2
out=dict(scope='All linked calls to the Soundpipe Moog low-pass implementation in the independently recovered factory graph. Both delay-input channels and each compiled voice implementation use the substitution. The original Synth One note/control, routing, wet processing apart from that low-pass, and final output remain on the reference graph. This is a component test, not a stock preset implementation or a callback timing test.',contract=read(a.contract),inputs={k:sha(v) for k,v in vars(a).items() if k!='out'},verified_historical_file_hashes=1388,commands=694*144,summary=summary(ordered),per_bank={k:summary(g) for k,g in count.items()},failures=[dict(index=r['index'],bank=r['bank'],name=r['name'],left=r['left'],right=r['right']) for r in ordered if not r['passed']],linked_calls=binary_calls)
a.out.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out['summary']));print('failures',len(out['failures']),'banks',len(count))
