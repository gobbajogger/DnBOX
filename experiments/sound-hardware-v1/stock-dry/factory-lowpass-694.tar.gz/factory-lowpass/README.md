# Bounded Synth One low-pass in the full original factory comparison graph

Both stereo channels of all 694 original programs across 12 banks passed the predeclared 1 dB RMS and 3 dB spectral RMS limits. All 66,624,000 stereo frames per arm were finite. The largest level error was 0.000083664 dB on Red Minor, right channel. The largest spectral RMS error was 0.050950 dB on The Pad, right channel. Ninety-six programs produced identical stereo PCM. The other 598 differed within those thresholds.

Each program uses its original 144 ordered parameter commands and the unchanged two-second, 48 kHz note/velocity stimulus. Both paths within each arm independently matched at every output word. For the unmodified arm, all 1,388 original and compact output filenames, lengths and digests matched the historical PCM manifest at their original absolute program indices. The final six-record batch covers presets 688 through 693. The contract was written before the first eight-program run. No gain fitting or event alignment was applied in scoring.

The executable replaces the Soundpipe low-pass call with the DnBOX alternate low-pass. Disassembly confirms five linked call sites, one in each of three voice implementations and one on each delay-input channel in the original FX graph. All other voice, control, effect and output logic stays in the reference graph. The comparison tests that substitution on the actual factory stimuli. It provides neither a production factory selector nor complete independent implementations of these effects. It provides no callback deadline result.

## Reproduction

Follow assets/test-inputs/synthone/README.md in the lane checkout to materialize the verified original source, tables and current generic factory build. BUILD must contain the compiled factory-test, its factory-build-commands.json, the closure, original command binary in commands/ and factory-inputs/. Recompile the recovered factory graph on the local machine before relinking. Generate ORIGINAL-PRESET-COMMANDS.json from the pinned factory files. In a separate ca0c00a4e5863132de4a66f5d1c477c14d699be5 checkout apply voice.patch and generate the normal drum table header. Run the scripts using a fresh output directory.

    python3 replay.py BUILD ALTERNATE_CHECKOUT GENERATED_HEADERS ORIGINAL-PRESET-COMMANDS.json NEW_OUTPUT
    python3 report.py NEW_OUTPUT/programs.jsonl ORIGINAL-PRESET-COMMANDS.json LANE_CHECKOUT/docs/sound/v2-synthone-factory-pcm-manifest.json contract.json NEW_OUTPUT/factory-filter NEW_OUTPUT/summary.json

The JSONL keeps both channel scores and actual input/output hashes for every program. summary.json contains the results by bank, five linked call sites, input pins and both extrema. The preceding live-cutoff-proof packet provides the independently generated coefficient grid, original filter transition stimuli and stock board sizes. Source and derived numerical receipts only.
