"""Run the genuine factory control stream on the two host graphs and score the low-pass replacement."""
import argparse, hashlib, json, struct, subprocess, tempfile
from pathlib import Path
import numpy as np
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def score(a,b,rate,c):
    a=a.astype(float);b=b.astype(float)
    if not np.any(a) or not np.any(b):
        equal=bool(np.array_equal(a,b))
        return dict(silent=True,passed=equal,level_db=0.0 if equal else None,spectral_rms_db=0.0 if equal else None)
    frame=c['fft'];hop=c['hop']
    def spec(x):
        v=np.lib.stride_tricks.sliding_window_view(x,frame)[::hop]
        return np.sqrt(np.mean(np.abs(np.fft.rfft(v*np.hanning(frame)))**2,axis=0))
    sr,sc=spec(a),spec(b);f=np.fft.rfftfreq(frame,1/rate)
    floor=max(sr.max()*10**(c['floor_db']/20),1e-12)
    use=((sr>floor)|(sc>floor))&(f>=c['min_hz'])&(f<=c['max_hz'])
    ls=float(np.sqrt(np.mean((20*np.log10(np.maximum(sc[use],floor)/np.maximum(sr[use],floor)))**2))) if use.any() else 0
    level=float(10*np.log10(np.mean(b*b)/np.mean(a*a)))
    return dict(silent=False,level_db=level,spectral_rms_db=ls,passed=abs(level)<=c['absolute_level_db'] and ls<=c['spectral_rms_db'])
def main():
    ap=argparse.ArgumentParser()
    for arg in ['build','candidate','gen','manifest','out']:ap.add_argument(arg,type=Path)
    ap.add_argument('--limit',type=int,default=694)
    a=ap.parse_args();out=a.out.resolve();out.mkdir(exist_ok=True,parents=True)
    build=a.build.resolve();src=a.candidate.resolve()/'firmware/src/dsp'
    root=Path(__file__).resolve().parent;con=json.loads((root/'contract.json').read_bytes())['criteria']
    inc=build/'closure/experiment/audiokit-4.9.2/AudioKit/Core/Soundpipe'
    obj=out/'replacement.o';exe=out/'factory-filter'
    subprocess.run(['cc','-O2','-std=gnu11','-fno-fast-math','-ffp-contract=off','-ffunction-sections','-fdata-sections','-DX0X_HOST','-DX0X_DRUM_TABLES_DEFINE','-DNO_LIBSNDFILE','-I'+str(inc),'-I'+str(inc/'lib/dr_wav'),'-I'+str(src),'-I'+str(a.gen.resolve()),'-c',root/'replace-filter.c','-o',obj],check=True)
    link=json.loads((build/'factory-build-commands.json').read_bytes())[-1]
    link[link.index('-o')+1]=str(exe)
    link[1:1]=[str(obj),'-Wl,--wrap=sp_moogladder_compute']
    subprocess.run(link,check=True)
    records=json.loads(a.manifest.read_bytes())['cases']
    stream=build/'commands/preset-commands.bin';data=stream.read_bytes();magic,n=struct.unpack_from('<II',data);assert magic==0x53315043 and n==len(records)==694
    pos=8;encoded=[]
    for record in records:
        start=pos;count,=struct.unpack_from('<I',data,pos);pos+=4
        assert count==len(record['commands'])
        for expected in record['commands']:
            i,v=struct.unpack_from('<If',data,pos);pos+=8
            assert [i,v]==expected
        encoded.append(data[start:pos])
    assert pos==len(data)
    outrows=out/'programs.jsonl'
    if outrows.exists():raise RuntimeError('Choose a fresh result directory')
    assets=build/'factory-inputs';saved=0
    for begin in range(0,min(a.limit,n),8):
        end=min(begin+8,a.limit,n)
        with tempfile.TemporaryDirectory(dir=out) as tmp:
            tmp=Path(tmp);cmd=tmp/'commands.bin';cmd.write_bytes(struct.pack('<II',magic,end-begin)+b''.join(encoded[begin:end]))
            for label,app in [('original',build/'factory-test'),('alternative',exe)]:
                dest=tmp/label;dest.mkdir()
                with (out/(label+'.log')).open('a') as log:
                    subprocess.run([app,assets/'public-morphs.f32',assets/'compact.bin',cmd,dest],stdout=log,stderr=subprocess.STDOUT,check=True)
                assert json.loads((dest/'progress.json').read_bytes())['completed_presets']==end-begin
            with outrows.open('a') as f:
                for idx in range(begin,end):
                    reg=records[idx];same=idx-begin;arr=[];hashes=[]
                    for label in ('original','alternative'):
                        d=tmp/label;pa=d/f'preset-{same:02d}-original.f32le.pcm';pb=d/f'preset-{same:02d}-compact.f32le.pcm'
                        assert pa.stat().st_size==768000 and digest(pa)==digest(pb)
                        v=np.fromfile(pa,'<f4').reshape(-1,2);assert np.isfinite(v).all()
                        hashes.append(digest(pa));arr.append(v)
                    left=score(arr[0][:,0],arr[1][:,0],48000,con);right=score(arr[0][:,1],arr[1][:,1],48000,con)
                    record=dict(index=idx,bank=reg['bank'],preset_index=reg['preset_index'],name=reg['name'],uid=reg['uid'],commands_sha256=hashlib.sha256(encoded[idx]).hexdigest(),original_sha256=hashes[0],alternative_sha256=hashes[1],frames=96000,bit_identical=hashes[0]==hashes[1],left=left,right=right,passed=left['passed'] and right['passed'])
                    print(json.dumps(record),file=f)
            saved=end
        print(f'{saved} records checked',flush=True)
    print('terminal',saved,'manifest',digest(a.manifest),'stream',digest(stream),'contract',digest(root/'contract.json'))
if __name__=='__main__':main()
