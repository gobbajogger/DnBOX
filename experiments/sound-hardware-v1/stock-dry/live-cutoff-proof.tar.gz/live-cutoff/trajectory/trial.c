#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "soundpipe.h"
/* The low-pass stage is intentionally isolated from the oscillator/ADSR. */
#include "s1_dry_voice.c"
int main(int argc,char **argv)
{
    if(argc!=9) return 2;
    float ahz=strtof(argv[1],NULL),bhz=strtof(argv[3],NULL);
    unsigned na=atoi(argv[2]), nb=atoi(argv[4]);
    float resonance=strtof(argv[5],NULL),halftime=strtof(argv[6],NULL);
    unsigned frames=atoi(argv[7]);
    FILE *out=fopen(argv[8],"wbx");if(!out) return 2;
    sp_data sp={0}; sp.sr=44100;
    sp_port *port; sp_moogladder *ref;
    if(sp_port_create(&port)!=SP_OK || sp_port_init(&sp,port,halftime)!=SP_OK ||
       sp_moogladder_create(&ref)!=SP_OK || sp_moogladder_init(&sp,ref)!=SP_OK) return 3;
    port->htime=halftime; sp_port_reset(&sp,port,&ahz);
    s1_dry_voice v; s1_dry_reset(&v); s1_dry_controls c; s1_dry_frozen_controls(&c);
    c.cutoff_hz=ahz;c.resonance=resonance;
    if(s1_dry_configure(&v,&c)!=S1_DRY_OK) return 4;
    ref->res=resonance;
    for(unsigned i=0;i<frames;++i) {
        float command=i%(na+nb)<na?ahz:bhz,cutoff,original,actual;
        float input=(float)(0.125*sin((6.2831853071795864769*261.625565/44100.0)*i));
        if(sp_port_compute(&sp,port,&command,&cutoff)!=SP_OK)return 5;
        ref->freq=cutoff;
        if(sp_moogladder_compute(&sp,ref,&input,&original)!=SP_OK)return 5;
        if(cutoff!=v.prepared.cached_cutoff_hz)prepare_filter(&v.prepared,cutoff);
        float a=filter_substep(&v,input), b=filter_substep(&v,input);
        actual=0.5f*(a+b);
        float values[]={cutoff,original,actual};
        if(fwrite(values,sizeof values,1,out)!=1)return 5;
    }
    sp_port_destroy(&port); sp_moogladder_destroy(&ref);
    return fclose(out)!=0;
}
