"""Evaluate cutoff trajectories through a separately linked reference low-pass."""
import argparse, hashlib, json, subprocess
from pathlib import Path
import numpy as np

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def analyse(path, contract):
    v=np.fromfile(path,'<f4').reshape(-1,3)
    assert len(v)==contract['frames']
    ctl,ref,y=v.astype(float).T
    finite=np.isfinite(y);assert np.all(np.isfinite(ref)) and np.all(np.isfinite(ctl))
    a=contract['criteria']
    res=dict(first_nonfinite=(int(np.flatnonzero(~finite)[0]) if not finite.all() else None),
             cutoff_min=float(ctl.min()),cutoff_max=float(ctl.max()),original_peak=float(abs(ref).max()),passed=False)
    if not finite.all():return res
    res['candidate_peak']=float(abs(y).max())
    res['rms_db']=float(10*np.log10(np.mean(y*y)/np.mean(ref*ref)))
    def spec(x):
        w=np.lib.stride_tricks.sliding_window_view(x,a['fft'])[::a['hop']]
        return np.sqrt(np.mean(abs(np.fft.rfft(w*np.hanning(a['fft'])))**2,axis=0))
    sr,sy=spec(ref),spec(y);f=np.fft.rfftfreq(a['fft'],1/contract['sample_rate'])
    floor=sr.max()*10**(a['floor_db']/20);lo,hi=a['band_hz']
    used=(f>=lo)&(f<=hi)&((sr>floor)|(sy>floor))
    res['spectral_rms_db']=float(np.sqrt(np.mean((20*np.log10(np.maximum(sy[used],floor)/np.maximum(sr[used],floor)))**2)))
    res['passed']=abs(res['rms_db'])<=a['rms_db_max'] and res['spectral_rms_db']<=a['spectral_rms_db_max']
    return res
def main():
    p=argparse.ArgumentParser()
    for q in ['repo','recovery','staged','gen','output']:p.add_argument(q,type=Path)
    args=p.parse_args();here=Path(__file__).resolve().parent
    repo=args.repo.resolve();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    seed=args.recovery.resolve()/'comparison_only/reference_filter_inputs/full_dry_preparation'
    lib=seed/'staged_reference/closure/experiment/audiokit-4.9.2/AudioKit/Core/Soundpipe'
    names=['build/dependency-007.o','build/dependency-010.o']
    pins=json.loads((repo/'experiments/sound-hardware-v1/stock-dry/comparison-inputs.json').read_bytes())
    obj=[seed/q for q in names]
    for f,n in zip(obj,names):assert digest(f)==pins[n]
    dsp=args.staged.resolve()/'firmware/src/dsp';exe=out/'trial'
    subprocess.run(['cc','-std=gnu11','-O2','-fno-fast-math','-ffp-contract=off','-fno-builtin','-ffunction-sections','-fdata-sections','-DNO_LIBSNDFILE','-DX0X_HOST','-I'+str(lib),'-I'+str(lib/'lib/dr_wav'),'-I'+str(dsp),'-I'+str(args.gen.resolve()),'-DX0X_DRUM_TABLES_DEFINE',here/'trial.c',dsp/'dnbx_s1_envelope.c',*obj,'-Wl,--gc-sections','-lm','-o',exe],check=True)
    con=json.loads((here/'contract.json').read_bytes())
    rows=[]
    for s in con['schedules']:
        for idx,t in enumerate(con['half_times_s']):
            dest=out/(s['name']+'-'+str(idx)+'.f32')
            subprocess.run([exe,str(s['a']),str(s['na']),str(s['b']),str(s['nb']),str(s['res']),str(t),str(con['frames']),dest],check=True)
            rows.append(dict(name=s['name'],half_time=t,**analyse(dest,con),capture_sha256=digest(dest)))
            dest.unlink()  # The published recipe can regenerate each verified capture.
    r=dict(contract_sha256=digest(here/'contract.json'),source_sha256=digest(dsp/'s1_dry_voice.c'),objects={n:pins[n] for n in names},rows=rows)
    (out/'results.json').write_text(json.dumps(r,indent=2)+'\n')
    for row in rows:print(row['name'],row['half_time'],row['first_nonfinite'],row['original_peak'],row.get('rms_db'),row.get('spectral_rms_db'),row['passed'])
if __name__=='__main__':main()
