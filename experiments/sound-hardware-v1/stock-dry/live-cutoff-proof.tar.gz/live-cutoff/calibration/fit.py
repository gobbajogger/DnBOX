import csv, json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize_scalar
p=Path(__file__).resolve().parent
rows=[r for r in csv.DictReader((p/'calibration.csv').open()) if r['cutoff']=='64']
x,y=[np.array([float(r[k]) for r in rows]) for k in ('input','first')]
ratios=(y/x)/(y[0]/x[0])
depart=np.flatnonzero(abs(ratios-1)>0.01)[0]
onset=(x[depart]+x[depart-1])/2
active=x>onset
def loss(scale):
    prediction=np.tanh(x[active]/scale)/(x[active]/scale)
    return np.mean((ratios[active]-prediction)**2)
fit=minimize_scalar(loss,bounds=(10000,100000),method='bounded')
scale=float(fit.x)
j={'fitted_at_hz':64,'last_linear_test':x[depart-1],'first_compressed_test':x[depart],'onset':onset,'scale':scale,'rms_curve_error':float(np.sqrt(fit.fun))}
(p/'fit.json').write_text(json.dumps(j,indent=2)+'\n')
(p/'calibration.h').write_text(f'#define DRIVE_ONSET {onset:.6f}f\n#define DRIVE_SCALE {scale:.6f}f\n')
print(j)
