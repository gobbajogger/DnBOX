#include <math.h>
#include <stdio.h>
#include "soundpipe.h"
static void level(sp_data *sp,float hz,float res,float input,float *first,double *sum)
{
    sp_moogladder *p;sp_moogladder_create(&p);sp_moogladder_init(sp,p);
    p->freq=hz;p->res=res;*sum=0;
    for(int i=0;i<32768;++i){
        float y;sp_moogladder_compute(sp,p,&input,&y);
        if(!i)*first=y;
        *sum+=y;input=0;
    }
    sp_moogladder_destroy(&p);
}
int main(void)
{
    sp_data sp={0};sp.sr=44100;
    for(int i=0;i<257;++i){
        float f=64.f+i*((22050.f-64.f)/256.f),zero,half;double unused,sum;
        level(&sp,f,0,.0001f,&zero,&unused);
        level(&sp,f,.5f,.0001f,&half,&sum);
        printf("%.9g,%.17g,%.17g\n",f,zero/(double).0001f,sum/(double).0001f);
    }
}
