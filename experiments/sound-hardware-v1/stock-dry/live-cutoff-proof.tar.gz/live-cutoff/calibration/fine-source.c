#include <stdio.h>
#include <math.h>
#include "soundpipe.h"
int main(void) {
    sp_data sp={0};sp.sr=44100;
    puts("cutoff,resonance,input,first,peak");
    const float cutoffs[]={64.f,1000.f,8000.f};
    for(int q=0;q<3;++q)for(int v=0;v<514;++v){
        float in=(v ? 19967.f + v : 0.125f), impulse=in, first=0,peak=0;
        sp_moogladder *p;sp_moogladder_create(&p);sp_moogladder_init(&sp,p);p->freq=cutoffs[q];p->res=.63f;
        for(int i=0;i<256;++i){
            float y=0; sp_moogladder_compute(&sp,p,&in,&y);
            if(!i)first=y; if(fabsf(y)>peak)peak=fabsf(y);
            in=0.0f;
        }
        printf("%.0f,%.2f,%.9g,%.9g,%.9g\n",cutoffs[q],.63f,impulse,first,peak);
        sp_moogladder_destroy(&p);
    }
}
