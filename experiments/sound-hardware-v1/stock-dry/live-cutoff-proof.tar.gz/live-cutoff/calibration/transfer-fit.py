"""Fit stable polynomial coefficients on even calibration rows, check disjoint odd rows."""
from pathlib import Path
import json, numpy as np
from scipy.optimize import brentq
p=Path(__file__).resolve().parent
obs=np.loadtxt(p/'response.csv',delimiter=',')
x=obs[:,0]/22050.0
step=np.array([brentq(lambda s:s**4*(3-2*s)-w,1e-8,1.0) for w in obs[:,1]])
fb=2*(1/obs[:,2]-1)
train=np.arange(0,len(x),2);test=np.arange(1,len(x),2)
# The previous fit gives a smooth response; select the lowest tested degree to
# meet independent held-out coefficient tolerances on this calibration grid.
def choose(y,threshold):
    options=[]
    for n in range(2,12):
        c=np.polynomial.polynomial.polyfit(x[train],y[train],n).astype('<f4')
        xx=x[test].astype('<f4')
        pred=np.full_like(xx,c[-1])
        for v in c[-2::-1]:pred=v+xx*pred
        options.append((float(np.max(abs(pred-y[test]))),len(c),c))
    selected=next((v for v in options if v[0]<=threshold),min(options,key=lambda a:a[0]))
    return selected,[(a,b) for a,b,_ in options]
s,st=choose(step/x,2e-6);f,ft=choose(fb,2e-5)
def expression(coefs):
    expr=f'{coefs[-1]:.10g}f'
    for v in coefs[-2::-1]:expr=f'({v:.10g}f + x * {expr})'
    return expr
out=dict(step_errors=st,feedback_errors=ft,step_coeffs=list(map(float,s[2])),feedback_coeffs=list(map(float,f[2])))
(p/'transfer-fit.json').write_text(json.dumps(out,indent=2)+'\n')
(p/'coefficients.inc').write_text('''static void dense_filter(s1_dry_prepared *p, float hz)
{
    float x=hz*(1.0f/22050.0f);
    p->pole_retention=1.0f - x*'''+expression(s[2])+''';
    p->feedback=p->controls.resonance*'''+expression(f[2])+''';
    p->cached_cutoff_hz=hz;
}
''')
print([(v[0],v[1]) for v in (s,f)])
