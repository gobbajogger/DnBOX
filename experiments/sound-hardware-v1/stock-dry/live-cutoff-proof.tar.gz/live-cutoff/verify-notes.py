"""Run the stock dry-note metric on the alternate ordinary voice entry."""
from pathlib import Path
import argparse, contextlib, gzip, hashlib, io, json, runpy, subprocess, sys, tempfile
import numpy as np
def digest(f):return hashlib.sha256(f.read_bytes()).hexdigest()
p=argparse.ArgumentParser()
for name in ('repo','staged','original','captured','gen','output'):p.add_argument(name,type=Path)
a=p.parse_args();out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
bench=a.repo/'experiments/sound-hardware-v1/stock-dry';dsp=a.staged/'firmware/src/dsp'
o=a.original/'reference/dry_reference_packet'
reference={x['case']:x['reference'] for x in json.loads(gzip.decompress((bench/'results.json.gz').read_bytes()))['cases']}
tables=out/'tables.c';tables.write_text('#define X0X_DRUM_TABLES_DEFINE\n#include "x0x_drum_tables.h"\n')
exe=out/'voice'
subprocess.run(['cc','-O2','-std=c11','-ffp-contract=off','-fno-fast-math','-DX0X_HOST','-I'+str(a.gen),'-I'+str(dsp),bench/'render.c',dsp/'s1_dry_voice.c',dsp/'dnbx_s1_envelope.c',tables,'-o',exe],check=True)
rows=[]
for case in json.loads((o/'case_plan.json').read_text())['cases']:
    name=case['case_id'];kind='dynamic' if name.startswith('filter-modulation/') else 'static'
    stem=name.replace('/','-')
    if kind=='static':
        ref=np.fromfile(o/case['current_reference_mono_relative_path'],'<f4')
    else:
        ref=np.fromfile(a.captured/(stem+'.paired'),'<f4').reshape(-1,2)[:,0].copy()
    assert hashlib.sha256(ref.tobytes()).hexdigest()==reference[name]
    with tempfile.TemporaryDirectory(dir=out) as tmp:
        tmp=Path(tmp);cand=tmp/'voice.f32'
        subprocess.run([exe,cand,*[str(case[k]) for k in ('velocity','cutoff_hz','resonance','filter_depth')],kind],check=True)
        actual=np.fromfile(cand,'<f4');assert ref.shape==actual.shape==(264576,)
        pair=tmp/'pair.f32';np.column_stack((ref,actual)).astype('<f4').tofile(pair)
        sys.argv=[str(o/'metrics.py'),str(pair),'1']
        with contextlib.redirect_stdout(io.StringIO()):runpy.run_path(str(o/'metrics.py'),run_name='__main__')
        result=json.loads(pair.with_suffix('.json').read_bytes())
        assert len(result['rows'])==3 and result['nonfinite']==0 and result['gain']==1
        rows.append(dict(case=name,kind=kind,reference_sha256=reference[name],candidate_sha256=digest(cand),metrics=result))
summary={}
for k in ('static','dynamic'):
    vals=[v for r in rows if r['kind']==k for v in r['metrics']['rows']]
    summary[k]=dict(passed=sum(x['rms_db']<=1 and x['spectral_db']<=3 for x in vals),total=len(vals),worst_level_db=max(x['rms_db'] for x in vals),worst_spectral_db=max(x['spectral_db'] for x in vals))
(out/'results.json').write_text(json.dumps(dict(source_sha256=digest(dsp/'s1_dry_voice.c'),metric_sha256=digest(o/'metrics.py'),summary=summary,rows=rows),indent=2)+'\n')
print(summary)
