# Original cutoff transitions in the independent dry Synth One voice

Both reference and candidate receive identical sample-by-sample cutoff values from the pinned original parameter port. At its documented 0.1 s default, the stock dry low-pass handles the tested transitions. At its legal 1 µs minimum, seven fast switching schedules made the stock linear approximation nonfinite. The original instrument's filter remained finite in all seven. In the two initial stress schedules its peak raw filter outputs were 9,016 and 11,072. The expected bounded output is established before downstream gain or clipping.

The alternate low-pass adds bounded drive between adjacent stages and retains the original linear arithmetic at small amplitudes. It uses the already-linked drum saturation table. Measurements from the independent original 64 Hz impulse fixture determine the drive scale and the onset of compression. A separate 257-frequency impulse grid determines the step and feedback fit, using even rows for fitting and odd rows for validation. The cutoff trajectories and held notes are separate from the calibration impulses. The original study and the component tested here use the same original cutoff port and filter objects with verified SHA-256s.

| Control | Passes | Other result |
| --- | ---: | --- |
| Stock dry voice on 75 low-pass trajectories | 68/75 | Seven nonfinite traces at the minimum port half-time |
| Alternate dry voice on the same 75 trajectories | 75/75 | All finite, worst level error 0.000610 dB and worst spectral error 2.094 dB |
| Alternate existing static dry notes | 180/180 | Worst level and spectral errors 0.471 dB and 0.414 dB |
| Alternate existing modulated dry notes | 72/72 | Worst level and spectral errors 0.018 dB and 1.112 dB |

Each trajectory contains 131,072 samples. The 75 cases cover 15 control schedules at five half-times. The fixed physical criteria are 1 dB absolute RMS-level difference and 3 dB spectral RMS, with a separate finite-output requirement. Per-case peaks, first nonfinite frame, input limits and capture hashes are in records/. The original 252-note comparison uses the frozen DnBOX test metric at unity gain and validates every original PCM digest.

The unmodified native build flow links the alternate source on both models. The applications occupy 546,676 B on Elite and 546,668 B on Pro. Each adds 160 B against its production image, uses the same 97,204 B ordinary RAM and retains 8,972 B free pool. The production INIT backend and the timing-margin firmware stay at their previous source. The filter experiment qualifies one low-pass component. Factory selection, other voice stages and independent owner effects still need qualification in the complete firmware.

## Replay

Create a separate checkout at ca0c00a4e5863132de4a66f5d1c477c14d699be5 and apply voice.patch with git apply. Build each board using the pinned stock toolchain and SDK. The generated x0x_drum_tables.h must be available for host builds. Pass a fresh output directory to every command below.

    python3 trajectory/compare.py STOCK_CHECKOUT ORIGINAL_RECOVERY ALTERNATE_CHECKOUT GENERATED_HEADERS NEW_OUTPUT
    python3 trajectory/compare.py STOCK_CHECKOUT ORIGINAL_RECOVERY STOCK_CHECKOUT GENERATED_HEADERS NEW_STOCK_OUTPUT
    python3 verify-notes.py STOCK_CHECKOUT ALTERNATE_CHECKOUT ORIGINAL_RECOVERY BASELINE_DRY_OUTPUT GENERATED_HEADERS NEW_NOTE_OUTPUT

BASELINE_DRY_OUTPUT can be produced with the stock dry qualifier in experiments/sound-hardware-v1/stock-dry/qualify.py. It contains original/stock paired capture files, whose original channel is verified against the committed per-case digest. ORIGINAL_RECOVERY is the DnBOX-Sound-final-recovery source bundle indexed in the repository.

The calibration folder retains the standalone original-component impulse generators, all tabulated observations, the separate threshold bracket and the fitted coefficients. The generators link only the authenticated original comparison object. The candidate patch contains only the fitted runtime code.
