#include "s1_dry_part.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
int main(int argc,char **argv){
    if(argc!=3)return 2;
    unsigned keys[6], n=0;
    char *cursor=argv[1];
    while(*cursor){
        char *end;
        long key=strtol(cursor,&end,10);
        if(end==cursor||n>=6||key<0||key>127||(*end&&*end!=','))return 3;
        keys[n++]=(unsigned)key;cursor=*end?end+1:end;
    }
    if(!n)return 3;
    FILE *out=fopen(argv[2],"wbx");if(!out)return 4;
    float l[64],r[64];s1_dry_part p;s1_part_init(&p);
    for(unsigned b=0;b<2757;b++)s1_part_render(&p,l,r,64);
    for(unsigned i=0;i<n;i++)if(!s1_part_note(&p,keys[i],100))return 5;
    for(unsigned b=0;b<1378;b++){
        if(b==1033)for(unsigned i=0;i<n;i++)if(!s1_part_note(&p,keys[i],0))return 6;
        s1_part_render(&p,l,r,64);
        for(unsigned i=0;i<64;i++)if(!isfinite(l[i])||l[i]!=r[i])return 7;
        if(fwrite(l,sizeof(*l),64,out)!=64)return 8;
    }
    return fclose(out)!=0;
}
