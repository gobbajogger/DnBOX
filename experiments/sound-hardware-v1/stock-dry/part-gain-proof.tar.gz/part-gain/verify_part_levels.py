"""Compare the dry-part mix against eight captures from the independent original."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import numpy as np

HERE = Path(__file__).resolve().parent

def spectrum(samples):
    windows = np.lib.stride_tricks.sliding_window_view(samples, 2048)[::512]
    power = abs(np.fft.rfft(windows * np.hanning(2048), axis=-1)) ** 2
    return np.sqrt(np.mean(power, axis=0))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('tree', type=Path)
    parser.add_argument('output', type=Path, help='new output directory')
    args = parser.parse_args()
    destination = args.output.resolve()
    destination.mkdir(parents=True, exist_ok=False)
    firmware = args.tree.resolve() / 'firmware/src'
    dsp = firmware / 'dsp'
    app = firmware / 'app'
    executable = destination / 'render'
    subprocess.run(['cc','-std=c11','-O2','-fno-fast-math','-ffp-contract=off',
                    '-DX0X_HOST','-I'+str(app),'-I'+str(dsp), HERE/'candidate.c',
                    app/'s1_dry_part.c',dsp/'s1_dry_voice.c',dsp/'dnbx_s1_envelope.c',
                    '-lm','-o',executable], check=True)
    rows = []
    with np.load(HERE/'original-spectra.npz', allow_pickle=False) as gold:
        for row in json.loads((HERE/'levels.json').read_text()):
            keys=','.join(map(str,row['keys']))
            capture=destination/(keys+'.pcm')
            subprocess.run([executable,keys,capture],check=True)
            wave=np.fromfile(capture,'<f4').astype(float)
            if len(wave)!=88192 or not np.all(np.isfinite(wave)):
                raise ValueError(f'Invalid audio for {keys}')
            reference=gold[keys+'.spectrum']
            measured=spectrum(wave)
            floor=max(float(np.max(reference))*1e-4,1e-12)
            mask=(reference>=floor)|(measured>=floor)
            level_db=float(20*np.log10(np.sqrt(np.mean(wave**2))/gold[keys+'.rms']))
            band_errors=20*np.log10(np.maximum(measured[mask],floor)/np.maximum(reference[mask],floor))
            spectral_db=float(np.sqrt(np.mean(band_errors**2)))
            passed=abs(level_db)<=1 and spectral_db<=3
            rows.append(dict(notes=row['keys'],rms_db=level_db,spectral_db=spectral_db,
                             passed=passed,sha256=hashlib.sha256(capture.read_bytes()).hexdigest()))
    (destination/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
    count=sum(row['passed'] for row in rows)
    print(f'{count}/{len(rows)} scenes pass at fixed gain 1')
    return 0 if count==len(rows) else 1

if __name__ == '__main__':
    sys.exit(main())
