#include <cstdlib>
// New comparison-only fixture/file-I/O wrapper. No voice or filter algorithm.
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <array>
#include <cfenv>
#include <cfloat>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <exception>
#include <sys/mman.h>
#include <unistd.h>
#include "full_oracle.hpp"
#include "wave_frequencies.h"

namespace {
constexpr unsigned kRate = 44100;
constexpr unsigned kBlock = 64;
constexpr unsigned kWarmBlocks = 2757;
constexpr unsigned kRecordBlocks = 1378;
constexpr unsigned kOffBlock = 1033;
constexpr unsigned kNotes[3] = {36, 60, 84};
constexpr std::uint32_t kNoteFrequencyBits[3] = {0x4282d013u, 0x4382d013u, 0x4482d013u};
constexpr unsigned kVelocity = 100;
constexpr unsigned kControls = 150;
constexpr unsigned kTuning = 128;
constexpr std::size_t kRowSamples = 4097;
constexpr std::size_t kMorphRows = 52;
constexpr const char *kBaseline = "physical-gain/100_2000_.9";
constexpr const char *kActive = "filter-modulation/1.2_2000_0.9";
static_assert(sizeof(float) == 4 && sizeof(SPFLOAT) == 4, "binary32 storage required");
static_assert(FLT_RADIX == 2 && FLT_MANT_DIG == 24 && FLT_MAX_EXP == 128,
              "IEEE754 binary32 float required");

std::uint32_t bits(float value) {
    std::uint32_t result;
    std::memcpy(&result, &value, sizeof(result));
    return result;
}

bool read_floats(const char *path, float *destination, std::size_t count) {
    FILE *file = std::fopen(path, "rb");
    if (!file) { std::perror("open numeric input"); return false; }
    const std::size_t got = std::fread(destination, sizeof(float), count, file);
    const int trailing = std::fgetc(file);
    const int read_error = std::ferror(file);
    const int close_error = std::fclose(file);
    if (got != count || trailing != EOF || read_error || close_error) {
        std::fprintf(stderr, "numeric input has an unexpected byte length\n");
        return false;
    }
    for (std::size_t i = 0; i < count; ++i) {
        if (!std::isfinite(destination[i])) {
            std::fprintf(stderr, "nonfinite numeric input at index %zu\n", i);
            return false;
        }
    }
    return true;
}

// This owns the fixture storage and descriptors, not an engine implementation.
class TableInput {
public:
    synthone_shared::Tables tables{};
    const float *tuning = nullptr;
    TableInput() = default;
    TableInput(const TableInput &) = delete;
    TableInput &operator=(const TableInput &) = delete;
    ~TableInput() { if (mapping_ != MAP_FAILED) ::munmap(mapping_, mapped_bytes_); }

    bool load(const char *table_path, const char *tuning_path) {
        const long page = ::sysconf(_SC_PAGESIZE);
        if (page <= 0) { std::fprintf(stderr, "page size unavailable\n"); return false; }
        const std::size_t payload = ((kMorphRows + 1) * kRowSamples + kTuning) * sizeof(float);
        const std::size_t page_size = static_cast<std::size_t>(page);
        mapped_bytes_ = (payload + page_size - 1) / page_size * page_size;
        mapping_ = ::mmap(nullptr, mapped_bytes_, PROT_READ | PROT_WRITE,
                          MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (mapping_ == MAP_FAILED) { std::perror("allocate fixture mapping"); return false; }
        float *data = static_cast<float *>(mapping_);
        if (!read_floats(table_path, data, kMorphRows * kRowSamples)) return false;
        for (unsigned band = 0; band < 13; ++band) {
            tables.frequency_band[band] = wave_frequencies[band];
            for (unsigned shape = 0; shape < 4; ++shape) {
                const unsigned row = band * 4 + shape;
                tables.morph[row] = {data + row * kRowSamples, kRowSamples,
                                     band, static_cast<synthone_shared::Shape>(shape)};
            }
        }
        float *sine = data + kMorphRows * kRowSamples;
        tables.sine = sine;
        tables.sine_count = kRowSamples;
        sp_data context{};
        context.sr = static_cast<int>(kRate);
        sp_ftbl descriptor{};
        descriptor.tbl = sine;
        // Use the original public fixture helpers; implement no waveform generator here.
        if (sp_ftbl_init(&context, &descriptor, 4096) != SP_OK ||
            sp_gen_sine(&context, &descriptor) != SP_OK) {
            std::fprintf(stderr, "original public sine-table initialization failed\n");
            return false;
        }
        sine[4096] = 0.0f;
        float *frequencies = data + (kMorphRows + 1) * kRowSamples;
        if (!read_floats(tuning_path, frequencies, kTuning)) return false;
        for (unsigned i = 0; i < 3; ++i) {
            if (bits(frequencies[kNotes[i]]) != kNoteFrequencyBits[i]) {
                std::fprintf(stderr, "played-note tuning identity differs\n");
                return false;
            }
        }
        tuning = frequencies;
        if (::mprotect(mapping_, mapped_bytes_, PROT_READ) != 0) {
            std::perror("protect fixture mapping");
            return false;
        }
        return true;
    }
private:
    void *mapping_ = MAP_FAILED;
    std::size_t mapped_bytes_ = 0;
};

struct OutputFile {
    FILE *file = nullptr;
    ~OutputFile() { if (file) std::fclose(file); }
    bool close() {
        FILE *current = file;
        file = nullptr;
        return current && std::fclose(current) == 0;
    }
};

int capture(int argc, char **argv) {
    if (argc != 6) {
        std::fprintf(stderr, "usage: capture_original_dry TABLES.f32 CONTROLS.f32le TUNING.f32le NEW_OUTPUT.f32le CASE_ID\n");
        return 2;
    }
    const std::uint32_t endian_check = 1;
    if (*reinterpret_cast<const unsigned char *>(&endian_check) != 1 ||
        std::fegetround() != FE_TONEAREST) {
        std::fprintf(stderr, "little-endian host and round-to-nearest mode required\n");
        return 2;
    }
    std::array<float, kControls> controls{};
    if (!read_floats(argv[2], controls.data(), controls.size())) return 1;
    TableInput fixture;
    if (!fixture.load(argv[1], argv[3])) return 1;
    OutputFile output;
    output.file = std::fopen(argv[4], "wbx");
    if (!output.file) { std::perror("create new mono output"); return 1; }

    unsigned notes[6], n=0;
    const char *cursor=argv[5];
    while (*cursor) {
        char *end=nullptr;
        auto note=std::strtol(cursor,&end,10);
        if(end==cursor || n>=6 || note<0 || note>127 || (*end && *end!=','))return 2;
        notes[n++]=static_cast<unsigned>(note);cursor=*end?end+1:end;
    }
    if(!n)return 2;
    std::array<float,kBlock> left{},right{};
    s1scheduler::FullOracle original;
    if(!original.init(fixture.tables,static_cast<int>(kRate),controls.data(),controls.size(),fixture.tuning,kTuning))return 3;
    for(unsigned b=0;b<kWarmBlocks;b++)original.process(kBlock,0,left.data(),right.data());
    for(unsigned i=0;i<n;i++)original.startNote(notes[i],kVelocity);
    for(unsigned b=0;b<kRecordBlocks;b++) {
        if(b==kOffBlock)for(unsigned i=0;i<n;i++)original.stopNote(notes[i]);
        original.process(kBlock,0,left.data(),right.data());
        for(float v:left)if(!std::isfinite(v))return 4;
        for(float v:right)if(!std::isfinite(v))return 4;
        if(std::fwrite(left.data(),sizeof(float),kBlock,output.file)!=kBlock)return 5;
    }
    return output.close()?0:6;
}
} // namespace
int main(int argc,char **argv){return capture(argc,argv);}
