"""Rebuild the original-only observation tool using the frozen reference object files."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
OLD = '/workspace/scratch/e803955aec60/reference_filter_inputs/full_dry_preparation'

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('reference_closure',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    source=args.reference_closure.resolve()
    output=args.output.resolve()
    output.mkdir(parents=True,exist_ok=False)
    for name in ['baseline-compile-18.receipt.json','baseline-host-link.receipt.json']:
        old_args=json.loads((source/'metadata'/name).read_text())['argv'][1:]
        command=['g++']
        for arg in old_args:
            new=arg.replace(OLD,str(source))
            new=new.replace(str(source/'capture_original_dry.cpp'),str(HERE/'original.cpp'))
            new=new.replace(str(source/'build/capture_original_dry'),str(output/'original'))
            command.append(new)
        with (output/(name+'.log')).open('w') as log:
            subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
    for row in json.loads((HERE/'levels.json').read_text()):
        keys=','.join(map(str,row['keys']))
        dst=output/(keys+'.pcm')
        inputs=source/'inputs'
        subprocess.run([output/'original',inputs/'public-morphs.f32',inputs/'baseline-controls.f32le',
                        inputs/'tuning128.f32le',dst,keys],check=True)
        if hashlib.sha256(dst.read_bytes()).hexdigest()!=row['original_sha256']:
            raise ValueError('Original PCM checksum mismatch: '+keys)
    print('8/8 original PCM captures match')

if __name__=='__main__':
    main()
