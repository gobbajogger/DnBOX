# Host callback deadlines for all restored factory programs

The unmodified bench ran 750 callbacks for each of the 694 original programs. Each callback covered 128 frames at 48 kHz. The bench used the held keys, control sequence, initial floating-point environment and deadline checks in CONTRACT.md. The original and replacement ran serially in that order on the shared host. Wall time includes scheduling delay. Both arms had TracerPid zero, ordinary IEEE floating-point handling and no nonfinite samples.

| Linked graph | Callbacks | Wall misses | Thread CPU misses | Nonfinite words | Status |
| --- | ---: | ---: | ---: | ---: | --- |
| Original | 520,500 | 31,005 | 635 | 0 | FAIL |
| Replacement low-pass | 520,500 | 30,151 | 806 | 0 | FAIL |

The replacement covers the three compiled voice paths and both delay-input low-pass channels. The other original code and callback fixture were identical. Both miss counts remain part of qualification. These two runs do not isolate a speed difference from workload variation on the shared host. The separate original-PCM comparison in factory-lowpass-694.tar.gz uses its own note stimulus and scoring contract.

The two original and alternate JSONL files contain every per-program timing summary. full/summary.json pins every linked object, executable, the command stream and checksums of the 520,500-row per-callback CSV files. compare.py checks each raw cycle against the predeclared wall and CPU deadline and reconciles the totals to those per-program records. Reproduce with the factory closure and filter object from the adjacent low-pass packet. Pass the existing compiled factory build, this directory for the benchmark source, the replacement object, the factory run directory and a fresh output directory to compare.py. Running the code produces fresh timing measurements.
