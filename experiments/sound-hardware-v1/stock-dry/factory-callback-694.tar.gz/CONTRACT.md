# Host callback-deadline measurement contract

Predeclared before execution: every measured block has128 frames at48000Hz.
A miss is elapsed_nanoseconds *48000 >128 *1000000000, with no percentile or
outlier exclusion. Record wall-clock and thread-CPU deadlines separately; either
miss or any nonfinite output blocks a zero-miss claim. No heap call is allowed
inside the measured control/render region. All694 authenticated program inputs
are required for complete corpus coverage; partial pilots are labeled partial.

Each program keeps its original mono/poly/arp/FX settings. Six-voice polyphony is
not reduced. Sixteen held keys stress allocation/stealing, with chord replacement
every96 blocks and a final release segment. Control events and candidate render
with original common FX are inside the clock interval. File output, finite/hash
inspection and cold construction/program loading are outside it. There is no
warm-up exclusion. Wall time includes timestamp overhead and scheduling delay.

This is a synchronous host deadline measurement, not an audio-device callback,
device XRUN counter, all-engine integration, original iOS app, independently
validated FX/tails, or complete tuning/hold/modwheel qualification. Fixed fixture
tuning is explicitly retained. No pass is inferred from thread CPU if wall time
misses. A cloud scheduling cause requires evidence and does not erase a miss.
FNV64 is only a diagnostic digest, not a cryptographic or original-audio oracle.

Optional host-only FTZ/DAZ runs are diagnostics for denormal-cost hypotheses,
not qualification. They set only the benchmark process's x86 floating mode,
record original/effective MXCSR, and are labeled diagnostic in the receipt.
They may change output words. Their misses cannot replace baseline misses, and
no runtime/native floating-mode change follows without original-platform and
fidelity evidence. Retain both traces and compare diagnostic output hashes.

Optional resource diagnostics compile `DNBOX_CALLBACK_RUSAGE` and write a
separate CSV. Per-thread `getrusage` and `sched_getcpu` observations bracket the
original wall/thread-CPU clock interval; those extra probes are outside that
interval. Resource CPU time includes the surrounding clock probes and has the
platform's accounting resolution. Faults, context switches and migrations are
associations, not a proved cause or grounds to exclude a callback. Unknown CPU
observations remain unknown. All timing misses remain counted, and instrumented
runs are explicitly NOT_QUALIFIED even if no miss is observed.
