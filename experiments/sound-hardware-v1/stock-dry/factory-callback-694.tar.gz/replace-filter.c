/* Comparison fixture only: retain independent per-instance history in the
 * original filter object's storage. Use DnBOX's actual alternate stage. */
#include <math.h>
#include <string.h>
#include "soundpipe.h"
#include "s1_dry_voice.c"
int __wrap_sp_moogladder_compute(sp_data *sp, sp_moogladder *filter, SPFLOAT *input, SPFLOAT *output)
{
    s1_dry_voice voice;
    if (filter->freq != filter->oldfreq || filter->res != filter->oldres) {
        voice.prepared.controls.resonance=filter->res;
        prepare_filter(&voice.prepared, filter->freq * (44100.0f / (float)sp->sr));
        filter->oldfreq=filter->freq; filter->oldres=filter->res;
        filter->oldacr=voice.prepared.feedback;
        filter->oldtune=voice.prepared.pole_retention;
    } else {
        voice.prepared.feedback=filter->oldacr;
        voice.prepared.pole_retention=filter->oldtune;
    }
    memcpy(voice.filter_history,filter->delay,sizeof voice.filter_history);
    float a=filter_substep(&voice,*input);
    float b=filter_substep(&voice,*input);
    *output=(a+b)*0.5f;
    memcpy(filter->delay,voice.filter_history,sizeof voice.filter_history);
    return SP_OK;
}
