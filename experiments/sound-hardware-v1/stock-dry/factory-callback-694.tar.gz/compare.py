"""Run both arms of the frozen callback fixture on an already rebuilt factory closure."""
import argparse,csv,hashlib,json,os,platform,subprocess,time
from pathlib import Path
ap=argparse.ArgumentParser()
for k in ('build','fixture','replacement','factory_run','out'):ap.add_argument(k,type=Path)
a=ap.parse_args();build=a.build.resolve();fx=a.fixture.resolve();out=a.out.resolve();out.mkdir(exist_ok=False)
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
inputs=json.loads((build/'factory-build-commands.json').read_bytes())
cmd=next(c.copy() for c in inputs if '-c' in c and c[c.index('-c')+1].endswith('/preset_audio.cpp'))
old=cmd[cmd.index('-o')+1];new=str(out/'bench.o')
cmd[cmd.index('-o')+1]=new;cmd[cmd.index('-MF')+1]=str(out/'bench.d');cmd[cmd.index('-c')+1]=str(fx/'bench.cpp')
subprocess.run(cmd,check=True)
base=[new if v==old else v for v in inputs[-1]];assert base.count(new)==1
used={v:h(Path(v)) for v in base[1:] if v.endswith('.o')}
summary={'contract_sha256':h(fx/'CONTRACT.md'),'fixture_sha256':h(fx/'bench.cpp'),'replacement_object_sha256':h(a.replacement),'object_pins':used,'os':platform.platform(),'compiler':subprocess.check_output(['c++','--version'],text=True).splitlines()[0],'note':'Full 694 programs in each arm, original 128/48kHz wall and thread-CPU gate. Original and alternate runs execute serially in this order on a shared host. No warm-up exclusion, measured wall delays are retained.','arms':{}}
for fn in ('public-morphs.f32','compact.bin'): summary[fn]=h(build/'factory-inputs'/fn)
summary['commands_sha256']=h(build/'commands/preset-commands.bin')
for label in ('original','lowpass'):
 exe=out/(label+'-bench');link=base.copy();link[link.index('-o')+1]=str(exe)
 if label=='lowpass':link[1:1]=[str(a.replacement.resolve()),'-Wl,--wrap=sp_moogladder_compute']
 subprocess.run(link,check=True)
 csvfile=out/(label+'.csv');rows=out/(label+'.jsonl')
 call=[str(exe),str(build/'factory-inputs/public-morphs.f32'),str(build/'factory-inputs/compact.bin'),str(build/'commands/preset-commands.bin'),str(csvfile),str(rows),'694','0']
 started=time.time()
 with (out/(label+'.log')).open('w') as log:r=subprocess.run(call,stdout=log,stderr=log)
 assert r.returncode in (0,1)
 rec=[json.loads(s) for s in rows.read_text().splitlines()];assert len(rec)==694 and all(v['preset']==i and v['callbacks']==750 for i,v in enumerate(rec))
 with csvfile.open() as f:
  total=0;wm=0;cm=0;mw=0;mc=0
  for v in csv.DictReader(f):
   assert int(v['preset'])==total//750 and int(v['block'])==total%750 and int(v['frames'])==128 and int(v['rate'])==48000
   wt=int(v['wall_ns']);ct=int(v['cpu_ns'])
   assert (wt*48000>128*10**9)==bool(int(v['wall_miss'])) and (ct*48000>128*10**9)==bool(int(v['cpu_miss']))
   total+=1;wm+=int(v['wall_miss']);cm+=int(v['cpu_miss']);mw=max(mw,wt);mc=max(mc,ct)
 assert total==520500 and wm==sum(v['wall_misses'] for v in rec) and cm==sum(v['cpu_misses'] for v in rec)
 bad=sum(v['nonfinite_words'] for v in rec);assert r.returncode==int(bool(bad or wm or cm))
 arm=dict(programs=len(rec),callbacks=total,wall_misses=wm,cpu_misses=cm,max_wall_ns=mw,max_cpu_ns=mc,nonfinite_words=bad,exit=r.returncode,host_elapsed_seconds=time.time()-started,executable_sha256=h(exe),programs_sha256=h(rows),trace_sha256=h(csvfile),command=call,terminal=(out/(label+'.log')).read_text())
 summary['arms'][label]=arm;(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(label,wm,cm,mw,mc,flush=True)
assert all(h(Path(s))==v for s,v in used.items())
