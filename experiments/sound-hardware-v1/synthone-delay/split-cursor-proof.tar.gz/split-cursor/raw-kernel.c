#include <stdint.h>

typedef struct {
    float dry[2], feedback, long_seconds, short_seconds;
    uint32_t frame;
    uint32_t unused[29]; /* Preserve the fixed input stride of the comparison harness. */
} source_frame;

typedef struct {
    float history[109], previous[4];
} cursor_state;

typedef struct {
    int base;
    float f, w, x, y, z;
} lag;

static inline __attribute__((always_inline)) lag locate(float seconds, int t)
{
    float f = seconds * -44100.0f;
    int base = (int)f;
    f -= (float)base;
    base += t;
    if (base < 0 || f < 0.0f) {
        f += 1.0f;
        --base;
    }
    float z = (f*f - 1.0f) / 6.0f;
    float y = (f + 1.0f)*0.5f;
    float x = 3.0f*z;
    lag q = {base, f, (y-1.0f)-z, x-f, y-x, z};
    return q;
}

static inline __attribute__((always_inline)) float index_read(float *ring, int cap, int j, int t)
{
    return j >= 0 && j <= t ? ring[(unsigned)j % (unsigned)cap] : 0.0f;
}

static inline __attribute__((always_inline)) float advance(float *ring, int cap, int t, lag q,
        float input, float feedback, float previous)
{
    ring[(unsigned)t % (unsigned)cap] = input + previous*feedback;
    float b = index_read(ring,cap,q.base,t);
    float sum = q.w * index_read(ring,cap,q.base-1,t) + q.x*b;
    sum += q.y * index_read(ring,cap,q.base+1,t);
    sum += q.z * index_read(ring,cap,q.base+2,t);
    return sum*q.f+b;
}

void render(cursor_state *restrict state, const source_frame *restrict source, unsigned n)
{
    float r = state->previous[1];
#ifdef LONG_CURSOR
    float l = state->previous[0];
#else
    float fill = state->previous[2], rr = state->previous[3];
#endif
    for (unsigned i=0;i<n;++i) {
        const source_frame *frame = source+i;
        const int t = (int)frame->frame;
        const lag long_lag = locate(frame->long_seconds,t);
        r = advance(state->history+35,35,t,long_lag,frame->dry[1],frame->feedback,r);
#ifdef LONG_CURSOR
        l = advance(state->history,35,t,long_lag,frame->dry[0],frame->feedback,l);
#else
        const lag short_lag = locate(frame->short_seconds,t);
        fill = advance(state->history+70,19,t,short_lag,frame->dry[1],frame->feedback,fill);
        rr = advance(state->history+89,19,t,short_lag,r,frame->feedback,rr);
#endif
    }
    state->previous[1] = r;
#ifdef LONG_CURSOR
    state->previous[0] = l;
#else
    state->previous[2] = fill;
    state->previous[3] = rr;
#endif
}
