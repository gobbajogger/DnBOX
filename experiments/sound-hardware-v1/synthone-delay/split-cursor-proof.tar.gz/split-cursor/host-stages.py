"""Reconstruct both original owners with only the feedback paths each cursor needs."""
import argparse, hashlib, subprocess
from pathlib import Path

def main():
    parser=argparse.ArgumentParser()
    for arg in ('prewarm_sources','baseline_traces','edited_traces','output'):
        parser.add_argument(arg,type=Path)
    args=parser.parse_args()
    dst=args.output.resolve()
    dst.mkdir(exist_ok=False,parents=True)
    sources=args.prewarm_sources.resolve()
    header=(sources/'checkpoint_core.hpp').read_text()
    original='static void tick(flash_witness_cursor& c,const Frame& frame) {'
    assert header.count(original)==1
    header=header.replace(original,'static void tick(flash_witness_cursor& c,const Frame& frame,int cursor=-1) {')
    mark='        float input=p==3?c.prev[1]:frame[p].input;'
    assert header.count(mark)==1
    header=header.replace(mark,'        if ((cursor==0 && p>1) || (cursor==1 && p==0)) continue;\n'+mark)
    (dst/'checkpoint_core.hpp').write_text(header)
    (dst/'checkpoint_state.h').write_bytes((sources/'checkpoint_state.h').read_bytes())
    code=(sources/'amortize.cpp').read_text()
    mark='tick(c,predicted[c.next]);'
    assert code.count(mark)==1
    code=code.replace(mark,'tick(c,predicted[c.next],k);')
    mark='tick(c,actual[c.next]);'
    assert code.count(mark)==1
    code=code.replace(mark,'tick(c,actual[c.next],k);')
    (dst/'host.cpp').write_text(code)
    subprocess.run(['c++','-std=c++17','-O2','-fno-fast-math','-ffp-contract=off',dst/'host.cpp','-o',dst/'host'],check=True)
    for owner in (1,8):
        baseline=args.baseline_traces/f'feedback-{owner}.bin'
        for name,trace in [('predicted',baseline),('stale',args.edited_traces/f'source-{owner}.bin')]:
            result=subprocess.check_output([dst/'host',baseline,trace])
            out=dst/f'{name}-{owner}.csv'
            out.write_bytes(result)
            assert result==(sources/out.name).read_bytes()
            print(out.name,hashlib.sha256(result).hexdigest(),result.splitlines()[-1].decode())

if __name__=='__main__':main()
