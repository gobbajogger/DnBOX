"""Reproduce the complete 512-frame wet-output callback for both owners."""
import argparse, csv, hashlib, json, struct, subprocess
from pathlib import Path
import numpy as np

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def pack(x,kind):
    def mirror(a):return np.concatenate([a,a[:3]],axis=0).ravel()
    if kind=='long':
        return np.concatenate([mirror(np.column_stack((x[:35],x[35:70]))),x[109:111]]).tobytes()
    return np.concatenate([mirror(x[35:70]),mirror(np.column_stack((x[70:89],x[89:108]))),x[110:113]]).tobytes()
def main():
    p=argparse.ArgumentParser()
    for arg in ('tc','runner','prepared','traces','out'):p.add_argument(arg,type=Path)
    a=p.parse_args()
    a.out.mkdir(parents=True,exist_ok=True)
    tc=a.tc.resolve()/'pi32v2'
    src=Path(__file__).with_name('callback.c')
    obj=a.out/'kernel.o';image=a.out/'kernel.raw'
    subprocess.run([tc/'bin/clang','-target','pi32v2','-mcpu=r3','-mfprev1','-fno-fast-math','-ffp-contract=off','-Oz','-idirafter',tc/'include','-c',src,'-o',obj],check=True)
    subprocess.run([tc/'bin/objcopy','-O','binary','-j','.text',obj,image],check=True)
    result=[]
    for scenario,owner in [('changed',1),('control',8)]:
        d=a.out/scenario
        d.mkdir(exist_ok=True)
        trace=a.traces/f'source-{owner}.bin'
        x=np.fromfile(trace,'<f4').reshape(-1,4,5)
        cfg=a.prepared/scenario
        cases={k:(t,n) for k,t,n in json.loads((cfg/'requested.json').read_text())}
        input_blocks=[];initial=[];expected=[];starts=[];ends=[]
        for k in ('long','short'):
            case=f'512-{k}';start,length=cases[case]
            starts.append(start);ends.append(start+length)
            old=cfg/'data'/case
            initial.append(pack(np.fromfile(old/'initial.bin','<u4'),k))
            expected.append(pack(np.fromfile(old/'expected.bin','<u4'),k))
            v=x[start:start+length]
            assert np.all((v[:,0,3]*44100>=2)&(v[:,0,3]*44100<=32)) and np.all((v[:,2,3]*44100>=2)&(v[:,2,3]*44100<=16))
            assert np.array_equal(v[:,0,3],v[:,1,3]) and np.array_equal(v[:,2,3],v[:,3,3])
            input_blocks.append(np.column_stack((v[:,0,0],v[:,1,0],v[:,0,2],v[:,0,3],v[:,2,3])).astype('<f4').tobytes())
        live=242550
        first=x[live:live+512]
        header=struct.pack('<4I',*(len(b)//20 for b in input_blocks),live,512)
        inp=header+first[:,[0,2],3].astype('<f4').tobytes()+b''.join(input_blocks)
        (d/'source.bin').write_bytes(inp+b'\0'*(-len(inp)%140))
        (d/'initial.bin').write_bytes(b''.join(initial)+struct.pack('<2I',*starts)+bytes(8192))
        (d/'expected.bin').write_bytes(b''.join(expected)+struct.pack('<2I',*ends)+first[:,:,4].astype('<f4').tobytes())
        row=subprocess.check_output([a.runner.resolve(),image,d],text=True).strip().split(',')
        assert int(row[1])==2213 and int(row[2])==0
        result.append(dict(owner=owner,scenario=scenario,output_frames=512,wet_words=2048,checked_state_words=165,unequal=int(row[2]),instructions=int(row[3]),ticks=int(row[4]),us=float(row[5]),trace_sha256=digest(trace),input_sha256=digest(d/'source.bin'),output_sha256=digest(d/'expected.bin')))
    report=dict(raw_kernel_bytes=image.stat().st_size,sha256=digest(image),rows=result)
    (a.out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
