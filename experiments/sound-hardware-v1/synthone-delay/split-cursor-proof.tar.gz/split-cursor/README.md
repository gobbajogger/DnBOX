# Two independent Synth One delay cursors on PI32v2

The first 512-frame half after an unannounced delay-time edit took **16,148.297 µs** for the edited owner and **1,228.492 µs** for the unchanged owner. Every one of their 4,096 wet output words and all 330 final state words matched the original instrument. The target gets historical dry samples and smoothed controls from an ideal provider. It computes its own intermediate feedback, tap locations, interpolation weights and four output streams.

The complete wet-output kernel is 1,774 bytes of target code. It generated 17,556 past frames for the two long paths and 9,034 for the short paths in the edited half. On the short cursor, the second right repeat consumes the current output of the long right path. Each path keeps a mirrored three-sample guard so that the four interpolation samples are contiguous when a ring wraps. The active cursors and their two frame counters occupy 660 bytes per owner. Four earlier 452-byte checkpoints bring this witness to **2,468 bytes per owner**, leaving 296 bytes out of the conditional 2,764-byte budget. Wet output capture storage in the runner is external to this delay state. The rings here cover the observed mature 32- and 16-frame source segments in these two projects. Full source regeneration, other tap trajectories, the remaining engines and flash integration are still outstanding.

| Edited owner's work | Long cursor | Short cursor | Serial total |
| --- | ---: | ---: | ---: |
| Feedback arithmetic with supplied tap indices and coefficients | 5,760.749 µs | 4,159.622 µs | 9,920.372 µs |
| Guarded rings, derive taps from raw controls, each cursor advanced in one call | 7,966.567 µs | 5,326.291 µs | 13,292.858 µs |
| Complete native 512-frame callback, advance cursors interleaved and emit every requested wet word | | | 16,148.297 µs |

The separate components can run below the 11,609 µs deadline if each has a dedicated core. The complete one-owner serial callback exceeds it by 4,539 µs before computing the historical dry inputs. The 9,920 µs arithmetic control assumes a provider already computed and stored every intermediate tap operand. Each per-cursor test checks its active state and the frozen inactive sentinels, or every word in the compact layout. The callback checks both cursor states, both next-frame indices and every emitted word. The complete capture, image and harness hashes are in results.json. All elapsed times are emulated 360 MHz CPU time.

## Reproduction

Use the sources and upstream original factory traces from the adjacent checkpoint-provider and prewarm-live-edit archives. The earlier target_cases.py creates PREPARED (with changed/data and control/data). EDITED contains source-1.bin and source-8.bin from the original single-edit reference fixture. BASELINE contains feedback-1.bin and feedback-8.bin. RUNNER is the unmodified strict CPU-model runner compiled from target-run.rs in the checkpoint-provider archive, and TC is the pinned JieLi toolchain root. Use distinct empty output directories.

```sh
python3 host-stages.py PREWARM_SOURCES BASELINE EDITED host-check
python3 run.py TC RUNNER PREPARED component-prepared
python3 run.py TC RUNNER PREPARED component-guarded --raw-traces EDITED --guarded
python3 callback.py TC RUNNER PREPARED EDITED full-callback
```

The host control reconstructs the original checkpoints from frame zero and then prunes only the dependencies that each replay cursor never consumes. It reproduced the complete forecast, one-owner edit and peer-control word counts at every agreed prefix. Native initial states come from the matching prepared source positions. The freestanding native callback is a computation and memory probe. Real instrument firmware still needs a bounded historical provider and a complete link and load test.
