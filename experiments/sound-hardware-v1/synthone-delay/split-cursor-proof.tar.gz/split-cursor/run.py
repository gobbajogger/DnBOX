import argparse, csv, hashlib, struct, subprocess
from pathlib import Path

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    for arg in ('tc','runner','prepared','out'):
        parser.add_argument(arg,type=Path)
    parser.add_argument("--raw-traces",type=Path)
    parser.add_argument("--cached",action="store_true")
    parser.add_argument("--guarded",action="store_true")
    args = parser.parse_args()
    args.out.mkdir(exist_ok=True,parents=True)
    root=Path(__file__).resolve().parent
    tc=args.tc.resolve()/'pi32v2'
    output = []
    for kind,active in [('long',(0,1)),('short',(1,2,3))]:
        obj = args.out/(kind+'.o')
        binary = args.out/(kind+'.raw')
        flags = ['-DLONG_CURSOR'] if kind=='long' else []
        subprocess.run([tc/'bin/clang','-target','pi32v2','-mcpu=r3','-mfprev1','-fno-fast-math','-ffp-contract=off','-Oz','-idirafter',tc/'include',*flags,'-c',root/('guarded-kernel.c' if args.guarded else 'cached-kernel.c' if args.cached else 'raw-kernel.c' if args.raw_traces else 'kernel.c'),'-o',obj],check=True)
        subprocess.run([tc/'bin/objcopy','-O','binary','-j','.text',obj,binary],check=True)
        for scene in ['changed','control']:
            base=args.prepared/scene/'data'
            for scenario in sorted(base.glob('*-'+kind)):
                dest=args.out/scene/scenario.name
                dest.mkdir(exist_ok=True,parents=True)
                if args.raw_traces:
                    import json
                    import numpy as np
                    trace = args.raw_traces/('source-1.bin' if scene=='changed' else 'source-8.bin')
                    rows = np.memmap(trace,dtype='<f4',mode='r').reshape(-1,4,5)
                    intervals = {key:(start,n) for key,start,n in json.loads((base.parent/'requested.json').read_text())}
                    first,n = intervals[scenario.name]
                    content = np.zeros((n,35),dtype='<f4')
                    data = rows[first:first+n]
                    content[:,0:2]=data[:,:2,0]
                    content[:,2]=data[:,0,2]
                    content[:,3]=data[:,0,3]
                    content[:,4]=data[:,2,3]
                    content.view('<u4')[:,5]=np.arange(first,first+n,dtype='<u4')
                    if args.cached or args.guarded:
                        assert first>35 and np.all((data[:,0,3]*44100>=2)&(data[:,0,3]*44100<=32))
                        assert np.all((data[:,2,3]*44100>=2)&(data[:,2,3]*44100<=16))
                    assert (data[:,0,3]==data[:,1,3]).all() and (data[:,2,3]==data[:,3,3]).all()
                    (dest/'source.bin').write_bytes(content.tobytes())
                for f in (['initial.bin'] if args.raw_traces else ['initial.bin','source.bin']):
                    path=dest/f
                    if not path.exists():path.symlink_to((scenario/f).resolve())
                init=(scenario/'initial.bin').read_bytes()
                full=(scenario/'expected.bin').read_bytes()
                assert len(init)==len(full)==113*4
                expected=bytearray(init)
                spans=[(0,35),(35,70),(70,89),(89,108)]
                live_words=0
                for p in active:
                    a,b=spans[p]
                    for i in [*range(a,b),109+p]:
                        expected[4*i:4*i+4]=full[4*i:4*i+4]
                        live_words+=1
                if args.guarded:
                    def pack(words):
                        import numpy as np
                        x=np.frombuffer(words,'<u4')
                        def guarded(view):
                            return np.concatenate([view,view[:3]],axis=0).ravel()
                        stereo=np.column_stack
                        if kind=='long':
                            return np.concatenate([guarded(stereo((x[:35],x[35:70]))),x[109:111]]).tobytes()
                        return np.concatenate([guarded(x[35:70]),guarded(stereo((x[70:89],x[89:108]))),x[110:113]]).tobytes()
                    (dest/'initial.bin').unlink()
                    (dest/'initial.bin').write_bytes(pack(init))
                    expected=pack(full)
                (dest/'expected.bin').write_bytes(expected)
                s=subprocess.check_output([args.runner.resolve(),binary,dest],text=True).strip().split(',')
                assert int(s[1])*4==len(expected) and int(s[2])==0
                output.append((scene,scenario.name,live_words,*s,digest(binary),digest(dest/'source.bin')))
    p=args.out/'results.csv'
    with p.open('w') as f:
        w=csv.writer(f);w.writerow(['scenario','prefix_cursor','active_state_words','source_frames','compared_words','different','instructions','ticks','us','kernel_sha256','source_sha256']);w.writerows(output)
    print(p.read_text())
if __name__=='__main__':main()
