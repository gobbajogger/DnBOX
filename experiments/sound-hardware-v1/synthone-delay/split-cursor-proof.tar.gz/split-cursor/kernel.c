#include <stdint.h>

typedef struct {
    uint16_t dest, at[4], pad;
    float f, w, x, y, z;
} prepared_tap;

typedef struct {
    float dry[2], feedback;
    prepared_tap tap[4];
} source_frame;

typedef struct {
    float history[109], previous[4];
} cursor_state;

static inline __attribute__((always_inline)) float next_value(float *history,
        const prepared_tap *tap, float input, float previous, float feedback)
{
    history[tap->dest] = input + previous * feedback;
    const float b = history[tap->at[1]];
    float mix = tap->w * history[tap->at[0]] + tap->x * b;
    mix += tap->y * history[tap->at[2]];
    mix += tap->z * history[tap->at[3]];
    return mix * tap->f + b;
}

/* The short right repeat consumes the current output of the long right path. */
void render(cursor_state *restrict state, const source_frame *restrict source, unsigned n)
{
    float r = state->previous[1];
#ifdef LONG_CURSOR
    float l = state->previous[0];
#else
    float fill = state->previous[2], rr = state->previous[3];
#endif
    for (unsigned t=0; t<n; ++t) {
        const source_frame *frame = source+t;
        r = next_value(state->history, &frame->tap[1], frame->dry[1], r, frame->feedback);
#ifdef LONG_CURSOR
        l = next_value(state->history, &frame->tap[0], frame->dry[0], l, frame->feedback);
#else
        fill = next_value(state->history, &frame->tap[2], frame->dry[1], fill, frame->feedback);
        rr = next_value(state->history, &frame->tap[3], r, rr, frame->feedback);
#endif
    }
    state->previous[1] = r;
#ifdef LONG_CURSOR
    state->previous[0] = l;
#else
    state->previous[2] = fill;
    state->previous[3] = rr;
#endif
}
