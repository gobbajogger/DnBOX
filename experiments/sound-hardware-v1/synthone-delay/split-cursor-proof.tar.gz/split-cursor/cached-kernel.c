#include <stdint.h>

typedef struct {
    float dry[2], feedback, long_seconds, short_seconds;
    uint32_t frame;
    uint32_t unused[29]; /* Preserve the fixed input stride of the comparison harness. */
} source_frame;

typedef struct {
    float history[109], previous[4];
} cursor_state;

typedef struct {
    int base;
    float f, w, x, y, z;
} lag;

static inline __attribute__((always_inline)) lag locate(float seconds, int t)
{
    float f = seconds * -44100.0f;
    int base = (int)f;
    f -= (float)base;
    base += t;
    if (base < 0 || f < 0.0f) {
        f += 1.0f;
        --base;
    }
    float z = (f*f - 1.0f) / 6.0f;
    float y = (f + 1.0f)*0.5f;
    float x = 3.0f*z;
    lag q = {base, f, (y-1.0f)-z, x-f, y-x, z};
    return q;
}

typedef struct { unsigned a, b, c, d; } positions;

static inline __attribute__((always_inline)) unsigned wrap_next(unsigned x, unsigned cap)
{
    return x+1 == cap ? 0 : x+1;
}

static inline __attribute__((always_inline)) positions offsets(unsigned head, unsigned cap, int d)
{
    int i=(int)head+d-1;
    if (i<0) i+=(int)cap;
    positions j;
    j.a=(unsigned)i;
    j.b=wrap_next(j.a,cap);
    j.c=wrap_next(j.b,cap);
    j.d=wrap_next(j.c,cap);
    return j;
}

static inline __attribute__((always_inline)) float step(float *ring, unsigned head, lag q, positions j,
        float input, float feedback, float previous)
{
    ring[head]=input+previous*feedback;
    float b=ring[j.b];
    float sum=q.w*ring[j.a]+q.x*b;
    sum+=q.y*ring[j.c];
    sum+=q.z*ring[j.d];
    return sum*q.f+b;
}

/* Measured mature, short-history section only. Caller must dispatch other legal
 * delays and startup to the generic kernel. All ring neighbors exist here. */
void render(cursor_state *restrict state, const source_frame *restrict source, unsigned n)
{
    if (!n) return;
    unsigned t=source->frame, head=t%35;
    float r=state->previous[1];
#ifdef LONG_CURSOR
    float l=state->previous[0];
#else
    unsigned small_head=t%19;
    float fill=state->previous[2], rr=state->previous[3];
    float last_short=-1.0f;
    lag small_lag={0};
#endif
    float last_long=-1.0f;
    lag long_lag={0};
    for (unsigned i=0;i<n;++i) {
        const source_frame *frame=source+i;
        if (frame->long_seconds!=last_long) {
            last_long=frame->long_seconds;
            long_lag=locate(last_long,0x10000);
            long_lag.base-=0x10000;
        }
        positions cols=offsets(head,35,long_lag.base);
        r=step(state->history+35,head,long_lag,cols,frame->dry[1],frame->feedback,r);
#ifdef LONG_CURSOR
        l=step(state->history,head,long_lag,cols,frame->dry[0],frame->feedback,l);
#else
        if (frame->short_seconds!=last_short) {
            last_short=frame->short_seconds;
            small_lag=locate(last_short,0x10000);
            small_lag.base-=0x10000;
        }
        positions small=offsets(small_head,19,small_lag.base);
        fill=step(state->history+70,small_head,small_lag,small,frame->dry[1],frame->feedback,fill);
        rr=step(state->history+89,small_head,small_lag,small,r,frame->feedback,rr);
        small_head=wrap_next(small_head,19);
#endif
        head=wrap_next(head,35);
    }
    state->previous[1]=r;
#ifdef LONG_CURSOR
    state->previous[0]=l;
#else
    state->previous[2]=fill;
    state->previous[3]=rr;
#endif
}
