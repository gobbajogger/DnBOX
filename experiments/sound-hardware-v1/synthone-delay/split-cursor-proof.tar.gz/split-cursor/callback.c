#include <stdint.h>

typedef struct { float l,r; } stereo;
typedef struct { float l,r,feedback,long_delay,short_delay; } past_input;
typedef struct { float length[2]; } live_input;
typedef struct { unsigned long_count, short_count, output_frame, frames; } header;
typedef struct { float f,w,x,y,z; int base; } tap;
typedef struct { stereo samples[38], last; } long_cursor;
typedef struct { float right[38]; stereo small[22]; float last_right; stereo last_small; } short_cursor;
typedef struct {
    long_cursor long_path;
    short_cursor short_path;
    unsigned next_long, next_short;
    float measured_output[512][4];
} test_output;

static inline __attribute__((always_inline)) tap coefficients(float seconds)
{
    float f=seconds*-44100.0f;
    int base=(int)f;
    f-=(float)base;
    if(f<0.0f){--base;f+=1.0f;}
    float z=(f*f-1.0f)/6.0f, y=(f+1.0f)*0.5f, x=3.0f*z;
    tap q={f,(y-1.0f)-z,x-f,y-x,z,base};
    return q;
}
static inline __attribute__((always_inline)) float value(tap q,float a,float b,float c,float d)
{
    float v=q.w*a+q.x*b;
    v+=q.y*c;
    v+=q.z*d;
    return v*q.f+b;
}
static inline __attribute__((always_inline)) stereo read_pair(const stereo *a,tap q)
{
    stereo out={value(q,a[0].l,a[1].l,a[2].l,a[3].l),value(q,a[0].r,a[1].r,a[2].r,a[3].r)};
    return out;
}
static inline __attribute__((always_inline)) int old_first(int head,tap q,int cap)
{
    int j=head+q.base-1;
    return j<0?j+cap:j;
}
static inline __attribute__((always_inline)) stereo put_pair(stereo *ring,int cap,int head,tap q,stereo s)
{
    ring[head]=s;
    if(head<3)ring[head+cap]=s;
    return read_pair(ring+old_first(head,q,cap),q);
}
static inline __attribute__((always_inline)) tap cached(float time,float *last,tap *cache)
{
    if(time!=*last){*last=time;*cache=coefficients(time);}
    return *cache;
}

/* All retained source spans are mature and in the validated short-delay window.
 * The upstream provider supplies past dry inputs and smoothed controls. */
void render(test_output *restrict s,const header *restrict inputs,unsigned unused)
{
    (void)unused;
    const live_input *live=(const live_input *)(inputs+1);
    const past_input *long_input=(const past_input *)(live+inputs->frames);
    const past_input *short_input=long_input+inputs->long_count;
    unsigned next_l=s->next_long, next_s=s->next_short;
    unsigned hl=next_l%35, hr=next_s%35, hs=next_s%19;
    float t1=-1,t2=-1,t3=-1;
    tap c1={0},c2={0},c3={0};
    stereo l=s->long_path.last, small=s->short_path.last_small;
    float r=s->short_path.last_right;
    for(unsigned i=0;i<inputs->frames;++i) {
        int now=(int)(inputs->output_frame+i);
        tap a=coefficients(live[i].length[0]), b=coefficients(live[i].length[1]);
        int base_l=now+a.base,base_s=now+b.base;
        while((int)next_l<=base_l+2){
            const past_input *f=long_input++;
            tap q=cached(f->long_delay,&t1,&c1);
            stereo w={f->l+l.l*f->feedback,f->r+l.r*f->feedback};
            l=put_pair(s->long_path.samples,35,hl,q,w);
            hl=hl==34?0:hl+1; ++next_l;
        }
        while((int)next_s<=base_s+2){
            const past_input *f=short_input++;
            tap q=cached(f->long_delay,&t2,&c2);
            float w=f->r+r*f->feedback;
            s->short_path.right[hr]=w;
            if(hr<3)s->short_path.right[hr+35]=w;
            const float *h=s->short_path.right+old_first(hr,q,35);
            r=value(q,h[0],h[1],h[2],h[3]);
            q=cached(f->short_delay,&t3,&c3);
            stereo w2={f->r+small.l*f->feedback,r+small.r*f->feedback};
            small=put_pair(s->short_path.small,19,hs,q,w2);
            hr=hr==34?0:hr+1; hs=hs==18?0:hs+1; ++next_s;
        }
        stereo wl=read_pair(s->long_path.samples+(unsigned)(base_l-1)%35,a);
        stereo ws=read_pair(s->short_path.small+(unsigned)(base_s-1)%19,b);
        s->measured_output[i][0]=wl.l; s->measured_output[i][1]=wl.r;
        s->measured_output[i][2]=ws.l; s->measured_output[i][3]=ws.r;
    }
    s->long_path.last=l; s->short_path.last_small=small; s->short_path.last_right=r;
    s->next_long=next_l; s->next_short=next_s;
}
