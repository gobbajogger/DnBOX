# A bounded periodic source for the two Synth One delay histories

The two restored programs receive the original 16 note starts and all original live controls at 44.1 kHz. The causal encoder sees each synthesized stereo pre-delay frame once, during its actual note interval. It records the event start frame and MIDI note, a quantized cycle sampled at half the played MIDI frequency, and two envelope measurements. In the authentic traces the maximum left–right dry differences are 5.96e−8 for the bass and 2.38e−7 for the square. The decoder interpolates its own per-event records. It consumes no historical dry frames, wet taps or expected output.

During the initial performance, the actual live signal seeds the four short-feedback checkpoints. Later each replay cursor reconstructs historical dry samples with the learned provider. The experiment keeps the authentic past control timeline, split future announcement and new owner-A time setter at frame 242,550. The 8-bin experiment retains 224 bytes of records for 16 events per owner, uses 300 bytes including its streaming encoder, and uses 16 bytes per historical reader. The 64-bin sensitivity control uses 1,120 bytes of records and 1,532 with the encoder. Actual PI32v2 object symbols confirm every size. The captured start fields span 24 bits. The two cases exercise 11,025 frames per note and 16 intervals. Longer sessions, additional distinct note events, strongly stereo factory effects, and arbitrary polyphony require independent representation.

Four original 452-byte feedback checkpoints and the guarded 312/340-byte live cursors use 2,460 bytes. Of the conditional 2,764-byte allowance this leaves up to 304 bytes per owner before additional control or position state. For these particular scenes the 300-byte encoder finishes before the delayed reads, so the encoder scratch can be reused for the two playback cursors. Simultaneous capture and replay would require 332 bytes with the eight-bin implementation. The 64-bin variant cannot coexist with this allocation.

## Original feedback comparison

The acceptance criteria in contract.json were written before the trial. Each original tap needs RMS level error at most 1 dB, spectral RMS error at most 3 dB and an aligned waveform SNR of at least 24 dB. No gain or phase matching was permitted at scoring. All 512 original frames and all four taps were evaluated. The output order is left long, right long, right-input short fill, and cascaded right short. Every 512-sample channel differs at every float word for both programs and both resolutions.

| Program | Phase bins | Dry SNR over 176,400 frames | First wet-half aligned SNR, four channels |
| --- | ---: | ---: | --- |
| Dat Bomb Bass, Yo (changed) | 8 | 4.97 dB | 6.67, 6.67, 12.00, 15.78 dB |
| Dat Bomb Bass, Yo (changed) | 64 | 6.57 dB | 6.56, 6.56, 16.23, 18.27 dB |
| June Oh 06 Sqr (unchanged control) | 8 | 3.01 dB | −2.25, −2.25, 6.04, 5.30 dB |
| June Oh 06 Sqr (unchanged control) | 64 | 3.40 dB | −2.16, −2.16, 7.71, 6.50 dB |

A unit constant reconstructed exactly for all 11,025 samples at both sizes. The matching-frequency sine yielded 25.38 and 46.90 dB SNR respectively, while its low-level harmonic artifacts exceeded the spectral gate. An original sustained MIDI 60 INIT interval yielded 1.76 and 15.23 dB SNR. The measured factory inputs contain changing pitches, transients and components outside one cycle locked to the current MIDI note. These results qualify this particular periodic representation and leave other source representations open.

## Strict target cost

Both target kernels accept per-frame feedback and delay times. All historical dry fields in their test buffers were zeroed. The PI32v2 code obtains the note phase, waveform and gain from its own 224-byte event records. The target result compares every returned state word, including the modified feedback state, with an independent x86 compilation at the same initial condition. All four comparisons matched. This measures the first 512 wet frames after the edit. It retains the earlier guarded test's supplied starting cursor states and optimistic random-access control stream.

| Owner and cursor | Historical frames generated | Strict 360 MHz elapsed |
| --- | ---: | ---: |
| Changed, long | 17,556 | 14,752.032 µs |
| Changed, short | 9,034 | 8,157.285 µs |
| Unchanged, long | 511 | 434.888 µs |
| Unchanged, short | 511 | 467.866 µs |

The changed long cursor exceeds one 11,609.98 µs physical 512-frame callback by itself. The prior identical guarded arithmetic with ideal external dry data measured 7,966.567 µs and 5,326.291 µs on the changed owner's two cursors. This does not measure a complete firmware callback or prove a lower bound for other implementations. The full stock-independent FX item remains FAIL.

## Replay

Use the traces and original held-note source from the earlier checkpoint-provider-feedback, prewarm-live-edit and original master-gain packets. Their SHA-256 values appear in results.json. The guarded-kernel.c input and the checkpoint_core.hpp, checkpoint_state.h headers are included. Run `sh replay.sh CHANGED_TRACE_DIR FORECAST_TRACE_DIR ORIGINAL_HELD_MIDI60_PCM OUTPUT_DIR` to compile both resolutions, replay the two original programs, score against the separate references and regenerate the control measurements. Row 1 and row 8 use source-1.bin and source-8.bin from the unchanged authored capture and feedback-1.bin and feedback-8.bin as their respective forecasts. The target.py arguments are the PI32v2 toolchain directory, prior strict target-run executable, guarded-kernel.c, original guarded trial directory, generated records directory and new output directory. It compiles fresh native objects and checks for unresolved symbols or code relocations before execution. Its host-side initial cursor checks use the unchanged guarded baseline setup. The comparison deliberately retains the first original cutoff, envelope and release timeline.
