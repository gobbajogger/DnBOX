#include "checkpoint_core.hpp"
#include "provider.h"
#include <string>
static std::vector<Frame> load(const char *path) {
    std::vector<Frame> x(264600);FILE *f=fopen(path,"rb");assert(f);
    assert(fread(x.data(),sizeof(Frame),x.size(),f)==x.size()&&fgetc(f)==EOF);
    fclose(f);return x;
}
static void emit(FILE *f,float x){assert(fwrite(&x,sizeof x,1,f)==1);}
int main(int argc,char **argv) {
    assert(argc==5);
    const auto data=load(argv[1]),pred=load(argv[2]);
    unsigned owner=(unsigned)atoi(argv[3]);assert(owner==1||owner==8);
    std::string out=argv[4];dry_history hist{};
    FILE *dry=fopen((out+".dry").c_str(),"wb"),*wet=fopen((out+".wet").c_str(),"wb");
    assert(dry&&wet);
    for(unsigned e=0;e<16;++e) {
        unsigned at=e*11025;unsigned note=42+(owner==8?17:0)+e%5;
        assert(dry_begin(&hist,at,note));
        for(unsigned k=at;k<at+11025;++k)dry_offer(&hist,data[k][0].input,data[k][1].input);
        dry_finish(&hist,at+11025);
    }
    FILE *pack=fopen((out+".records").c_str(),"wb");assert(pack);
    assert(fwrite(hist.events,sizeof hist.events,1,pack)==1);fclose(pack);
    dry_reader all{};
    for(unsigned t=0;t<176400;++t)emit(dry,dry_get(&hist,&all,t));
    fclose(dry);
    flash_witness_owner state{};
    /* The on-line owner sees authentic dry while it creates historical checkpoints. */
    for(unsigned t=0;t<4*stride;++t) {
        tick(state.active[0],data[t]);
        if(state.active[0].next%stride==0)state.saved[state.active[0].next/stride-1]=state.active[0];
    }
    unsigned want[2];dry_reader cursors[2]{};
    auto advance=[&](unsigned k,unsigned limit) {
        auto &c=state.active[k];auto &r=cursors[k];
        while(c.next<limit) {
            auto f=data[c.next];
            float v=dry_get(&hist,&r,c.next);
            for(unsigned p=0;p<3;++p)f[p].input=v;
            tick(c,f);
        }
    };
    for(unsigned k=0;k<2;++k) {
        Query q=at(first_wet,pred[first_wet][2*k].delay);want[k]=q.base+3;
        prepare(state,state.active[k],q.base-1);
        advance(k,want[k]);
    }
    for(unsigned t=first_wet;t<first_wet+512;++t) {
        for(unsigned k=0;k<2;++k) {
            Query q=at(t,data[t][2*k].delay);advance(k,q.base+3);
            for(unsigned p=2*k;p<2*k+2;++p)
                emit(wet,read(state.active[k],q,p,int(state.active[k].next)-1));
        }
    }
    fclose(wet);
    printf("events_bytes=%zu complete_encoder_bytes=%zu reader_bytes=%zu bins=%u\n",sizeof hist.events,sizeof(hist),sizeof(dry_reader),PHASE_BINS);
}
