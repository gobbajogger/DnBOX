#ifndef WITNESS_SHORT_STATE_H
#define WITNESS_SHORT_STATE_H
#include <stdint.h>
/* Five guard positions cover the authentic four-point interpolation around
 * the observed 32/16-frame early taps, including startup. No pointers. */
typedef struct {
    float long_writes[2][35], short_writes[2][19], prev[4];
    uint32_t next;
} flash_witness_cursor;
typedef struct {
    flash_witness_cursor saved[4], active[2];
} flash_witness_owner;
#endif
