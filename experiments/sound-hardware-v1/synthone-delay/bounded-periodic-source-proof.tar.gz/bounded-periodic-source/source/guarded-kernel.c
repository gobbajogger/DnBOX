#include <stdint.h>
#include <stddef.h>

typedef struct {
    float dry[2], feedback, long_seconds, short_seconds;
    uint32_t frame, stride_padding[29];
} source_frame;

/* Three mirrored samples at the end permit a contiguous cubic read. */
typedef struct { float left, right; } pair;
#ifdef LONG_CURSOR
typedef struct { pair long_ring[38], previous; } state_t;
#else
typedef struct { float right_ring[38]; pair short_ring[22]; float right, fill, repeat; } state_t;
#endif

typedef struct { float f, w, x, y, z; int delta; } weights;

static inline __attribute__((always_inline)) weights calculate(float delay)
{
    float f=delay * -44100.0f;
    int delta=(int)f;
    f-=(float)delta;
    if (f<0.0f) { --delta; f+=1.0f; }
    float z=(f*f-1.0f)/6.0f, y=(f+1.0f)*0.5f, x=3.0f*z;
    weights q={f,(y-1.0f)-z,x-f,y-x,z,delta-1};
    return q;
}

static inline __attribute__((always_inline)) float interpolate(weights q,float a,float b,float c,float d)
{
    float mix=q.w*a+q.x*b;
    mix+=q.y*c;
    mix+=q.z*d;
    return mix*q.f+b;
}

static inline __attribute__((always_inline)) int first(int head,int delta,int capacity)
{
    int index=head+delta;
    return index<0 ? index+capacity : index;
}

static inline __attribute__((always_inline)) pair advance_pair(pair *ring,int cap,int head,
        weights q,float left,float right)
{
    const pair input={left,right};
    ring[head]=input;
    if (head<3) ring[cap+head]=input;
    const pair *a=ring+first(head,q.delta,cap);
    const pair out={interpolate(q,a[0].left,a[1].left,a[2].left,a[3].left),
                    interpolate(q,a[0].right,a[1].right,a[2].right,a[3].right)};
    return out;
}

/* Dispatch to the ordinary kernel during startup or outside the retained window. */
void render(state_t *restrict s,const source_frame *restrict frames,unsigned n)
{
    if (!n) return;
    unsigned head=frames->frame%35;
    weights full={0};
    float last_full=-1.0f;
#ifdef LONG_CURSOR
    pair previous=s->previous;
#else
    unsigned small_head=frames->frame%19;
    float last_half=-1.0f; weights half={0};
    float right=s->right; pair previous={s->fill,s->repeat};
#endif
    for (unsigned i=0;i<n;++i) {
        const source_frame *f=frames+i;
        if (f->long_seconds!=last_full) {
            last_full=f->long_seconds;
            full=calculate(last_full);
        }
#ifdef LONG_CURSOR
        previous=advance_pair(s->long_ring,35,head,full,f->dry[0]+previous.left*f->feedback,
                              f->dry[1]+previous.right*f->feedback);
#else
        if (f->short_seconds!=last_half) {
            last_half=f->short_seconds;
            half=calculate(last_half);
        }
        float written=f->dry[1]+right*f->feedback;
        s->right_ring[head]=written;
        if (head<3) s->right_ring[head+35]=written;
        float *r=s->right_ring+first(head,full.delta,35);
        right=interpolate(full,r[0],r[1],r[2],r[3]);
        previous=advance_pair(s->short_ring,19,small_head,half,
                  f->dry[1]+previous.left*f->feedback,right+previous.right*f->feedback);
        small_head=small_head==18 ? 0 : small_head+1;
#endif
        head=head==34 ? 0 : head+1;
    }
#ifdef LONG_CURSOR
    s->previous=previous;
#else
    s->right=right; s->fill=previous.left; s->repeat=previous.right;
#endif
}
