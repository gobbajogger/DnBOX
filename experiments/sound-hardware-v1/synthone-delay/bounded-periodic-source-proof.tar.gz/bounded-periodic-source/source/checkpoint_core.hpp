/* A bounded, online-checkpoint variant for the observed short-to-long scenes.
 * The historical input and control values come from an ideal immutable
 * random-access provider. Original wet results only validate the regenerated
 * output; all saved state comes from this implementation's own recurrence. */
#include "checkpoint_state.h"
#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <vector>
struct Sample {float input,previous,feedback,delay,expected;};
using Frame=std::array<Sample,4>;
struct Query {int base;float f;};
static constexpr unsigned stride=35280,first_wet=242550;
static unsigned long long cpu_time() {
    timespec t{};if(clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t))std::abort();
    return static_cast<unsigned long long>(t.tv_sec)*1000000000+t.tv_nsec;
}
static Query at(unsigned t,float delay) {
    float f=static_cast<float>(delay*(-1.0*44100));
    int base=static_cast<int>(f);f-=float(base);base+=int(t);
    if(base<0||f<0){++f;--base;}
    return {base,f};
}
static float get(const flash_witness_cursor& c,int j,unsigned p,int latest) {
    if(j<0 || j>latest)return 0.f;
    unsigned cap=p<2?35:19;
    assert(latest-j<int(cap));
    return p<2?c.long_writes[p][unsigned(j)%cap]:c.short_writes[p-2][unsigned(j)%cap];
}
static float read(const flash_witness_cursor& c,Query q,unsigned p,int latest) {
    float f=q.f,z=f*f;--z;z*=.1666666667;
    float y=f;++y;float w=(y*=.5);--w;float x=3.f*z;y-=x;w-=z;x-=f;
    float a=get(c,q.base-1,p,latest),b=get(c,q.base,p,latest);
    float d=get(c,q.base+1,p,latest),e=get(c,q.base+2,p,latest);
    return (w*a+x*b+y*d+z*e)*f+b;
}
static void tick(flash_witness_cursor& c,const Frame& frame) {
    unsigned t=c.next;
    for(unsigned p=0;p<4;++p) {
        float input=p==3?c.prev[1]:frame[p].input; // R output has already updated this frame.
        float written=input+c.prev[p]*frame[p].feedback;
        if(p<2)c.long_writes[p][t%35]=written;
        else c.short_writes[p-2][t%19]=written;
        c.prev[p]=read(c,at(t,frame[p].delay),p,int(t));
    }
    ++c.next;
}
static unsigned prepare(const flash_witness_owner& owner,flash_witness_cursor& c,unsigned source_start) {
    unsigned which=std::min(source_start/stride,4u);
    if(which)c=owner.saved[which-1];
    else c=flash_witness_cursor{};
    return c.next;
}
