#!/bin/sh
set -eu
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ "$#" -ne 4 ]; then echo "usage: $0 CHANGED_DRY_TRACE_DIR FORECAST_TRACE_DIR ORIGINAL_HELD_MIDI60_PCM OUTPUT_DIR" >&2; exit 2; fi
mkdir -p "$4"
for bits in 3 6; do
    c++ -std=c++17 -O2 -fno-fast-math -ffp-contract=off -I"$here/source" -DPHASE_BITS="$bits" "$here/experiment.cpp" -o "$4/test-$bits"
    for owner in 1 8; do
        "$4/test-$bits" "$1/source-$owner.bin" "$2/feedback-$owner.bin" "$owner" "$4/$bits-$owner"
    done
done
python3 "$here/measure.py" "$1" "$3" "$4"
