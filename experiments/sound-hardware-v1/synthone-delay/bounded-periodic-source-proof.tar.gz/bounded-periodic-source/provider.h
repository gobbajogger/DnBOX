#ifndef DRY_PERIODIC_PROVIDER_H
#define DRY_PERIODIC_PROVIDER_H
#include <stdint.h>
#include <string.h>
#include <math.h>
#ifndef PHASE_BITS
#define PHASE_BITS 3
#endif
#define PHASE_BINS (1u << PHASE_BITS)
#define DRY_NOTES 16u
#define HALF_ENV 5512u
typedef struct {
    uint8_t start[3], midi, levels[2];
    int8_t cycle[PHASE_BINS];
} dry_record;
typedef struct {
    float sum[PHASE_BINS], energy[2];
    uint16_t hits[PHASE_BINS];
    uint32_t phase, step, count;
} dry_analysis;
typedef struct {
    dry_record events[DRY_NOTES];
    dry_analysis run;
    uint32_t used, end;
} dry_history;
typedef struct {
    uint32_t start,end,step,index;
} dry_reader;
static inline __attribute__((always_inline)) uint32_t dry_start(const dry_record *r) {
    return r->start[0]|((uint32_t)r->start[1]<<8)|((uint32_t)r->start[2]<<16);
}
static inline __attribute__((always_inline)) uint32_t dry_increment(unsigned midi) {
    /* Q0.32 phase/sample, for half the authentic equal-tempered note pitch. */
    int d=(int)midi-69;
    float f=220.0f;
    while (d>=12){f*=2;d-=12;}
    while (d<0){f*=.5f;d+=12;}
    while (d-->0) f*=1.0594630943592952646f;
    return (uint32_t)(int32_t)(f*(4294967296.0f/44100.0f)+.5f);
}
static int dry_begin(dry_history *h,unsigned frame,unsigned note) {
    if(h->used>=DRY_NOTES||frame>=0x1000000||note>127)return 0;
    dry_record *r=&h->events[h->used++];
    r->start[0]=frame;r->start[1]=frame>>8;r->start[2]=frame>>16;r->midi=(uint8_t)note;
    memset(&h->run,0,sizeof h->run);h->run.step=dry_increment(note);return 1;
}
static void dry_offer(dry_history *h,float left,float right) {
    dry_analysis *a=&h->run;
    unsigned slot=(a->phase+(1u<<(31-PHASE_BITS)))>>(32-PHASE_BITS);
    float v=.5f*(left+right);
    a->sum[slot]+=v;++a->hits[slot];a->energy[a->count>=HALF_ENV]+=v*v;
    ++a->count;a->phase+=a->step;
}
static unsigned dry_byte(float v) {
    return v<0?0:v>1?255:(unsigned)(v*255.f+.5f);
}
static void dry_finish(dry_history *h,unsigned end) {
    dry_analysis *a=&h->run;
    dry_record *r=&h->events[h->used-1];h->end=end;
    float peak=0,power=0;
    for(unsigned k=0;k<PHASE_BINS;++k) {
        if(a->hits[k])a->sum[k]/=a->hits[k];
        float x=fabsf(a->sum[k]);if(x>peak)peak=x;
        power+=x*x;
    }
    for(unsigned k=0;k<PHASE_BINS;++k)r->cycle[k]=peak?(int8_t)lrintf(127.f*a->sum[k]/peak):0;
    for(unsigned k=0;k<2;++k) {
        unsigned n=k?(a->count>HALF_ENV?a->count-HALF_ENV:0):(a->count>HALF_ENV?HALF_ENV:a->count);
        float level=(n&&power>0)?peak*sqrtf(a->energy[k]*(float)PHASE_BINS/(n*power)):0;
        r->levels[k]=dry_byte(level);
    }
}
static inline __attribute__((always_inline)) void dry_seek(const dry_history *h,dry_reader *q,unsigned t) {
    unsigned lo=0,hi=h->used;
    while (lo+1<hi) {
        unsigned m=(lo+hi)/2;
        if(dry_start(&h->events[m])<=t)lo=m;else hi=m;
    }
    q->index=lo;q->start=dry_start(&h->events[lo]);
    q->end=lo+1<h->used?dry_start(&h->events[lo+1]):h->end;
    q->step=dry_increment(h->events[lo].midi);
}
static inline __attribute__((always_inline)) float dry_get(const dry_history *h,dry_reader *q,unsigned t) {
    if(!h->used||t>=h->end)return 0;
    if(t<q->start||t>=q->end)dry_seek(h,q,t);
    const dry_record *r=&h->events[q->index];
    uint32_t since=t-q->start,phase=since*q->step;
    unsigned bin=phase>>(32-PHASE_BITS);
    float alpha=((phase>>(16-PHASE_BITS))&65535u)*(1.f/65536.f);
    float v=r->cycle[bin]+alpha*(r->cycle[(bin+1)%PHASE_BINS]-r->cycle[bin]);
    unsigned finish=q->end-q->start;
    float fraction=((float)since-.5f*(finish<HALF_ENV?finish:HALF_ENV))*(2.f/(float)finish);
    if(fraction<0)fraction=0;if(fraction>1)fraction=1;
    float level=r->levels[0]+fraction*((float)r->levels[1]-r->levels[0]);
    return v*(level*(1.f/(127.f*255.f)));
}
#endif
