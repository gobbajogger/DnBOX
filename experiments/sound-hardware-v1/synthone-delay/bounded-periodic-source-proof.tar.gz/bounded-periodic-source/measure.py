from pathlib import Path
import argparse,hashlib,json,subprocess
import numpy as np
p=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument("changed_trace_dir",type=Path)
parser.add_argument("original_midi60_pcm",type=Path)
parser.add_argument("output_dir",type=Path)
args=parser.parse_args();output=args.output_dir.resolve()
contract=json.loads((p/'contract.json').read_text())
def compare(x,y):
    x,y=x.astype('f8'),y.astype('f8')
    n=contract['musical_gates']['fft'];hop=contract['musical_gates']['hop']
    def rms(v):return np.sqrt(np.mean(v*v))
    def spec(v):
        sl=np.lib.stride_tricks.sliding_window_view(v,n)[::hop]*np.hanning(n)
        return np.sqrt(np.mean(abs(np.fft.rfft(sl))**2,axis=0))
    sx,sy=spec(x),spec(y);floor=max(sx.max()*1e-4,1e-12);use=(sx>floor)|(sy>floor)
    dr=float(20*np.log10(max(rms(y),1e-30)/max(rms(x),1e-30)))
    ds=float(rms(20*np.log10(np.maximum(sy[use],floor)/np.maximum(sx[use],floor))))
    snr=float(20*np.log10(max(rms(x),1e-30)/max(rms(x-y),1e-30)))
    return {'signed_rms_db':dr,'spectrum_rms_db':ds,'snr_db':snr,
            'different_words':int(np.sum(x.astype('<f4').view('<u4')!=y.astype('<f4').view('<u4'))),
            'passed':abs(dr)<=1 and ds<=3 and snr>=24}
out={'limits':contract['musical_gates'],'programs':{},'controls':{},'input_sha256':{}}
for owner in (1,8):
    fn=args.changed_trace_dir/f'source-{owner}.bin';a=np.memmap(fn,dtype='<f4',mode='r').reshape(-1,4,5)
    out['input_sha256'][fn.name]=hashlib.sha256(fn.read_bytes()).hexdigest()
    ownerres=out['programs'][owner]={}
    for bits in (3,6):
        tag=f'{bits}-{owner}'; y=np.fromfile(output/(tag+'.dry'),'<f4');w=np.fromfile(output/(tag+'.wet'),'<f4').reshape(512,4)
        t=242550;d=a[:16*11025,:2,0]
        spans=([(22136,22136+17556),(132344,132344+9034)] if owner==1 else [(22136,22136+511),(132344,132344+511)])
        scores={'all_dry':[compare(d[:,c],y) for c in range(2)],'requested_ranges':[], 'wet':[compare(a[t:t+512,j,4],w[:,j]) for j in range(4)],'peak_left_minus_right':float(np.max(np.abs(d[:,0]-d[:,1])))}
        for start,end in spans:
            scores['requested_ranges'].append({'first':start,'end_exclusive':end,'left':compare(d[start:end,0],y[start:end])})
        ownerres[1<<bits]=scores
orig=args.original_midi60_pcm;actual=np.fromfile(orig,'<f4')[32768:32768+11025]
f=440*2**((60-69)/12)/2
for label,v in [('sine',(0.6*np.sin(2*np.pi*np.arange(11025)*f/44100+.6)).astype('<f4')),('original_held_60',actual),('constant_exact',np.ones(11025,dtype='<f4'))]:
    fname=output/(label+'.f32');v.tofile(fname)
    out['controls'][label]={}
    for bits in (3,6):
        exe=output/('control-'+str(bits));subprocess.run(['cc','-O2','-ffp-contract=off','-fno-fast-math','-DPHASE_BITS='+str(bits),p/'control.c','-lm','-o',exe],check=True)
        outfile=output/(label+str(bits)+'.out');subprocess.run([exe,fname,outfile],check=True)
        out['controls'][label][1<<bits]=compare(v,np.fromfile(outfile,'<f4'))
out['input_sha256']['original-60.pcm']=hashlib.sha256(orig.read_bytes()).hexdigest()
(output/'results.json').write_text(json.dumps(out,indent=2)+'\n')
for owner,d in out['programs'].items():
 for bins,k in d.items(): print(owner,bins,'dry SNR',round(k['all_dry'][0]['snr_db'],2),'wet SNR',[round(v['snr_db'],2) for v in k['wet']],'RMSdB',[round(v['signed_rms_db'],2) for v in k['wet']],'specdB',[round(v['spectrum_rms_db'],2) for v in k['wet']])
for n,d in out['controls'].items():print(n,[(b,round(r['snr_db'],2),r['different_words']) for b,r in d.items()])
