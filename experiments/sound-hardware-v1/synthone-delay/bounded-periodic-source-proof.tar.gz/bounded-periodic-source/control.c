#include "provider.h"
#include <stdio.h>
#include <assert.h>
int main(int argc,char **argv) {
    assert(argc==3);float input[11025];
    FILE *src=fopen(argv[1],"rb"),*out=fopen(argv[2],"wb");assert(src&&out);
    assert(fread(input,sizeof input,1,src)==1);fclose(src);
    dry_history h={0};dry_reader q={0};
    assert(dry_begin(&h,0,60));
    for(unsigned k=0;k<11025;++k)dry_offer(&h,input[k],input[k]);
    dry_finish(&h,11025);
    for(unsigned k=0;k<11025;++k){float y=dry_get(&h,&q,k);fwrite(&y,4,1,out);}
    fclose(out);
}
