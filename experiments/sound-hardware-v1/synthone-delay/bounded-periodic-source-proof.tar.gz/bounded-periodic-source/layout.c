#include "provider.h"
char layout_records[sizeof(((dry_history *)0)->events)];
char layout_capture[sizeof(dry_history)];
char layout_replay_cursor[sizeof(dry_reader)];
