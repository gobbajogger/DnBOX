"""Fuse actual generated dry audio into the previously measured guarded feedback loop."""
from pathlib import Path
import csv,ctypes,hashlib,struct,subprocess,sys
import numpy as np
here=Path(__file__).resolve().parent
tc,runner,guarded,scenarios,records,out=map(lambda x:Path(x).resolve(),sys.argv[1:])
out.mkdir(exist_ok=True,parents=True)
src=guarded.read_text().replace('#include <stddef.h>','#include <stddef.h>\n#include "provider.h"')
old='void render(state_t *restrict s,const source_frame *restrict frames,unsigned n)\n{'
new='typedef struct { state_t dsp; dry_history history; dry_reader pos; } combined;\nvoid render(combined *restrict c,const source_frame *restrict frames,unsigned n)\n{\n    state_t *restrict s=&c->dsp;'
assert src.count(old)==1
src=src.replace(old,new)
mark='const source_frame *f=frames+i;'
assert src.count(mark)==1
src=src.replace(mark,mark+'\n        float regenerated=dry_get(&c->history,&c->pos,f->frame);')
assert src.count('f->dry[0]')==1 and src.count('f->dry[1]')==3
src=src.replace('f->dry[0]','regenerated').replace('f->dry[1]','regenerated')
source=out/'fused.c';source.write_text(src)
result=[]
for kind in ['long','short']:
    flags=['-DLONG_CURSOR'] if kind=='long' else []
    obj=out/(kind+'.o');bin=out/(kind+'.raw');dso=out/(kind+'.so')
    subprocess.run([tc/'bin/clang','-target','pi32v2','-mcpu=r3','-mfprev1','-fno-fast-math','-ffp-contract=off','-Oz','-idirafter',tc/'include','-I'+str(here),*flags,'-c',source,'-o',obj],check=True)
    symbols=subprocess.check_output([tc/'bin/nm','-u',obj],text=True);assert not symbols.strip(),symbols
    reloc=subprocess.check_output([tc/'bin/objdump','-r',obj],text=True)
    (out/(kind+'.relocations.txt')).write_text(reloc);assert 'RELOCATION RECORDS FOR [.text]' not in reloc,reloc
    subprocess.run([tc/'bin/objcopy','-O','binary','-j','.text',obj,bin],check=True)
    subprocess.run(['cc','-O2','-fno-fast-math','-ffp-contract=off','-shared','-fPIC','-I'+str(here),*flags,source,'-o',dso],check=True)
    fn=ctypes.CDLL(str(dso)).render;fn.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_uint]
    for shape,owner in [('changed',1),('control',8)]:
        base=scenarios/shape/('512-'+kind);dest=out/(shape+'-'+kind);dest.mkdir(exist_ok=True)
        old=(base/'initial.bin').read_bytes()
        rec=(records/f'3-{owner}.records').read_bytes();assert len(rec)==224
        init=old+rec+bytes(300-224-8)+struct.pack('<II',16,176400)+bytes(16)
        raw=np.fromfile(base/'source.bin',dtype='<f4').reshape(-1,35)
        raw[:,0:2]=0  # no historical dry samples left in the read-only trace
        data=raw.tobytes()
        st=ctypes.create_string_buffer(init,len(init));a=ctypes.create_string_buffer(data,len(data))
        fn(st,a,len(raw))
        (dest/'initial.bin').write_bytes(init);(dest/'expected.bin').write_bytes(st.raw);(dest/'source.bin').write_bytes(data)
        z=subprocess.check_output([runner,bin,dest],text=True).strip().split(',')
        assert int(z[2])==0 and int(z[1])*4==len(init),z
        result.append([shape,kind,*z,len(bin.read_bytes()),hashlib.sha256(bin.read_bytes()).hexdigest(),hashlib.sha256(data).hexdigest()])
with (out/'target-results.csv').open('w') as f:
    w=csv.writer(f);w.writerow(['scene','cursor','frames','compared_words','different_words','instructions','ticks','us','text_bytes','text_sha256','source_sha256']);w.writerows(result)
