from pathlib import Path
import sys,json,subprocess,ctypes as C,struct,hashlib,csv,statistics
here=Path(__file__).resolve().parent;folder,out=[Path(s).resolve() for s in sys.argv[1:]];out.mkdir(exist_ok=False)
subprocess.run(['cc','-std=c11','-O2','-Wall','-Werror','-shared','-fPIC',here/'codec.c','-o',out/'codec.so'],check=True)
d=C.CDLL(str(out/'codec.so'));d.pack_snapshot.argtypes=[C.c_char_p,C.c_uint,C.c_void_p,C.c_uint,C.c_void_p];d.pack_snapshot.restype=C.c_uint
d.unpack_snapshot.argtypes=[C.c_char_p,C.c_uint,C.c_void_p,C.c_uint];d.unpack_snapshot.restype=C.c_uint
def pack(v):
    dst=C.create_string_buffer(2*len(v)+10);scratch=(C.c_uint16*256)()
    n=d.pack_snapshot(v,len(v),dst,len(dst),scratch);assert n>0
    blob=dst.raw[:n]
    rt=C.create_string_buffer(len(v));assert d.unpack_snapshot(blob,n,rt,len(rt))==len(v) and rt.raw==v
    return blob
h=lambda b:hashlib.sha256(b).hexdigest()
summary={};profiles=[];framing=4
for owner in (1,8):
    contents=(folder/f'source-{owner}.bin.records').read_bytes();at=0;rows=[];keep={}
    while at<len(contents):
        t,n=struct.unpack_from('<IH',contents,at);at+=6;src=contents[at:at+n];at+=n;blob=pack(src)
        records=dict(frame=t,raw_bytes=n,stored_bytes=len(blob)+framing,raw_sha256=h(src),packed_sha256=h(blob))
        rows.append(records);profiles.append(dict(owner=owner,**records))
        if t in (22050,132300):keep[t]=(src,blob)
    assert at==len(contents) and len(rows)==2088
    first,one=keep[22050];second,two=keep[132300];delta=bytes(b^(first[i] if i<len(first) else 0) for i,b in enumerate(second));pair=pack(delta)
    assert bytes(v^(first[i] if i<len(first) else 0) for i,v in enumerate(delta))==second
    for name,buf in [('first',one),('second',two),('xor',pair)]: (out/f'{owner}-{name}.packed').write_bytes(buf)
    s=[v['stored_bytes'] for v in rows]
    summary[owner]=dict(frames=len(s),encoded_length_and_raw_length_header_bytes=framing,min=min(s),median=statistics.median(s),max=max(s),max_frame=rows[s.index(max(s))]['frame'],first=len(one)+framing,second=len(two)+framing,second_xor=len(pair)+framing,pair_standalone=len(one)+len(two)+2*framing,pair_xor=len(one)+len(pair)+2*framing,source_records_sha256=h(contents))
    print(owner,summary[owner],flush=True)
with (out/'per-block.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(profiles[0]));w.writeheader();w.writerows(profiles)
(out/'results.json').write_text(json.dumps(summary,indent=2)+'\n')
# Wrong lengths and impossible distance are checked without consuming destination capacity.
for data,sz in [(bytes([128,0,0]),100),(bytes([128,1,0]),100),(bytes([127,12]),100),(bytes([0,4,128,1,0]),2)]:
    dst=C.create_string_buffer(100);assert d.unpack_snapshot(data,len(data),dst,sz)==0
