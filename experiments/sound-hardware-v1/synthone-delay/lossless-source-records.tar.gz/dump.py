from pathlib import Path
import json,sys,subprocess,hashlib
here=Path(__file__).resolve().parent
factory,reader,prefix,source,voices,observed,out=map(lambda a:Path(a).resolve(),sys.argv[1:])
out.mkdir(exist_ok=False)
inp=(source/'run/reader.cpp').read_text()
key='    FactoryTemplate factory{};';assert inp.count(key)==1;inp=inp.replace(key,key+' FILE* records=nullptr;')
key='        smallest=std::min(smallest,unsigned(snapshot.bytes.size()));';assert inp.count(key)==1
inp=inp.replace(key,'''        uint16_t length=static_cast<uint16_t>(snapshot.bytes.size());CHECK(length==snapshot.bytes.size());
        CHECK(std::fwrite(&start,sizeof(start),1,records)==1 && std::fwrite(&length,2,1,records)==1 && std::fwrite(snapshot.bytes.data(),1,length,records)==length);
'''+key)
key='        CHECK(owners[i]->trace);';assert inp.count(key)==1;inp=inp.replace(key,key+' owners[i]->records=std::fopen((path+".records").c_str(),"wb");CHECK(owners[i]->records);')
key='        CHECK(std::fclose(x.trace)==0);';assert inp.count(key)==1;inp=inp.replace(key,'        CHECK(std::fclose(x.records)==0);'+key)
(out/'dump.cpp').write_text(inp)
commands=json.loads((factory/'factory-build-commands.json').read_bytes());cc=next(c.copy() for c in commands if '-c' in c and c[c.index('-c')+1].endswith('/preset_audio.cpp'));old=cc[cc.index('-o')+1]
for flag,name in [('-c','dump.cpp'),('-o','dump.o'),('-MF','dump.d')]:cc[cc.index(flag)+1]=str(out/name)
cc[1:1]=['-I'+str(x) for x in (source,reader,prefix,voices)];subprocess.run(cc,check=True)
ld=[str(out/'dump.o') if p==old else p for p in commands[-1]];ld[ld.index('-o')+1]=str(out/'dump');subprocess.run(ld,check=True)
assets=factory/'factory-inputs';h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
r=subprocess.run([out/'dump',assets/'public-morphs.f32',assets/'compact.bin',factory/'commands/preset-commands.bin','late',out/'source'],check=True,capture_output=True,text=True)
(out/'dump.log').write_text(r.stderr);assert '2044 0 4294967295' in r.stderr and '2060 0 4294967295' in r.stderr
for o in (1,8): assert h(out/f'source-{o}.bin')==h(observed/f'source-{o}.bin')
