#include <stddef.h>
#include <stdint.h>
#include <string.h>

/* Literal runs use one tag, backward copies use a tag and a 16-bit distance. */
enum { INDEX_SIZE=256, MAX_LITERAL=128, MAX_COPY=130, MIN_COPY=4 };
static unsigned index_key(const uint8_t *s) {
    uint32_t a=(uint32_t)s[0]|((uint32_t)s[1]<<8)|((uint32_t)s[2]<<16)|((uint32_t)s[3]<<24);
    return (a*2654435761u)>>24;
}
static int literal(const uint8_t *s,unsigned start,unsigned end,uint8_t *out,unsigned cap,unsigned *written) {
    while(start<end) {
        unsigned n=end-start; if(n>MAX_LITERAL)n=MAX_LITERAL;
        if(*written>cap || cap-*written<n+1)return 0;
        out[(*written)++]=(uint8_t)(n-1);
        memcpy(out+*written,s+start,n);*written+=n;start+=n;
    }
    return 1;
}
unsigned pack_snapshot(const uint8_t *s,unsigned n,uint8_t *out,unsigned cap,uint16_t index[INDEX_SIZE]) {
    if(!s||!out||!index||n==0||n>=65535u)return 0;
    memset(index,0,INDEX_SIZE*sizeof(*index));
    unsigned pos=0,lit=0,written=0;
    while(n-pos>=MIN_COPY) {
        unsigned key=index_key(s+pos),next=index[key],count=0;
        if(next){
            unsigned prior=next-1;
            while(count<n-pos && count<MAX_COPY && s[pos+count]==s[prior+count])count++;
        }
        if(count<MIN_COPY){index[key]=(uint16_t)(pos+1);pos++;continue;}
        if(!literal(s,lit,pos,out,cap,&written) || cap-written<3)return 0;
        unsigned distance=pos-(next-1);
        out[written++]=(uint8_t)(128+(count-3));
        out[written++]=(uint8_t)distance;out[written++]=(uint8_t)(distance>>8);
        unsigned end=pos+count;
        while(pos<end){if(n-pos>=MIN_COPY)index[index_key(s+pos)]=(uint16_t)(pos+1);pos++;}
        lit=pos;
    }
    return literal(s,lit,n,out,cap,&written)?written:0;
}
unsigned unpack_snapshot(const uint8_t *s,unsigned n,uint8_t *out,unsigned cap) {
    if(!s||!out)return 0;
    unsigned r=0,w=0;
    while(r<n){
        unsigned tag=s[r++];
        if(tag<128){
            unsigned size=tag+1;
            if(n-r<size||cap-w<size)return 0;
            for(unsigned i=0;i<size;i++)out[w++]=s[r++];
        }else{
            unsigned size=(tag&127)+3;
            if(n-r<2||cap-w<size)return 0;
            unsigned distance=(unsigned)s[r]|((unsigned)s[r+1]<<8);r+=2;
            if(!distance||distance>w)return 0;
            for(unsigned i=0;i<size;i++){out[w]=out[w-distance];w++;}
        }
    }
    return w;
}
