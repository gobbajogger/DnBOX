from pathlib import Path
import hashlib,struct,subprocess,json,sys
here=Path(__file__).resolve().parent;data,compiled,tools,runner,out=map(lambda x:Path(x).resolve(),sys.argv[1:]);out.mkdir(exist_ok=False)
src=(here/'codec.c').read_text().split('unsigned unpack_snapshot(')[1]
src='#include <stdint.h>\nstatic inline __attribute__((always_inline)) unsigned unpack_snapshot('+src
src+='''
void decode_frame(uint8_t *dst,const uint8_t *frame,unsigned ignored){
    unsigned len=frame[0]+256u*frame[1];unsigned capacity=frame[2]+256u*frame[3];
    *((uint32_t*)dst)=unpack_snapshot(frame+4,len,dst+4,capacity);
}
'''
(out/'decode.c').write_text(src)
tc=tools/'pi32v2';cc=tc/'bin/clang';obj=out/'decode.o';binary=out/'decode.raw'
subprocess.run([cc,'-target','pi32v2','-mcpu=r3','-mfprev1','-Oz','-idirafter',tc/'include','-c',out/'decode.c','-o',obj],check=True)
subprocess.run([tc/'bin/objcopy','-O','binary','-j','.text',obj,binary],check=True)
dump=subprocess.check_output([tools/'common/bin/objdump','-t','-r',obj],text=True)
assert '*UND*' not in dump.replace('00000000         *UND*\t\t 00000000 \n','') and 'RELOCATION RECORDS' not in dump, dump
(out/'symbols.txt').write_text(dump)
h=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
res={'decoder_bytes':binary.stat().st_size,'code_sha256':h(binary),'compiler_sha256':h(cc),'runner_sha256':h(runner),'rows':[]}
for owner in (1,8):
    raw=(data/f'source-{owner}.bin.records').read_bytes();at=0;cases={}
    while at<len(raw):
        t,n=struct.unpack_from('<IH',raw,at);at+=6;v=raw[at:at+n];at+=n
        if t in (22050,132300):cases[t]=v
    a=cases[22050];b=cases[132300]
    for name,want in [('first',a),('second',b),('xor',bytes(val^(a[i] if i<len(a) else 0) for i,val in enumerate(b)))]:
        encoded=(compiled/f'{owner}-{name}.packed').read_bytes()
        source=struct.pack('<HH',len(encoded),len(want))+encoded
        # The unchanged scalar target harness allocates input memory in units of 140B.
        source+=bytes((-len(source))%140)
        path=out/f'{owner}-{name}';path.mkdir();(path/'source.bin').write_bytes(source)
        expected=struct.pack('<I',len(want))+want+bytes([0x5a])*(8+(-len(want))%4)
        (path/'initial.bin').write_bytes(bytes([0x5a])*len(expected));(path/'expected.bin').write_bytes(expected)
        outtext=subprocess.check_output([runner,binary,path],text=True);rows=outtext.strip().split(',');assert len(rows)==6 and int(rows[2])==0
        r=dict(owner=owner,record=name,raw_bytes=len(want),stored_bytes=len(encoded)+4,wrong_words=int(rows[2]),instructions=int(rows[3]),ticks=int(rows[4]),target_us=float(rows[5]))
        res['rows'].append(r);print(r,flush=True)
(out/'results.json').write_text(json.dumps(res,indent=2)+'\n')
