#include <stdint.h>
static inline __attribute__((always_inline)) unsigned unpack_snapshot(const uint8_t *s,unsigned n,uint8_t *out,unsigned cap) {
    if(!s||!out)return 0;
    unsigned r=0,w=0;
    while(r<n){
        unsigned tag=s[r++];
        if(tag<128){
            unsigned size=tag+1;
            if(n-r<size||cap-w<size)return 0;
            for(unsigned i=0;i<size;i++)out[w++]=s[r++];
        }else{
            unsigned size=(tag&127)+3;
            if(n-r<2||cap-w<size)return 0;
            unsigned distance=(unsigned)s[r]|((unsigned)s[r+1]<<8);r+=2;
            if(!distance||distance>w)return 0;
            for(unsigned i=0;i<size;i++){out[w]=out[w-distance];w++;}
        }
    }
    return w;
}

void decode_frame(uint8_t *dst,const uint8_t *frame,unsigned ignored){
    unsigned len=frame[0]+256u*frame[1];unsigned capacity=frame[2]+256u*frame[3];
    *((uint32_t*)dst)=unpack_snapshot(frame+4,len,dst+4,capacity);
}
