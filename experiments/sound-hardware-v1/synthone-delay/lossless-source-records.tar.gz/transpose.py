from pathlib import Path
import ctypes as C,numpy as np,struct,json,sys,hashlib
here=Path(__file__).resolve().parent
folder,compiled,out=map(lambda x:Path(x).resolve(),sys.argv[1:]);out.mkdir(exist_ok=False)
d=C.CDLL(str(compiled/'codec.so'));d.pack_snapshot.argtypes=[C.c_char_p,C.c_uint,C.c_void_p,C.c_uint,C.c_void_p];d.pack_snapshot.restype=C.c_uint;d.unpack_snapshot.argtypes=[C.c_char_p,C.c_uint,C.c_void_p,C.c_uint];d.unpack_snapshot.restype=C.c_uint
def pack(x):
    buf=C.create_string_buffer(2*len(x)+10);index=(C.c_uint16*256)()
    n=d.pack_snapshot(x,len(x),buf,len(buf),index);b=buf.raw[:n];rt=C.create_string_buffer(len(x))
    assert n and d.unpack_snapshot(b,len(b),rt,len(x))==len(x) and rt.raw==x
    return b
def transform(x,mode,reverse):
    i=224+80;held=x[i];i+=1+4*held;i+=2+4*struct.unpack_from('<H',x,i)[0]
    block=np.frombuffer(x,'u1',7*216,i)
    if mode==0:return x
    if not reverse:
        v=block.reshape(7,54,4).copy()
        if mode==3:v[1:]^=v[:-1].copy()
        b=v.transpose(1,0,2).tobytes() if mode==1 else v.transpose(2,1,0).tobytes()
    else:
        v=block.reshape(54,7,4).transpose(1,0,2) if mode==1 else block.reshape(4,54,7).transpose(2,1,0)
        if mode==3:v=np.bitwise_xor.accumulate(v,axis=0)
        b=v.tobytes()
    return x[:i]+b+x[i+1512:]
summary={};modes=('original','word','byte','byte-xor')
for owner in (1,8):
    observed=(folder/f'source-{owner}.bin.records').read_bytes();at=0;stats={i:[] for i in range(4)};keep={}
    while at<len(observed):
        t,n=struct.unpack_from('<IH',observed,at);at+=6;buf=observed[at:at+n];at+=n
        for mode in range(4):
            work=transform(buf,mode,False);assert transform(work,mode,True)==buf
            blob=pack(work);stats[mode].append(len(blob)+5)
            if t in (22050,132300):keep[t,mode]=(work,blob)
    summary[owner]={}
    for mode in range(4):
        a,one=keep[22050,mode];b,two=keep[132300,mode];delta=bytes(v^(a[i] if i<len(a) else 0) for i,v in enumerate(b));pair=pack(delta)
        sumr=dict(min=min(stats[mode]),max=max(stats[mode]),median=float(np.median(stats[mode])),first=len(one)+5,second=len(two)+5,second_xor=len(pair)+5,pair=len(one)+len(two)+10,pair_xor=len(one)+len(pair)+10)
        summary[owner][modes[mode]]=sumr
        print(owner,modes[mode],sumr,flush=True)
(out/'results.json').write_text(json.dumps(summary,indent=2)+'\n')
