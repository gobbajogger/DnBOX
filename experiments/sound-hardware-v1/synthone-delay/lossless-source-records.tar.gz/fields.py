from pathlib import Path
import ctypes as C,collections,json,struct,sys
folder,compiled,out=map(lambda p:Path(p).resolve(),sys.argv[1:]);out.mkdir(exist_ok=False)
d=C.CDLL(str(compiled/'codec.so'));d.pack_snapshot.argtypes=[C.c_char_p,C.c_uint,C.c_void_p,C.c_uint,C.c_void_p];d.pack_snapshot.restype=C.c_uint;d.unpack_snapshot.argtypes=[C.c_char_p,C.c_uint,C.c_void_p,C.c_uint];d.unpack_snapshot.restype=C.c_uint
def pack(value):
    slot=C.create_string_buffer(len(value)*2+32);idx=(C.c_uint16*256)();n=d.pack_snapshot(value,len(value),slot,len(slot),idx)
    assert n>0;return slot.raw[:n]
def unpack(value,n):
    slot=C.create_string_buffer(n);assert d.unpack_snapshot(value,len(value),slot,n)==n
    return slot.raw
def parts(x):
    head=305+4*x[304];head+=2+4*struct.unpack_from('<H',x,head)[0]
    return x[:head],list(struct.unpack_from('<378I',x,head)),x[head+1512:]
def choose(words,j,earlier,low):
    return [earlier[j],0,words[j-54] if j>=54 else 0,words[j-1] if j%54 else 0,words[j%54] if j>=54 else 0,0x3f800000,0xbf800000,0x3f000000,0xffffffff]+low
def prev(head,tail,ref):
    if ref is None:return bytes(len(head)+len(tail)),[0]*378
    rh,rw,rt=parts(ref)
    return (rh+bytes(len(head)))[:len(head)]+(rt+bytes(len(tail)))[:len(tail)],rw
def encode(x,ref=None):
    head,actual,tail=parts(x);glob,old=prev(head,tail,ref)
    plain=bytearray(a^b for a,b in zip(head+tail,glob));tags=bytearray();lit=bytearray();cache=[]
    for j,v in enumerate(actual):
        options=choose(actual,j,old,cache)
        if v in options:tags.append(options.index(v))
        else:tags.append(255);lit.extend(struct.pack('<I',v))
        if v in cache:cache.remove(v)
        cache.insert(0,v);del cache[16:]
    words=bytes(plain+tags+lit);blob=pack(words)
    return struct.pack('<HHHH',len(head),len(tail),len(words),len(blob))+blob
def decode(z,ref=None):
    h,t,n,zl=struct.unpack_from('<HHHH',z,0);assert zl==len(z)-8
    v=unpack(z[8:],n);glob,old=prev(bytes(h),bytes(t),ref);plain=bytes(a^b for a,b in zip(v[:h+t],glob))
    tags=v[h+t:h+t+378];lits=v[h+t+378:];offset=0;words=[];cache=[]
    for j,tag in enumerate(tags):
        if tag==255:w=struct.unpack_from('<I',lits,offset)[0];offset+=4
        else:w=choose(words,j,old,cache)[tag]
        words.append(w)
        if w in cache:cache.remove(w)
        cache.insert(0,w);del cache[16:]
    assert offset==len(lits)
    return plain[:h]+struct.pack('<378I',*words)+plain[h:]
result={}
for owner in (1,8):
    data=(folder/f'source-{owner}.bin.records').read_bytes();k=0;keep={};sizes=[]
    while k<len(data):
        frame,n=struct.unpack_from('<IH',data,k);k+=6;v=data[k:k+n];k+=n
        coded=encode(v);assert decode(coded)==v;sizes.append(len(coded))
        if frame in (22050,132300):keep[frame]=(v,coded)
    first,a=keep[22050];second,b=keep[132300];delta=encode(second,first);assert decode(delta,decode(a))==second
    for fn,comp in [('first',a),('second',b),('delta',delta)]: (out/f'{owner}-{fn}.record').write_bytes(comp)
    obs=dict(exact_records=len(sizes),min=min(sizes),max=max(sizes),first=len(a),second=len(b),delta=len(delta),pair_standalone=len(a)+len(b),pair_delta=len(a)+len(delta))
    result[owner]=obs;print(owner,obs,flush=True)
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
