import csv
import json
from pathlib import Path

directory = Path(__file__).resolve().parent
rows = list(csv.DictReader((directory / "results.csv").open()))
pairs = ["L", "R", "amp", "filter"]
mismatches = sum(s["actual_" + c] != s["reference_" + c] for s in rows for c in pairs)
assert len(rows) == 169 and mismatches == 0
summary = {"rows": len(rows), "compared_words": len(rows)*4, "mismatched_words": mismatches,
           "frequency_mhz": 360, "ticks_per_microsecond":5760, "prefix_length_frames":16,
           "full_history_voice_calls": {"1": [17556,9034], "8": [1022,2555]}, "prefixes": []}
for owner in [1,8]:
    for start in [22136,132344]:
        sub = [s for s in rows if int(s["owner"]) == owner and start <= int(s["absolute_frame"]) < start+16]
        assert {int(s["absolute_frame"]) for s in sub} == set(range(start,start+16))
        per_frame = [sum(int(s["voice_ticks"]) for s in sub if int(s["absolute_frame"])==i) for i in range(start,start+16)]
        total = sum(per_frame)
        prefix = {"program":owner,"first_frame":start,"actual_voice_calls":len(sub),"voice_time_us":total/5760,
                  "ideal_two_core_minimum_us":total/11520,
                  "first_full_frame_count_exceeding_budget_us":{}}
        for threshold in [10909,11609.977]:
            prefix["first_full_frame_count_exceeding_budget_us"][str(threshold)]=next((i for i in range(1,17) if sum(per_frame[:i])/11520 > threshold),None)
        summary["prefixes"].append(prefix)
summary['call_times_us'] = {k: f([int(r["voice_ticks"])/5760 for r in rows]) for k,f in (("min",min),("max",max))}
(directory/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps(summary,indent=2))
