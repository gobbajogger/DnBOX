#!/bin/sh
set -eu
export LC_ALL=C
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
root=$(CDPATH= cd -- "$here/../.." && pwd)
cd "$root"
: "${EMU_TOOLS:=/workspace/scratch/cc2e3d785d40/build-tools}"
: "${RUSTC:=$EMU_TOOLS/rust/bin/rustc}"
: "${FM1_DEPS:=$EMU_TOOLS/cargo-target/release/deps}"
: "${FM1_CORE:=$FM1_DEPS/libfm1_core-d7a756f43fcc298f.rlib}"
python3 "$here/host.py" >"$here/host.log" 2>&1
python3 "$here/build.py" >"$here/build.log" 2>&1
"$RUSTC" --edition=2021 -C opt-level=2 -C lto=fat -C embed-bitcode=yes -C codegen-units=1 -L "$FM1_DEPS" --extern "fm1_core=$FM1_CORE" "$here/run.rs" -o "$here/run" >"$here/rust.log" 2>&1
"$here/run" "$here/build/voice.bin" "$here/host/cases.bin" sj6-work/delay/work/build/factory-inputs/public-morphs.f32 "$here/host/sine.bin" 1156 "$here/pc.csv" >"$here/results.csv" 2>"$here/runner.log"
python3 "$here/summarize.py"
python3 "$here/profile.py"
