import json,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent;r=p.parents[1];d=r/'native/final-init/firmware/src/dsp/synthone';tc=r/'native/tools/jieli-linux-toolchains-20260730.1/pi32v2'
out=p/'build';out.mkdir(exist_ok=True)
sched=d/'scheduler';nd=sched/'nodouble';probe=d/'experiment/probe';au=d/'experiment/audiokit-4.9.2/AudioKit/Core'
incl=[probe,sched,nd,au/'Soundpipe',au/'SoundpipeExtension',au/'Soundpipe/lib/dr_wav',p]
files=[p/'voice.cpp',probe/'portable_voice.cpp',sched/'float_math.c']+[nd/(n+'.c') for n in ['base','exact','d64','ftbl','osc','fosc','oscmorph2d','adsr','moogladder','buthp','butbp','crossfade','noise']]
cmds=[];objects=[]
for src in files:
 obj=out/(src.name+'.o');objects.append(obj)
 args=[tc/'bin/clang','-target','pi32v2','-mcpu=r3','-mfprev1','-O2','-fno-fast-math','-ffp-contract=off','-ffunction-sections','-fdata-sections','-DS1_NO_DOUBLE','-idirafter',tc/'include']+['-I'+str(q) for q in incl]+(['-std=gnu++11','-fno-exceptions','-fno-rtti'] if src.suffix=='.cpp' else ['-std=gnu11'])+['-c',src,'-o',obj]
 cmds.append(list(map(str,args)));subprocess.run(args,check=True)
lib=tc/'lib/r3';outelf=out/'voice.elf'
args=[tc/'bin/ld','-T',p/'voice.ld','--gc-sections','-o',outelf,*objects,'--start-group',lib/'libc.a',lib/'libm.a',lib/'libcompiler-rt.a','--end-group'];cmds.append(list(map(str,args)));subprocess.run(args,check=True)
subprocess.run([tc/'bin/objcopy','-O','binary','-j','.payload',outelf,out/'voice.bin'],check=True)
(out/'commands.json').write_text(json.dumps(cmds,indent=2)+'\n')
