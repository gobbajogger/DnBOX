use fm1_core::{Bus,Cpu};
use std::{collections::HashMap,env,fs};
const IO:usize=0x10000;
const MORPH:usize=0x20000;
const SINE:usize=0x100000;
struct Memory {data:Vec<u8>,ticks:u64,begin:u64,end:u64}
impl Bus for Memory {
 fn read8(&mut self,a:u32)->u8 {self.data[a as usize]}
 fn read16(&mut self,a:u32)->u16 {u16::from_le_bytes(self.data[a as usize..a as usize+2].try_into().unwrap())}
 fn read32(&mut self,a:u32)->u32 {u32::from_le_bytes(self.data[a as usize..a as usize+4].try_into().unwrap())}
 fn write8(&mut self,a:u32,v:u8){self.data[a as usize]=v;}
 fn write16(&mut self,a:u32,v:u16){self.data[a as usize..a as usize+2].copy_from_slice(&v.to_le_bytes());}
 fn write32(&mut self,a:u32,v:u32){
     if a as usize==IO {if v==1{self.begin=self.ticks;}if v==2{self.end=self.ticks;}}
     self.data[a as usize..a as usize+4].copy_from_slice(&v.to_le_bytes());
 }
 fn add_ticks(&mut self,n:u64){self.ticks+=n;}
}
fn u(b:&[u8],off:usize)->u32{u32::from_le_bytes(b[off..off+4].try_into().unwrap())}
fn main(){
 let args:Vec<String>=env::args().collect();let read=|i:usize|fs::read(&args[i]).unwrap();
 let code=read(1);let cases=read(2);let waves=read(3);let sine=read(4);
 let wire_size:usize=args[5].parse().unwrap();
 let mut m=Memory{data:vec![0;SINE+sine.len()+1024],ticks:0,begin:0,end:0};
 m.data[0x1000..0x1000+code.len()].copy_from_slice(&code);
 m.data[MORPH..MORPH+waves.len()].copy_from_slice(&waves);
 m.data[SINE..SINE+sine.len()].copy_from_slice(&sine);
 assert!(cases.len()%(wire_size+16)==0);
 println!("owner,absolute_frame,voice_call,full_ticks,voice_ticks,voice_us,insns,actual_L,reference_L,actual_R,reference_R,actual_amp,reference_amp,actual_filter,reference_filter");
 let mut cost_by_pc=HashMap::<(u32,u32,u32),u64>::new();
 let mut accumulated=HashMap::<(u32,u32),(u32,u32)>::new();
 for row in cases.chunks_exact(wire_size+16){
  m.data[IO..IO+24].fill(0);m.data[IO+24..IO+24+wire_size].copy_from_slice(&row[..wire_size]);m.ticks=0;m.begin=0;m.end=0;
  let key=(u(row,4),u(row,8));
  let (left,right)=accumulated.get(&key).copied().unwrap_or((0,0));
  const INPUT_SUM:usize=(5+4+3+150+7+13)*4;
  assert_eq!((left,right),(u(row,INPUT_SUM),u(row,INPUT_SUM+4)));
  m.write32((IO+24+INPUT_SUM) as u32,left);m.write32((IO+28+INPUT_SUM) as u32,right);
  let mut cpu=Cpu::new(0x1000);cpu.sp=0x1f000;cpu.rets=0xfffe;cpu.cost_model=true;cpu.regs[0]=IO as u32;cpu.regs[1]=MORPH as u32;cpu.regs[2]=SINE as u32;
  while cpu.pc!=0xfffe{
   assert!(cpu.insn_count<100_000_000,"native kernel did not return at pc={:#x}",cpu.pc);
   let pc=cpu.pc;let before=m.ticks;let measure_pc=(key.1==22136 || key.1==132344) && m.begin!=0 && m.end==0;
   cpu.step(&mut m).unwrap();m.ticks+=1;
   if measure_pc{*cost_by_pc.entry((key.0,key.1,pc)).or_default()+=m.ticks-before;}
  }
  assert_eq!(m.read32(IO as u32+4),wire_size as u32);assert!(m.end>m.begin);
  print!("{},{},{},{},{},{:.6},{}",u(row,4),u(row,8),u(row,12),m.ticks,m.end-m.begin,(m.end-m.begin) as f64/5760.,cpu.insn_count);
  accumulated.insert(key,(m.read32((IO+8) as u32),m.read32((IO+12) as u32)));
  for i in 0..4{print!(",{:08x},{:08x}",m.read32((IO+8+4*i) as u32),u(row,wire_size+4*i));}
  println!();
 }
 let mut pcs:Vec<_>=cost_by_pc.into_iter().collect();pcs.sort_by_key(|x|x.0);
 let mut out=String::from("program,frame,pc,ticks\n");
 for ((program,frame,pc),ticks) in pcs{out.push_str(&format!("{},{},{:x},{}\n",program,frame,pc,ticks));}
 fs::write(&args[6],out).unwrap();
}
