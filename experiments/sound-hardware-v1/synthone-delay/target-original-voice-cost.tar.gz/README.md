# Time required by active original Synth One voices on PI32v2

At sample 242,550 the first factory owner edits delay time and opens the wet path. The second owner opens its wet path at its existing delay time. A prior feedback study found the two causal source cursors needed at that instant. This test measures how much time the existing exact-math original voice implementation spends generating genuine samples for those cursor requests. The two programs use the original 44.1 kHz restore, note events, parameter smoothing and feedback controls.

| Factory program | Cursor start | Historical frames required | Active voice calls across entire demand | Calls in first 16 frames | Measured time on one core | Minimum time on two fully available cores |
|---|---:|---:|---:|---:|---:|---:|
| 1 · Dat Bomb Bass, Yo | 22,136 | 17,556 | 17,556 | 16 | 28,357.747 µs | 14,178.873 µs |
| 1 · Dat Bomb Bass, Yo | 132,344 | 9,034 | 9,034 | 16 | 28,259.419 µs | 14,129.710 µs |
| 8 · June Oh 06 Sqr | 22,136 | 511 | 1,022 | 32 | 56,458.615 µs | 28,229.307 µs |
| 8 · June Oh 06 Sqr | 132,344 | 511 | 2,555 | 80 | 99,482.288 µs | 49,741.144 µs |

Each call executed on the emulator's real PI32v2 ISA cost model at 360 MHz. The two-core number divides the sum of the measured individual kernel times by two. This gives an optimistic lower bound for these calls with perfect distribution and zero handoff overhead. Every listed time uses the actual first 16 consecutive historical frames. Row 1 exhausts the 10,909 µs target after 13 frames and the 11,609.977 µs half after 14, for either cursor. Row 8 exhausts both after 7 or 4 frames. Source tracing counted every active call throughout each full demand. Only the 16-frame prefixes and six additional individual placements were timed.

## Source and measurement

The host wraps the original C++ S1NoteState::run at its real call site, capturing live state and controls just before the function and its stereo output and amplitude/filter envelopes immediately upon return. Across four prefixes and additional samples it captured 169 calls on 76 unique program/frame pairs. The source uses both oscillators and their actual band selection, sub and FM oscillators, noise RNG, phases, both envelopes, voice filters and their histories, and all 150 source parameters. Target code reconstructs pointer-bearing objects explicitly. Both builds agree on the 1,156-byte pointer-free test record. The record is a diagnostic exchange format. It is not proposed as live RAM or as an event-stream encoding.

The target feeds the literal original portable voice body with the project's strict no-double DSP implementation and the authentic public waveform and sine tables. The driver initializes each frame's mix with zero and uses the preceding active target voice's actual sum for subsequent voices. The original incoming accumulators serve only as assertions. The target receives no prerecorded dry PCM or expected return words as function inputs. Initial voice state and upstream smoothed parameters at each frame are provided by the native bridge, so their generation takes zero measured time. This isolates the existing voice work even when authentic state is available for free.

For all 169 calls the native and original reference producers agreed bit for bit on left, right, amplitude envelope and filter envelope, or 676 returned binary32 words. Single-call times spanned 324.952 through 1,952.829 µs. Repeating the original complete host render with capture enabled preserved the earlier full output bytes for both owners. The included ref files hold the seven-float-per-frame records for the subsequent original 512-frame wet comparison.

The markers immediately bracket v.run. The elapsed model uses 5,760 instruction-cost ticks per microsecond. The target's table wiring, state transfer, source/control checkpoint restoration, LFO and note scheduling, pan, phaser, delay input filters, feedback recursion and downstream effects all fall outside measured time. The runner provides ideal memory access for the 852,176-byte public wave payload and 16,388-byte public sine payload. Physical storage, XIP/cache stalls, the board scheduler, other engines and synchronization would require separate accounting. The isolated linked image is 10,754 bytes. Its size does not measure the change in a complete firmware image.

The existing exact arithmetic implementation therefore misses the callback budget on these true dynamic source inputs, even with authentic prefetched checkpoint data. An algorithm with a different representation or an earlier completed render has a separate timing question. Numerical time and memory claims here are restricted to the indicated scenes and implementation.

## Target cost profile

The emulator also counted the complete per-instruction cost at both exact cursor starts. Across the four program/cursor pairs, the integer binary64 division routine d64_div accounted for 55.88% to 58.18% of active voice cost. The next three symbols were round_sig, d64_add and d64_mul. profile.csv reports all linked-symbol costs. pc.csv retains every charged address.

## Reproduction and provenance

Install this folder as native/live-voice in the recovered Sound workspace and use replay.sh. It needs the pinned Jieli PI32v2 toolchain, the strict 360 MHz fm1_core build, native/final-init sources, the native/dual/whole capture and the authenticated sj6-work/delay/work/build original factory objects, command manifest and waveform files. Set EMU_TOOLS, RUSTC, FM1_DEPS and FM1_CORE to use equivalent external locations. The runner verifies every initial mix word against its own earlier output, checks the target ABI and compares all four final values. build/commands.json contains the exact target compiler/link commands, and INPUTS.sha256 pins upstream files. The prior two-core feedback receipt is dual-core-complete-wet-proof.tar.gz with SHA-256 260e3ecb5b80190d9a47c615b40e2adc4769a7ec43932d40ae906cefa1f027e0. No firmware or gate source changed for this experiment.
