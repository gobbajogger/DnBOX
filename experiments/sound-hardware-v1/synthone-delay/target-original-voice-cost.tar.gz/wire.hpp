#pragma once
#include "portable_interface.hpp"
struct OscWire {float freq,amp,iphs;int32_t phase,inc;};
struct MorphWire {OscWire osc; float wtpos;int nft,nbl,enable,over;};
struct FmWire {float amp,freq,car,mod,indx,iphs;int32_t mphs,cphs;};
struct VoiceWire {
    unsigned tag,program,frame,id,rand_before;
    int stage,velocity,root,transpose;
    float gate,amp,filter,params[150],lfo[7],bands[13],in_l,in_r;
    MorphWire m[2];OscWire sub;FmWire fm;
    sp_adsr env[2];sp_moogladder low;sp_buthp high;sp_butbp band;
    sp_crossfade mc,fc;sp_noise noise;
};
