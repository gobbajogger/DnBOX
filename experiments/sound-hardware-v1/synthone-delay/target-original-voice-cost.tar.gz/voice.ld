ENTRY(measure)
SECTIONS {
 . = 0x1000;
 .payload : { KEEP(*(.text.entry)) *(.text*) *(.rodata*) *(.data*) }
 .zero (NOLOAD) : { *(.bss*) *(COMMON) }
}
