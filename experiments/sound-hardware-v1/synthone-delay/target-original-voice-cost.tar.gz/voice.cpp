#include "wire.hpp"
#include <string.h>
struct Io {volatile unsigned marker;unsigned abi; float result[4];VoiceWire wire;};
extern "C" __attribute__((section(".text.entry"))) void measure(Io *io,float *raw,float *sines){
    VoiceWire &w=io->wire;io->abi=sizeof w;
    S1DSPKernel k{};sp_data sp{};sp.sr=44100;sp.nchan=1;sp.rand=w.rand_before;k.sp=&sp;
    memcpy(k.parameters, w.params,sizeof w.params);
    memcpy(k.ft_frequencyBand,w.bands,sizeof w.bands);
    k.lfo1_0_1=w.lfo[0];k.lfo1_1_0=w.lfo[1];k.lfo2_0_1=w.lfo[2];k.lfo2_1_0=w.lfo[3];k.lfo3_0_1=w.lfo[4];k.lfo3_1_0=w.lfo[5];k.monoFrequencySmooth=w.lfo[6];
    sp_ftbl tables[53];for(int i=0;i<53;++i){sp_ftbl_init(&sp,&tables[i],4096);tables[i].tbl=i==52?sines:raw+i*4097;tables[i].del=0;if(i==52)k.sine=tables+i;else k.ft_array[i]=tables+i;}
    S1NoteState v{};v.kernel=&k;v.internalGate=w.gate;v.amp=w.amp;v.filter=w.filter;v.velocity=w.velocity;v.stage=(S1NoteState::NoteStateStage)w.stage;v.rootNoteNumber=w.root;v.transpose=w.transpose;
    sp_oscmorph2d morph[2];for(int i=0;i<2;++i){const auto &s=w.m[i];auto &m=morph[i];m.freq=s.osc.freq;m.amp=s.osc.amp;m.iphs=s.osc.iphs;m.lphs=s.osc.phase;m.inc=s.osc.inc;m.wtpos=s.wtpos;m.nft=s.nft;m.nbl=s.nbl;m.enableBandlimit=s.enable;m.bandlimitIndexOverride=s.over;m.tbl=k.ft_array;m.fbl=k.ft_frequencyBand;}
    v.oscmorph1=morph;v.oscmorph2=morph+1;sp_osc sub{};sub.freq=w.sub.freq;sub.amp=w.sub.amp;sub.iphs=w.sub.iphs;sub.lphs=w.sub.phase;sub.inc=w.sub.inc;sub.tbl=k.sine;
    v.subOsc=&sub;sp_fosc fm{};fm.amp=w.fm.amp;fm.freq=w.fm.freq;fm.car=w.fm.car;fm.mod=w.fm.mod;fm.indx=w.fm.indx;fm.iphs=w.fm.iphs;fm.mphs=w.fm.mphs;fm.cphs=w.fm.cphs;fm.ft=k.sine;v.fmOsc=&fm;
    v.adsr=w.env;v.fadsr=w.env+1;v.loPass=&w.low;v.hiPass=&w.high;v.bandPass=&w.band;v.morphCrossFade=&w.mc;v.filterCrossFade=&w.fc;v.noise=&w.noise;
    float l=w.in_l,r=w.in_r;
    __asm__ volatile("":::"memory");io->marker=1;__asm__ volatile("":::"memory");
    v.run(0,&l,&r);
    __asm__ volatile("":::"memory");io->marker=2;__asm__ volatile("":::"memory");
    io->result[0]=l;io->result[1]=r;io->result[2]=v.amp;io->result[3]=v.filter;
}
