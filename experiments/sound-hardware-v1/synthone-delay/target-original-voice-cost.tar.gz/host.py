from pathlib import Path
import json,subprocess
here=Path(__file__).resolve().parent;root=here.parents[1];b=root/'sj6-work/delay/work/build';out=here/'host';out.mkdir(exist_ok=True)
s=(root/'native/dual/whole/capture.cpp').read_text().replace('constexpr unsigned hz =','#include "host.inc"\nconstexpr unsigned hz =').replace('FullPair pair; FILE *trace=nullptr;','unsigned program; FullPair pair; FILE *trace=nullptr;').replace('        absolute = start;','        absolute = start;audit_row=program;audit_frame=start;').replace('    Fixture fixture(argv[1]);','    voice_out=fopen("cases.bin","wb");CHECK(voice_out);\n    Fixture fixture(argv[1]);').replace('        owners[i]->trace=','        owners[i]->program=rows[i];owners[i]->trace=')
k=s.rindex('}');s=s[:k]+'    CHECK(fclose(voice_out)==0);printf("VOICE %u %zu %u %u %u %u\\n",captured,sizeof(VoiceWire),call_counts[0][0],call_counts[0][1],call_counts[1][0],call_counts[1][1]);\n'+s[k:]
(out/'capture.cpp').write_text(s);cmd=json.loads((b/'factory-build-commands.json').read_text());c=next(a.copy() for a in cmd if any(v.endswith('/preset_audio.cpp') for v in a))
for flag,path in [('-c',out/'capture.cpp'),('-MF',out/'capture.d'),('-o',out/'capture.o')]:c[c.index(flag)+1]=str(path)
c.extend(['-I'+str(here),'-I'+str(root/'native/dual/whole')]);subprocess.run(c,check=True)
ld=cmd[-1].copy();ld[ld.index(str(b/'factory-6.o'))]=str(out/'capture.o');ld[ld.index('-o')+1]=str(out/'capture');ld+=['-Wl,--wrap=_ZN11S1NoteState3runEiPfS0_'];subprocess.run(ld,check=True)
with (out/'result.log').open('w') as log:subprocess.run([out/'capture',b/'factory-inputs/public-morphs.f32',b/'factory-inputs/compact.bin',b/'commands/preset-commands.bin','late',out/'ref','-'],check=True,cwd=out,stdout=log)
