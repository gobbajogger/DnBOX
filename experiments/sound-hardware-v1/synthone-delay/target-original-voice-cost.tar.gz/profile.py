import csv
import re
import subprocess
from collections import Counter, defaultdict
from pathlib import Path

p = Path(__file__).resolve().parent
symbols = subprocess.check_output(["readelf","-Ws",p/"build/voice.elf"],text=True)
(p/"build/symbols.txt").write_text(symbols)
ranges = sorted((int(addr,16),int(addr,16)+int(size),name) for addr,size,name in
                re.findall(r"^\s*\d+:\s+(\w+)\s+(\d+)\s+FUNC\s+\S+\s+\S+\s+\d+\s+(\S+)\s*$",symbols,re.M))
groups = defaultdict(Counter)
for s in csv.DictReader((p/"pc.csv").open()):
    pc = int(s["pc"],16)
    sym = next((name for lo,hi,name in ranges if lo<=pc<hi),"[unresolved]")
    groups[int(s["program"]),int(s["frame"])][sym]+=int(s["ticks"])
with (p/"profile.csv").open("w") as out:
    records=csv.writer(out);records.writerow(["program","first_frame","function","ticks","percent"])
    for (owner,frame), c in sorted(groups.items()):
        total=sum(c.values())
        for name,ticks in c.most_common():
            records.writerow([owner,frame,name,ticks,f"{ticks*100/total:.4f}"])
        print(owner,frame,c.most_common(5),total)
