#include "provider.h"
#include "source/checkpoint_state.h"
typedef struct { float l,r; } stereo;
typedef struct { stereo ring[38],previous; } long_cursor;
typedef struct { float right_ring[38]; stereo short_ring[22]; float right,fill,repeat; } short_cursor;
typedef struct {
    flash_witness_cursor retained[4];
    long_cursor left;
    short_cursor right;
    uint32_t position[2];
} active_fx;
typedef struct { dry_record records[16]; uint32_t used,end; } stored_audio;
typedef struct {
    flash_witness_cursor saved[4];
    stored_audio audio;
    union {
        struct {flash_witness_cursor live;dry_analysis learn;} capturing;
        struct {long_cursor left;short_cursor right;uint32_t position[2];dry_reader q[2];} playing;
    } phase;
} observed_timeline;
char measured_fx[sizeof(active_fx)];
char only_records[sizeof(active_fx)+sizeof(((dry_history *)0)->events)];
char complete_readers[sizeof(active_fx)+sizeof(stored_audio)+2*sizeof(dry_reader)];
char simultaneous_capture_read[sizeof(active_fx)+sizeof(dry_history)+2*sizeof(dry_reader)];
char observed_phase_union[sizeof(observed_timeline)];
