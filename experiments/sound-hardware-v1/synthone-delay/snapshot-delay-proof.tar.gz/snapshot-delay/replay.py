"""Measure reset-only, four-sample forward replay with the real original note and pre-delay graph."""
import argparse
from pathlib import Path
import hashlib
import json
import subprocess

HERE=Path(__file__).resolve().parent

def replace(s,a,b):
    assert s.count(a)==1, a
    return s.replace(a,b)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("factory_build",type=Path)
    p.add_argument("authored",type=Path)
    p.add_argument("new_output",type=Path)
    args=p.parse_args()
    build=args.factory_build.resolve(); out=args.new_output.resolve()
    out.mkdir(parents=True,exist_ok=False)
    fx_path=build/"factory-inputs/tests/fixtures/synthone-factory/fullfx/source_fx.hpp"
    assert hashlib.sha256(fx_path.read_bytes()).hexdigest()=="aee3fe78b450b35bfe6d40741d12dcedf02e24388bdf07850bde7b13d8d8d33e"
    fx=fx_path.read_text()
    fx=replace(fx,"// PING PONG DELAY","""if (regenerate) {
            cursor->consume(delayInputLowPassOutL);
            return;
        }
        // PING PONG DELAY""")
    (out/"replay-fx.hpp").write_text(fx)
    code=args.authored.read_text().replace('#include "source_fx.hpp"','#include "cursor.hpp"\n#include "replay-fx.hpp"')
    code=replace(code,"FullPair pair;","""FullPair pair;
    ReplayCursor rewind;
    FILE *all_positions=nullptr;
    unsigned edits=0,starts=0,stops=0;""")
    code=replace(code,"{CHECK(controls.set_parameter(id,value));}","{++edits;CHECK(controls.set_parameter(id,value));}")
    code=replace(code,"x.fx.frame(x.left[frame]","cursor=&x.rewind; x.fx.frame(x.left[frame]")
    code=replace(code,"const unsigned lag =", """if(regenerate) return;
        if(now>=long_edit) {float time=x.fx.delayL->del;CHECK(std::fwrite(&time,4,1,x.all_positions)==1);}
        if(x.fx.delayCrossfadeL->pos>0 && now>=wet_edit) {
            Request q{now,x.fx.delayL->del,x.fx.delayL->prev};
            CHECK(std::fwrite(&q,sizeof q,1,x.rewind.file)==1);
        }
        const unsigned lag =""")
    code=replace(code,"absolute = start;","absolute = start; rewind.start_ns=cpu_now();")
    code=replace(code,"pair.o.trace_fn=nullptr;","rewind.spent_ns+=cpu_now()-rewind.start_ns; pair.o.trace_fn=nullptr;")
    code=replace(code,"CHECK(argc==4);","CHECK(argc==6); regenerate=std::strcmp(argv[4],\"replay\")==0;")
    code=replace(code,"const unsigned rows[]={1,8};","""const unsigned rows[]={1,8};
    for(unsigned p=0;p<2;++p) {
        const auto stem=std::string(argv[5])+"-"+std::to_string(rows[p]);
        owners[p]->rewind.file=std::fopen((stem+".queries").c_str(),regenerate?"rb":"wb");
        CHECK(owners[p]->rewind.file);
        if(regenerate) CHECK((owners[p]->rewind.reading=owners[p]->rewind.fetch()));
        else {owners[p]->all_positions=std::fopen((stem+".positions").c_str(),"wb");CHECK(owners[p]->all_positions);}
    }""")
    code=replace(code,"x.pair.o.stopAllNotes();","++x.stops; x.pair.o.stopAllNotes();")
    code=replace(code,"if(pos<long_edit) x.pair.o.startNote(", "if(pos<long_edit && ++x.starts) x.pair.o.startNote(")
    code=replace(code,"pos+=n;","pos+=n; if(regenerate && !bass.rewind.reading && !square.rewind.reading) break;")
    code=replace(code,"std::puts(\"program_index,", """if(regenerate) {
        std::puts("program,original_source_frames,first_query_ready_after_source_frame,last_query_source_frame,queries,unequal_samples,cold_prefix_cpu_ns,total_replay_cpu_ns,controller_edits,note_starts,stop_all_calls,host_raw_scheduler_bytes,host_source_scheduler_bytes");
        for(unsigned p=0;p<2;++p) {
            Owner& x=*owners[p]; const auto& r=x.rewind;
            CHECK(!r.reading && std::fclose(r.file)==0);
            std::printf("%u,%u,%u,%u,%u,%u,%llu,%llu,%u,%u,%u,%zu,%zu\\n",rows[p],
                        r.generated,r.earliest,r.last,r.checked,r.unequal,(unsigned long long)r.first_ns,
                        (unsigned long long)r.spent_ns,x.edits,x.starts,x.stops,sizeof(x.pair.o),sizeof(x.pair.s));
        }
        return 0;
    }
    for(unsigned p=0;p<2;++p) {
        Owner& x=*owners[p];
        CHECK(std::fclose(x.rewind.file)==0 && std::fclose(x.all_positions)==0);
        std::fprintf(stderr,"program=%u restore_calls=144 edits=%u starts=%u stops=%u resets=1\\n",rows[p],x.edits,x.starts,x.stops);
    }
    std::puts("program_index,""")
    (out/"capture.cpp").write_text(code)
    commands=json.loads((build/"factory-build-commands.json").read_text())
    cc=next(c.copy() for c in commands if any(v.endswith("/preset_audio.cpp") for v in c));cc.insert(1,"-I"+str(HERE))
    for flag,path in (("-c",out/"capture.cpp"),("-MF",out/"capture.d"),("-o",out/"capture.o")):cc[cc.index(flag)+1]=str(path)
    subprocess.run(cc,check=True)
    ld=commands[-1].copy();ld[ld.index(str(build/"factory-6.o"))]=str(out/"capture.o");ld[ld.index("-o")+1]=str(out/"capture")
    subprocess.run(ld,check=True)
    inputs=build/"factory-inputs"
    for mode in ("original","replay"):
        with (out/(mode+".csv")).open("w") as f,(out/(mode+".log")).open("w") as err:
            subprocess.run([out/"capture",inputs/"public-morphs.f32",inputs/"compact.bin",build/"commands/preset-commands.bin",
                            mode,out/"source"],stdout=f,stderr=err,check=True)
    assert (out/"original.csv").read_bytes()==args.authored.with_suffix(".csv").read_bytes()
    subprocess.run(["python3",HERE/"summarize.py",out],check=True)
if __name__=="__main__":
    main()
