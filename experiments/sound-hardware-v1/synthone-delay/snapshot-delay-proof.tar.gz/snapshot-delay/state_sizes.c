#include "soundpipe.h"
#include "soundpipeextension.h"
typedef struct {
  sp_adsr adsr, fadsr;
  sp_oscmorph2d morph1, morph2;
  sp_crossfade morph_crossfade, filter_crossfade;
  sp_osc sub; sp_fosc fm; sp_noise noise;
  sp_moogladder lowpass; sp_butbp bandpass; sp_buthp highpass;
} scheduler_note_objects;
char layout_seven_note_objects[sizeof(scheduler_note_objects)*7];
char layout_original_parameter_ports[sizeof(sp_port)*150];
