import csv,json,sys
from pathlib import Path
import numpy as np
out=Path(sys.argv[1])
results={}
for row in csv.DictReader((out/"replay.csv").open()):
    data={k:int(v) for k,v in row.items()}
    preset=row["program"]
    positions=np.fromfile(out/f"source-{preset}.positions",dtype="<f4")
    ticks=np.arange(176400,264600)
    assert positions.size==len(ticks)
    requested=ticks-np.ceil((positions*44100).astype(float)).astype(np.int64)
    delta=np.diff(requested)
    nonnegative=np.maximum(requested,0)
    q=np.fromfile(out/f"source-{preset}.queries",dtype=[("n","<u4"),("s","<f4"),("tap","<f4")])
    assert np.isfinite(q["tap"]).all() and data["queries"]==len(q) and data["unequal_samples"]==0
    data.update(first_audible_frame=int(q["n"][0]),last_audible_frame=int(q["n"][-1]),
                negative_source_steps_in_full_warm_sweep=int((delta<0).sum()),
                largest_single_frame_backward_source_step=int(-delta.min()),
                maximum_backward_excursion_frames=int(np.max(np.maximum.accumulate(requested)-requested)),
                max_excursion_clamped_at_start=int(np.max(np.maximum.accumulate(nonnegative)-nonnegative)),
                backwards_steps_clamped_at_start=int((np.diff(nonnegative)<0).sum()),
                callback_128_budget_ns=128e9/44100)
    results[preset]=data
(out/"summary.json").write_text(json.dumps(results,indent=2)+"\n")
print(json.dumps(results,indent=2))
