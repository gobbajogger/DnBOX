#pragma once
#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <ctime>
struct Request {uint32_t frame;float time,tap;};
static uint64_t cpu_now() {
    timespec t;
    if(clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t)!=0) std::abort();
    return uint64_t(t.tv_sec)*1000000000+t.tv_nsec;
}
struct ReplayCursor {
    FILE *file=nullptr;
    bool reading=false;
    Request request{};
    unsigned generated=0,checked=0,unequal=0,earliest=0,last=0;
    float recent[4]{};
    uint64_t spent_ns=0,start_ns=0,first_ns=0;
    bool fetch(){return std::fread(&request,sizeof request,1,file)==1;}
    void consume(float input) {
        recent[generated%4]=input;
        while(reading) {
            /* Matching Soundpipe vdelay3 arithmetic. Request frames postdate the
               delay and precede the first 441,000-sample wrap in this witness. */
            float f=static_cast<float>(request.time * (-1.0 * 44100));
            int v1=static_cast<int>(f); f-=float(v1); v1+=static_cast<int>(request.frame);
            if(v1<0||f<0) {f++;v1--;}
            if(v1+2>static_cast<int>(generated)) break;
            if(v1+2!=static_cast<int>(generated)||v1<1) std::abort();
            float z=f*f;z--;z*=0.1666666667;
            float y=f;y++;float w=(y*=.5);w--;float x=3.f*z;y-=x;w-=z;x-=f;
            float a=recent[(v1-1)%4],b=recent[v1%4],c=recent[(v1+1)%4],d=recent[(v1+2)%4];
            float found=(w*a+x*b+y*c+z*d)*f+b;
            unequal+=std::memcmp(&found,&request.tap,4)!=0;
            if(!checked) {earliest=generated;first_ns=spent_ns+cpu_now()-start_ns;}
            ++checked;last=generated;
            reading=fetch();
        }
        ++generated;
    }
};
static ReplayCursor *cursor;
static bool regenerate=false;
