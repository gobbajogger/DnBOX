#include "exact.h"
#include <string.h>
int math_call(unsigned pc, unsigned *reg, unsigned char *mem, unsigned sp) {
    float f[4], a[6], ret;
    uint32_t dest;
    uint64_t wide = (uint64_t)reg[1] | ((uint64_t)reg[2]<<32);
    memcpy(f,reg,16);
    switch (pc) {
    case 0x1df6: /* s1_adsr_pole */
        ret=s1_adsr_pole(f[0], f[1]);memcpy(reg,&ret,4);
        return 1;
    case 0x1e4a: /* s1_butbp_coeffs */
        s1_butbp_coeffs(f[0],f[1],f[2],f[3],a);memcpy(&dest,mem+sp,4);memcpy(mem+dest+4,a+1,20);
        return 1;
    case 0x1f24: /* s1_buthp_coeffs */
        s1_buthp_coeffs(f[0],f[1],a);memcpy(mem+reg[2]+4,a+1,20);
        return 1;
    case 0x1a8e: /* s1_exp2_f64 */
        ret=s1_exp2_f64(f[0]);memcpy(reg,&ret,4);
        return 1;
    case 0x19aa: /* s1_exp2f */
        ret=s1_exp2_f64(f[0]);memcpy(reg,&ret,4);
        return 1;
    case 0x1e34: /* s1_f_gt_d */
        reg[0]=s1_f_gt_d(f[0],wide);
        return 1;
    case 0x1c1c: /* s1_log2_f64 */
        ret=s1_log2_f64(f[0]);memcpy(reg,&ret,4);
        return 1;
    case 0x19ae: /* s1_log2f */
        ret=s1_log2_f64(f[0]);memcpy(reg,&ret,4);
        return 1;
    case 0x200e: /* s1_moog_coeffs */
        s1_moog_coeffs(f[0],f[1],&a[0],&a[1]);memcpy(mem+reg[2],a,4);memcpy(mem+reg[3],a+1,4);
        return 1;
    case 0x2236: /* s1_moog_direct */
        ret=s1_moog_direct(f[0], f[1], f[2], f[3]);memcpy(reg,&ret,4);
        return 1;
    case 0x218c: /* s1_moog_half */
        ret=s1_moog_half(f[0], f[1]);memcpy(reg,&ret,4);
        return 1;
    case 0x215c: /* s1_moog_res4 */
        ret=s1_moog_res4(f[0], f[1]);memcpy(reg,&ret,4);
        return 1;
    case 0x228e: /* s1_moog_stored */
        ret=s1_moog_stored(f[0], f[1], f[2], f[3]);memcpy(reg,&ret,4);
        return 1;
    case 0x22d0: /* s1_moog_tail */
        ret=s1_moog_tail(f[0], f[1], f[2], f[3]);memcpy(reg,&ret,4);
        return 1;
    case 0x2216: /* s1_moog_tanh_store */
        ret=s1_moog_tanh_store(f[0]);memcpy(reg,&ret,4);
        return 1;
    case 0x1e1c: /* s1_round_mul */
        ret=s1_round_mul(f[0],wide);memcpy(reg,&ret,4);
        return 1;
    default: return 0;
    }
}
