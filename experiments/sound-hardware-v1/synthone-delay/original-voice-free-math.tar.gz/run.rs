use fm1_core::{Bus, Cpu};
use std::collections::HashMap;
use std::{env, fs};

extern "C" {
    fn math_call(pc: u32, registers: *mut u32, memory: *mut u8, sp: u32) -> i32;
}

const ENTRY: u32 = 0x1000;
const RETURN: u32 = 0xfffe;
const IO: usize = 0x10000;
const MORPH: usize = 0x20000;
const SINE: usize = 0x100000;
const INPUT_SUM_OFFSET: usize = (5 + 4 + 3 + 150 + 7 + 13) * 4;

struct Memory {
    data: Vec<u8>,
    ticks: u64,
    begin: u64,
    end: u64,
}

fn word(data: &[u8], offset: usize) -> u32 {
    u32::from_le_bytes(data[offset..offset + 4].try_into().unwrap())
}

impl Bus for Memory {
    fn read8(&mut self, address: u32) -> u8 {
        self.data[address as usize]
    }

    fn read16(&mut self, address: u32) -> u16 {
        let index = address as usize;
        u16::from_le_bytes(self.data[index..index + 2].try_into().unwrap())
    }

    fn read32(&mut self, address: u32) -> u32 {
        word(&self.data, address as usize)
    }

    fn write8(&mut self, address: u32, value: u8) {
        self.data[address as usize] = value;
    }

    fn write16(&mut self, address: u32, value: u16) {
        let index = address as usize;
        self.data[index..index + 2].copy_from_slice(&value.to_le_bytes());
    }

    fn write32(&mut self, address: u32, value: u32) {
        if address as usize == IO {
            match value {
                1 => self.begin = self.ticks,
                2 => self.end = self.ticks,
                _ => {}
            }
        }
        let index = address as usize;
        self.data[index..index + 4].copy_from_slice(&value.to_le_bytes());
    }

    fn add_ticks(&mut self, ticks: u64) {
        self.ticks += ticks;
    }
}

fn main() {
    let args: Vec<String> = env::args().collect();
    let code = fs::read(&args[1]).unwrap();
    let cases = fs::read(&args[2]).unwrap();
    let waves = fs::read(&args[3]).unwrap();
    let sine = fs::read(&args[4]).unwrap();
    let wire_size: usize = args[5].parse().unwrap();
    let symbol = fs::read_to_string(&args[6]).unwrap();
    let range: Vec<u32> = symbol.split_whitespace().map(|s| s.parse().unwrap()).collect();
    let caller = range[0]..range[0] + range[1];
    let fresh = env::var_os("FREE_MATH_FRESH_DECODER").is_some();

    assert_eq!(cases.len() % (wire_size + 16), 0);
    let mut memory = Memory {
        data: vec![0; SINE + sine.len() + 1024],
        ticks: 0,
        begin: 0,
        end: 0,
    };
    memory.data[ENTRY as usize..ENTRY as usize + code.len()].copy_from_slice(&code);
    memory.data[MORPH..MORPH + waves.len()].copy_from_slice(&waves);
    memory.data[SINE..SINE + sine.len()].copy_from_slice(&sine);

    let mut cpu = Cpu::new(ENTRY);
    cpu.sp = 0x1f000;
    cpu.rets = RETURN;
    cpu.cost_model = true;
    cpu.regs[0] = IO as u32;
    cpu.regs[1] = MORPH as u32;
    cpu.regs[2] = SINE as u32;
    let start = cpu.plain_state().unwrap();
    let mut accumulated = HashMap::<(u32, u32), (u32, u32)>::new();

    println!("owner,absolute_frame,voice_call,full_ticks,voice_ticks,body_ticks,helper_calls,voice_us,insns,actual_L,reference_L,actual_R,reference_R,actual_amp,reference_amp,actual_filter,reference_filter");
    for row in cases.chunks_exact(wire_size + 16) {
        let key = (word(row, 4), word(row, 8));
        let (left, right) = accumulated.get(&key).copied().unwrap_or((0, 0));
        assert_eq!(left, word(row, INPUT_SUM_OFFSET));
        assert_eq!(right, word(row, INPUT_SUM_OFFSET + 4));
        memory.ticks = 0;
        memory.begin = 0;
        memory.end = 0;
        memory.data[IO..IO + 24].fill(0);
        memory.data[IO + 24..IO + 24 + wire_size].copy_from_slice(&row[..wire_size]);
        memory.write32((IO + 24 + INPUT_SUM_OFFSET) as u32, left);
        memory.write32((IO + 28 + INPUT_SUM_OFFSET) as u32, right);

        if fresh {
            cpu = Cpu::new(ENTRY);
            cpu.cost_model = true;
        }
        cpu.set_plain_state(&start);
        cpu.insn_count = 0;
        let mut caller_ticks = 0;
        let mut helpers = 0;
        while cpu.pc != RETURN {
            assert!(cpu.insn_count < 100_000_000, "native call stalled at {:#x}", cpu.pc);
            let pc = cpu.pc;
            let before = memory.ticks;
            let in_caller = caller.contains(&pc) && memory.begin != 0 && memory.end == 0;
            // The bridge uses the pinned entry addresses and genuine PI32 register/stack ABI.
            let substituted = unsafe {
                math_call(pc, cpu.regs.as_mut_ptr(), memory.data.as_mut_ptr(), cpu.sp)
            };
            if substituted != 0 {
                cpu.pc = cpu.rets;
                helpers += 1;
                continue;
            }
            cpu.step(&mut memory).unwrap();
            memory.ticks += 1;
            if in_caller {
                caller_ticks += memory.ticks - before;
            }
        }

        assert_eq!(memory.read32(IO as u32 + 4), wire_size as u32);
        assert!(memory.end > memory.begin);
        let ticks = memory.end - memory.begin;
        print!("{},{},{},{},{},{},{},{:.6},{}", key.0, key.1, word(row, 12),
               memory.ticks, ticks, caller_ticks, helpers, ticks as f64 / 5760.0, cpu.insn_count);
        accumulated.insert(key, (memory.read32(IO as u32 + 8), memory.read32(IO as u32 + 12)));
        for index in 0..4 {
            let actual = memory.read32((IO + 8 + 4 * index) as u32);
            let reference = word(row, wire_size + 4 * index);
            print!(",{:08x},{:08x}", actual, reference);
        }
        println!();
    }
}
