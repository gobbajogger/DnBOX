#!/usr/bin/env python3
"""Replay the four factory history demands outside the source checkout."""
import argparse
import csv
import hashlib
import json
import os
import re
from pathlib import Path
import subprocess
import tarfile


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def checked(path, expected):
    if sha256(path) != expected:
        raise ValueError(f"digest mismatch for {path}")


def run(args, out=None, **options):
    if out is None:
        subprocess.run(args, check=True, **options)
    else:
        with out.open("wb") as stream:
            subprocess.run(args, stdout=stream, check=True, **options)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("repo", "factory-build", "rustc", "fm1-core", "output"):
        parser.add_argument("--" + name, required=True, type=Path)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    repo, factory = args.repo.resolve(), args.factory_build.resolve()
    rustc, core, out = args.rustc.absolute(), args.fm1_core.resolve(), args.output.resolve()
    expected = json.loads((here / "expected.json").read_text())
    digest = expected["sha256"]
    out.mkdir(parents=True, exist_ok=False)
    dep = repo / "experiments/sound-hardware-v1/synthone-delay/target-original-voice-cost.tar.gz"
    checked(dep, digest["previous_receipt"])
    checked(core, digest["fm1_core"])
    members = {"build/voice.bin": "voice.bin", "build/voice.elf": "voice.elf",
               "host/capture.cpp": "capture.cpp", "host/cases.bin": "169.bin",
               "host/sine.bin": "sine-reference.bin", "wire.hpp": "wire.hpp"}
    with tarfile.open(dep) as archive:
        for src, dest in members.items():
            (out / dest).write_bytes(archive.extractfile(src).read())
    checked(out / "voice.bin", digest["target_code"])
    checked(out / "voice.elf", digest["target_elf"])
    waves = factory / "factory-inputs/public-morphs.f32"
    compact = factory / "factory-inputs/compact.bin"
    presets = factory / "commands/preset-commands.bin"
    for file, key in [(waves,"full_waveforms"),(compact,"compact_waveforms"),(presets,"factory_commands")]:
        checked(file, digest[key])

    # Reuse the original, freshly installed factory oracle and its linker wrappers.
    commands = json.loads((factory / "factory-build-commands.json").read_text())
    compile_args = next(cmd.copy() for cmd in commands if any(s.endswith("/preset_audio.cpp") for s in cmd))
    for flag, name in [("-c","capture.cpp"),("-o","capture.o"),("-MF","capture.d")]:
        compile_args[compile_args.index(flag)+1] = str(out / name)
    run(compile_args + ["-I"+str(here), "-I"+str(out)])
    link = commands[-1].copy()
    link[next(i for i,s in enumerate(link) if s.endswith("/factory-6.o"))] = str(out / "capture.o")
    link[link.index("-o")+1] = str(out / "capture")
    run(link + ["-Wl,--wrap=_ZN11S1NoteState3runEiPfS0_"])
    run([out/"capture", waves, compact, presets, "late", out/"ref", "-"],out/"host.log",cwd=out)
    checked(out / "cases.bin", digest["full_states"])
    checked(out / "ref-1.bin", digest["original_1"])
    checked(out / "ref-8.bin", digest["original_8"])
    if (out/"sine.bin").read_bytes() != (out/"sine-reference.bin").read_bytes():
        raise ValueError("sine table differs from native input control")

    source = repo / "firmware/src/dsp/synthone/scheduler/nodouble"
    for name in ("exact.c","exact.h","d64.c","d64.h"):
        checked(source / name, digest[name])
    for src in [here/"math.c", source/"exact.c", source/"d64.c"]:
        run(["cc","-O3","-ffp-contract=off","-fno-fast-math","-I"+str(source),
             "-c",src,"-o",out/(src.name+".o")])
    run(["ar","rcs",out/"libzmath.a",out/"math.c.o",out/"exact.c.o",out/"d64.c.o"])
    run([rustc,"--edition=2021","-C","opt-level=2","-C","lto=fat","-C","embed-bitcode=yes",
         "-C","codegen-units=1","-L",core.parent,"-L",out,"-l","static=zmath","--extern",
         "fm1_core="+str(core),here/"run.rs","-o",out/"run"])
    # Exact symbol range in the pinned linked ELF, checked independently of the firmware source.
    symbols = subprocess.check_output(["readelf","-Ws",out/"voice.elf"],text=True)
    registered={name:int(address,16) for address,name in re.findall(r"case 0x([a-f0-9]+): /\* (s1_\w+) \*/",(here/"math.c").read_text())}
    linked={l.split()[-1]:int(l.split()[1],16) for l in symbols.splitlines() if " FUNC " in l and l.split()[-1].startswith("s1_")}
    assert len(registered)==16 and registered==linked
    line = next(l.split() for l in symbols.splitlines() if l.endswith(" _ZN11S1NoteState3runEiPfS0_"))
    (out/"range.txt").write_text(f"{int(line[1],16)} {int(line[2])}\n")
    (out/"4096.bin").write_bytes((out/"cases.bin").read_bytes()[:4096*1172])
    for name, file, reference, cold in [
            ("control-169","169.bin","control_169_csv",False),
            ("whole","cases.bin","whole_csv",False),
            ("control-4096","4096.bin","control_4096_csv",True)]:
        env = os.environ.copy()
        env.pop("FREE_MATH_FRESH_DECODER",None)
        if cold:
            env["FREE_MATH_FRESH_DECODER"]="1"
        dest=out/(name+".csv")
        run([out/"run",out/"voice.bin",out/file,waves,out/"sine.bin","1156",out/"range.txt"],dest,env=env)
        checked(dest,digest[reference])

    with (out/"whole.csv").open() as stream:
        rows=list(csv.DictReader(stream))
    fields=("L","R","amp","filter")
    assert len(rows)==expected["rows"]==30167
    assert len(rows)*len(fields)==expected["compared_reference_words"]==120668
    assert all(row["actual_"+f]==row["reference_"+f] for row in rows for f in fields)
    for summary in expected["original_epoch_prefixes"]:
        owner,start,length=summary["program"],summary["start"],summary["frames"]
        group=[r for r in rows if int(r["owner"])==owner and start<=int(r["absolute_frame"])<start+length]
        assert len(group)==summary["voice_calls"]
        assert len({r["absolute_frame"] for r in group})==length
        assert sum(int(r["helper_calls"]) for r in group)==summary["free_math_calls"]
        for key in ["voice_ticks","body_ticks"]:
            assert sum(int(r[key]) for r in group)==summary[key]["total"]
    assert (out/"whole.csv").read_bytes().startswith((out/"control-4096.csv").read_bytes())
    print("PASS 30,167 genuine voice calls, 120,668 matching outputs, four exact timing totals and both cache controls")


if __name__ == "__main__":
    main()
