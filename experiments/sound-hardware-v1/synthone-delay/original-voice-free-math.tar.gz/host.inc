#include "wire.hpp"
static unsigned audit_frame,audit_idx,audit_row,call_counts[2][2],captured;
static FILE *voice_out;
extern "C" void __real__ZN11S1NoteState3runEiPfS0_(S1NoteState*,int,float*,float*);
extern "C" void __wrap__ZN11S1NoteState3runEiPfS0_(S1NoteState*v,int ix,float*l,float*r){
    unsigned at=audit_frame+ix,row=audit_row,k=row==8,low=(at>=22136&&at<(k?22647:39692)),high=(at>=132344&&at<(k?132855:141378));
    if(low||high)++call_counts[k][high];
    bool selected=low||high;
    if(!selected){__real__ZN11S1NoteState3runEiPfS0_(v,ix,l,r);return;}
    VoiceWire w{}; auto &s=*v->kernel;
    w.tag=0x53515657;w.program=row;w.frame=at;w.id=audit_idx++;w.rand_before=s.sp->rand;
    w.stage=v->stage;w.velocity=v->velocity;w.root=v->rootNoteNumber;w.transpose=v->transpose;w.gate=v->internalGate;w.amp=v->amp;w.filter=v->filter;
    memcpy(w.params,s.parameters,sizeof w.params);memcpy(w.bands,s.ft_frequencyBand,sizeof w.bands);
    float levels[]={s.lfo1_0_1,s.lfo1_1_0,s.lfo2_0_1,s.lfo2_1_0,s.lfo3_0_1,s.lfo3_1_0,s.monoFrequencySmooth};memcpy(w.lfo,levels,sizeof levels);
    for(int i=0;i<2;i++){auto &m=*(i?v->oscmorph2:v->oscmorph1);w.m[i]={{m.freq,m.amp,m.iphs,m.lphs,m.inc},m.wtpos,m.nft,m.nbl,m.enableBandlimit,m.bandlimitIndexOverride};}
    auto &o=*v->subOsc;w.sub={o.freq,o.amp,o.iphs,o.lphs,o.inc};auto &f=*v->fmOsc;w.fm={f.amp,f.freq,f.car,f.mod,f.indx,f.iphs,f.mphs,f.cphs};
    w.env[0]=*v->adsr;w.env[1]=*v->fadsr;w.low=*v->loPass;w.high=*v->hiPass;w.band=*v->bandPass;w.mc=*v->morphCrossFade;w.fc=*v->filterCrossFade;w.noise=*v->noise;w.in_l=l[ix];w.in_r=r[ix];
    if(!captured){FILE*g=fopen("sine.bin","wb");CHECK(g&&fwrite(s.sine->tbl,4,4097,g)==4097&&fclose(g)==0);}
    __real__ZN11S1NoteState3runEiPfS0_(v,ix,l,r);
    float result[4]={l[ix],r[ix],v->amp,v->filter};CHECK(fwrite(&w,sizeof w,1,voice_out)==1&&fwrite(result,sizeof result,1,voice_out)==1);++captured;
}
