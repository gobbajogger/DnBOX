# Full original voice workload with zero-cost exact arithmetic

This experiment measures the complete dynamic voice work covering the two historical cursor requests from each recorded factory program. The edited row 1 history comprises 26,590 actual voice calls. The unchanged row 8 history comprises 3,577. The test makes the existing software binary64 operations free and keeps the original voice control flow, actual input data, causal accumulation order and downstream numeric results. Every one of the 120,668 returned left, right, amplitude and filter words matched the original host implementation exactly.

| Factory program | First history frame | Frames | Active voice calls | All arithmetic helpers free, one core | All arithmetic helpers free, ideal two cores | Only original caller's own instructions, ideal two cores |
|---|---:|---:|---:|---:|---:|---:|
| 1 · Dat Bomb Bass, Yo | 22,136 | 17,556 | 17,556 | 136,435.755 µs | 68,217.877 µs | 27,659.202 µs |
| 1 · Dat Bomb Bass, Yo | 132,344 | 9,034 | 9,034 | 70,190.627 µs | 35,095.314 µs | 14,233.347 µs |
| 8 · June Oh 06 Sqr | 22,136 | 511 | 1,022 | 7,981.329 µs | 3,990.664 µs | 1,630.484 µs |
| 8 · June Oh 06 Sqr | 132,344 | 511 | 2,555 | 19,892.238 µs | 9,946.119 µs | 4,075.644 µs |

For row 1, either history cursor alone exceeds the 11,609.977 µs audio half, even if every instruction in every called function takes zero time. For row 8 the two cursor requests together take at least 13,936.783 µs with free exact arithmetic. Charging only instructions inside the row 8 voice caller gives 5,706.129 µs across both cursors. The project qualification deadline is 10,909 µs. The measured timings apply to the recorded operation sequence. A different state representation or algorithm, or a correctly completed earlier render, has a separate qualification burden.

## What executed

The original capture serializes causal state immediately before each actual voice call. The target driver initializes each frame's mix to zero and passes each voice's preceding native stereo sum to the next. All expected outputs live outside guest memory. Initial object state and authentic per-frame smoothed controls are supplied for free. The 52 public waveform tables and sine table have ideal memory access.

The PI32v2 kernel is the same 10,754-byte linked binary as in native-dynamic-voice-budget.tar.gz, SHA-256 a431ae803381414fc0ae6030a14fe6b6b2bd2e75dc8380a8c4963232c0a98ab9. At each linked s1_ exact-arithmetic helper entry, the host calls the project's exact C implementation with the current guest register and memory arguments. It writes the actual return word or coefficient array to the guest, sets the PC to the genuine return address and charges zero ticks for that entire helper. The dispatcher checks all linked s1_ symbols. Guest CPU code still executes the voice mix, control branches, oscillators, envelopes, filter dispatch and state updates. The whole-call counter charges those instructions, including the guest's calls into the free helper. A separate address-range counter charges only instructions inside S1NoteState::run. Its callees, including all Soundpipe DSP modules, carry zero cost in that column. Both counters use the strict 360 MHz instruction model and 5,760 cost ticks per microsecond. Dividing by two gives the optimistic bound with perfect distribution across two cores. Checkpoint acquisition, wet processing, memory stalls, other engines and inter-core synchronization fall outside these figures.

The 169-case genuine-PI32 comparison from the preceding receipt remains exact with these substitutions. An independent run with a fresh decoder cache for each voice produced identical complete CSV rows for those cases and the first 4,096 full-workload cases. Reusing the decoded-instruction cache changes host runtime only. Architectural state is restored before every voice.

## Verify this compact record

The 30,167-row CSV has SHA-256 b3dd1dd2c925ebf228ec4abdf3350407fdac0877856a6ea231d62b35b4187d51. Its 35,355,724-byte original pre-call input stream has SHA-256 5053c93e45d52022ebc34dcf372468a8731267bf6d881fd3d26d80048ff07d84. The larger, self-contained raw evidence packet original-voice-free-math-full-history.tar.gz is 3,290,434 bytes with SHA-256 6aabf4b255f0ccb225b8ece086df5948528adfa56c84ab00d4c3a343d88a63df. It includes every recorded state and all result rows. The reproduction below regenerates those states and rows from source without that packet.

Use a checkout of DnBOX containing the authentic factory test-input bundle and the tracked target-original-voice-cost.tar.gz packet under experiments/sound-hardware-v1/synthone-delay. Provide the matching 360 MHz emulator Rust compiler, dependency directory and fm1_core rlib as obtained from the pinned emulator build. expected.json pins the rlib, target ELF, target load image, exact arithmetic sources, controls, table bytes and retained oracle outputs. The PI32 compilation command list and kernel sources are in target-original-voice-cost.tar.gz. The driver checks and uses that exact linked ELF. The fixed entry addresses in math.c belong to those pinned ELF bytes. The verifier checks all 16 linked helper names and addresses against the ELF symbol table. The single caller's range comes directly from the ELF symbol table.

From the repository root choose a fresh directory and set RECORD to the path containing measure.py. RUSTC must point to the matching rustc executable. FM1_CORE must point to its fm1_core rlib in the emulator's release/deps directory.

```sh
work=$(mktemp -d)
python3 tools/restore-synthone-test-inputs.py --bundle assets/test-inputs/synthone --output "$work/inputs"
python3 tests/host/run_synthone_factory.py --source-build "$work/inputs" --output "$work/factory" --build-only
python3 "$RECORD/measure.py" --repo "$PWD" --factory-build "$work/factory" \
  --rustc "$RUSTC" --fm1-core "$FM1_CORE" --output "$work/measurement"
```

The capture uses the original 694-entry command stream, plays the two disclosed factory programs, records every active call in the demanded windows and confirms both seven-word-per-frame post-FX reference outputs. The target runner recomputes every mix accumulator from zero and preceding calculated voices, compares every source/reference output word and checks complete CSV digests. It also reproduces all four independent active-call and timing totals and the 4,096-row fresh-decoder control. The direct oracle capture, current architecture state and uncapped-precision host helper computations precede the target timing measurement. This method is a diagnostic counterfactual, and expected.json separates genuine required frame counts, active calls, free helper calls and remaining charged target ticks.

The command writes the complete rows to whole.csv and the four smaller control and capture outputs in the provided measurement directory. On success it reports 30,167 calls and 120,668 matching outputs.
