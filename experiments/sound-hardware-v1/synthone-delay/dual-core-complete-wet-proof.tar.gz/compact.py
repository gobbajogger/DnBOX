from pathlib import Path
import sys
src=Path(sys.argv[1]).read_text()
head=src[:src.index('typedef struct {\n    float sum[PHASE_BINS]')]
reader=src[src.index('typedef struct {\n    uint32_t start,end,step,index;'):src.index('static int dry_begin(')]
seek=src[src.index('static inline __attribute__((always_inline)) void dry_seek('):]
head=head.replace('DRY_PERIODIC_PROVIDER_H','DRY_REPLAY_RECORDS_H')
Path(sys.argv[2]).write_text(head+'typedef struct {dry_record events[DRY_NOTES];uint32_t used,end;} dry_history;\n'+reader+seek)
