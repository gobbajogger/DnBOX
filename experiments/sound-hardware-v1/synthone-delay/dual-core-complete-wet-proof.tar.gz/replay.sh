#!/bin/sh
set -eu
if [ "$#" -ne 9 ]; then
    echo "usage: replay.sh PI32V2_DIR RUSTC FM1_RLIB ORIG_FACTORY_BUILD PREDICTED_TRACES EDITED_TRACES PERIODIC_RECEIPTS CAPTURE_SOURCE FRAME_IMPLEMENTATION" >&2
    exit 2
fi
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
tc=$1
rustc=$2
library=$3
factory=$4
pred=$5
edited=$6
records=$7
cap=$8
impl=$9
out=${RUN_DIR:-"$here/reproduced"}
mkdir -p "$out"
"$rustc" --edition=2021 -C opt-level=2 -C lto=fat -C embed-bitcode=yes -C codegen-units=1 -L "$(dirname "$library")" --extern "fm1_core=$library" "$here/dual-run.rs" -o "$out/dual-run"
for bits in 3 6; do
    c++ -DPHASE_BITS="$bits" -O2 -std=c++17 -ffp-contract=off -fno-fast-math -I"$here/source" "$here/seed.cpp" -o "$out/seed$bits"
    "$tc/bin/clang" -target pi32v2 -mcpu=r3 -mfprev1 -Oz -DPHASE_BITS="$bits" -idirafter "$tc/include" -I"$here/source" -c "$here/layout.c" -o "$out/layout$bits.o"
    "$tc/bin/nm" -S --radix=d "$out/layout$bits.o" > "$out/layout$bits.txt"
done
python3 "$here/capture_full.py" "$factory" "$cap" "$impl" "$records" "$out/whole"
"$out/whole/capture" "$factory/factory-inputs/public-morphs.f32" "$factory/factory-inputs/compact.bin" "$factory/commands/preset-commands.bin" late "$out/whole/periodic64" "$records/6-" > "$out/whole/periodic64.csv"
python3 "$here/verify_ports.py" "$edited" "$out/whole" "$out/ports.json"
python3 "$here/run.py" "$tc" "$out/dual-run" "$out/seed" "$pred" "$edited" "$records" "$out/whole" "$out/lean"
python3 "$here/downstream.py" "$factory" "$out/whole" "$out/lean" "$out/downstream"
