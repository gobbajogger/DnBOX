#include "shared.h"
#include "checkpoint_state.h"
struct snapshot {flash_witness_cursor history;float delay,feedback;};
struct combined {struct snapshot saved;shared_state active;};
shared_state active;
struct snapshot saved;
struct combined total;
#ifdef PHASE_BINS
struct encoder_only {float sum[PHASE_BINS],energy[2];uint16_t hits[PHASE_BINS];uint32_t phase,step,count;} encode;
#endif
