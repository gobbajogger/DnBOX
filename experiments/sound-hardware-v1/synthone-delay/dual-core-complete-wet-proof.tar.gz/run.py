from pathlib import Path
import csv,ctypes,hashlib,json,subprocess,struct,sys,time
import numpy as np
here=Path(__file__).resolve().parent
tc,runner,seed,pred,changed,periodic,full,out=map(lambda x:Path(x).resolve(),sys.argv[1:])
out.mkdir(exist_ok=True,parents=True)
rows=[];matrices={}
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(args,**kw):return subprocess.run([str(k) for k in args],check=True,**kw)
def error(a,b):
 x=a.astype('f8');y=b.astype('f8');power=np.mean(x*x,axis=0);err=np.mean((x-y)**2,axis=0)
 return {'different':list(map(int,(a.view('<u4')!=b.view('<u4')).sum(axis=0))),'snr_db':[float(10*np.log10(p/e)) if e else None for p,e in zip(power,err)],'max_abs':list(map(float,np.max(np.abs(x-y),axis=0)))}
for trial in ('generic','piecewise'):
 for mode in ('ideal','periodic','periodic64'):
  bits=6 if mode=='periodic64' else 3
  f0=(['-DIDEAL_DRY'] if mode=='ideal' else [])+(['-DFIXED_HISTORY'] if trial=='piecewise' else [])+['-DPHASE_BITS='+str(bits)]
  bins=[];procs=[]
  for kind in ('long','short'):
   flags=f0+(['-DSHORT'] if kind=='short' else [])
   tag=trial+'-'+mode+'-'+kind;obj=out/(tag+'.o');raw=out/(tag+'.raw');so=out/(tag+'.so')
   run([tc/'bin/clang','-target','pi32v2','-mcpu=r3','-mfprev1','-fno-fast-math','-ffp-contract=off','-Oz','-idirafter',tc/'include','-I'+str(periodic),*flags,'-c',here/'worker.c','-o',obj])
   undef=subprocess.check_output([tc/'bin/nm','-u',obj],text=True).strip()
   assert not undef,undef
   rel=subprocess.check_output([tc/'bin/objdump','-r',obj],text=True)
   assert 'RELOCATION RECORDS FOR [.text]' not in rel,rel
   run([tc/'bin/objcopy','-O','binary','-j','.text',obj,raw])
   run(['cc','-std=c11','-fPIC','-shared','-O2','-ffp-contract=off','-fno-fast-math','-DHOST_MATH','-I'+str(periodic),*flags,here/'worker.c','-o',so])
   proc=ctypes.CDLL(str(so)).render;proc.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_uint]
   procs.append(proc);bins.append(raw)
  for owner in [1,8]:
   orig=np.fromfile(full/f'original-{owner}.bin','<f4').reshape(512,7)
   ref=np.fromfile(full/f'{mode}-{owner}.bin','<f4').reshape(512,7) if mode!='ideal' else orig
   trace=np.memmap(changed/f'source-{owner}.bin','<f4',mode='r').reshape(-1,4,5)
   for warmth in (['warm','cold'] if trial=='generic' else ['warm']):
    key=f'{trial}-{mode}-{owner}-{warmth}';dest=out/key;dest.mkdir(exist_ok=True)
    if trial=='piecewise':
     endpoints=((22136,39692),(132344,141378)) if owner==1 else ((22136,22647),(132344,132855))
     for start,end in endpoints:
      x=trace[start:end,0,3]*np.float32(44100);y=trace[start:end,2,3]*np.float32(44100)
      assert np.all((31<x)&(x<=32)&(15<y)&(y<=16))
    tmp=dest/f'seed{owner}'
    run([str(seed)+str(bits),pred/f'feedback-{owner}.bin',changed/f'source-{owner}.bin',periodic/f'{bits}-{owner}.records',mode,warmth,tmp])
    init=tmp.read_bytes();(dest/'initial.bin').write_bytes(init);tmp.unlink()
    io=orig[:,:2].astype('<f4').tobytes()+bytes(4096)
    if mode=='ideal':
     io+=trace[:176400,:2,0].copy().tobytes()
    (dest/'io.bin').write_bytes(io)
    for n in ([0,512] if mode=='periodic' and owner==1 and warmth=='warm' else [512]):
     c=ctypes.create_string_buffer(init,len(init));audio=ctypes.create_string_buffer(io,len(io))
     for proc in procs:proc(c,audio,n)
     hx=np.frombuffer(audio.raw[4096:8192],'<f4').reshape(512,2)
     flags=list(map(int,subprocess.check_output([runner,*bins,dest,str(n)],text=True).strip().split(',')))
     state_n=(dest/f'native-state-{n}.bin').read_bytes();nx=np.fromfile(dest/f'native-mix-{n}.bin','<f4').reshape(512,2)
     state_mism=sum(a!=b for a,b in zip(struct.iter_unpack('<I',state_n),struct.iter_unpack('<I',c.raw)))
     native_mism=int(np.sum(nx.view('<u4')!=hx.view('<u4')))
     m=error(orig[:,3:5],nx) if n else None
     verified=error(ref[:,3:5],nx) if n and (warmth=='warm' or mode=='ideal') else None
     assert state_mism==0 and native_mism==0
     if verified: assert not any(verified['different']), (key,verified)
     rows.append([trial,mode,owner,warmth,n,len(io),len(init)//4,state_mism,native_mism,*flags,max(flags[4:6])/5760,*([*m['different'],*m['snr_db']] if n else [0,0,0,0]),*([*verified['different']] if verified else ['',''])])
     print(key,n,'tick-us',round(max(flags[4:6])/5760,2),'host-state',state_mism,'mix',native_mism,'vs-authored',m['different'] if n else None,'frozen-control',verified['different'] if verified else None,flush=True)
     if n: matrices[key]={'completed_stereo_delay':m,'expected_independent_reader':verified}
with (out/'results.csv').open('w') as f:
 w=csv.writer(f);w.writerow('trial provider owner warmth frames io_bytes state_words target_host_state_mismatch target_host_mix_mismatch ready0 ready1 done0 done1 return0 return1 polls0 polls1 insns0 insns1 makespan_us wet_mismatch_L wet_mismatch_R wet_snr_L wet_snr_R crosscheck_L crosscheck_R'.split());w.writerows(rows)
(out/'scores.json').write_text(json.dumps(matrices,indent=2)+'\n')
