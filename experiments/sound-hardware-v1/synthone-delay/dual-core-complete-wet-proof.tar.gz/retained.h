#ifndef DRY_REPLAY_RECORDS_H
#define DRY_REPLAY_RECORDS_H
#include <stdint.h>
#include <string.h>
#include <math.h>
#ifndef PHASE_BITS
#define PHASE_BITS 3
#endif
#define PHASE_BINS (1u << PHASE_BITS)
#define DRY_NOTES 16u
#define HALF_ENV 5512u
typedef struct {
    uint8_t start[3], midi, levels[2];
    int8_t cycle[PHASE_BINS];
} dry_record;
typedef struct {dry_record events[DRY_NOTES];uint32_t used,end;} dry_history;
typedef struct {
    uint32_t start,end,step,index;
} dry_reader;
static inline __attribute__((always_inline)) uint32_t dry_start(const dry_record *r) {
    return r->start[0]|((uint32_t)r->start[1]<<8)|((uint32_t)r->start[2]<<16);
}
static inline __attribute__((always_inline)) uint32_t dry_increment(unsigned midi) {
    /* Q0.32 phase/sample, for half the authentic equal-tempered note pitch. */
    int d=(int)midi-69;
    float f=220.0f;
    while (d>=12){f*=2;d-=12;}
    while (d<0){f*=.5f;d+=12;}
    while (d-->0) f*=1.0594630943592952646f;
    return (uint32_t)(int32_t)(f*(4294967296.0f/44100.0f)+.5f);
}
static inline __attribute__((always_inline)) void dry_seek(const dry_history *h,dry_reader *q,unsigned t) {
    unsigned lo=0,hi=h->used;
    while (lo+1<hi) {
        unsigned m=(lo+hi)/2;
        if(dry_start(&h->events[m])<=t)lo=m;else hi=m;
    }
    q->index=lo;q->start=dry_start(&h->events[lo]);
    q->end=lo+1<h->used?dry_start(&h->events[lo+1]):h->end;
    q->step=dry_increment(h->events[lo].midi);
}
static inline __attribute__((always_inline)) float dry_get(const dry_history *h,dry_reader *q,unsigned t) {
    if(!h->used||t>=h->end)return 0;
    if(t<q->start||t>=q->end)dry_seek(h,q,t);
    const dry_record *r=&h->events[q->index];
    uint32_t since=t-q->start,phase=since*q->step;
    unsigned bin=phase>>(32-PHASE_BITS);
    float alpha=((phase>>(16-PHASE_BITS))&65535u)*(1.f/65536.f);
    float v=r->cycle[bin]+alpha*(r->cycle[(bin+1)%PHASE_BINS]-r->cycle[bin]);
    unsigned finish=q->end-q->start;
    float fraction=((float)since-.5f*(finish<HALF_ENV?finish:HALF_ENV))*(2.f/(float)finish);
    if(fraction<0)fraction=0;if(fraction>1)fraction=1;
    float level=r->levels[0]+fraction*((float)r->levels[1]-r->levels[0]);
    return v*(level*(1.f/(127.f*255.f)));
}
#endif
