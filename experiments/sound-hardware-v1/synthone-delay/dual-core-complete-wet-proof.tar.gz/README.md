# Two-core feedback delay replay at a live edit

At frame 242,550, factory program 1 receives a delay-time change at the same sample that its wet controls open. Program 8 opens its wet controls at its existing delay time. Both owners contain 16 original played-note intervals, feedback of 0.7 and an earlier change from minimum to maximum delay at frame 176,400. The test includes 512 stereo output frames for each owner. It preserves the original four feedback/cubic paths, including the cascade into the right short tap, and finishes both stereo crossfades.

Two emulated PI32v2 cores execute separately compiled long and short workers on one shared address space. The harness steps the core with the earliest instruction-cost tick, with source-order tie breaking. Both execute `csync`, publish ready and done flags and read the peer flags until the barrier completes. Each CPU has its own dry reader into the same immutable event records. Both cores are available for the whole half, start at the function entry and use an ideal shared RAM bus. Stock mailbox dispatch, interrupts, DMA transfers, other engines and the remaining effects graph are outside these kernel timings. The original downstream graph was executed separately with the actual native stereo outputs substituted after the delay crossfades.

## Resource and timing results

The live-time and historical parameter streams were regenerated from their causal one-pole recurrences. Across both owners the strict float values matched all 176,400 early full-delay, half-delay and feedback samples and all 512 new full-delay, half-delay and wet-mix samples. The complete live half takes only 4,096 bytes of ordinary current stereo input and 4,096 bytes of current stereo output in the measurement setup. An in-place implementation could share these ordinary audio buffers after both channels complete each element. The bounded trials carry no historical audio or per-frame control table in those buffers. The exact-input control adds 1,411,200 bytes of historical stereo input.

| Two-core replay of one 512-frame half | Edited owner, µs | Unchanged owner, µs |
| --- | ---: | ---: |
| Generic cubic, exact dry, warm | 12,443.396 | 760.811 |
| Generic cubic, exact dry, cold | 29,785.733 | 22,723.227 |
| Generic cubic, 8 or 64 bins, warm | 16,693.224 | 894.346 |
| Generic cubic, 8 or 64 bins, cold | 40,127.590 | 30,599.313 |
| Fixed old integer offsets, exact dry, warm | 10,075.624 | 624.589 |
| Fixed old integer offsets, 8 or 64 bins, warm | 14,720.716 | 789.365 |

The actual zero-frame ready/complete barrier and function prologues/returns cost 0.701 µs for the fixed-offset bounded kernel. Timings use 5,760 instruction-cost ticks per microsecond at 360 MHz. The individual ready, completion, return, instruction and poll counts are in results.csv. The edited 8-bin warm worker made 2 and 231,614 remote flag reads on its two cores. The same computation with ideal original input required 2 and 146,703. These measurements include polling on the faster-finishing core. The edited bounded kernel alone exceeded the 11,609.977 µs audio half and the 10,909 µs project target.

The warm cursors start at frames 22,136 and 132,344. The edited half advances them by 17,556 and 9,034 samples. The unchanged half advances both by 511. Cold starting points are frame zero and frame 105,840 with 39,692 and 35,538 advances for the edited half, or 22,647 and 27,015 for the unchanged half. In the original early segment the positive, monotonic delay control first has both integer interpolation offsets fixed at frame 22,084. The full delay stays in (31,32] samples and the short delay in (15,16]. For the measured fixed-offset segment, initial full delay is 31.008156 samples and reaches 31.985422 on the later cursor. We used -32 and -16 in that segment and recomputed all cubic fractions from the generated float delay whenever it changed. The four wet operands come from consecutive writes in each actual replay ring. Hold/settle is detected via float equality. Cold startup traverses changing integer offsets and uses the generic path.

| Per-owner state on the target ABI | 8 bins | 64 bins |
| --- | ---: | ---: |
| One retained feedback snapshot and its two smoothed values | 460 | 460 |
| Active two-core guards, controls, flags, records, two readers | 956 | 1,852 |
| Total during replay | 1,416 | 2,312 |
| Concurrent streaming encoder scratch, if needed | 68 | 404 |
| Total with concurrent encoding | 1,484 | 2,716 |
| Bytes left from this selected engine’s 2,764-byte allowance with concurrent encoding | 1,280 | 48 |

For these two scenes a single genuine saved snapshot at frame 105,840 and implicit initial zero suffice. The snapshot contains 452 bytes of feedback state and eight bytes of smoothed historical controls. It was computed when authentic early audio and control values were available. At the long-time setter the snapshot can remain frozen while the two warm replay cursors advance toward the forecast live reads. The saved snapshot is the last completed 105,840-frame interval at the setter. No claim is made that one checkpoint covers arbitrary edit arrival, independent tails, other engines, or additional polyphonic events. Snapshot capture, cursor prewarming, live stock dry synthesis and downstream DSP are outside the timed warm interval. The cold condition removes prewarming. The concurrent scratch count covers the existing causal encoder with this immutable event set. A changing record would additionally require ownership/lifetime control. No firmware link, ROM budget, stock stacks, or processing time remains qualified by this isolated resource receipt.

## Complete sound comparison

The strict native and independent host implementations agree on every shared-state word and stereo sample for all trials. Using exact historical input also agrees on all 1,024 float words of the original complete stereo delay mix and all 1,024 words after original downstream effects for each factory program, cold and warm. Each bounded resolution differs on every final output word. The warm native results also equal the independent tap-replacement route after the original downstream graph, including the original phaser, wet mix, reverb and compressor history. The first wet crossfade has gain 2.470475e-8, rising to 0.00597958 at its 512th frame.

| Factory row | Source bins | Final L SNR | Final R SNR |
| --- | ---: | ---: | ---: |
| 1 Dat Bomb Bass, Yo | 8 | 10.27 dB | 16.28 dB |
| 1 Dat Bomb Bass, Yo | 64 | 11.53 dB | 23.27 dB |
| 8 June Oh 06 Sqr | 8 | 7.50 dB | 14.03 dB |
| 8 June Oh 06 Sqr | 64 | 7.32 dB | 15.61 dB |

The prior tap criteria require 24 dB aligned SNR, level error at most 1 dB and spectral error at most 3 dB for every tap. Both previously tested periodic encodings failed those gates. Moving from four retained snapshots to one makes larger event storage feasible on these two histories. It does not make either existing decoder reproduce the original audio or meet this half's timing.

## Reproduction

Run replay.sh with the project PI32v2 toolchain, matching fm1 emulator Rust compiler and fm1_core rlib, the authenticated Synth One factory build directory, the forecast and actual late-edit trace directories, the earlier bounded-periodic source folder, its original capture.cpp and original measured.hpp. The earlier dependency receipts are bounded-periodic-source-proof.tar.gz (a7d0be7b9c68e24aa1d062ef79b7d1d8e3daebfcdb3f28c7a7e027c2a02b1f02), checkpoint-provider-feedback.tar.gz (294adae1c853b8b8a44fa6b15b1e550350fd19bf7eca874f49255a38c0cf08eb) and prewarm-live-edit-proof.tar.gz (5a30da980f8c4a9631f41eeb7cd2bf22008c3458cb63457d7cbba723dcf78762). Input hashes are listed in INPUTS.sha256. The package includes all target kernels, authentic and altered 512-frame outputs, compact event records, trial initial and returned states, and per-scene receipts. Each seven-float output row contains phaser L/R, true crossfade position, stereo delay mix L/R and final L/R. Short tables emit blank SNR for exact equality.
