#include "checkpoint_core.hpp"
#include "shared.h"
#include <string>
int main(int argc,char **argv){
    assert(argc==7);
    auto load=[](const char*p){std::vector<Frame> a(264600);FILE*f=fopen(p,"rb");assert(f&&fread(a.data(),sizeof(Frame),a.size(),f)==a.size()&&fclose(f)==0);return a;};
    auto pred=load(argv[1]),data=load(argv[2]);
    bool ideal=!strcmp(argv[4],"ideal"), warm=!strcmp(argv[5],"warm");
    shared_state s{};FILE *rec=fopen(argv[3],"rb");assert(rec&&fread(s.hist.events,sizeof s.hist.events,1,rec)==1&&fclose(rec)==0);
    s.hist.end=176400;s.hist.used=16;s.wet_half=pred[first_wet-1][2].delay;
    s.wet_target=strcmp(argv[6]+strlen(argv[6])-1,"1")==0?16.f/44100.f:2.5f;
    /* Keep one authenticated early feedback snapshot. The long-time edit at
       four seconds preserves the last 105840-frame checkpoint. */
    flash_witness_cursor saved{};
    float saved_delay=0, saved_feedback=0;
    constexpr float c2=0x1.ffeb66p-1f, dry_delay=0x1.e9d920p-25f, dry_feedback=0x1.cd799ap-14f;
    for(unsigned t=0;t<105840;++t) {
        saved_delay=dry_delay+c2*saved_delay;saved_feedback=dry_feedback+c2*saved_feedback;
        assert(saved_delay==data[t][2].delay && saved_feedback==data[t][0].feedback);
        tick(saved,data[t]);
    }
    for(unsigned k=0;k<2;++k){
        auto q=at(first_wet,pred[first_wet][2*k].delay);
        const bool later=q.base-1>=105840;
        flash_witness_cursor c=later?saved:flash_witness_cursor{};
        float port_delay=later?saved_delay:0,port_fb=later?saved_feedback:0;
        unsigned end=(unsigned)(q.base+3);
        while(warm&&c.next<end){
            auto frame=data[c.next];
            port_delay=dry_delay+c2*port_delay;port_fb=dry_feedback+c2*port_fb;
            assert(port_delay==frame[2].delay && port_fb==frame[0].feedback);
            if(!ideal){float v=dry_get(&s.hist,&s.lookup[k],c.next);for(unsigned j=0;j<3;++j)frame[j].input=v;}
            tick(c,frame);
        }
        s.next[k]=c.next;
        s.slew_delay[k]=port_delay;s.slew_feedback[k]=port_fb;
        if(!k){
            for(unsigned i=0;i<38;++i)s.ll.ring[i]={c.long_writes[0][i%35],c.long_writes[1][i%35]};
            s.ll.prev={c.prev[0],c.prev[1]};
        }else{
            for(unsigned i=0;i<38;++i)s.rr.right[i]=c.long_writes[1][i%35];
            for(unsigned i=0;i<22;++i)s.rr.short_ring[i]={c.short_writes[0][i%19],c.short_writes[1][i%19]};
            s.rr.a=c.prev[1];s.rr.b=c.prev[2];s.rr.c=c.prev[3];
        }
    }
    FILE*f=fopen(argv[6],"wb");assert(f&&fwrite(&s,sizeof(s),1,f)==1&&fclose(f)==0);
}
