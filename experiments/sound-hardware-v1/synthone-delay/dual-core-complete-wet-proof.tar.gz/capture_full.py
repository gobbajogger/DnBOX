"""Replay the entire original effects graph and extract the actual stereo delay mixer boundaries."""
from pathlib import Path
import subprocess,json,sys
build,old,measured,records,out=map(lambda x:Path(x).resolve(),sys.argv[1:])
out.mkdir(parents=True,exist_ok=True)
h=measured.read_text()
h=h.replace('static FILE *trace_file;','static FILE *trace_file;\nstatic const float *override_taps; static float full_mix[5];')
drop='if(std::fwrite(row,sizeof(row),1,trace_file)!=1) std::abort();';assert h.count(drop)==1;h=h.replace(drop,'(void)row;')
mark='        delayOutRR += delayFillInOut;';assert h.count(mark)==1
h=h.replace(mark,'        if(override_taps){delayOutL=override_taps[0];delayOutR=override_taps[1];delayFillInOut=override_taps[2];delayOutRR=override_taps[3];}\n'+mark)
mark='        // REVERB INPUT HIPASS FILTER';assert h.count(mark)==1
h=h.replace(mark,'        full_mix[0]=phaserOutL;full_mix[1]=phaserOutR;full_mix[2]=delayCrossfadeL->pos;full_mix[3]=mixedDelayL;full_mix[4]=mixedDelayR;\n'+mark)
(out/'measured.hpp').write_text(h)
s=old.read_text().replace('FullPair pair; FILE *trace=nullptr;','FullPair pair; FILE *trace=nullptr; float taps[512][4]{}; bool inject=false;')
mark='        trace_file=x.trace;';assert s.count(mark)==1
s=s.replace(mark,'        const unsigned abs=x.absolute+frame;override_taps=x.inject&&abs>=wet_edit&&abs<wet_edit+512?x.taps[abs-wet_edit]:nullptr;\n'+mark)
mark='        const unsigned now = x.absolute + frame;';assert s.count(mark)==1
s=s.replace(mark,mark+'\n        if(now>=wet_edit&&now<wet_edit+512){float a[7]={full_mix[0],full_mix[1],full_mix[2],full_mix[3],full_mix[4],x.left[frame],x.right[frame]};CHECK(fwrite(a,sizeof a,1,x.trace)==1);}')
s=s.replace('CHECK(argc==6);','CHECK(argc==7);')
mark='        owners[i]->trace=std::fopen(path.c_str(),"wb");';assert s.count(mark)==1
s=s.replace(mark,mark+'\n        if(strcmp(argv[6],"-")){FILE *in=fopen((std::string(argv[6])+std::to_string(rows[i])+".wet").c_str(),"rb");CHECK(in&&fread(owners[i]->taps,sizeof owners[i]->taps,1,in)==1&&fclose(in)==0);owners[i]->inject=true;}')
(out/'capture.cpp').write_text(s)
cmd=json.loads((build/'factory-build-commands.json').read_text());cc=next(c.copy() for c in cmd if any(v.endswith('/preset_audio.cpp') for v in c))
for flag,path in [('-c',out/'capture.cpp'),('-MF',out/'capture.d'),('-o',out/'capture.o')]:cc[cc.index(flag)+1]=str(path)
subprocess.run(cc,check=True);ld=cmd[-1].copy();ld[ld.index(str(build/'factory-6.o'))]=str(out/'capture.o');ld[ld.index('-o')+1]=str(out/'capture');subprocess.run(ld,check=True)
inp=build/'factory-inputs'
for tag,inject in [('original','-'),('periodic',str(records/'3-'))]:
 with (out/(tag+'.csv')).open('w') as log:
  subprocess.run([out/'capture',inp/'public-morphs.f32',inp/'compact.bin',build/'commands/preset-commands.bin','late',out/tag,inject],stdout=log,check=True)
