"""Feed measured PI32 stereo into the original remaining effects in the two factory owners."""
from pathlib import Path
import csv,json,subprocess,sys
import numpy as np
build,whole,lean,out=[Path(p).resolve() for p in sys.argv[1:]]
out.mkdir(parents=True,exist_ok=True)
def edit(code,before,after):
    assert code.count(before)==1,before
    return code.replace(before,after)
h=(whole/'measured.hpp').read_text()
h=edit(h,'static const float *override_taps;', 'static const float *override_taps, *override_mix;')
h=edit(h,'        full_mix[0]=phaserOutL;', '        if(override_mix){mixedDelayL=override_mix[0];mixedDelayR=override_mix[1];}\n        full_mix[0]=phaserOutL;')
(out/'measured.hpp').write_text(h)
s=(whole/'capture.cpp').read_text()
s=edit(s,'float taps[512][4]{};','float mix[512][2]{};')
s=edit(s,'override_taps=x.inject&&abs>=wet_edit&&abs<wet_edit+512?x.taps[abs-wet_edit]:nullptr;', 'override_taps=nullptr;override_mix=x.inject&&abs>=wet_edit&&abs<wet_edit+512?x.mix[abs-wet_edit]:nullptr;')
s=edit(s,'+".wet"', '+"-mixed.bin"')
s=edit(s,'fread(owners[i]->taps,sizeof owners[i]->taps','fread(owners[i]->mix,sizeof owners[i]->mix')
(out/'capture.cpp').write_text(s)
cmd=json.loads((build/'factory-build-commands.json').read_text())
cc=next(c.copy() for c in cmd if any(v.endswith('/preset_audio.cpp') for v in c))
for flag,path in [('-c',out/'capture.cpp'),('-MF',out/'capture.d'),('-o',out/'capture.o')]:
    cc[cc.index(flag)+1]=str(path)
subprocess.run(cc,check=True)
ld=cmd[-1].copy()
ld[ld.index(str(build/'factory-6.o'))]=str(out/'capture.o')
ld[ld.index('-o')+1]=str(out/'capture')
subprocess.run(ld,check=True)
rows=[]
for trial,warmth in [('piecewise','warm'),('generic','cold')]:
    for mode in ['ideal','periodic','periodic64']:
        label=f'{trial}-{mode}-{warmth}'
        for owner in [1,8]:
            m=lean/f'{trial}-{mode}-{owner}-{warmth}'/'native-mix-512.bin'
            (out/f'{label}-{owner}-mixed.bin').write_bytes(m.read_bytes())
        inp=build/'factory-inputs'
        with (out/(label+'.log')).open('w') as log:
            subprocess.run([out/'capture',inp/'public-morphs.f32',inp/'compact.bin',build/'commands/preset-commands.bin','late',out/label,str(out/label)+'-'],stdout=log,check=True)
        for owner in [1,8]:
            def load(path,n=7):
                return np.fromfile(path,'<f4').reshape(512,n)
            original=load(whole/f'original-{owner}.bin')
            reference=load(whole/f'{mode}-{owner}.bin') if mode!='ideal' else original
            observed=load(out/f'{label}-{owner}.bin')
            mixed=load(out/f'{label}-{owner}-mixed.bin',2)
            assert np.array_equal(observed[:,:3].view('u4'),original[:,:3].view('u4'))
            assert np.array_equal(observed[:,3:5].view('u4'),mixed.view('u4'))
            diff=(observed[:,5:].view('u4')!=original[:,5:].view('u4')).sum(axis=0)
            exact=(observed[:,5:].view('u4')!=reference[:,5:].view('u4')).sum(axis=0)
            e=observed[:,5:].astype('f8')-original[:,5:].astype('f8')
            signal=original[:,5:].astype('f8')
            snr=[float(10*np.log10(p/d)) if d else None for p,d in zip(np.sum(signal*signal,axis=0),np.sum(e*e,axis=0))]
            if mode=='ideal': assert not diff.any()
            if warmth=='warm': assert not exact.any()
            rows.append([trial,mode,owner,warmth,*diff,*snr,*np.max(abs(e),axis=0),*exact])
with (out/'final.csv').open('w') as f:
    w=csv.writer(f);w.writerow('trial mode owner warmth final_mismatch_L final_mismatch_R snr_L snr_R max_abs_L max_abs_R tap_reference_mismatch_L tap_reference_mismatch_R'.split());w.writerows(rows)
