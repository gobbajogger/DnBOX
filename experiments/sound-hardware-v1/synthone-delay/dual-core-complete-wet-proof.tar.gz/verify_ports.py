from pathlib import Path
import json,sys
import numpy as np
trace,rx,out=map(Path,sys.argv[1:])
q=np.float32
c2=q(.5**float(q(q(1/44100)/q(.1))));c1=q(1-float(c2))
fb_input=q(c1*q(.7));dt_input=q(c1*q(16/44100))
fd=np.empty((176400,2),dtype='<f4');fb=dt=q(0)
for i in range(len(fd)):
    fb=q(fb_input+c2*fb);dt=q(dt_input+c2*dt);fd[i]=(fb,dt)
ret={'c1':float(c1).hex(),'c2':float(c2).hex(),'owners':{}}
for owner in (1,8):
    a=np.memmap(trace/f'source-{owner}.bin','<f4',mode='r').reshape(-1,4,5)
    actual=np.fromfile(rx/f'original-{owner}.bin','<f4').reshape(-1,7)
    wet=a[242549,2,3];level=q(0);wet_target=q(16/44100) if owner==1 else q(2.5)
    h=np.zeros((512,3),dtype='<f4')
    for i in range(512):
        wet=q(c1*wet_target+c2*wet);level=q(c1+c2*level)
        h[i]=[q(2)*wet,wet,q(level*level)]
    found={'old_feedback_mismatch':int(np.count_nonzero(a[:176400,0,2].view('u4')!=fd[:,0].view('u4'))),
           'old_half_time_mismatch':int(np.count_nonzero(a[:176400,2,3].view('u4')!=fd[:,1].view('u4'))),
           'old_full_time_mismatch':int(np.count_nonzero(a[:176400,0,3].view('u4')!=(fd[:,1]*q(2)).view('u4'))),
           'new_full_mismatch':int(np.count_nonzero(h[:,0].view('u4')!=a[242550:243062,0,3].view('u4'))),
           'new_half_mismatch':int(np.count_nonzero(h[:,1].view('u4')!=a[242550:243062,2,3].view('u4'))),
           'new_mix_mismatch':int(np.count_nonzero(h[:,2].view('u4')!=actual[:,2].view('u4')))}
    assert not any(found.values()),found
    ret['owners'][owner]=found
out.write_text(json.dumps(ret,indent=2)+'\n')
