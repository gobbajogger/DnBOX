#include "shared.h"
#define INLINE static inline __attribute__((always_inline))
#ifdef SHORT
#define K 1
#else
#define K 0
#endif
#ifdef HOST_MATH
#define SYNC() ((void)0)
#else
#define SYNC() __asm__ volatile ("csync":::"memory")
#endif
#define C2 0x1.ffeb66p-1f
#define C1 0x1.49a0p-13f
#define EARLY_FB 0x1.cd799ap-14f
#define EARLY_DELAY 0x1.e9d920p-25f
typedef struct {float f,w,x,y,z;int delta;} coeffs;
INLINE coeffs cub(float delay) {
    float f=delay * -44100.f;
    int d=(int)f;f-=(float)d;if(f<0){--d;f+=1.f;}
    float z=(f*f-1.f)/6.f,y=(f+1.f)*.5f,x=3.f*z;
    coeffs w={f,(y-1.f)-z,x-f,y-x,z,d};
    return w;
}
INLINE coeffs known_cub(float d,int offset) {
    float f=d*(-44100.f)-(float)offset;
    float z=(f*f-1.f)/6.f,y=(f+1.f)*.5f,x=3.f*z;
    coeffs w={f,(y-1.f)-z,x-f,y-x,z,offset};return w;
}
#ifdef FIXED_HISTORY
#define HIST_FULL(x) known_cub(2.f*(x),-32)
#define HIST_SHORT(x) known_cub(x,-16)
#define FULL_OFF -33
#define SHORT_OFF -17
#define FULL_FUTURE 0
#define SHORT_FUTURE 0
#else
#define HIST_FULL(x) cub(2.f*(x))
#define HIST_SHORT(x) cub(x)
#define FULL_OFF (full.delta-1)
#define SHORT_OFF (half.delta-1)
#define FULL_FUTURE (full.delta>=-1)
#define SHORT_FUTURE (half.delta>=-1)
#endif
INLINE float mix4(coeffs q,float a,float b,float c,float d) {
    float m=q.w*a+q.x*b;m+=q.y*c;m+=q.z*d;return m*q.f+b;
}
INLINE unsigned index_at(unsigned head,int offset,unsigned cap){
    int i=(int)head+offset;return i<0?(unsigned)(i+(int)cap):(unsigned)i;
}
INLINE duo read_pair(const duo *ring,unsigned h,unsigned cap,coeffs q,int off,int future) {
    const duo *p=ring+index_at(h,off,cap);
    duo a=p[0],b=p[1],c=p[2],d=p[3],zero={0,0};
    if(future){if(off+3>0)d=zero;if(off+2>0)c=zero;if(off+1>0)b=zero;}
    duo out={mix4(q,a.l,b.l,c.l,d.l),mix4(q,a.r,b.r,c.r,d.r)};return out;
}
INLINE float read_one(const float *ring,unsigned h,unsigned cap,coeffs q,int off,int future) {
    const float *p=ring+index_at(h,off,cap);
    return mix4(q,p[0],future&&off+1>0?0:p[1],future&&off+2>0?0:p[2],future&&off+3>0?0:p[3]);
}
INLINE void pair_in(duo *ring,unsigned cap,unsigned head,duo x){ring[head]=x;if(head<3)ring[cap+head]=x;}
void render(shared_state *restrict s,audio_io *restrict io,unsigned frames) {
    unsigned n=s->next[K],head=n%35,small=n%19;
    float delay=s->slew_delay[K],feedback=s->slew_feedback[K],wet=s->wet_half,gain=0;
    float wet_in=C1*s->wet_target;
    coeffs full=HIST_FULL(delay),half=HIST_SHORT(delay);
    SYNC();s->phase[K]=1;SYNC();
#ifndef HOST_MATH
    while(s->phase[1-K]<1){SYNC();}
#endif
    for(unsigned j=0;j<frames;++j){
        wet=wet_in+C2*wet;gain=C1+C2*gain;
        coeffs query=cub(K?wet:wet*2.f);unsigned t=242550+j;
        unsigned needed=(unsigned)((int)t+query.delta+3);
        while(n<needed) {
#ifdef IDEAL_DRY
            duo dry=io->exact_old[n];
#else
            float reconstructed=dry_get(&s->hist,&s->lookup[K],n);
            duo dry={reconstructed,reconstructed};
#endif
            float nd=EARLY_DELAY+C2*delay;
            feedback=EARLY_FB+C2*feedback;
            if(nd!=delay){delay=nd;full=HIST_FULL(delay);half=HIST_SHORT(delay);}
#if K==0
            duo ins={dry.l+s->ll.prev.l*feedback,dry.r+s->ll.prev.r*feedback};
            pair_in(s->ll.ring,35,head,ins);
            s->ll.prev=read_pair(s->ll.ring,head,35,full,FULL_OFF,FULL_FUTURE);
#else
            float ins=dry.r+s->rr.a*feedback;s->rr.right[head]=ins;if(head<3)s->rr.right[35+head]=ins;
            s->rr.a=read_one(s->rr.right,head,35,full,FULL_OFF,FULL_FUTURE);
            duo v={dry.r+s->rr.b*feedback,s->rr.a+s->rr.c*feedback};
            pair_in(s->rr.short_ring,19,small,v);
            duo q=read_pair(s->rr.short_ring,small,19,half,SHORT_OFF,SHORT_FUTURE);
            s->rr.b=q.l;s->rr.c=q.r;
            small=small==18?0:small+1;
#endif
            head=head==34?0:head+1;++n;
        }
        /* n is now query.base+3, so the four requested historical writes
           are n-4..n-1. Taking the wet interpolation late needs no operands
           from the preceding sample. */
        float wet_gain=gain*gain;
#if K==0
        duo q=read_pair(s->ll.ring,head,35,query,-4,0);
        io->out[j].l=q.l*wet_gain+io->dry_live[j].l*(1.f-wet_gain);
#else
        duo q=read_pair(s->rr.short_ring,small,19,query,-4,0);
        io->out[j].r=(q.r+q.l)*wet_gain+io->dry_live[j].r*(1.f-wet_gain);
#endif
    }
    s->next[K]=n;s->slew_delay[K]=delay;s->slew_feedback[K]=feedback;
    SYNC();s->phase[K]=2;SYNC();
#ifndef HOST_MATH
    while(s->phase[1-K]<2){SYNC();}
#endif
}
