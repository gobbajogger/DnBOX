from pathlib import Path
import datetime,gzip,hashlib,io,json,subprocess,tarfile
base=Path(__file__).resolve().parents[2];here=base/'native/dual';proof=here/'repeated'
files={}
def bind(path,data):
    assert path not in files,path
    files[path]=data
def take(name,p):
    bind(name,p.read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def same(p,q):assert p.read_bytes()==q.read_bytes(),(p,q)
for filename in ['README.md','replay.sh','capture_full.py','compact.py','retained.h','shared.h','seed.cpp','verify_ports.py','worker.c','dual-run.rs','layout.c','run.py','downstream.py','package.py']:
    take(filename,here/filename)
for p in (here/'source').glob('*'):take('source/'+p.name,p)
for bits in (3,6):
    same(proof/f'layout{bits}.txt',here/f'layout{bits}.txt')
    take(f'layout{bits}.txt',proof/f'layout{bits}.txt')
same(proof/'ports.json',here/'ports.json')
take('ports.json',proof/'ports.json')
for sub,file in [('lean','results.csv'),('lean','scores.json'),('downstream','final.csv')]:
    take(file,proof/sub/file)
for p in sorted((proof/'whole').glob('*.bin')):
    same(p,here/'whole'/p.name)
    take('full-original-and-tap-replays/'+p.name,p)
for p in sorted((proof/'downstream').glob('*.bin')):
    same(p,here/'downstream'/p.name)
    if not p.name.endswith('-mixed.bin'):take('full-native-mix-replays/'+p.name,p)
for p in sorted((proof/'lean').glob('*.raw')):
    same(p,here/'lean'/p.name)
    take('kernels/'+p.name,p)
for p in sorted((proof/'lean').glob('*/*')):
    if p.name=='io.bin':continue
    if not p.is_file():continue
    k=p.parent.name+'/'+p.name
    same(p,here/'lean'/k)
    take('target/'+k,p)
inputs=[]
for d,g in [('native/strict/flash-render','feedback-*.bin'),('native/strict/prewarm-clean','source-*.bin'),('native/strict/prewarm-clean','capture.cpp'),('native/strict/flash-render','measured.hpp'),('native/periodic','provider.h'),('native/periodic','contract.json'),('native/periodic','?-?.records'),('native/periodic','?-?.wet'),('sj6-work/delay/work/build','factory-build-commands.json'),('sj6-work/delay/work/build/factory-inputs','public-morphs.f32'),('sj6-work/delay/work/build/factory-inputs','compact.bin'),('sj6-work/delay/work/build/commands','preset-commands.bin')]:
    got=list((base/d).glob(g));assert got,(d,g)
    for p in sorted(got):
        checksum=hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
        inputs.append(checksum+'  '+str(p.relative_to(base)))
        if p.parent==base/'native/periodic' and p.suffix in ('.records','.wet','.json','.h'):
            take('periodic/'+p.name,p)
bind('INPUTS.sha256',('\n'.join(inputs)+'\n').encode())
bind('FILES.sha256',(''.join(sha(v)+'  '+k+'\n' for k,v in sorted(files.items()))).encode())
arc=base/'native/publication/dual-core-complete-wet-proof.tar.gz'
with arc.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as gz,tarfile.open(fileobj=gz,mode='w:') as tf:
    for k,v in sorted(files.items()):
        t=tarfile.TarInfo(k);t.mode=0o755 if k=='replay.sh' else 0o644;t.size=len(v);t.mtime=0;tf.addfile(t,io.BytesIO(v))
with tarfile.open(arc,'r:gz') as tf:
    assert tf.getnames()==sorted(files)
    for k,v in files.items():assert tf.extractfile(k).read()==v,k
print(sha(arc.read_bytes()),arc,arc.stat().st_size,len(files))
