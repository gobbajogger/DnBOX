from pathlib import Path
import csv,ctypes,hashlib,json,struct,subprocess,sys
import numpy as np
here=Path(__file__).resolve().parent;base=here.parents[1];tc=base/'native/tools/jieli-linux-toolchains-20260730.1/pi32v2';old=base/'native/dual';cache='--cache' in sys.argv[1:];out=here/('cache' if cache else 'data');out.mkdir(exist_ok=True)
def call(args,**kwargs):return subprocess.run([str(x) for x in args],check=True,**kwargs)
def matrix(a,b):return (a.view('<u4')!=b.view('<u4')).sum(axis=0).tolist()
rows=[]
for mode in (['periodic'] if cache else ['ideal','periodic']):
    bins=[];procs=[]
    for side in ('long','short'):
        name=mode+'-'+side
        common=(['-DCACHE_SOURCE'] if cache else [])+['-DFIXED_HISTORY','-DPHASE_BITS=3']+(['-DIDEAL_DRY'] if mode=='ideal' else [])+(['-DSHORT'] if side=='short' else [])
        obj=out/(name+'.o');raw=out/(name+'.raw');so=out/(name+'.so')
        call([tc/'bin/clang','-target','pi32v2','-mcpu=r3','-mfprev1','-fno-fast-math','-ffp-contract=off','-Oz','-idirafter',tc/'include',*common,'-c',here/'worker.c','-o',obj])
        undefined=subprocess.check_output([tc/'bin/nm','-u',obj]).strip();assert not undefined,undefined
        assert b'RELOCATION RECORDS' not in subprocess.check_output([tc/'bin/objdump','-r',obj])
        call([tc/'bin/objcopy','-O','binary','-j','.text',obj,raw]);bins.append(raw)
        call(['cc','-O2','-fno-fast-math','-ffp-contract=off','-shared','-fPIC','-DHOST_MATH',*common,here/'worker.c','-o',so])
        f=ctypes.CDLL(str(so)).render;f.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_uint];procs.append(f)
    for owner in [1,8]:
        changed=base/f'native/strict/prewarm-clean/source-{owner}.bin';pred=base/f'native/strict/flash-render/feedback-{owner}.bin'
        hist=np.memmap(changed,'<f4','r').reshape(-1,4,5)
        ref=hist[242550:243062]
        dry=np.fromfile(old/f'whole/original-{owner}.bin','<f4').reshape(512,7)
        wet=np.fromfile(base/f'native/periodic/3-{owner}.wet','<f4').reshape(512,4) if mode!='ideal' else ref[:,:,4]
        live=dry[:,:2].copy().tobytes()+bytes(4096+16384)+ref[:,:2,0].copy().tobytes()
        if mode=='ideal':live+=hist[:176400,:2,0].copy().tobytes()
        truth=ref[:,:,0]+ref[:,:,1]*ref[:,:,2]
        for split in [0,256,512]:
            dest=out/f'{mode}-{owner}-{split}';dest.mkdir(exist_ok=True)
            initial=dest/f's{owner}';call([here/('seed-cache' if cache else 'seed'),pred,changed,base/f'native/periodic/3-{owner}.records',mode,'warm',initial,split])
            init=initial.read_bytes();initial.rename(dest/'initial.bin');(dest/'io.bin').write_bytes(live)
            cr=ctypes.create_string_buffer(init,len(init));audio=ctypes.create_string_buffer(live,len(live))
            for f in procs:f(cr,audio,512)
            flags=list(map(int,subprocess.check_output([here/'dual-run',*bins,dest,'512'],text=True).strip().split(',')))
            native=(dest/'native-state-512.bin').read_bytes();assert native==cr.raw
            details=(dest/'native-detail-512.bin').read_bytes();assert details==audio.raw[8192:8192+16384]
            nt,nw=np.frombuffer(details,'<f4').reshape(2,512,4)
            mx=(dest/'native-mix-512.bin').read_bytes();assert mx==audio.raw[4096:8192]
            mix=np.frombuffer(mx,'<f4').reshape(512,2)
            baseline=np.fromfile(old/f'lean/piecewise-{mode}-{owner}-warm/native-mix-512.bin','<f4').reshape(512,2)
            assert not any(matrix(mix,baseline)) and not any(matrix(nt,wet)),(owner,mode,split,matrix(mix,baseline),matrix(nt,wet))
            if mode=='ideal':assert not any(matrix(nw,truth)),(owner,mode,split,matrix(nw,truth))
            rows.append({'mode':mode,'owner':owner,'split':split,'shared_bytes':len(init),'io_bytes':len(live),'ready0':flags[0],'ready1':flags[1],'done0':flags[2],'done1':flags[3],'return0':flags[4],'return1':flags[5],'makespan_us':max(flags[4:6])/5760,'stereo0_ticks':flags[10],'stereo1_ticks':flags[11],'stereo_ready_us':max(flags[10:12])/5760,'old4_source_mismatch':matrix(nt,ref[:,:,4]),'new4_write_mismatch':matrix(nw,truth),'stereo_mix_mismatch':matrix(mix,dry[:,3:5]),'target_host_state_mismatch':0,'target_host_taps_writes_mismatch':0})
            print(mode,owner,split,round(rows[-1]['makespan_us'],3),flush=True)
(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
