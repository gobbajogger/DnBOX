# Delaying part of right feedback replay

The four original delay paths include two long lines, a short right-input fill and a short cascade driven by the current long-right output. Each original live stereo frame mixes the long-left tap on the left, and the fill plus cascade on the right. The long-right tap is still required for the *new* write into the cascade. This study measures the full four-way recurrence and the cost of retaining that write.

## Two-core schedule and timing

Core 0 processes the long cursor. At a fixed split of zero, one half of the current 512-frame block, or the end of that block, it publishes the current right ring, right previous output, source reader and smoothed controls. It continues the long-left branch. Core 1 completes the short/cascade lookup and takes the rest of long-right from that published state. Only core 0 writes the right ring before publication and only core 1 writes it afterward. Both published cursors use actual target `csync` with a shared flag, then rendezvous when the half is complete. Source values and interpolation phases continue from their own causal cursors. The split at 256 is a general mid-block division.

Each of the four historic tap outputs, four new write values and two mixed output samples is recorded for every frame on two real emulated PI32v2 instruction streams in one shared, ideal RAM. Current input reuses independently produced current pre-delay-filter and phaser outputs. The exact positive uses a large original historical stereo provider. When seeded with the bounded 8-bin dry records, neither target worker has a historical audio table. All four historic outputs, all four new current writes and both stereo channels match the original on every frame in both exact-input owners. Every native state and output also matches the independent host compilation. The bounded decoder exactly reproduces the former measured approximation. Every one of its 2,048 historic tap values per owner and all 1,024 current stereo values differ from the original. The complete new-write mismatch counts are 511, 511, 511, 512 on each owner; previous values at frame zero were authentic.

| Provider and factory program | Right divided after 0 frames | Right divided after 256 | Right divided after 512 |
| --- | ---: | ---: | ---: |
| Exact historical input, row 1 edited | 12,324.971 µs | 9,406.277 µs | 10,902.537 µs |
| Exact historical input, row 8 unchanged | 1,089.198 µs | 887.723 µs | 732.139 µs |
| Original 8-bin encoded input, row 1 | 21,477.566 µs | 15,018.379 µs | 16,177.977 µs |
| Original 8-bin encoded input, row 8 | 1,435.885 µs | 1,145.840 µs | 907.815 µs |
| Same source with four cached event scalars, row 1 | 20,430.068 µs | 14,309.663 µs | 14,585.316 µs |
| Same source with four cached event scalars, row 8 | 1,411.788 µs | 1,129.972 µs | 877.540 µs |

The cache moves each event's envelope midpoint, reciprocal duration and two gain terms into its read cursor. All generated samples and strict floating-point values are unchanged. In the zero-prefix schedule both stereo outputs are ready at 7,908.954 µs for the exact edited owner and 12,635.532 µs for the cached encoded owner. These timestamps come from the existing two completed scan cursors. The observer added no guest instructions. Even if the currently inaudible part of long-right work could be deferred, this actual bounded provider still exceeds 11,609.977 µs for the edited 512-frame half. The complete half with the midpoint split exceeds the project limit of 10,909 µs by 3,400.663 µs. The timings use both cores entirely, with prewarmed cursors. They exclude other engines, boot, stock dispatch and IRQ, final downstream effects, and shared-bus stalls. No stock callback or firmware image qualifies from these measurements.

On the target ABI the active handoff construction occupies 1,024 bytes, rising to 1,072 with all three read cursors cached. Adding the actual 460-byte one-checkpoint state and the concurrent 68-byte encoder leaves 1,212 or 1,164 bytes respectively from the selected owner's 2,764-byte allowance. The input/output fixtures include the current raw audio, all observed history writes and the disjoint reference records needed for validation. The isolated working-state figures do not include a general lifetime store for those new writes.

## A currently inaudible state write becomes audible

The actual original full effects graph was executed from its two authentic factory restores, extended to three seconds after the wet-on event. The comparison changed only the 512 nonzero current long-right inputs written to the cascading right delay over the first wet half, feeding zero for that one dependency. All outputs in that half were byte-identical. The long-right output itself remained identical for every subsequent sample.

| Program | First changed final sample after edit | Absolute frame | Changed final right samples / 132,300 | Maximum final right error |
| --- | ---: | ---: | ---: | ---: |
| 1 Dat Bomb Bass, Yo | 13,406 (303.99 ms) | 255,956 | 13,547 | 0.270278 |
| 8 June Oh 06 Sqr | 110,207 (2,499.02 ms) | 352,757 | 22,091 | 0.683185 |

The unchanged program's final left channel also changes after 114,338 samples through downstream processing. The edited program's final left channel remains exact throughout the three measured seconds. These are actual arrival deadlines for the frozen control streams. Different future controls need their own qualification.

The shorter history is already outside the earlier 35/19-slot early-delay guards before the first missing right write returns. The edited short cursor requests past frame 176,411 at current frame 245,518, 2,968 frames after wet-on. The historical delays there are 447.457 and 223.729 samples. The long cursor first crosses at wet+7,016. A continuously valid replay needs the four-second historical control transition in addition to the initial fixed-offset segment. A literal 512-float escrow of the previously computed RR feedback products would take another 2,048 bytes. The measured 32-subblock, 1st/2nd-order lossless widths of only that operand are 1,900/1,937 bytes for the edited row and 1,592/1,547 bytes for the unchanged row. These counts exclude record metadata and future readers. They exceed the 1,164-byte cached-state allowance. Other exact recurrence or bounded reconstruction schemes remain open.

## Reproduction

Use the project PI32v2 compiler, matching fm1_core Rust library and the original inputs listed by the previous dual-core-complete-wet-proof.tar.gz with SHA256 260e3ecb5b80190d9a47c615b40e2adc4769a7ec43932d40ae906cefa1f027e0. The current test uses its seed/checkpoint headers, original full-graph factory build, capture implementation and two source traces. The scored historical and late-edit data, event records and initial 512 samples are unchanged. replay.sh rebuilds the fork experiment within the existing working directory and can reproduce each schedule, future witness and resource count. The native observer downloads no inputs and performs no device operations.
