from pathlib import Path
import subprocess,json,sys
import numpy as np
build,orig,out=map(lambda x:Path(x).resolve(),sys.argv[1:]);out.mkdir(exist_ok=True,parents=True)
def change(s,a,b):
 assert s.count(a)==1,a
 return s.replace(a,b)
h=(orig/'measured.hpp').read_text()
h=change(h,'static const float *override_taps;', 'static bool omit_right;static float captured_longr;\nstatic const float *override_taps;')
h=change(h,'        observe(sp, delayRR,     &delayOutR,  &delayOutRR);','        captured_longr=delayOutR;float silent=0;\n        observe(sp, delayRR,     omit_right?&silent:&delayOutR,  &delayOutRR);')
(out/'measured.hpp').write_text(h)
s=(orig/'capture.cpp').read_text()
s=change(s,'constexpr unsigned end_at = wet_edit + hz / 2;', 'constexpr unsigned end_at = wet_edit + hz * 3;')
s=change(s,'trace_file=x.trace;', 'omit_right=x.inject&&abs>=wet_edit&&abs<wet_edit+512;trace_file=x.trace;')
# The original four-tap override slot is unused by this counterfactual.
s=change(s,'override_taps=x.inject&&abs>=wet_edit&&abs<wet_edit+512?x.taps[abs-wet_edit]:nullptr;', 'override_taps=nullptr;')
start=s.index('        if(strcmp(argv[6],"-"))')
end=s.index('\n',start)
s=s[:start]+'        owners[i]->inject=!strcmp(argv[6],"omit");'+s[end:]
s=change(s,'if(now>=wet_edit&&now<wet_edit+512){float a[7]={full_mix[0],full_mix[1],full_mix[2],full_mix[3],full_mix[4],x.left[frame],x.right[frame]};','if(now>=wet_edit){float a[5]={captured_longr,full_mix[3],full_mix[4],x.left[frame],x.right[frame]};')
(out/'capture.cpp').write_text(s)
cmd=json.loads((build/'factory-build-commands.json').read_text());cc=next(c.copy() for c in cmd if any(v.endswith('/preset_audio.cpp') for v in c))
for flag,path in [('-c',out/'capture.cpp'),('-MF',out/'capture.d'),('-o',out/'capture.o')]:cc[cc.index(flag)+1]=str(path)
subprocess.run(cc,check=True);ld=cmd[-1].copy();ld[ld.index(str(build/'factory-6.o'))]=str(out/'capture.o');ld[ld.index('-o')+1]=str(out/'capture');subprocess.run(ld,check=True)
for mode in ('original','omit'):
 with (out/(mode+'.log')).open('w') as f:
  subprocess.run([out/'capture',build/'factory-inputs/public-morphs.f32',build/'factory-inputs/compact.bin',build/'commands/preset-commands.bin','late',out/mode,mode],check=True,stdout=f)
r={}
for owner in [1,8]:
 a,b=[np.fromfile(out/f'{m}-{owner}.bin','<f4').reshape(132300,5) for m in ('original','omit')]
 mx=a.view('<u4')!=b.view('<u4')
 ca=np.fromfile(orig/f'original-{owner}.bin','<f4').reshape(512,7)
 assert not (a[:512,1:].view('u4')!=ca[:,3:].view('u4')).any()
 assert not mx[:512].any() and not mx[:,0].any() and mx[:,2].any()
 rec={}
 for i,n in enumerate(['current_r_long','mixed_l','mixed_r','final_l','final_r']):
  idx=np.flatnonzero(mx[:,i]);new=(a[:,i]-b[:,i]).astype('f8')
  rec[n]={'first_relative_sample':int(idx[0]) if len(idx) else None,'first_absolute_sample':int(idx[0])+242550 if len(idx) else None,'changed_count':int(len(idx)),'max_abs':float(np.max(np.abs(new)))}
 r[owner]=rec|{'original_nonzero_current_rr_inputs_first512':int(np.count_nonzero(a[:512,0]))}
(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
