#ifndef DUAL_REPLAY_SHARED_H
#define DUAL_REPLAY_SHARED_H
#include "retained.h"
typedef struct {float l,r;} duo;
typedef struct {float left[38],right[38];duo prev;} long_replay;
typedef struct {float right[38];duo short_ring[22];float a,b,c;} short_replay;
typedef struct {
    volatile unsigned phase[2];
    unsigned next[2];
    float slew_delay[2],slew_feedback[2],wet_half,wet_target;
    long_replay ll;
    short_replay rr;
    dry_history hist;
    dry_reader lookup[2];
    volatile unsigned fork_ready;
    unsigned split_at,fork_n,absolute;
    float fork_delay,fork_feedback,fork_wet,previous[4],current_feedback,wet_mix;
    dry_reader fork_reader;
} shared_state;
typedef struct {duo dry_live[512],out[512]; float taps[512][4],writes[512][4]; duo dry_delayin[512],exact_old[];} audio_io;
#endif
