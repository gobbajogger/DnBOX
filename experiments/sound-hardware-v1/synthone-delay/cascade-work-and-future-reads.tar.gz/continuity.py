"""Exact lookbacks and a bounded predictor size for the transient RR addition operand."""
from pathlib import Path
import json,sys,zlib
import numpy as np
h=Path(sys.argv[1]);output=Path(sys.argv[2])
rows={}
for owner in (1,8):
 a=np.memmap(h/f'source-{owner}.bin','<f4',mode='r').reshape(-1,4,5)
 indices=np.arange(242550,len(a)); rr={}
 for stream in (0,2):
    # Original cubic needs the four words ending at base+2.
    nexts=indices+np.floor(-a[indices,stream,3]*np.float32(44100)).astype('i8')+3
    cross={}
    for point in (176400,242550):
        hits=np.flatnonzero(nexts>point)
        if len(hits):
            j=int(hits[0]);t=int(nexts[j])-1
            cross[point]={'relative_wet_frame':j,'absolute_output':int(indices[j]),'newest_needed_old_frame':t,
                         'needed_old_full_delay_samples':float(a[t,0,3]*np.float32(44100)),
                         'needed_old_short_delay_samples':float(a[t,2,3]*np.float32(44100))}
        else:cross[point]=None
    rr['current_long' if stream==0 else 'current_short']=cross
 sl=a[242550:243062,3];v=(sl[:,1]*sl[:,2]).astype('<f4')
 x=v.view('u4').astype('i8');ordered=np.where(x>>31,x^0xffffffff,x^0x80000000)
 r={}
 for order in (1,2):
    diff=np.diff(ordered,n=order);zigzag=(diff<<1)^(diff>>63)
    # Six bits encode each subblock width, covering each possible range 0..33.
    sizes=[len(z)*int(max(z)).bit_length()+6 for z in np.array_split(zigzag,32)]
    r[f'order{order}_bytes']=(sum(sizes)+7)//8+4*order
 rr['exact_rr_prev_times_feedback_512']={'literal_bytes':len(v.tobytes()),'deflate9_bytes':len(zlib.compress(v.tobytes(),9)),**r}
 rows[owner]=rr
output.write_text(json.dumps(rows,indent=2)+'\n')
