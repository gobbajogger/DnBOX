use fm1_core::{Bus,Cpu};
use std::{env,fs};
const STATE:usize=0x6000;
const DATA:usize=0x10000;
struct Memory {data:Vec<u8>,slot:usize,ticks:[u64;2], audible:[u64;2], ready:[u64;2], done:[u64;2], polls:[u64;2]}
impl Bus for Memory {
 fn read8(&mut self,a:u32)->u8 {self.data[a as usize]}
 fn read16(&mut self,a:u32)->u16 {u16::from_le_bytes(self.data[a as usize..a as usize+2].try_into().unwrap())}
 fn read32(&mut self,a:u32)->u32 {
  if a as usize==STATE+(1-self.slot)*4{self.polls[self.slot]+=1;}
  u32::from_le_bytes(self.data[a as usize..a as usize+4].try_into().unwrap())
 }
 fn write8(&mut self,a:u32,v:u8){self.data[a as usize]=v}
 fn write16(&mut self,a:u32,v:u16){self.data[a as usize..a as usize+2].copy_from_slice(&v.to_le_bytes())}
 fn write32(&mut self,a:u32,v:u32){
  if a as usize==STATE+8+4*self.slot {self.audible[self.slot]=self.ticks[self.slot];}
  if v==1 && a as usize==STATE+4*self.slot {self.ready[self.slot]=self.ticks[self.slot];}
  if v==2 && a as usize==STATE+4*self.slot {self.done[self.slot]=self.ticks[self.slot];}
  self.data[a as usize..a as usize+4].copy_from_slice(&v.to_le_bytes());
 }
 fn add_ticks(&mut self,n:u64){self.ticks[self.slot]+=n;}
}
fn main(){
 let args:Vec<String>=env::args().collect();let dir=&args[3];
 let read=|n:&str|fs::read(format!("{dir}/{n}.bin")).unwrap();
 let init=read("initial");let io=read("io");let frames:u32=args[4].parse().unwrap();
 let mut m=Memory{data:vec![0;DATA+io.len()+16],slot:0,ticks:[0;2],audible:[0;2],ready:[0;2],done:[0;2],polls:[0;2]};
 m.data[STATE..STATE+init.len()].copy_from_slice(&init);m.data[DATA..DATA+io.len()].copy_from_slice(&io);
 let mut cpu=[Cpu::new(0x1000),Cpu::new(0x3000)];
 for k in 0..2 {
  let code=fs::read(&args[1+k]).unwrap();let entry=cpu[k].pc as usize;assert!(code.len()<0x2000);
  m.data[entry..entry+code.len()].copy_from_slice(&code);
  cpu[k].sp=if k==0{0xf000}else{0xd000};cpu[k].rets=0xfffe;cpu[k].cost_model=true;
  cpu[k].regs[0]=STATE as u32;cpu[k].regs[1]=DATA as u32;cpu[k].regs[2]=frames;
 }
 while cpu[0].pc!=0xfffe||cpu[1].pc!=0xfffe{
  let k=if cpu[0].pc==0xfffe {1} else if cpu[1].pc==0xfffe||m.ticks[0]<=m.ticks[1]{0}else{1};
  m.slot=k;cpu[k].step(&mut m).unwrap();m.ticks[k]+=1;
  assert!(cpu[k].insn_count<80_000_000,"stuck at pc={:x}, counters={:?}",cpu[k].pc,m.ticks);
 }
 fs::write(format!("{dir}/native-state-{frames}.bin"),&m.data[STATE..STATE+init.len()]).unwrap();
 fs::write(format!("{dir}/native-mix-{frames}.bin"),&m.data[DATA+4096..DATA+8192]).unwrap();
 fs::write(format!("{dir}/native-detail-{frames}.bin"),&m.data[DATA+8192..DATA+8192+16384]).unwrap();
 println!("{},{},{},{},{},{},{},{},{},{},{},{}",m.ready[0],m.ready[1],m.done[0],m.done[1],m.ticks[0],m.ticks[1],m.polls[0],m.polls[1],cpu[0].insn_count,cpu[1].insn_count,m.audible[0],m.audible[1]);
}
