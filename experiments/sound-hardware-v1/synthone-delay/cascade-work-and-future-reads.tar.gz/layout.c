#include "shared.h"
#include "checkpoint_state.h"
struct snapshot {flash_witness_cursor history;float delay,feedback;};
struct combined {struct snapshot one;shared_state active;};
shared_state working;
struct combined total;
struct snapshot one;
