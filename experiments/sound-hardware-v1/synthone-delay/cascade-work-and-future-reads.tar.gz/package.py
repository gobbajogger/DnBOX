from pathlib import Path
import gzip,hashlib,io,json,tarfile
import numpy as np
here=Path(__file__).resolve().parent;base=here.parents[1]
files={}
def bind(n,b):
 assert n not in files,n
 files[n]=b
def take(n,p):bind(n,p.read_bytes())
def digest(b):return hashlib.sha256(b).hexdigest()
for n in ('README.md','worker.c','shared.h','seed.cpp','retained.h','dual-run.rs','score.py','future.py','continuity.py','layout.c','package.py','replay.sh','score.log','cache.log','layout-active.txt','layout-cache.txt','continuity.json'):
 take(n,here/n)
for variant in ('data','cache'):
 d=here/variant;take(variant+'/results.json',d/'results.json')
 for p in sorted(d.glob('*.raw')):take(variant+'/kernels/'+p.name,p)
 for p in sorted(d.glob('*/*.bin')):
    if p.name=='io.bin':continue
    take(variant+'/trials/'+p.parent.name+'/'+p.name,p)
take('future/result.json',here/'future/result.json')
for n in ('original','omit'):take('future/'+n+'.log',here/'future'/(n+'.log'))
shas=[]
for owner in (1,8):
 filespec=[here/'future'/f'{n}-{owner}.bin' for n in ('original','omit')];a,b=[np.fromfile(p,'<f4').reshape(132300,5) for p in filespec]
 for p in filespec:shas.append(hashlib.file_digest(p.open('rb'),'sha256').hexdigest()+'  future/'+p.name)
 idx=np.flatnonzero(np.any(a.view('u4')!=b.view('u4'),axis=1));w=int(idx[0]);model=[0,w-2,w+2,int(idx[len(idx)//2]),int(idx[-1])-3]
 for q,z in enumerate((a,b)):
    for pos in model:bind(f'future/samples-{owner}-{q}-{pos}.f32',z[pos:pos+4].tobytes())
bind('future/FULL.sha256',('\n'.join(shas)+'\n').encode())
bind('FILES.sha256',(''.join(digest(b)+'  '+n+'\n' for n,b in sorted(files.items()))).encode())
path=base/'native/publication/forked-right-cascade-deadline.tar.gz'
with path.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as gz,tarfile.open(fileobj=gz,mode='w:') as tar:
 for n,b in sorted(files.items()):
  ti=tarfile.TarInfo(n);ti.size=len(b);ti.mode=0o755 if n=='replay.sh' else 0o644
  tar.addfile(ti,io.BytesIO(b))
with tarfile.open(path,'r:gz') as tar:
 assert tar.getnames()==sorted(files)
 for n,b in files.items():assert tar.extractfile(n).read()==b,n
print(path,digest(path.read_bytes()),path.stat().st_size,len(files))
