#!/bin/sh
set -eu
if [ "$#" -ne 2 ]; then echo "usage: replay.sh RUSTC FM1_CORE_RLIB" >&2; exit 2; fi
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
root=$(CDPATH= cd -- "$here/../.." && pwd)
tc="$root/native/tools/jieli-linux-toolchains-20260730.1/pi32v2"
"$1" --edition=2021 -C opt-level=2 -C lto=fat -C embed-bitcode=yes -C codegen-units=1 -L "$(dirname "$2")" --extern "fm1_core=$2" "$here/dual-run.rs" -o "$here/dual-run"
for type in regular cache; do
    flags=; target=seed; scoreopt=
    if [ "$type" = cache ]; then flags=-DCACHE_SOURCE;target=seed-cache;scoreopt=--cache;fi
    c++ $flags -DPHASE_BITS=3 -O2 -std=c++17 -ffp-contract=off -fno-fast-math -I"$root/native/dual/source" "$here/seed.cpp" -o "$here/$target"
    OPENBLAS_NUM_THREADS=1 python3 "$here/score.py" $scoreopt
    "$tc/bin/clang" -target pi32v2 -mcpu=r3 -mfprev1 -Oz $flags -idirafter "$tc/include" -I"$root/native/dual/source" -c "$here/layout.c" -o "$here/layout-$type.o"
    "$tc/bin/nm" -S --radix=d "$here/layout-$type.o" > "$here/layout-$type.txt"
done
OPENBLAS_NUM_THREADS=1 python3 "$here/future.py" "$root/sj6-work/delay/work/build" "$root/native/dual/whole" "$here/future"
OPENBLAS_NUM_THREADS=1 python3 "$here/continuity.py" "$root/native/strict/prewarm-clean" "$here/continuity.json"
