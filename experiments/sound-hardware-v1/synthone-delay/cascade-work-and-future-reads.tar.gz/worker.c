#include "shared.h"
#define INLINE static inline __attribute__((always_inline))
#ifdef SHORT
#define K 1
#else
#define K 0
#endif
#ifdef HOST_MATH
#define SYNC() ((void)0)
#else
#define SYNC() __asm__ volatile ("csync":::"memory")
#endif
#define C2 0x1.ffeb66p-1f
#define C1 0x1.49a0p-13f
#define EARLY_FB 0x1.cd799ap-14f
#define EARLY_DELAY 0x1.e9d920p-25f
typedef struct {float f,w,x,y,z;int delta;} coeffs;
INLINE coeffs cub(float delay) {
    float f=delay * -44100.f;
    int d=(int)f;f-=(float)d;if(f<0){--d;f+=1.f;}
    float z=(f*f-1.f)/6.f,y=(f+1.f)*.5f,x=3.f*z;
    coeffs w={f,(y-1.f)-z,x-f,y-x,z,d};
    return w;
}
INLINE coeffs known_cub(float d,int offset) {
    float f=d*(-44100.f)-(float)offset;
    float z=(f*f-1.f)/6.f,y=(f+1.f)*.5f,x=3.f*z;
    coeffs w={f,(y-1.f)-z,x-f,y-x,z,offset};return w;
}
#ifdef FIXED_HISTORY
#define HIST_FULL(x) known_cub(2.f*(x),-32)
#define HIST_SHORT(x) known_cub(x,-16)
#define FULL_OFF -33
#define SHORT_OFF -17
#define FULL_FUTURE 0
#define SHORT_FUTURE 0
#else
#define HIST_FULL(x) cub(2.f*(x))
#define HIST_SHORT(x) cub(x)
#define FULL_OFF (full.delta-1)
#define SHORT_OFF (half.delta-1)
#define FULL_FUTURE (full.delta>=-1)
#define SHORT_FUTURE (half.delta>=-1)
#endif
INLINE float mix4(coeffs q,float a,float b,float c,float d) {
    float m=q.w*a+q.x*b;m+=q.y*c;m+=q.z*d;return m*q.f+b;
}
INLINE unsigned index_at(unsigned head,int offset,unsigned cap){
    int i=(int)head+offset;return i<0?(unsigned)(i+(int)cap):(unsigned)i;
}
INLINE duo read_pair(const duo *ring,unsigned h,unsigned cap,coeffs q,int off,int future) {
    const duo *p=ring+index_at(h,off,cap);
    duo a=p[0],b=p[1],c=p[2],d=p[3],zero={0,0};
    if(future){if(off+3>0)d=zero;if(off+2>0)c=zero;if(off+1>0)b=zero;}
    duo out={mix4(q,a.l,b.l,c.l,d.l),mix4(q,a.r,b.r,c.r,d.r)};return out;
}
INLINE float read_one(const float *ring,unsigned h,unsigned cap,coeffs q,int off,int future) {
    const float *p=ring+index_at(h,off,cap);
    return mix4(q,p[0],future&&off+1>0?0:p[1],future&&off+2>0?0:p[2],future&&off+3>0?0:p[3]);
}
INLINE void pair_in(duo *ring,unsigned cap,unsigned head,duo x){ring[head]=x;if(head<3)ring[cap+head]=x;}
INLINE void write_ring(float *r,unsigned size,unsigned head,float v){r[head]=v;if(head<3)r[size+head]=v;}
INLINE float source(shared_state *s,audio_io *io,dry_reader *reader,unsigned n,int right){
#ifdef IDEAL_DRY
    return right?io->exact_old[n].r:io->exact_old[n].l;
#else
    return dry_get(&s->hist,reader,n);
#endif
}
INLINE int next_head(unsigned n,int len){return n+1==(unsigned)len?0:(int)n+1;}
INLINE float mono_feedback(float *ring,unsigned head,float dry,float old,float fb,coeffs curve){
    write_ring(ring,35,head,dry+old*fb);
    return read_one(ring,head,35,curve,FULL_OFF,FULL_FUTURE);
}
#if K==0
INLINE void give_right(shared_state *s,unsigned n,float delay,float fb,float wet,float right){
    s->fork_n=n;s->fork_delay=delay;s->fork_feedback=fb;s->fork_wet=wet;volatile dry_reader *saved=&s->fork_reader;
    saved->start=s->lookup[0].start;saved->end=s->lookup[0].end;saved->step=s->lookup[0].step;saved->index=s->lookup[0].index;
#ifdef CACHE_SOURCE
    saved->midpoint=s->lookup[0].midpoint;saved->scale=s->lookup[0].scale;
    saved->level0=s->lookup[0].level0;saved->level_delta=s->lookup[0].level_delta;
#endif
    s->ll.prev.r=right;
    SYNC();s->fork_ready=1;SYNC();
}
#endif
void render(shared_state *restrict s,audio_io *restrict io,unsigned frames){
    unsigned n=s->next[K],head=n%35,small=n%19,cut=s->split_at<frames?s->split_at:frames;
    float delay=s->slew_delay[K],fb=s->slew_feedback[K],wet=s->wet_half,gain=s->wet_mix;
    unsigned first=s->absolute;
    float wet_in=C1*s->wet_target;
    coeffs hist=HIST_FULL(delay),short_hist=HIST_SHORT(delay);
#if K==0
    float left=s->ll.prev.l,right=s->ll.prev.r,last=s->previous[0];
#endif
    SYNC();s->phase[K]=1;SYNC();
#ifndef HOST_MATH
    while(s->phase[1-K]<1){SYNC();}
#endif
    for(unsigned j=0;j<frames;++j){
#if K==0
        if(j==cut)give_right(s,n,delay,fb,wet,right);
#endif
        wet=wet_in+C2*wet;gain=C1+C2*gain;
        coeffs query=cub(K?wet:2.f*wet);
        unsigned needed=(unsigned)((int)(first+j)+query.delta+3);
        while(n<needed){
            float nd=EARLY_DELAY+C2*delay;fb=EARLY_FB+C2*fb;
            if(nd!=delay){delay=nd;hist=HIST_FULL(delay);short_hist=HIST_SHORT(delay);}
#if K==0
            float mono=source(s,io,&s->lookup[0],n,0);
            left=mono_feedback(s->ll.left,head,mono,left,fb,hist);
            if(j<cut){
#ifdef IDEAL_DRY
                mono=io->exact_old[n].r;
#endif
                right=mono_feedback(s->ll.right,head,mono,right,fb,hist);
            }
#else
            float d=source(s,io,&s->lookup[1],n,1);
            s->rr.a=mono_feedback(s->rr.right,head,d,s->rr.a,fb,hist);
            duo v={d+s->rr.b*fb,s->rr.a+s->rr.c*fb};
            pair_in(s->rr.short_ring,19,small,v);
            duo q=read_pair(s->rr.short_ring,small,19,short_hist,SHORT_OFF,SHORT_FUTURE);
            s->rr.b=q.l;s->rr.c=q.r;small=next_head(small,19);
#endif
            ++n;head=next_head(head,35);
        }
        float g=gain*gain;
#if K==0
        float t=read_one(s->ll.left,head,35,query,-4,0);
        io->taps[j][0]=t;
        if(j<cut)io->taps[j][1]=read_one(s->ll.right,head,35,query,-4,0);
        io->out[j].l=t*g+io->dry_live[j].l*(1.f-g);
        io->writes[j][0]=io->dry_delayin[j].l+last*s->current_feedback;last=t;
#else
        duo q=read_pair(s->rr.short_ring,small,19,query,-4,0);
        io->taps[j][2]=q.l;io->taps[j][3]=q.r;
        io->out[j].r=(q.r+q.l)*g+io->dry_live[j].r*(1.f-g);
#endif
    }
    s->next[K]=n;s->slew_delay[K]=delay;s->slew_feedback[K]=fb;
#if K==0
    if(cut==frames)give_right(s,n,delay,fb,wet,right);
    s->ll.prev.l=left;s->previous[0]=last;
#else
#ifndef HOST_MATH
    while(!s->fork_ready){SYNC();}
#endif
    unsigned rn=s->fork_n,rh=rn%35;float rd=s->fork_delay,rf=s->fork_feedback,rw=s->fork_wet,rr=s->ll.prev.r;
    coeffs rcurve=HIST_FULL(rd);
    for(unsigned j=cut;j<frames;++j){
        rw=wet_in+C2*rw;coeffs query=cub(2.f*rw);
        unsigned needed=(unsigned)((int)(first+j)+query.delta+3);
        while(rn<needed){
            float nd=EARLY_DELAY+C2*rd;rf=EARLY_FB+C2*rf;
            if(nd!=rd){rd=nd;rcurve=HIST_FULL(rd);}
            rr=mono_feedback(s->ll.right,rh,source(s,io,&s->fork_reader,rn,1),rr,rf,rcurve);
            ++rn;rh=next_head(rh,35);
        }
        io->taps[j][1]=read_one(s->ll.right,rh,35,query,-4,0);
    }
    s->ll.prev.r=rr;
    float last_right=s->previous[1],last_fill=s->previous[2],last_rr=s->previous[3],f=s->current_feedback;
    for(unsigned j=0;j<frames;++j){
        float r=io->taps[j][1],fill=io->taps[j][2],h=io->taps[j][3],dry=io->dry_delayin[j].r;
        io->writes[j][1]=dry+last_right*f;io->writes[j][2]=dry+last_fill*f;io->writes[j][3]=r+last_rr*f;
        last_right=r;last_fill=fill;last_rr=h;
    }
    s->wet_half=wet;s->wet_mix=gain;s->absolute=first+frames;
    s->previous[1]=last_right;s->previous[2]=last_fill;s->previous[3]=last_rr;
#endif
    SYNC();s->phase[K]=2;SYNC();
#ifndef HOST_MATH
    while(s->phase[1-K]<2){SYNC();}
#endif
}
