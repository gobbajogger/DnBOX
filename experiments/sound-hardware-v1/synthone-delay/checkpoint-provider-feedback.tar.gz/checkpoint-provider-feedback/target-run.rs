use fm1_core::{Bus,Cpu};
use std::{env,fs};
struct Memory { bytes: Vec<u8>, ticks: u64 }
impl Bus for Memory {
    fn read8(&mut self,a:u32)->u8 {self.bytes[a as usize]}
    fn read16(&mut self,a:u32)->u16 {u16::from_le_bytes(self.bytes[a as usize..a as usize+2].try_into().unwrap())}
    fn read32(&mut self,a:u32)->u32 {u32::from_le_bytes(self.bytes[a as usize..a as usize+4].try_into().unwrap())}
    fn write8(&mut self,a:u32,v:u8){self.bytes[a as usize]=v;}
    fn write16(&mut self,a:u32,v:u16){self.bytes[a as usize..a as usize+2].copy_from_slice(&v.to_le_bytes());}
    fn write32(&mut self,a:u32,v:u32){self.bytes[a as usize..a as usize+4].copy_from_slice(&v.to_le_bytes());}
    fn add_ticks(&mut self,n:u64){self.ticks+=n;}
}
fn main() {
    let args:Vec<String>=env::args().collect();
    let read=|name:&str|fs::read(format!("{}/{}.bin",args[2],name)).unwrap();
    let code=fs::read(&args[1]).unwrap();let source=read("source");let init=read("initial");let expect=read("expected");
    let entry:usize=0x1000;let state:usize=0x3000;let start:usize=0x10000;
    let mut mem=Memory{bytes:vec![0;start+source.len()+16],ticks:0};
    mem.bytes[entry..entry+code.len()].copy_from_slice(&code);
    mem.bytes[state..state+init.len()].copy_from_slice(&init);
    mem.bytes[start..start+source.len()].copy_from_slice(&source);
    let mut cpu=Cpu::new(entry as u32);cpu.sp=0xf000;cpu.rets=0xfffe;cpu.cost_model=true;
    cpu.regs[0]=state as u32;cpu.regs[1]=start as u32;cpu.regs[2]=(source.len()/140) as u32;
    while cpu.pc!=0xfffe {
        cpu.step(&mut mem).unwrap();
        mem.ticks+=1;
        assert!(cpu.insn_count<60_000_000);
    }
    let got=&mem.bytes[state..state+expect.len()];
    let incorrect=got.chunks_exact(4).zip(expect.chunks_exact(4)).filter(|(a,b)|a!=b).count();
    println!("{},{},{},{},{},{:.6}",source.len()/140,expect.len()/4,incorrect,cpu.insn_count,mem.ticks,mem.ticks as f64/5760.);
    assert_eq!(incorrect,0);
}
