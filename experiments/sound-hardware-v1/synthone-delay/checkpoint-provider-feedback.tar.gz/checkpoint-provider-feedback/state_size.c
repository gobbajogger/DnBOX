#include "checkpoint_state.h"
char target_cursor[sizeof(flash_witness_cursor)];
char target_owner[sizeof(flash_witness_owner)];
