#!/bin/sh
set -eu
# Inputs: restored source trace, pinned native PI32v2 toolchain, the fm1-core
# release dependency directory built from the timing emulator, and scratch.
trace=$(realpath "$1")
tc=$(realpath "$2")
deps=$(realpath "$3")
mkdir "$4"
out=$(realpath "$4")
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
"$tc/pi32v2/bin/clang" -target pi32v2 -mcpu=r3 -mfprev1 -fno-fast-math -ffp-contract=off -Oz -idirafter "$tc/pi32v2/include" -c "$here/target.c" -o "$out/target.o"
"$tc/pi32v2/bin/objcopy" -O binary -j .text "$out/target.o" "$out/target.bin"
set -- "$deps"/libfm1_core-*.rlib
test "$#" -eq 1
rustc --edition=2021 -C opt-level=2 -C lto=fat -C embed-bitcode=yes -C codegen-units=1 -L "$deps" --extern "fm1_core=$1" "$here/target-run.rs" -o "$out/target-run"
python3 "$here/target-inputs.py" "$trace" "$out/data"
for span in long short; do "$out/target-run" "$out/target.bin" "$out/data/$span"; done
