#include <stdint.h>
/* Optimistic source provider supplies original dry data and precomputed tap
 * indices and interpolation coefficients. Only the actual feedback writes
 * and wet reads are evaluated in the costed target. Relative indices point
 * at bounded per-cursor history. No sample is taken from reference wet output. */
typedef struct {uint16_t dest,at[4],pad;float f,w,x,y,z;} prepared;
typedef struct {float dry[2],fb;prepared tap[4];} source_frame;
typedef struct {float words[109],previous[4];} measured_state;
void render(measured_state *s,const source_frame *source,unsigned n) {
    for(unsigned t=0;t<n;++t) {
        const source_frame *r=source+t;
        for(unsigned p=0;p<4;++p) {
            const prepared *a=r->tap+p;
            float dry=p==0?r->dry[0]:(p==3?s->previous[1]:r->dry[1]);
            s->words[a->dest]=dry+s->previous[p]*r->fb;
            float b=s->words[a->at[1]];
            s->previous[p]=(a->w*s->words[a->at[0]]+a->x*b+a->y*s->words[a->at[2]]+a->z*s->words[a->at[3]])*a->f+b;
        }
    }
}
