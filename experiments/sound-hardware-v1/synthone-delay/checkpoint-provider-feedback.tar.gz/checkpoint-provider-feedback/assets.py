"""Locate full original pre-delay PCM spans in the stock flash images, at every byte alignment."""
import argparse
import hashlib
import json
import struct
import zlib
from pathlib import Path
import numpy as np

def filehash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('renders',type=Path)
    cli.add_argument('out',type=Path)
    cli.add_argument('assets',type=Path,nargs='+')
    args=cli.parse_args()
    candidates={}
    probes={}
    split={}; changes={}
    def include(blob,key,category):
        if not any(blob):
            return
        probes[category]=probes.get(category,0)+1
        head=int.from_bytes(blob[:8],'little')
        candidates.setdefault(head,[]).append((blob,key,category))
    for owner in (1,8):
        def capture(name):
            return np.fromfile(args.renders/f'{name}-{owner}.bin','<f4').reshape(-1,4,5)
        feedback=capture('feedback')
        for source in ('changed','zero'):
            alternate=capture(source)
            delta={}
            for path in range(4):
                x=feedback[:,path,4].view('<u4');y=alternate[:,path,4].view('<u4')
                mask=x!=y
                delta[str(path)]={'total_different':int(mask.sum()),'first':int(np.flatnonzero(mask)[0]) if mask.any() else None,
                                  'different_last_3158':int(mask[-3158:].sum())}
            changes[f'{owner}-{source}']=delta
        for name,field,channels in [('source',0,(0,1)),('wet',4,range(4))]:
            for t in range(0,len(feedback)-127,128):
                for p in channels:
                    block=feedback[t:t+128,p,field]
                    key=f'{owner}-{name}-{t}-{p}'
                    include(block.astype('<f4').tobytes(),key,name+'-float32')
                    q=np.clip(np.rint(block*32768),-32768,32767).astype('<i2')
                    include(q.tobytes(),key,name+'-q15')
        for start in (242550,261442,264088):
            taps=feedback[start:start+512,:,4].copy()
            payload=taps.tobytes()
            split[f'{owner}-{start}']={'raw_f32':len(payload),'zlib9_bytes':len(zlib.compress(payload,9)),
                     'unique_tap_words':int(len(np.unique(taps.view('<u4'))))}
    files=[]
    for p in args.assets:
        blob=p.read_bytes()
        positive_start=137128
        positive=blob[positive_start:positive_start+512]
        assert any(positive)
        lookup=candidates.copy()
        key=int.from_bytes(positive[:8],'little')
        lookup[key]=lookup.get(key,[])+[(positive,'positive','control')]
        matches={}
        offset=0
        while offset+8<=len(blob):
            head=struct.unpack_from('<Q',blob,offset)[0]
            if head in lookup and head!=0:
                for probe,k,cat in lookup[head]:
                    if blob.startswith(probe,offset):
                        matches.setdefault(cat,set()).add(k)
            offset+=1
        # A zero prefix is common in actual ROM. Check each distinct zero-prefixed
        # *nonzero* candidate using the C byte-search primitive.
        if 0 in lookup:
            solved={}
            for probe,k,cat in lookup[0]:
                if probe not in solved:solved[probe]=blob.find(probe)>=0
                if solved[probe]:matches.setdefault(cat,set()).add(k)
        assert matches.get('control')=={'positive'}
        files.append(dict(asset=p.name,path=str(p),bytes=len(blob),sha256=filehash(p),
                    matching_windows={category:len(matches.get(category,())) for category in probes},positive_controls=1))
    receipt=dict(frame_rate=44100,frames_per_owner=264600,block_frames=128,nonzero_window_counts=probes,
                 assets=files,wet_assets=split,live_and_feedback_differences=changes,
                 inputs={p.name:filehash(p) for p in sorted(args.renders.glob('*.bin'))})
    args.out.write_text(json.dumps(receipt,indent=2)+'\n')

if __name__=='__main__':
    main()
