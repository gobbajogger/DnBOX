/* A bounded, online-checkpoint variant for the observed short-to-long scenes.
 * The historical input and control values come from an ideal immutable
 * random-access provider. Original wet results only validate the regenerated
 * output; all saved state comes from this implementation's own recurrence. */
#include "checkpoint_state.h"
#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <vector>
struct Sample {float input,previous,feedback,delay,expected;};
using Frame=std::array<Sample,4>;
struct Query {int base;float f;};
static constexpr unsigned stride=35280,first_wet=242550;
static unsigned long long cpu_time() {
    timespec t{};if(clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t))std::abort();
    return static_cast<unsigned long long>(t.tv_sec)*1000000000+t.tv_nsec;
}
static Query at(unsigned t,float delay) {
    float f=static_cast<float>(delay*(-1.0*44100));
    int base=static_cast<int>(f);f-=float(base);base+=int(t);
    if(base<0||f<0){++f;--base;}
    return {base,f};
}
static float get(const flash_witness_cursor& c,int j,unsigned p,int latest) {
    if(j<0 || j>latest)return 0.f;
    unsigned cap=p<2?35:19;
    assert(latest-j<int(cap));
    return p<2?c.long_writes[p][unsigned(j)%cap]:c.short_writes[p-2][unsigned(j)%cap];
}
static float read(const flash_witness_cursor& c,Query q,unsigned p,int latest) {
    float f=q.f,z=f*f;--z;z*=.1666666667;
    float y=f;++y;float w=(y*=.5);--w;float x=3.f*z;y-=x;w-=z;x-=f;
    float a=get(c,q.base-1,p,latest),b=get(c,q.base,p,latest);
    float d=get(c,q.base+1,p,latest),e=get(c,q.base+2,p,latest);
    return (w*a+x*b+y*d+z*e)*f+b;
}
static void tick(flash_witness_cursor& c,const Frame& frame) {
    unsigned t=c.next;
    for(unsigned p=0;p<4;++p) {
        float input=p==3?c.prev[1]:frame[p].input; // R output has already updated this frame.
        float written=input+c.prev[p]*frame[p].feedback;
        if(p<2)c.long_writes[p][t%35]=written;
        else c.short_writes[p-2][t%19]=written;
        c.prev[p]=read(c,at(t,frame[p].delay),p,int(t));
    }
    ++c.next;
}
static unsigned prepare(const flash_witness_owner& owner,flash_witness_cursor& c,unsigned source_start) {
    unsigned which=std::min(source_start/stride,4u);
    if(which)c=owner.saved[which-1];
    else c=flash_witness_cursor{};
    return c.next;
}
static void run(const std::vector<Frame>& obs,unsigned start,unsigned len,flash_witness_owner& state) {
    unsigned initial[2]={},advanced[2]={},unequal=0,compared=0;
    unsigned first=0,previous=0,max_warm=0;
    auto begin=cpu_time();
    for(unsigned i=0;i<len;++i) {
        unsigned t=start+i;
        for(unsigned k=0;k<2;++k) {
            auto q=at(t,obs[t][k*2].delay);
            assert(q.base>=1);
            if(i==0)initial[k]=prepare(state,state.active[k],unsigned(q.base-1));
            auto& c=state.active[k];
            while(int(c.next)<=q.base+2) {
                assert(c.next<176400);
                tick(c,obs[c.next]);++advanced[k];
            }
            for(unsigned p=2*k;p<2*k+2;++p) {
                float val=read(c,q,p,int(c.next)-1);
                unequal+=std::memcmp(&val,&obs[t][p].expected,4)!=0;
                ++compared;
            }
        }
        if((i+1)%512==0 || i+1==len) {
            unsigned current=advanced[0]+advanced[1];
            if(i<512)first=current;
            else max_warm=std::max(max_warm,current-previous);
            previous=current;
        }
    }
    auto end=cpu_time();
    std::printf("%u,%u,%zu,%u,%u,%u,%u,%u,%u,%u,%u,%llu\n",start,len,sizeof state,initial[0],initial[1],advanced[0],advanced[1],compared,unequal,first,max_warm,end-begin);
    assert(!unequal);
}
int main(int argc,char**argv) {
    assert(argc>=2);
    FILE* f=std::fopen(argv[1],"rb");assert(f);
    std::vector<Frame> obs(264600);
    assert(std::fread(obs.data(),sizeof(Frame),obs.size(),f)==obs.size()&&std::fgetc(f)==EOF);
    std::fclose(f);
    flash_witness_owner frozen{};
    for(unsigned t=0;t<4*stride;++t) {
        auto& live=frozen.active[0];tick(live,obs[t]);
        if(live.next%stride==0)frozen.saved[live.next/stride-1]=live;
    }
    std::puts("start,frames,owner_state_bytes,long_checkpoint,short_checkpoint,long_replay_frames,short_replay_frames,checked_taps,unequal,first_callback_source_frames,max_subsequent_source_frames,host_cpu_ns");
    for(int i=2;i<argc;++i)run(obs,unsigned(std::atoi(argv[i])),512,frozen);
    run(obs,first_wet,22050,frozen);
}
