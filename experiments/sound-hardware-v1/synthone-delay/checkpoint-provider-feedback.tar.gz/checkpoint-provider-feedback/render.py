"""Drive both real restored factory FX graphs and log their four independent delay operations."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

def replace(src, old, new):
    assert src.count(old)==1, old
    return src.replace(old,new)

def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('build',type=Path)
    cli.add_argument('authored',type=Path)
    cli.add_argument('out',type=Path)
    args=cli.parse_args()
    build, authored, out = args.build.resolve(), args.authored.resolve(), args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    orig=build/'factory-inputs/tests/fixtures/synthone-factory/fullfx/source_fx.hpp'
    assert hashlib.sha256(orig.read_bytes()).hexdigest()=='aee3fe78b450b35bfe6d40741d12dcedf02e24388bdf07850bde7b13d8d8d33e'
    fx=orig.read_text()
    fx=replace(fx,'#define nil nullptr','''static FILE *trace_file;
static void observe(sp_data *sp, sp_vdelay *v, float *in, float *out) {
    const float dry=*in, prev=v->prev;
    sp_vdelay_compute(sp,v,in,out);
    const float row[]={dry,prev,v->feedback,v->del,*out};
    if(std::fwrite(row,sizeof(row),1,trace_file)!=1) std::abort();
}
#define nil nullptr''')
    for path in ['delayL','delayR','delayFillIn','delayRR']:
        fx=replace(fx,'sp_vdelay_compute(sp, '+path+',','observe(sp, '+path+',')
    (out/'measured.hpp').write_text(fx)
    fixture=authored.read_text()
    fixture=replace(fixture,'#include "source_fx.hpp"','#include "measured.hpp"')
    fixture=replace(fixture,'FullPair pair;','FullPair pair; FILE *trace=nullptr;')
    fixture=replace(fixture,'x.fx.frame(x.left[frame]','trace_file=x.trace; x.fx.frame(x.left[frame]')
    fixture=replace(fixture,'CHECK(argc==4);','CHECK(argc==6); const bool changed=std::strcmp(argv[4],"changed")==0;')
    fixture=replace(fixture,'const unsigned rows[]={1,8};','''const unsigned rows[]={1,8};
    for(unsigned i=0;i<2;++i) {
        const std::string path=std::string(argv[5])+"-"+std::to_string(rows[i])+".bin";
        owners[i]->trace=std::fopen(path.c_str(),"wb");
        CHECK(owners[i]->trace);
    }''')
    fixture=replace(fixture,'x->edit(delayFeedback,0);','x->edit(delayFeedback,std::strcmp(argv[4],"zero")==0 ? 0.f : .7f);')
    fixture=replace(fixture,'83+int(p)*23','83+int(p)*23+(changed && pos==hz/4 ? 1 : 0)')
    fixture=replace(fixture,'CHECK(x.old_reads>1000','CHECK(std::fclose(x.trace)==0); CHECK(x.old_reads>1000')
    (out/'capture.cpp').write_text(fixture)
    commands=json.loads((build/'factory-build-commands.json').read_text())
    cc=next(c.copy() for c in commands if any(v.endswith('/preset_audio.cpp') for v in c))
    for flag,path in (('-c',out/'capture.cpp'),('-MF',out/'capture.d'),('-o',out/'capture.o')):
        cc[cc.index(flag)+1]=str(path)
    subprocess.run(cc,check=True)
    ld=commands[-1].copy()
    ld[ld.index(str(build/'factory-6.o'))]=str(out/'capture.o')
    ld[ld.index('-o')+1]=str(out/'capture')
    subprocess.run(ld,check=True)
    inputs=build/'factory-inputs'
    for mode in ['zero','feedback','changed']:
        with (out/(mode+'.csv')).open('w') as log:
            subprocess.run([out/'capture',inputs/'public-morphs.f32',inputs/'compact.bin',build/'commands/preset-commands.bin',mode,out/mode],stdout=log,check=True)
    assert (out/'zero.csv').read_bytes()==authored.with_suffix('.csv').read_bytes()

if __name__=='__main__':
    main()
