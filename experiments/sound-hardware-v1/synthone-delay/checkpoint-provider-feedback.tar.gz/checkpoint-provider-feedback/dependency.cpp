/* Given an ideal O(1) immutable provider for the pre-delay signal and every
 * control, regenerate a requested 512-frame four-tap block. Stored witness
 * outputs are used only in the final comparison, never as source data.
 * Rows are independently produced by the original full factory graph. */
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <vector>
struct Observed {float dry, prior, fb, delay, actual;};
using Frame=std::array<Observed,4>;
using Flags=std::array<unsigned char,4>;
using Ends=std::array<int,4>;
using Vals=std::array<float,4>;
static unsigned long long cpu_time() {
    timespec t{};
    if(clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t)) std::abort();
    return static_cast<unsigned long long>(t.tv_sec)*1000000000+t.tv_nsec;
}
struct Query {int base;float fraction;};
static Query query(int frame,float delay) {
    float f=static_cast<float>(delay*(-1.0*44100));
    int pos=static_cast<int>(f);
    f-=float(pos);pos+=frame;
    if(pos<0 || f<0){++f;--pos;}
    return {pos,f};
}
static float interpolate(const std::vector<Vals>& write,float f,int b,int p) {
    auto get=[&](int i){return i<0?0.f:write[i][p];};
    float z=f*f;--z;z*=.1666666667;
    float y=f;++y;float w=(y*=.5);--w;float x=3.f*z;y-=x;w-=z;x-=f;
    return (w*get(b-1)+x*get(b)+y*get(b+1)+z*get(b+2))*f+get(b);
}
static void check(const std::vector<Frame>& obs,int start,int len) {
    const int end=start+len;
    std::vector<Flags> needY(end),needW(end);
    std::vector<Ends> lastUse(end);
    std::vector<int> releases(end+1);
    for(int t=start;t<end;++t)for(int p=0;p<4;++p)needY[t][p]=1;
    unsigned Ys=0,Ws=0,sourceL=0,sourceR=0;
    auto c0=cpu_time();
    for(int t=end-1;t>=0;--t) {
        for(int p=3;p>=0;--p) {
            if(needY[t][p]) {
                ++Ys;
                Query q=query(t,obs[t][p].delay);
                for(int j=q.base-1;j<=q.base+2;++j)if(j>=0 && j<=t) {
                    needW[j][p]=1;
                    lastUse[j][p]=std::max(lastUse[j][p],t);
                }
            }
            if(needW[t][p]) {
                ++Ws;
                if(t && obs[t][p].fb!=0)needY[t-1][p]=1;
                if(p==3)needY[t][1]=1;
            }
        }
        sourceL+=needW[t][0];sourceR+=(needW[t][1]||needW[t][2]);
    }
    auto c1=cpu_time();
    std::vector<Vals> write(end);
    Vals previous{},result{};
    int retained=0,peak=0,ncomp=0,failed=0;
    for(int t=0;t<end;++t) {
        retained-=releases[t];
        for(int p=0;p<4;++p) {
            if(needW[t][p]) {
                float source=p==3?result[1]:obs[t][p].dry;
                write[t][p]=source+previous[p]*obs[t][p].fb;
                ++retained;++releases[lastUse[t][p]+1];
            }
            if(needY[t][p]) {
                const auto q=query(t,obs[t][p].delay);
                result[p]=interpolate(write,q.fraction,q.base,p);
                if(t>=start){++ncomp;failed+=std::memcmp(&result[p],&obs[t][p].actual,4)!=0;}
            }
        }
        peak=std::max(peak,retained);
        previous=result;
    }
    auto c2=cpu_time();
    std::printf("%d,%d,%u,%u,%u,%u,%d,%d,%d,%llu,%llu\n",
        start,len,Ys,Ws,sourceL,sourceR,peak,ncomp,failed,c1-c0,c2-c1);
    if(failed)std::exit(2);
}
int main(int argc,char**argv){
    assert(argc>=2);
    FILE *file=std::fopen(argv[1],"rb");
    assert(file);
    std::vector<Frame> obs(264600);
    assert(std::fread(obs.data(),sizeof(Frame),obs.size(),file)==obs.size());
    assert(std::fgetc(file)==EOF);std::fclose(file);
    std::puts("first_frame,frames,distinct_taps,distinct_writes,source_left,source_right,peak_retained_floats,comparisons,unequal,host_plan_cpu_ns,host_eval_cpu_ns");
    for(int i=2;i<argc;++i)check(obs,std::atoi(argv[i]),512);
}
