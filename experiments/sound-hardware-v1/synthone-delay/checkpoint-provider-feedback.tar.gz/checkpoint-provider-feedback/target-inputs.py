"""Prepare oracle-supplied dry and controls for a standalone optimistic PI32v2 cost measurement."""
from pathlib import Path
import argparse
import numpy as np
import struct
cli=argparse.ArgumentParser(description=__doc__)
cli.add_argument('render',type=Path);cli.add_argument('out',type=Path)
args=cli.parse_args();args.out.mkdir(parents=True,exist_ok=False)
x=np.fromfile(args.render,'<f4').reshape(-1,4,5)
w=x[:,:,0]+x[:,:,1]*x[:,:,2]
offsets=[0,35,70,89];capacity=[35,35,19,19]
def state(t):
    a=np.zeros(113,'<f4')
    if t:
        for p in range(4):
            for j in range(max(0,t-capacity[p]),t):a[offsets[p]+j%capacity[p]]=w[j,p]
            a[109+p]=x[t-1,p,4]
    return a.tobytes()
for name,start,length in [('long',0,22647),('short',105840,27015)]:
    dest=args.out/name;dest.mkdir()
    (dest/'initial.bin').write_bytes(state(start));(dest/'expected.bin').write_bytes(state(start+length))
    frames=x[start:start+length]
    t=np.arange(start,start+length,dtype='<i4')
    dtype=np.dtype([('dest','<u2'),('at','<u2',4),('pad','<u2'),('f','<f4'),('w','<f4'),('x','<f4'),('y','<f4'),('z','<f4')])
    typ=np.dtype([('dry','<f4',2),('fb','<f4'),('tap',dtype,4)])
    prepared=np.zeros(length,dtype=typ)
    prepared['dry']=frames[:,0:2,0];prepared['fb']=frames[:,0,2]
    for p in range(4):
        a=prepared['tap'][:,p];a['dest']=offsets[p]+t%capacity[p]
        f=(frames[:,p,3].astype('f8')*(-44100.)).astype('f4')
        q=f.astype('i4');f-=q.astype('f4');q+=t
        m=(q<0)|(f<0);f[m]+=1;q[m]-=1
        for k in range(4):
            j=q+k-1
            a['at'][:,k]=np.where((j<0)|(j>t),108,offsets[p]+j%capacity[p])
        z=((f*f-np.float32(1)).astype('f8')*.1666666667).astype('f4')
        y=(f+np.float32(1))*np.float32(.5);w0=y-np.float32(1)
        xx=np.float32(3)*z
        a['f']=f;a['w']=w0-z;a['x']=xx-f;a['y']=y-xx;a['z']=z
    assert typ.itemsize==140
    (dest/'source.bin').write_bytes(prepared.tobytes())
