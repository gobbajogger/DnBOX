# Replaying the real source of a historical delay sample

Two independent factory voices play the original six-second, 16-note score at 44.1 kHz. The first program receives a sudden delay-time edit while both parts remain audible. The source reader receives the original immutable tables and static factory-control template. Each record includes the original note voices, held notes, sequencer position, pending notes, random seed, oscillator and smoother history, and exact control changes relative to that template. A second version also restores bitcrusher, panner, phaser and stereo input-filter history.

## A fresh reader for every block

A newly initialized original scheduler decodes each numerical record at an authentic application block boundary. Its memory and callbacks belong to that reader. Its inputs never include reference PCM. Each original program produced 2,088 blocks and 529,200 comparison words per stage.

| Program | Dry-note record size | Pre-delay record size | Unequal dry words | Unequal stereo delay-input words |
| --- | --- | --- | ---: | ---: |
| Dat Bomb Bass, Yo (row 1) | 1,780–1,820 B | 2,004–2,044 B | 0 | 0 |
| June Oh 06 Sqr (row 8) | 1,780–1,836 B | 2,004–2,060 B | 0 | 0 |

Removing oscillator phase, port-smoothing memory, or pre-effect histories separately changed the recovered audio. Clearing the pre-effects alone changed 46,412 and 101,832 stereo words. All source runs reproduced the corresponding complete 21,168,000-byte original observation trace.

## Continuous reads across the actual edit

For each cursor, retain only the record at the last real render boundary before the first request. Supply subsequent authored note events and the original render block divisions. This test takes five measurements per interval and compares every emitted word in all five. Initialization and decoding have separate timing records.

| Program and cursor | Snapshot frame | Requested frames | Actual frames processed | Snapshot bytes | Replay thread CPU on this host |
| --- | ---: | ---: | ---: | ---: | --- |
| Row 1 long | 22,050 | 17,556 | 17,681 | 2,034 | 18.409–32.171 ms |
| Row 1 short | 132,300 | 9,034 | 9,088 | 2,034 | 6.933–10.175 ms |
| Row 8 long | 22,050 | 511 | 640 | 2,046 | 0.828–1.417 ms |
| Row 8 short | 132,300 | 511 | 640 | 2,046 | 1.449–1.719 ms |

All samples matched at their original frames. The row 1 long replay crossed one real stop-and-note-on event. The original and independent instances shared only immutable source material. The measured stored state excludes live reader workspace, the event log, shared factory metadata, delay feedback state, output queues and other active engines. The timings use the host CPU. The 360 MHz feedback-worker results have a separate time base.

## Reproduction

Prepare the recovered factory build and the original two six-second traces using the adjacent prewarm and bounded-periodic packets. Keep the original build commands, assets and both original captures available to the replay. The cold reader uses Python, NumPy and the original C++17 build tooling. The prewarm target requests are in separate changed/requested.json and control/requested.json files. The original capture source, measured prefix and their hashes are included. Existing project sources supply the original headers and unchanged compiled modules. Compare the generated JSON to the three checked reports in results.

    python3 dry/run.py ORIGINAL_TRACE_DIR FACTORY_BUILD ORIGINAL_MEASURED_INCLUDE voices DRY_OUT
    python3 prefix/prepare.py dry voices ORIGINAL_TRACE_DIR FACTORY_BUILD ORIGINAL_MEASURED_INCLUDE PREFIX_OUT
    python3 spans/build.py dry prefix voices PREFIX_OUT ORIGINAL_TRACE_DIR FACTORY_BUILD REQUESTS SPANS_OUT

The original capture.cpp must be in ORIGINAL_TRACE_DIR. Use a fresh output directory for every invocation. The phaser layout comes from the original compiled C source. Retained recurrence memory ends at the first UI-control field. The numerical shape checks are enforced during compilation.
