#pragma once
#include "checkpoint.hpp"
#include <vector>
#include <type_traits>
#include <algorithm>

struct Writer {
    std::vector<unsigned char> bytes;
    template<class T> void put(const T& value) {
        static_assert(std::is_trivially_copyable<T>::value,"numeric representation");
        auto ptr=reinterpret_cast<const unsigned char*>(&value);
        bytes.insert(bytes.end(),ptr,ptr+sizeof(T));
    }
};
struct Reader {
    const std::vector<unsigned char>& bytes;
    size_t at=0;
    template<class T> T get() {
        T value{}; CHECK(at+sizeof(T)<=bytes.size());
        std::memcpy(&value,bytes.data()+at,sizeof value);at+=sizeof value;
        return value;
    }
};
struct FactoryTemplate {
    float values[150],targets[150],half_time[150];
    void load(const FullOracle& s) {
        for(unsigned k=0;k<150;k++) {
            values[k]=s.parameters[k];targets[k]=s.s1p[k].portamentoTarget;
            half_time[k]=s.s1p[k].portamento->htime;
        }
    }
};
static bool different(float a,float b){return std::memcmp(&a,&b,4)!=0;}
struct CoreHistory {
    uint32_t noise;
    int32_t owner,polyphony,previous_held,beat,notes_per_octave;
    float mono_freq,mono_smooth,prev_mode,process_count;
    float phase[2],port_history[3],half_time[3];
    double beat_time;
    static CoreHistory take(const FullOracle& s) {
        CoreHistory g{};
        const auto& q=s.sequencer.original;
        g.noise=s.sp->rand;g.owner=s.playingNoteStatesIndex;g.polyphony=s.polyphony;
        g.previous_held=q.previousHeldNoteNumbersAECount;g.beat=q.mStepCounter.load();g.notes_per_octave=q.mNotesPerOctave.load();
        g.mono_freq=s.monoFrequency;g.mono_smooth=s.monoFrequencySmooth;g.prev_mode=s.previousProcessMonoPolyStatus;g.process_count=s.processSampleCounter;
        g.phase[0]=s.lfo1Phasor->curphs;g.phase[1]=s.lfo2Phasor->curphs;
        const sp_port *ports[]={s.lfo1Port,s.lfo2Port,s.monoFrequencyPort};
        for(int i=0;i<3;i++){g.port_history[i]=ports[i]->yt1;g.half_time[i]=ports[i]->htime;}
        g.beat_time=q.mBeatTime;
        return g;
    }
    void restore(FullOracle& s) const {
        auto& q=s.sequencer.original;s.sp->rand=noise;s.playingNoteStatesIndex=owner;s.polyphony=polyphony;
        q.previousHeldNoteNumbersAECount=previous_held;q.mStepCounter.store(beat);q.mNotesPerOctave.store(notes_per_octave);
        s.monoFrequency=mono_freq;s.monoFrequencySmooth=mono_smooth;s.previousProcessMonoPolyStatus=prev_mode;s.processSampleCounter=process_count;
        s.lfo1Phasor->curphs=phase[0];s.lfo2Phasor->curphs=phase[1];
        sp_port *ports[]={s.lfo1Port,s.lfo2Port,s.monoFrequencyPort};
        for(int i=0;i<3;i++){ports[i]->yt1=port_history[i];ports[i]->htime=half_time[i];ports[i]->prvhtim=-100.f;}
        q.mBeatTime=beat_time;
    }
};
static Writer encode(const FullOracle& s,const FactoryTemplate& shared) {
    Writer w;w.put(CoreHistory::take(s));
    CHECK(s.heldNoteNumbers.count<=128);
    w.put(static_cast<uint8_t>(s.heldNoteNumbers.count));
    for(int i=0;i<s.heldNoteNumbers.count;i++) w.put(s.heldNoteNumbers.values.elements[i]);
    const auto& pending=s.sequencer.original.sequencerLastNotes;
    CHECK(pending.size()<=1024);w.put(static_cast<uint16_t>(pending.size()));
    for(int n:pending)w.put(static_cast<int32_t>(n));
    for(unsigned i=0;i<7;i++){
        const auto&v=i==6?*s.monoNote:(*s.noteStates)[i];
        VoiceHistory voice{};voice.read(v);w.put(voice);
    }
    // Flags 1/2/4/8 distinguish current value, target, time constant and
    // port history. A tick leaves port history equal to its published value.
    for(unsigned i=0;i<150;i++){
        const auto& p=s.s1p[i];
        uint8_t flags=different(s.parameters[i],shared.values[i])?1:0;
        if(p.usePortamento){
            if(different(p.portamentoTarget,shared.targets[i]))flags|=2;
            if(different(p.portamento->htime,shared.half_time[i]))flags|=4;
            if(different(p.portamento->yt1,s.parameters[i]))flags|=8;
        }
        if(!flags)continue;
        w.put(static_cast<uint8_t>(i));w.put(flags);
        if(flags&1)w.put(s.parameters[i]);
        if(flags&2)w.put(p.portamentoTarget);
        if(flags&4)w.put(p.portamento->htime);
        if(flags&8)w.put(p.portamento->yt1);
    }
    w.put(uint8_t(255));return w;
}
static void decode(FullOracle& dst,const FactoryTemplate& base,Reader& in,int omit) {
    dst.initializeNoteStates();auto& q=dst.sequencer.original;q.reset(true);
    in.get<CoreHistory>().restore(dst);
    dst.heldNoteNumbers.clear();unsigned held=in.get<uint8_t>();CHECK(held<=128);
    for(unsigned i=0;i<held;i++)dst.heldNoteNumbers.insert(in.get<s1scheduler::NoteNumber>(),i);
    unsigned count=in.get<uint16_t>();CHECK(count<=1024);
    for(unsigned i=0;i<count;i++)q.sequencerLastNotes.push_back(in.get<int32_t>());
    for(unsigned i=0;i<7;i++) {
        auto& note=(i==6?*dst.monoNote:(*dst.noteStates)[i]);in.get<VoiceHistory>().restore(note,omit==1?1:0);
    }
    for(unsigned i=0;i<150;i++){
        dst.parameters[i]=base.values[i];auto&p=dst.s1p[i];
        if(p.usePortamento){
            p.portamentoTarget=base.targets[i];p.portamento->htime=base.half_time[i];
            p.portamento->yt1=dst.parameters[i];p.portamento->prvhtim=-100.f;
        }
    }
    for(unsigned i=in.get<uint8_t>();i!=255;i=in.get<uint8_t>()){
        CHECK(i<150);uint8_t flags=in.get<uint8_t>();auto&p=dst.s1p[i];
        if(flags&1)dst.parameters[i]=in.get<float>();
        if(flags&2)p.portamentoTarget=in.get<float>();
        if(flags&4)p.portamento->htime=in.get<float>();
        if(p.usePortamento)p.portamento->yt1=dst.parameters[i];
        if(flags&8)p.portamento->yt1=in.get<float>();
    }
    if(omit==2)for(auto&p:dst.s1p)if(p.usePortamento)p.portamento->yt1=0;
    CHECK(in.at==in.bytes.size());
}
