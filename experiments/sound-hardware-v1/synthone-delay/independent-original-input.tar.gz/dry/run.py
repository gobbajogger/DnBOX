import argparse,json,hashlib,subprocess,os,tempfile
from pathlib import Path
ap=argparse.ArgumentParser()
for name in ('capture','build','downstream','voices','out'):ap.add_argument(name,type=Path)
a=ap.parse_args();here=Path(__file__).resolve().parent;b=a.build.resolve();out=a.out.resolve();out.mkdir(exist_ok=False)
src=(a.capture/'capture.cpp').read_text().replace('constexpr unsigned hz', '#include "reader.hpp"\nconstexpr unsigned hz')
src=src.replace('    void block(unsigned start,unsigned n) {','''    FactoryTemplate factory{};
    float expected_left[128]{},expected_right[128]{};
    static constexpr unsigned limit=128;
    unsigned blocks=0,smallest=100000,largest=0,unequal=0,first_frame=~0u;
    void configure(){pair.o.initializeNoteStates();factory.load(pair.o);}
    void block(unsigned start,unsigned n) {
        CHECK(n<=limit);Writer snapshot=encode(pair.o,factory);
        smallest=std::min(smallest,unsigned(snapshot.bytes.size()));largest=std::max(largest,unsigned(snapshot.bytes.size()));
''')
key='        trace_file=x.trace;'
assert src.count(key)==1;src=src.replace(key,'        x.expected_left[frame]=x.left[frame];x.expected_right[frame]=x.right[frame];\n'+key)
key='        pair.o.trace_context=nullptr;';assert src.count(key)==1
src=src.replace(key,key+'''
        FullOracle independent;
        CHECK(independent.init(pair.f.tables,hz,pair.values,150,pair.f.tuning,128));
        CHECK(independent.sp!=pair.o.sp && independent.lfo1Port!=pair.o.lfo1Port);
        Reader reader{snapshot.bytes};
        const char* argument=std::getenv("OMIT_HISTORY");
        decode(independent,factory,reader,argument?std::atoi(argument):0);
        CHECK(independent.monoNote->loPass!=pair.o.monoNote->loPass);
        float historical_left[128]{},historical_right[128]{};
        compact_oracle_window=true;independent.process(n,0,historical_left,historical_right);compact_oracle_window=false;
        blocks++;
        for(unsigned t=0;t<n;t++){
            for(unsigned ch=0;ch<2;ch++){
                const float* current=ch?expected_right:expected_left;
                const float* copy=ch?historical_right:historical_left;
                if(std::memcmp(current+t,copy+t,sizeof(float))){
                    if(unequal==0)first_frame=start+t;
                    unequal++;
                }
            }
        }
''')
key='    for(unsigned pos=0;pos<end_at;)';assert src.count(key)==1
src=src.replace(key,'    for(auto*x:owners)x->configure();\n'+key)
key='        CHECK(std::fclose(x.trace)==0);';assert src.count(key)==1
src=src.replace(key,'        std::fprintf(stderr,"READER %u %u %u %u %u %u\\n",rows[p],x.blocks,x.smallest,x.largest,x.unequal,x.first_frame);\n'+key)
(out/'reader.cpp').write_text(src);commands=json.loads((b/'factory-build-commands.json').read_bytes())
cc=next(l.copy() for l in commands if '-c' in l and l[l.index('-c')+1].endswith('/preset_audio.cpp'))
old=cc[cc.index('-o')+1];cc[cc.index('-o')+1]=str(out/'reader.o');cc[cc.index('-MF')+1]=str(out/'reader.d');cc[cc.index('-c')+1]=str(out/'reader.cpp')
cc[1:1]=['-I'+str(here),'-I'+str(a.voices.resolve()),'-I'+str(a.downstream.resolve())];subprocess.run(cc,check=True)
ld=[str(out/'reader.o') if item==old else item for item in commands[-1]];ld[ld.index('-o')+1]=str(out/'reader');subprocess.run(ld,check=True)
assets=b/'factory-inputs';hashf=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
results={}
for mode in (0,1,2):
    with tempfile.TemporaryDirectory(dir=out) as tmp:
        p=Path(tmp);r=subprocess.run([out/'reader',assets/'public-morphs.f32',assets/'compact.bin',b/'commands/preset-commands.bin','late',p/'source'],env=dict(os.environ,OMIT_HISTORY=str(mode)),capture_output=True,text=True)
        print(mode,r.stderr,flush=True);r.check_returncode()
        rows={}
        for line in r.stderr.splitlines():
            if line.startswith('READER '):
                owner,blocks,minb,maxb,unequal,first=map(int,line.split()[1:])
                f=p/f'source-{owner}.bin';ref=a.capture/f.name
                assert f.stat().st_size==21168000 and hashf(f)==hashf(ref)
                rows[owner]=dict(blocks=blocks,bytes_min=minb,bytes_max=maxb,stereo_words=529200,unequal=unequal,first_frame=None if unequal==0 else first,full_original_trace_sha256=hashf(ref))
        assert len(rows)==2;results[mode]=rows
        (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
