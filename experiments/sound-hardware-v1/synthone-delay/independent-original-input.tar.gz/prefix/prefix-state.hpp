#pragma once
#include "phaser-state-size.hpp"
struct InputHistory {
    float crush_index,crush_frame,crush_value;
    int32_t pan_phase;
    unsigned char phaser[phaser_history_bytes];
    struct Stage {float delay[6],nonlinear[3];} lowpass[2];
    void read(const SourceFx& x) {
        crush_index=x.bitcrushIndex;crush_frame=x.bitcrushSampleIndex;crush_value=x.bitcrushValue;
        pan_phase=x.panOscillator->lphs;std::memcpy(phaser,x.phaser0->faust,sizeof phaser);
        const sp_moogladder *stages[]={x.loPassInputDelayL,x.loPassInputDelayR};
        for(unsigned i=0;i<2;i++){
            std::memcpy(lowpass[i].delay,stages[i]->delay,sizeof lowpass[i].delay);
            std::memcpy(lowpass[i].nonlinear,stages[i]->tanhstg,sizeof lowpass[i].nonlinear);
        }
    }
    void restore(SourceFx& x) const {
        x.bitcrushIndex=crush_index;x.bitcrushSampleIndex=crush_frame;x.bitcrushValue=crush_value;
        x.panOscillator->lphs=pan_phase;std::memcpy(x.phaser0->faust,phaser,sizeof phaser);
        sp_moogladder *stages[]={x.loPassInputDelayL,x.loPassInputDelayR};
        for(unsigned i=0;i<2;i++){
            std::memcpy(stages[i]->delay,lowpass[i].delay,sizeof lowpass[i].delay);
            std::memcpy(stages[i]->tanhstg,lowpass[i].nonlinear,sizeof lowpass[i].nonlinear);
            stages[i]->oldres=-1.f;
        }
    }
};
struct ReadInput {
    SourceFx& processor;
    float* left;
    float* right;
    static void capture(const OracleState& kernel,unsigned phase,unsigned frame,void* context) {
        if(phase!=1)return;
        auto& s=*static_cast<ReadInput*>(context);
        std::memcpy(s.processor.parameters.data(),kernel.parameters,sizeof(float)*150);
        s.processor.input_prefix(s.left[frame],s.left+frame,s.right+frame,kernel.lfo1_0_1,kernel.lfo1_1_0,kernel.lfo2_0_1,kernel.lfo2_1_0);
    }
};
