"""Extend the independently reset note reader with its authentic effects prefix."""
from pathlib import Path
import json,hashlib,sys,subprocess
here=Path(__file__).resolve().parent
reader,voice,capture,build,downstream,out=map(lambda x:Path(x).resolve(),sys.argv[1:])
out.mkdir(exist_ok=False)
orig=(downstream/'measured.hpp').read_text();start=orig.index(' void frame(float input');end=orig.index('        // PING PONG DELAY',start)
prefix=orig[start:end].replace(' void frame(', ' void input_prefix(',1)+'        *outL=delayInputLowPassOutL;*outR=delayInputLowPassOutR;\n }\n'
orig=orig[:start]+' float input_left=0.f,input_right=0.f;\n'+prefix+orig[start:end]+'        input_left=delayInputLowPassOutL;input_right=delayInputLowPassOutR;\n'+orig[end:]
(out/'measured.hpp').write_text(orig)
path=build/'factory-inputs/tests/fixtures/synthone-factory/fullfx/upstream/AudioKit/Core/Soundpipe/modules/phaser.c'
text=path.read_text();end=text.index('} phaser;')+len('} phaser;');start=text.rindex('typedef struct {',0,end)
raw=text[start:end].replace('FAUSTFLOAT','float').replace('} phaser;','} PinnedPhaserLayout;')
(out/'phaser-state-size.hpp').write_text('#pragma once\n#include <cstddef>\n'+raw+'\nconstexpr size_t phaser_history_bytes=offsetof(PinnedPhaserLayout,fHslider0);\nstatic_assert(phaser_history_bytes==136,"source-generated recurrence layout");\n')
driver=(reader/'run.py').read_text();key="(out/'reader.cpp').write_text(src);"
assert driver.count(key)==1
patch="""src=src.replace('#include "reader.hpp"', '#include "reader.hpp"\\n#include "prefix-state.hpp"')
src=src.replace('    FactoryTemplate factory{};', '    SourceFx replay_fx{hz};\\n    FactoryTemplate factory{};')
src=src.replace('        x.expected_left[frame]=x.left[frame];x.expected_right[frame]=x.right[frame];','')
src=src.replace('        const unsigned now = x.absolute + frame;', '        x.expected_left[frame]=x.fx.input_left;x.expected_right[frame]=x.fx.input_right;\\n        const unsigned now = x.absolute + frame;')
src=src.replace('Writer snapshot=encode(pair.o,factory);','InputHistory history{};history.read(fx);Writer state=encode(pair.o,factory);Writer snapshot;snapshot.put(history);snapshot.bytes.insert(snapshot.bytes.end(),state.bytes.begin(),state.bytes.end());')
src=src.replace('        decode(independent,factory,reader,argument?std::atoi(argument):0);','        auto input_state=reader.get<InputHistory>();if(argument && std::atoi(argument)==3)input_state={};input_state.restore(replay_fx);\\n        decode(independent,factory,reader,argument?std::atoi(argument):0);')
src=src.replace('        compact_oracle_window=true;independent.process(', '        ReadInput connection{replay_fx,historical_left,historical_right};independent.trace_fn=ReadInput::capture;independent.trace_context=&connection;\\n        compact_oracle_window=true;independent.process(')
"""
driver=driver.replace(key,patch+'\n'+key)
driver=driver.replace("['-I'+str(here),'-I'+str(a.voices.resolve())","['-I'+str(out.parent),'-I'+str(Path("+repr(str(here))+")),'-I'+str(Path("+repr(str(reader))+")),'-I'+str(a.voices.resolve())")
driver=driver.replace('for mode in (0,1,2):','for mode in (0,1,2,3):')
(out/'qualify.py').write_text(driver)
inputs={str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in [downstream/'measured.hpp',path,reader/'run.py',reader/'reader.hpp',voice/'checkpoint.hpp',capture/'capture.cpp']}
(out/'input-pins.json').write_text(json.dumps(inputs,indent=2)+'\n')
subprocess.run([sys.executable,out/'qualify.py',capture,build,downstream,voice,out/'run'],check=True)
