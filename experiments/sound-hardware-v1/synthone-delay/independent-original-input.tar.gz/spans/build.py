from pathlib import Path
import subprocess,json,hashlib,sys,tempfile,numpy as np
here=Path(__file__).resolve().parent
cold,pre,voices,fx,observed,build,requests,out=map(lambda x: Path(x).resolve(),sys.argv[1:])
out.mkdir(exist_ok=False)
for label,counts in [('changed',[17556,9034]),('control',[511,511])]:
    table=json.loads((requests/label/'requested.json').read_bytes());assert [(r[1],r[2]) for r in table if r[0] in ('512-long','512-short')]==list(zip([22136,132344],counts))
src=(fx/'run/reader.cpp').read_text()
a=src.index('    SourceFx replay_fx{hz};');b=src.index('        absolute = start;',a)
src=src[:a]+(here/'replay.inc').read_text()+'\n    void block(unsigned start,unsigned n){\n        record_start(start);\n'+src[b:]
a=src.index('        FullOracle independent;');b=src.index('\n};',a)
src=src[:a]+'    }'+src[b:]
src=src.replace('x.expected_left[frame]=x.fx.input_left;x.expected_right[frame]=x.fx.input_right;', '')
src=src.replace('for(auto*x:owners)x->configure();','for(unsigned i=0;i<2;i++)owners[i]->configure(rows[i]);')
key='                x.pair.o.stopAllNotes();';assert src.count(key)==1
src=src.replace(key,'                x.log_event(pos,pos<long_edit?42+int(p)*17+int(pos/11025)%5:-1,83+int(p)*23);\n'+key)
a=src.index('        std::fprintf(stderr,"READER ');b=src.index('        CHECK(std::fclose(x.trace)',a)
src=src[:a]+'        owners[p]->replay(rows[p],argv[5]);\n'+src[b:]
(out/'capture.cpp').write_text(src)
commands=json.loads((build/'factory-build-commands.json').read_bytes())
cc=next(c.copy() for c in commands if '-c' in c and c[c.index('-c')+1].endswith('/preset_audio.cpp'));old=cc[cc.index('-o')+1]
for flag,name in [('-c','capture.cpp'),('-o','capture.o'),('-MF','capture.d')]:cc[cc.index(flag)+1]=str(out/name)
cc[1:1]=['-I'+str(x) for x in (fx,pre,cold,voices)];subprocess.run(cc,check=True)
ld=[str(out/'capture.o') if p==old else p for p in commands[-1]];ld[ld.index('-o')+1]=str(out/'capture');subprocess.run(ld,check=True)
hashf=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assets=build/'factory-inputs'
with tempfile.TemporaryDirectory(dir=out) as tmp:
    temp=Path(tmp);r=subprocess.run([out/'capture',assets/'public-morphs.f32',assets/'compact.bin',build/'commands/preset-commands.bin','late',temp/'source'],capture_output=True,text=True)
    (out/'spans.log').write_text(r.stderr);r.check_returncode()
    for owner in (1,8):assert hashf(observed/f'source-{owner}.bin')==hashf(temp/f'source-{owner}.bin')
    records=[]
    for s in r.stderr.splitlines():
        if not s.startswith('SPAN '):continue
        v=list(map(int,s.split()[1:]));owner,k,rep,anchor,first,n,actual,blocks,events,num,setup,cpu,wall=v
        f=temp/f'source-{owner}-{k}-{rep}.f32'
        signal=np.fromfile(f,'<u4').reshape(n,2)
        truth=np.memmap(observed/f'source-{owner}.bin','<u4','r').reshape(-1,4,5)[first:first+n,:2,0]
        mismatch=int(np.count_nonzero(signal!=truth))
        rec=dict(zip('owner reader repeat checkpoint_frame first_requested_frame emitted_frames original_frames_processed original_blocks events_after_checkpoint checkpoint_bytes setup_cpu_ns replay_cpu_ns replay_wall_ns'.split(),v))
        rec.update(unequal_words=mismatch,emitted_sha256=hashf(f))
        records.append(rec)
        if rep==0:print(owner,k,n,actual,num,events,mismatch,cpu/1e6,flush=True)
    assert len(records)==20
    (out/'results.json').write_text(json.dumps(records,indent=2)+'\n')
    assert not any(q['unequal_words'] for q in records)
