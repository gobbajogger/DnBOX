    FactoryTemplate factory{};
    struct NoteEvent {uint32_t frame; int16_t note,velocity;};
    std::vector<NoteEvent> note_events;
    std::array<Writer,2> saved{};
    unsigned first_requested[2]{},length[2]{},anchor[2]{};
    void configure(unsigned row){
        pair.o.initializeNoteStates();factory.load(pair.o);
        first_requested[0]=22136;first_requested[1]=132344;
        length[0]=row==1?17556:511;length[1]=row==1?9034:511;
        for(unsigned k=0;k<2;k++){unsigned x=first_requested[k];anchor[k]=(x/11025)*11025+(x%11025)/128*128;}
    }
    void log_event(unsigned t,int pitch,int velocity){note_events.push_back({t,static_cast<int16_t>(pitch),static_cast<int16_t>(velocity)});}
    void record_start(unsigned start) {
        for(unsigned k=0;k<2;k++)if(start==anchor[k]){
            InputHistory h{};h.read(fx);auto voice=encode(pair.o,factory);saved[k].put(h);
            saved[k].bytes.insert(saved[k].bytes.end(),voice.bytes.begin(),voice.bytes.end());
        }
    }
    static uint64_t now(clockid_t clock){
        timespec t{};CHECK(clock_gettime(clock,&t)==0);return uint64_t(t.tv_sec)*1000000000ull+t.tv_nsec;
    }
    void replay(unsigned row,const std::string& location){
        for(unsigned k=0;k<2;k++)for(unsigned rep=0;rep<5;rep++){
            uint64_t init=now(CLOCK_THREAD_CPUTIME_ID);
            FullOracle rd;SourceFx prefix(hz);
            CHECK(rd.init(pair.f.tables,hz,pair.values,150,pair.f.tuning,128));
            Reader record{saved[k].bytes};record.get<InputHistory>().restore(prefix);decode(rd,factory,record,0);
            const uint64_t setup=now(CLOCK_THREAD_CPUTIME_ID)-init;
            std::vector<float> samples(2*length[k]);
            unsigned stop=first_requested[k]+length[k];unsigned hits=0,count=0,actual=0,blocks=0;
            uint64_t wall_start=now(CLOCK_MONOTONIC),cpu_start=now(CLOCK_THREAD_CPUTIME_ID);
            for(unsigned start=anchor[k];start<stop;){
               if(start!=anchor[k] && start%11025==0) {
                   auto it=std::find_if(note_events.begin(),note_events.end(),[&](const NoteEvent& e){return e.frame==start;});
                   CHECK(it!=note_events.end());rd.stopAllNotes();if(it->note>=0)rd.startNote(it->note,it->velocity);hits++;
               }
               unsigned n=std::min(128u,11025-start%11025);
               float l[128]{},r[128]{};ReadInput source{prefix,l,r};rd.trace_fn=ReadInput::capture;rd.trace_context=&source;
               compact_oracle_window=true;rd.process(n,0,l,r);compact_oracle_window=false;
               unsigned lo=std::max(start,first_requested[k]),hi=std::min(start+n,stop);
               for(unsigned t=lo;t<hi;t++){samples[2*count]=l[t-start];samples[2*count+1]=r[t-start];count++;}
               actual+=n;blocks++;start+=n;
            }
            uint64_t cpu=now(CLOCK_THREAD_CPUTIME_ID)-cpu_start,wall=now(CLOCK_MONOTONIC)-wall_start;
            CHECK(count==length[k]);
            std::string file=location+"-"+std::to_string(row)+"-"+std::to_string(k)+"-"+std::to_string(rep)+".f32";
            FILE*f=std::fopen(file.c_str(),"wb");CHECK(f&&std::fwrite(samples.data(),sizeof(float),samples.size(),f)==samples.size()&&std::fclose(f)==0);
            std::fprintf(stderr,"SPAN %u %u %u %u %u %u %u %u %u %zu %llu %llu %llu\n",row,k,rep,anchor[k],first_requested[k],count,actual,blocks,hits,saved[k].bytes.size(),(unsigned long long)setup,(unsigned long long)cpu,(unsigned long long)wall);
        }
    }
