"""Check exact strict CPU costs for changed/predicted cursor work at the callback boundary."""
import csv,json,subprocess,sys
from pathlib import Path
import tempfile
prior=Path(sys.argv[1]).resolve();here=Path(__file__).resolve().parent
prefix=Path(sys.argv[2]).resolve();target=Path(sys.argv[3]).resolve();image=Path(sys.argv[4]).resolve();out=Path(sys.argv[5]).resolve()
out.mkdir(exist_ok=False)
builder=(prior/'target-inputs.py').read_text()
fixed="for name,start,length in [('long',0,22647),('short',105840,27015)]:"
assert builder.count(fixed)==1
script=out/'target-inputs.py';script.write_text(builder.replace(fixed,"for name,start,length in __import__('json').loads((args.out.parent/'requested.json').read_text()):"))
records=[]
for owner,scenario,trace in [(1,'changed',prefix/'source-1.bin'),(8,'control',prefix/'source-8.bin')]:
 rows=list(csv.reader((here/('stale-'+str(owner)+'.csv')).open()))
 pre=rows[0];start=[int(pre[8]),int(pre[9])]
 # pre[8:10] are the next unread source indices after the exact prewarm.
 assert start==[22136,132344]
 needed={int(row[1]):(int(row[3]),int(row[4])) for row in rows[1:]}
 chosen=[1,235,236,251,252,384,385,512] if owner==1 else [512]
 cases=[('prewarm-quota',0,378)]
 for n in chosen:
  for i,name in enumerate(['long','short']):
   count=needed[n][i]
   if count:cases.append((f'{n}-{name}',start[i],count))
 d=out/scenario;d.mkdir();(d/'requested.json').write_text(json.dumps(cases))
 subprocess.run([sys.executable,script,trace,d/'data'],check=True)
 for label,initial,count in cases:
  line=subprocess.check_output([target,image,d/'data'/label],text=True).strip().split(',')
  nf,words,mismatch,instr,ticks=map(int,line[:5])
  assert nf==count and words==113 and mismatch==0 and ticks==5028*count+1113
  records.append((owner,scenario,label,initial,nf,words,mismatch,instr,ticks,float(line[5])))
with (out/'results.csv').open('w') as f:
 w=csv.writer(f);w.writerow('owner scenario received_prefix_cursor source_begin advanced_source_frames checked_words unequal guest_instructions cost_ticks guest_us'.split());w.writerows(records)
