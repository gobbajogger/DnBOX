# Prewarming independent Synth One feedback and one late control edit

The 2,712-byte checkpoint implementation can spread its work over time when its prediction is correct. For the same two real restored musical programs at feedback 0.7, grant it the exact future wet-on frame and the smoothed tap trajectory if no new time edit arrives. After the existing long-time edit at frame 176,400 (4 s), it has 129 complete 512-frame callbacks before the wet request at 242,550 (5.5 s). Each owner advances at most 378 historical source frames in one callback. Its long and short cursors reach frames 22,136 and 132,344 by frame 242,448, 102 frames before opening. Inputs for these past frames already existed by the time prewarming began.

The strict PI32v2 core measured 330.156 µs for one 378-frame chunk. A callback that splits work between cursors can incur a second small entry/return overhead. The first predicted wet half advances only 511 additional frames in each cursor, measured at 446.254 µs each. The complete two-owner forecast and the unmodified control owner in the counterexample recover every output word. The 2,712 bytes cover four saved short-delay checkpoints and two live replay cursors per owner. The external dry/parameter provider and cost of any other engine remain outside these figures.

## A control edit arriving at the predicted opening

The second test changes one accepted original setter on the first owner only. At precisely frame 242,550, after its original delayOn=1 and delayMix=1 commands and before rendering that frame, it calls delayTime with the documented minimum. The second owner's input stays identical. Previous notes, velocity, delay feedback, all 242,550 original frames of source, feedback state, replay work and the predicted time of opening are identical in both executions.

On the first sample the authentic long tap moves from the predicted 4.998104095 s to 4.997318268 s. The original wet sample changes from 0.14213118 to 0.11465444. All 2,048 authentic outputs (512 frames × four paths) on this owner change. All remain finite. The second owner's entire six-second source/control/output trace is byte-identical, with SHA-256 bc37a46a3df31625d39220034d9e85109363674f9bf103741aed0526d7b19696.

The already-warm implementation still reconstructs every changed word correctly. Its workload changes enough to miss the physical interval.

| First 512-frame callback | Long cursor source frames | Short cursor source frames | Long cursor, µs | Short cursor, µs | Total on one idle core, µs |
| --- | ---: | ---: | ---: | ---: | ---: |
| Accurate forecast | 511 | 511 | 446.254 | 446.254 | 892.507 |
| One extra legal time edit | 17556 | 9034 | 15325.118 | 7886.122 | 23211.241 |

The physical period is 11,609.977 µs. On one idle core the changed owner's accumulated work crosses the 10,909 µs strict budget at its 236th output frame and the physical period at its 252nd. Even with two idle cores dedicated entirely to this single owner, its long path alone crosses the physical period at the 385th frame (11,634.427 µs) and totals 15,325.118 µs. Neighboring prefix controls appear in target-results.csv. The unedited owner, other engines, cache stalls, and the historical dry/input provider consume additional resources in real firmware.

The target receipt executes the same 182-byte PI32v2 feedback arithmetic as the prior checkpoint test using the strict timing emulator's CPU model. The ideal provider supplies all previous dry inputs and precomputed intermediate indices/weights. Each recorded run checks 113 native final state words against the independently captured original. All 20 target runs passed. Stage outputs were compared independently across the first 512 actual frames. A general application with arbitrary live edits needs a different way to make past source positions available by the deadline. This counterexample applies to these dedicated cursors and checkpoint placement. S6 remains FAIL.

## Reproduce

Generate the baseline feedback traces with the earlier checkpoint-provider-feedback report's render.py and the original authored_histories.cpp. Run `python3 render_stale.py FACTORY_BUILD BASELINE_CAPTURE_DIR CHANGED_CAPTURE_DIR` to replay the precise second timeline. The script uses the original comparison sources and the baseline capture's measured.hpp. Compile amortize.cpp with C++17, -O2, -fno-fast-math and -ffp-contract=off. Give it a baseline trace and a probe trace. Passing the baseline twice tests its forecast, and using source-1.bin or source-8.bin tests the new control and the independent control owner. To regenerate target-results.csv, run `python3 target_cases.py PRIOR_CHECKPOINT_PROOF CHANGED_CAPTURE_DIR TARGET_RUN_NATIVE TARGET_KERNEL_BIN NEW_OUTPUT`. The two target executables and matching Rust project/toolchain are detailed in the prior proof.

The prewarm rows record the announce frame, requested wet frame, complete callbacks available, largest assigned source-frame quota, completion frame, starting positions (long/short), ending positions (long/short) and per-cursor advances. Receive rows record prefix length, absolute output frame, retained long and short cursor advances since warm completion, tap words checked, unequal words, and whether that frame's original left tap differs from the forecast. first-edit.json records the full independent stream digests and first-sample observations.
