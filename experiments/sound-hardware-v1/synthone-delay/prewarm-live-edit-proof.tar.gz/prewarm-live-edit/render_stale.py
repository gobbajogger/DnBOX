"""Apply one legal delayTime edit at the wet boundary to owner zero only."""
import argparse,json,subprocess
from pathlib import Path
cli=argparse.ArgumentParser(description=__doc__)
cli.add_argument('build',type=Path);cli.add_argument('existing_capture',type=Path);cli.add_argument('out',type=Path)
a=cli.parse_args();build=a.build.resolve();existing=a.existing_capture.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=False)
s=(existing/'capture.cpp').read_text();needle='if(pos==wet_edit) {x.edit(delayOn,1);x.edit(delayMix,1);}'
assert s.count(needle)==1
s=s.replace(needle,needle+'\n            if(pos==wet_edit && p==0) x.edit(delayTime,minimums[delayTime]);')
needle='CHECK(x.old_reads>1000 && x.nonzero_old_reads>1000 && x.oldest>4*hz && x.peak>.001f);'
assert s.count(needle)==1
s=s.replace(needle,'if(p!=0) '+needle)
s=s.replace('std::sqrt(x.tap_energy/x.old_reads)', '(x.old_reads ? std::sqrt(x.tap_energy/x.old_reads) : 0.0)')
(out/'capture.cpp').write_text(s)
commands=json.loads((build/'factory-build-commands.json').read_text())
cc=next(c.copy() for c in commands if any(v.endswith('/preset_audio.cpp') for v in c))
cc.insert(1,'-I'+str(existing))
for flag,path in (('-c',out/'capture.cpp'),('-MF',out/'capture.d'),('-o',out/'capture.o')):cc[cc.index(flag)+1]=str(path)
subprocess.run(cc,check=True)
ld=commands[-1].copy();ld[ld.index(str(build/'factory-6.o'))]=str(out/'capture.o');ld[ld.index('-o')+1]=str(out/'capture')
subprocess.run(ld,check=True)
inp=build/'factory-inputs'
with (out/'late.csv').open('w') as log:subprocess.run([out/'capture',inp/'public-morphs.f32',inp/'compact.bin',build/'commands/preset-commands.bin','late',out/'source'],stdout=log,check=True)
