/* Reuse the previous bounded exact feedback cursor. A predictor gets the true
 * past controls, original dry data and the future wet-on frame for free. */
#include "checkpoint_core.hpp"
static std::vector<Frame> load(const char *name) {
    std::vector<Frame> obs(264600);FILE* f=std::fopen(name,"rb");assert(f);
    assert(std::fread(obs.data(),sizeof(Frame),obs.size(),f)==obs.size() && std::fgetc(f)==EOF);
    std::fclose(f);return obs;
}
static void receive(const std::vector<Frame>& predicted,const std::vector<Frame>& actual) {
    constexpr unsigned announce=176400,live=242550,period=512;
    assert(!std::memcmp(predicted.data(),actual.data(),sizeof(Frame)*live));
    flash_witness_owner state{};
    for(unsigned t=0;t<4*stride;++t) {
        tick(state.active[0],predicted[t]);
        if(state.active[0].next%stride==0)state.saved[state.active[0].next/stride-1]=state.active[0];
    }
    unsigned want[2],pre[2],start[2],left[2],total=0;
    for(unsigned k=0;k<2;++k) {
        const auto q=at(live,predicted[live][2*k].delay);
        want[k]=unsigned(q.base+3);
        start[k]=prepare(state,state.active[k],unsigned(q.base-1));
        pre[k]=want[k]-start[k];left[k]=pre[k];total+=pre[k];
    }
    const unsigned pre_callbacks=(live-announce)/period,quota=(total+pre_callbacks-1)/pre_callbacks;
    unsigned largest_quota=0,finish_at=0;
    for(unsigned h=0;h<pre_callbacks;++h){
        unsigned budget=quota;
        for(unsigned k=0;k<2;++k) {
            const unsigned use=std::min(budget,left[k]);budget-=use;left[k]-=use;
            for(unsigned i=0;i<use;++i){auto& c=state.active[k];tick(c,predicted[c.next]);}
        }
        largest_quota=std::max(largest_quota,quota-budget);
        if(!left[0]&&!left[1]&&!finish_at)finish_at=announce+(h+1)*period;
    }
    assert(!left[0]&&!left[1]);
    std::printf("prewarm,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u\n",
        announce,live,pre_callbacks,largest_quota,finish_at,start[0],start[1],want[0],want[1],pre[0],pre[1]);
    unsigned total0=0,compared=0,unequal=0;
    for(unsigned t=live;t<live+period;++t) {
        unsigned need[2];
        for(unsigned k=0;k<2;++k) {
            auto q=at(t,actual[t][2*k].delay);auto& c=state.active[k];
            assert(q.base>=1 && c.next<=176400);
            while(int(c.next)<=q.base+2){assert(c.next<176400);tick(c,actual[c.next]);}
            need[k]=c.next-want[k];
            for(unsigned p=2*k;p<2*k+2;++p) {
                float got=read(c,q,p,int(c.next)-1);
                ++compared;unequal+=std::memcmp(&got,&actual[t][p].expected,4)!=0;
            }
        }
        if(!t || need[0]+need[1]!=total0 || t==live) {
            std::printf("receive,%u,%u,%u,%u,%u,%u,%u\n",t-live+1,t,need[0],need[1],compared,unequal,
                std::memcmp(&predicted[t][0].expected,&actual[t][0].expected,4)!=0);
        }
        total0=need[0]+need[1];
    }
    assert(compared==2048 && !unequal);
}
int main(int argc,char**argv) {
    assert(argc==3);auto p=load(argv[1]);auto a=load(argv[2]);receive(p,a);
}
