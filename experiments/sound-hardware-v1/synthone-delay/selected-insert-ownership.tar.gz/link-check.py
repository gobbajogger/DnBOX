from pathlib import Path
import hashlib,json,subprocess,re,sys
here=Path(__file__).resolve().parent;src,tool,out=map(lambda x:Path(x).resolve(),sys.argv[1:]);out.mkdir(exist_ok=False)
cc=tool/'pi32v2/bin/clang';dump=tool/'common/bin/objdump';obj=out/'layout.o'
cmd=[cc,'-target','pi32v2','-mcpu=r3','-mfprev1','-ffreestanding','-fno-common','-Oz','-idirafter',tool/'pi32v2/include','-I'+str(src),'-I'+str(src/'firmware/src'),'-I'+str(src/'experiments/original_synth'),'-I'+str(src/'experiments/wobble'),'-I'+str(src/'build/gen'),'-DX0X_ORIGINAL_SYNTH=1','-c',here/'layout.c','-o',obj]
subprocess.run(cmd,check=True);sym=subprocess.check_output([dump,'-t',obj],text=True);(out/'layout.txt').write_text(sym)
sizes={}
for row in sym.splitlines():
 if '.bss' in row:
    parts=row.split();sizes[parts[-1]]=int(parts[-2],16)
assert sizes['insert_owner']==4252 and sizes['insert_arena']==4096 and sizes['synth_one_active']==956 and sizes['combined_conditional']==6860,sizes
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();boards={}
for board,folder in [('Elite','smk37-elite'),('Pro','smk37')]:
    elf=src/'build'/folder/'x0x.elf';app=elf.with_suffix('.bin');syms=subprocess.check_output([dump,'-t',elf],text=True)
    rows=[l for l in syms.splitlines() if l.split() and l.split()[-1] in ('original_fx','original_bass')]
    assert len(rows)==2 and next(int(r.split()[-2],16) for r in rows if r.endswith('original_fx'))==8504
    boards[board]=dict(app_bytes=app.stat().st_size,app_sha256=h(app),elf_sha256=h(elf),symbols=rows)
res=dict(layout=sizes,compile_command=list(map(str,cmd)),compiler_sha256=h(cc),boards=boards)
(out/'links.json').write_text(json.dumps(res,indent=2)+'\n');print(sizes,boards['Elite']['app_bytes'],boards['Pro']['app_bytes'])
