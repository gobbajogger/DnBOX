from pathlib import Path
import hashlib,os,sys,subprocess,shutil,json,shlex
here=Path(__file__).resolve().parent;src,records,out=map(lambda x:Path(x).resolve(),sys.argv[1:])
out.mkdir(exist_ok=False);work=out/'src';work.mkdir()
for f in ('firmware','tools','experiments','host','assets','tests','reference','docs'):
 if (src/f).is_dir():(work/f).symlink_to(src/f,target_is_directory=True)
(work/'build').mkdir();shutil.copytree(src/'build/gen',work/'build/gen')
compiler=out/'compiler.py'
compiler.write_text('#!'+sys.executable+'\nimport sys,os\nchanged='+repr({'firmware/src/app/engine.c':str(here/'hook.c'),'host/x0x_host.c':str(here/'fixture.c')})+'\nos.execvp("cc",["cc","-I.",*map(lambda x:changed.get(x,x),sys.argv[1:])])\n')
compiler.chmod(0o755)
with (out/'build.log').open('w') as log:
 q=subprocess.run(['sh','host/build_host.sh'],cwd=work,env=dict(os.environ,CC=str(compiler),X0X_HOST_OUT=str(out/'host')),stdout=log,stderr=log)
assert q.returncode==0,(out/'build.log').read_text()[-2000:]
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
results={}
for mode in (0,1):
 pcm=out/f'pcm-{mode}.bin';project=out/f'project-{mode}.bin'
 q=subprocess.run([out/'host',str(mode),pcm,project,records/'1-first.packed',records/'8-first.packed'],cwd=work,capture_output=True,text=True)
 (out/f'run-{mode}.log').write_text(q.stderr);print(mode,q.returncode,q.stderr[-500:],flush=True);q.check_returncode()
 results[mode]=dict(pcm_bytes=pcm.stat().st_size,project_bytes=project.stat().st_size,pcm_sha256=h(pcm),project_sha256=h(project),terminal=q.stderr)
assert results[0]==results[1]
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
