#include "firmware/src/app/engine.c"
#include <string.h>
#include <stdlib.h>
int arena_access(int part,const unsigned char *write,unsigned char *readback,unsigned n){
    if((unsigned)part>=NBASS || original_bass[part].kind!=ORIGINAL_SOUND_SYNTHONE ||
       original_bass[part].status!=ORIGINAL_RUNTIME_OK || original_fx[part].selected ||
       n>sizeof original_fx[part].arena) return 0;
    if(write)memcpy(&original_fx[part].arena,write,n);
    if(readback)memcpy(readback,&original_fx[part].arena,n);
    return 1;
}
int compare_effects(void){
    unsigned tested=0;
    for(unsigned t=0;t<30;t++){
        if(!original_chicago_fx2_compact_supports(t))continue;
        original_chicago_fx2_compact a,b;
        if(!original_chicago_fx2_compact_init(&a)||!original_chicago_fx2_compact_init(&b))return -1;
        original_chicago_fx2_cold_owner x=original_chicago_fx2_compact_owner(&a),y=original_chicago_fx2_compact_owner(&b);
        for(unsigned i=0;i<sizeof b.arena;i++)((unsigned char*)&b.arena)[i]=(unsigned char)(i*67+31+t);
        const original_chicago_fx2_kernel *l=x.select_cold(x.context,t),*r=y.select_cold(y.context,t);
        if(!l||!r)return -2;
        l->begin(l->context);r->begin(r->context);l->reset(l->context);r->reset(r->context);
        l->parameter(l->context,2,93);r->parameter(r->context,2,93);l->parameter(l->context,3,99);r->parameter(r->context,3,99);
        l->tempo(l->context,1270);r->tempo(r->context,1270);
        for(unsigned blk=0;blk<112;blk++){
            int16_t al[128],ar[128],bl[128],br[128];
            for(unsigned i=0;i<128;i++){unsigned j=blk*128+i;al[i]=bl[i]=j<2000?(int16_t)(j*4817+231):0; ar[i]=br[i]=j<2000?(int16_t)(j*1271+790):0;}
            l->process(l->context,al,ar,128);r->process(r->context,bl,br,128);
            if(memcmp(al,bl,sizeof al)||memcmp(ar,br,sizeof ar))return -100-(int)t;
        }
        x.discard(x.context);y.discard(y.context);tested++;
    }
    return (int)tested;
}
