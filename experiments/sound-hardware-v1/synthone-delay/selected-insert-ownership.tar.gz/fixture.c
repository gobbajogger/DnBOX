#define main simulator_main
#include "host/x0x_host.c"
#undef main
extern int arena_access(int,const unsigned char*,unsigned char*,unsigned);
extern int compare_effects(void);
#define REQUIRE(v) do {if(!(v)){fprintf(stderr,"failure line %d: %s\n",__LINE__,#v);exit(2);}}while(0)
static FILE *output;
static unsigned blocks=0,nonzero=0;
static void emit(void){int32_t sound[512];engine_render(sound,256);for(unsigned i=0;i<512;i++)nonzero+=sound[i]!=0;REQUIRE(fwrite(sound,sizeof sound,1,output)==1);blocks++;}
static void select_bank(int p,int bank,int preset){
    REQUIRE(engine_bass_select_preset(p,bank,preset,&proj.sound)==0);
    for(unsigned n=0;n<700 && engine_bass_preset_pending(p);n++)emit();
    REQUIRE(engine_bass_bank(p)==bank && engine_bass_preset_index(p)==preset);
}
static void play_note(int p,int pitch){
    uint32_t g=0,c=0;int arp=0;engine_live_key_state(p,&g,&arp,&c);
    REQUIRE(engine_live_key(p,g,2,pitch,93,0,0));
    for(int j=0;j<8;j++)emit();
    REQUIRE(engine_live_key(p,g,2,pitch,0,0,0));
    for(int j=0;j<36;j++)emit();
}
int main(int argc,char**argv){
    REQUIRE(argc==6);
    int fill=atoi(argv[1]);output=fopen(argv[2],"wb");REQUIRE(output);
    unsigned char payload[2][4096],got[4096];
    for(unsigned p=0;p<2;p++){
        for(unsigned i=0;i<4096;i++)payload[p][i]=(unsigned char)(i*67+p*63+31);
        FILE*f=fopen(argv[4+p],"rb");REQUIRE(f);size_t n=fread(payload[p],1,4096,f);REQUIRE(n>400&&n<4096&&feof(f));fclose(f);
    }
    boot();run_ms(50);
    select_bank(0,ORIGINAL_SOUND_CHICAGO,0);select_bank(1,ORIGINAL_SOUND_CHICAGO,0);
    REQUIRE(!arena_access(-1,0,got,1)&&!arena_access(2,0,got,1));
    for(unsigned p=0;p<2;p++)REQUIRE(!arena_access(p,payload[p],0,4096));
    for(unsigned p=0;p<2;p++){
        REQUIRE(engine_bass_select_preset(p,ORIGINAL_SOUND_SYNTHONE,255,&proj.sound)<0);
        REQUIRE(!arena_access(p,payload[p],0,4096));
        REQUIRE(engine_bass_select_preset(p,ORIGINAL_SOUND_SYNTHONE,0,&proj.sound)==0);
        REQUIRE(!arena_access(p,payload[p],0,4096));
        for(unsigned b=0;b<700 && engine_bass_preset_pending(p);b++)emit();
        REQUIRE(engine_bass_bank(p)==ORIGINAL_SOUND_SYNTHONE);
        REQUIRE(arena_access(p,fill?payload[p]:0,got,4096));
        if(fill)REQUIRE(memcmp(got,payload[p],4096)==0);
        REQUIRE(!arena_access(p,payload[p],0,4097));
        play_note(p,47+p*12);
    }
    for(int p=0;p<2;p++){REQUIRE(arena_access(p,0,got,4096));if(fill)REQUIRE(!memcmp(got,payload[p],4096));}
    for(unsigned p=0;p<2;p++){
        REQUIRE(engine_bass_select_preset(p,ORIGINAL_SOUND_CHICAGO,0,&proj.sound)==0);
        REQUIRE(arena_access(p,0,got,4096));
        for(unsigned b=0;b<700 && engine_bass_preset_pending(p);b++)emit();
        REQUIRE(engine_bass_bank(p)==ORIGINAL_SOUND_CHICAGO);REQUIRE(!arena_access(p,payload[p],0,4096));
        play_note(p,55+p);
        if(!p){REQUIRE(arena_access(1,0,got,4096));if(fill)REQUIRE(!memcmp(got,payload[1],4096));}
        select_bank(p,ORIGINAL_SOUND_MIAMI,0);REQUIRE(!arena_access(p,0,got,1));play_note(p,50+p);
        select_bank(p,ORIGINAL_SOUND_JUNO,0);REQUIRE(!arena_access(p,0,got,1));play_note(p,53+p);
    }
    REQUIRE(fclose(output)==0);
    FILE*f=fopen(argv[3],"wb");REQUIRE(f&&fwrite(&proj,sizeof proj,1,f)==1&&fclose(f)==0);
    int algorithms=compare_effects();fprintf(stderr,"blocks=%u nonzero=%u project=%zu algorithms=%d\n",blocks,nonzero,sizeof proj,algorithms);
    REQUIRE(algorithms==12 && nonzero>0);return 0;
}
