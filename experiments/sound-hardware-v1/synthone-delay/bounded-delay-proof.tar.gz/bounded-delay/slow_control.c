#include "small-history.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>

int main(void) {
    small_history owner[2] = {0};
    double sum[2][4]={0}, norm[2][4]={0};
    /* Every socket gets its own slow signal. Both rings wrap several times. */
    for(int n=0;n<44100*15;++n) {
        for(int p=0;p<2;++p) for(int r=0;r<4;++r) {
            const double hz=2.+4*p+r, scale=.1+.06*(r+1);
            const int lag=r<2 ? 220500 : 110250;
            const double phase=6.283185307179586*hz/44100.;
            const float input=(float)(scale*sin(phase*n));
            const float actual=history_tick(&owner[p],r,(float)lag/44100.f,0.f,input);
            if(n>=44100*6) {
                double ref=scale*sin(phase*(n-lag));
                double error=actual-ref;
                sum[p][r]+=error*error; norm[p][r]+=ref*ref;
            }
        }
    }
    puts("owner,ring,hz,normalized_rms_error");
    for(int p=0;p<2;++p) for(int r=0;r<4;++r) {
        const double error=sqrt(sum[p][r]/norm[p][r]);
        printf("%d,%d,%d,%.9f\n",p,r,2+4*p+r,error);
        assert(error<.04);
    }
}
