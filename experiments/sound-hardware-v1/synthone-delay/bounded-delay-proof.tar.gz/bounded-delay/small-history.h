#ifndef SOUND_SMALL_HISTORY_H
#define SOUND_SMALL_HISTORY_H
#include <stdint.h>

enum { DELAY_HOP = 245, LONG_POINTS = 902, SHORT_POINTS = 452 };
typedef struct {
    int8_t long_bank[2][LONG_POINTS], short_bank[2][SHORT_POINTS];
    float sum[4], previous[4];
    uint16_t phase, next_long, next_short;
} small_history;

static float history_read(const int8_t *points, int capacity, int next, int age)
{
    return points[(next + capacity - 1 - age) % capacity] * (1.0f / 127);
}

/* One chronological write and one read per channel/frame. i=3 completes the frame. */
static float history_tick(small_history *h, int i, float seconds, float feedback, float input)
{
    const int is_long = i < 2;
    int8_t *points = is_long ? h->long_bank[i] : h->short_bank[i-2];
    const int capacity = is_long ? LONG_POINTS : SHORT_POINTS;
    const int next = is_long ? h->next_long : h->next_short;
    h->sum[i] += input + feedback * h->previous[i];

    /* Samples are centered in their capture blocks. The unfinished block provides
       the newest mean for taps too short to reach the previous completed block. */
    const float age = 44100.f * seconds - (h->phase + 123.f);
    float value;
    if (age < 0.f) {
        float a = history_read(points, capacity, next, 0);
        float b = h->sum[i] / (h->phase + 1.f);
        float blend = -age / (123.f + 0.5f * h->phase);
        if (blend > 1.f) blend = 1.f;
        value = a + blend * (b-a);
    } else {
        float offset = age * (1.f / DELAY_HOP);
        int first = (int)offset;
        float fraction = offset - first;
        float a = history_read(points, capacity, next, first);
        float b = history_read(points, capacity, next, first+1);
        value = a + fraction*(b-a);
    }
    h->previous[i] = value;

    if (h->phase == DELAY_HOP-1) {
        float quantized = h->sum[i] * (127.f / DELAY_HOP);
        if (quantized < -127.f) quantized = -127.f;
        if (quantized > 127.f) quantized = 127.f;
        points[next] = (int8_t)(quantized < 0 ? quantized-.5f : quantized+.5f);
        h->sum[i] = 0.f;
        if (i == 3) {
            h->phase = 0;
            h->next_long = (h->next_long+1) % LONG_POINTS;
            h->next_short = (h->next_short+1) % SHORT_POINTS;
        }
    } else if (i == 3) {
        ++h->phase;
    }
    return value;
}
#endif
