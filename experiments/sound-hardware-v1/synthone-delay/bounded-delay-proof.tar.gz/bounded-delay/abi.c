#include "small-history.h"
char history_bytes_per_selected_owner[sizeof(small_history)];
float measure_history_step(small_history *s,int i,float seconds,float fb,float sample) {
    return history_tick(s,i,seconds,fb,sample);
}
