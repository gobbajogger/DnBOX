import hashlib
import json
from pathlib import Path
import sys

import numpy as np

def spectrum(x, win, hop):
    frames=np.lib.stride_tricks.sliding_window_view(x,win)[::hop]
    fft=np.fft.rfft(frames*np.hanning(win),axis=1)
    return np.sqrt(np.mean(abs(fft)**2,axis=0))

def compare(ref,candidate,contract):
    sr=spectrum(ref,contract["fft"],contract["hop"])
    sc=spectrum(candidate,contract["fft"],contract["hop"])
    floor=max(sr.max()*10**(contract["amplitude_floor_db"]/20),1e-12)
    used=(sr>floor)|(sc>floor)
    spectral=np.sqrt(np.mean((20*np.log10(np.maximum(sc[used],floor)/np.maximum(sr[used],floor)))**2))
    ratio=max(1e-20,np.mean(candidate*candidate))/np.mean(ref*ref)
    rms=10*np.log10(ratio)
    return dict(signed_rms_db=float(rms),spectral_rms_db=float(spectral),
                passed=bool(abs(rms)<=contract["absolute_rms_db_max"] and spectral<=contract["spectrum_rms_db_max"]))

def main():
    out=Path(sys.argv[1])
    contract=json.loads(Path(__file__).with_name("contract.json").read_text())
    result={}
    dtype=np.dtype([("frames","<u4"),("values","<f4",(3,))])
    for preset in (1,8):
        refs=[out/f"{mode}-{preset}.pcm" for mode in ("original","bounded")]
        original,bounded=[np.fromfile(p,dtype=dtype) for p in refs]
        assert len(original)==3158 and np.array_equal(original["frames"],bounded["frames"])
        assert np.all(np.diff(original["frames"])==1), "selected old reads must be contiguous for FFTs"
        assert np.isfinite(original["values"]).all() and np.isfinite(bounded["values"]).all()
        scores={k:compare(original["values"][:,i].astype(float),bounded["values"][:,i].astype(float),contract["acceptance"])
                for i,k in enumerate(contract["observables"])}
        result[str(preset)]=dict(scores=scores,frames=len(original),start=int(original["frames"][0]),
            end_inclusive=int(original["frames"][-1]),capture_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in refs})
    (out/"scores.json").write_text(json.dumps(result,indent=2)+"\n")
    for key, row in result.items():
        print(key,row["scores"])
if __name__=="__main__":
    main()
