"""Compare the original and bounded four-ring graphs on the two original authored cases."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

HERE=Path(__file__).resolve().parent
ORIGINAL_FX="aee3fe78b450b35bfe6d40741d12dcedf02e24388bdf07850bde7b13d8d8d33e"

def replace(source, old, new):
    if source.count(old)!=1:
        raise ValueError("Unexpected comparison fixture near "+old[:50])
    return source.replace(old,new)

def instrument(build, authored, out):
    fullfx=build/"factory-inputs/tests/fixtures/synthone-factory/fullfx"
    original=fullfx/"source_fx.hpp"
    assert hashlib.sha256(original.read_bytes()).hexdigest()==ORIGINAL_FX
    fx=original.read_text()
    fx=replace(fx,'#define nil nullptr','''#include "small-history.h"
static small_history *candidate_state;
static uint64_t *left_input_digest;
static void history_compute(unsigned i, sp_data *sp, sp_vdelay *v, float *in, float *out) {
    if(i==0) {
        uint32_t bits; std::memcpy(&bits, in, 4);
        *left_input_digest ^= bits;
        *left_input_digest *= UINT64_C(1099511628211);
    }
    if(!candidate_state) {
        sp_vdelay_compute(sp,v,in,out);
        return;
    }
    *out = history_tick(candidate_state,i,v->del,v->feedback,*in);
    v->prev = *out;
}
#define nil nullptr''')
    for i,name in enumerate(("delayL","delayR","delayFillIn","delayRR")):
        fx=replace(fx,"sp_vdelay_compute(sp, "+name+",",f"history_compute({i}, sp, "+name+",")
    (out/"capture-fx.hpp").write_text(fx)
    fixture=authored.read_text().replace('#include "source_fx.hpp"','#include "capture-fx.hpp"')
    fixture=replace(fixture,"float mode = 0","""small_history bounded{};
    FILE *wet_trace=nullptr;
    uint64_t input_digest=UINT64_C(14695981039346656037);
    bool use_bounded=false;
    float mode = 0""")
    fixture=replace(fixture,"x.fx.source_reset_delays();",
                    "x.fx.source_reset_delays(); x.bounded={};")
    fixture=replace(fixture,"x.fx.frame(x.left[frame]", """candidate_state=x.use_bounded ? &x.bounded : nullptr;
        left_input_digest=&x.input_digest;
        x.fx.frame(x.left[frame]""")
    fixture=replace(fixture,"++x.old_reads;","""++x.old_reads;
        const float outputs[]={x.fx.delayL->prev,x.left[frame],x.right[frame]};
        CHECK(std::fwrite(&now,4,1,x.wet_trace)==1);
        CHECK(std::fwrite(outputs,4,3,x.wet_trace)==3);""")
    fixture=replace(fixture,"CHECK(argc==4);","CHECK(argc==6);")
    fixture=replace(fixture,"const unsigned rows[]={1,8};","""const unsigned rows[]={1,8};
    CHECK(sizeof(small_history)<=2764);
    for(unsigned p=0;p<2;++p) {
        owners[p]->use_bounded=std::strcmp(argv[4],"bounded")==0;
        const auto path=std::string(argv[5])+"-"+std::to_string(rows[p])+".pcm";
        owners[p]->wet_trace=std::fopen(path.c_str(),"wb");
        CHECK(owners[p]->wet_trace);
    }""")
    fixture=replace(fixture,"CHECK(x.old_reads>1000", """CHECK(std::fclose(x.wet_trace)==0);
        std::fprintf(stderr,"program=%u frames=%u input_digest=%016llx bytes=%zu\\n",
                     rows[p], x.old_reads,(unsigned long long)x.input_digest,sizeof(small_history));
        if(!x.use_bounded) CHECK(x.old_reads>1000""")
    source=out/"capture.cpp"
    source.write_text(fixture)
    commands=json.loads((build/"factory-build-commands.json").read_text())
    compile_cmd=next(c.copy() for c in commands if any(e.endswith("/preset_audio.cpp") for e in c))
    compile_cmd.insert(1,"-I"+str(HERE))
    for flag,dest in (("-c",source),("-o",out/"capture.o"),("-MF",out/"capture.d")):
        compile_cmd[compile_cmd.index(flag)+1]=str(dest)
    subprocess.run(compile_cmd, check=True)
    link=commands[-1].copy()
    link[link.index(str(build/"factory-6.o"))]=str(out/"capture.o")
    link[link.index("-o")+1]=str(out/"capture")
    subprocess.run(link,check=True)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("factory_build",type=Path)
    parser.add_argument("authored_histories",type=Path)
    parser.add_argument("output",type=Path)
    args=parser.parse_args()
    out=args.output.resolve()
    out.mkdir(parents=True,exist_ok=False)
    build=args.factory_build.resolve()
    instrument(build,args.authored_histories,out)
    versions=("original","bounded")
    for mode in versions:
        inputs=build/"factory-inputs"
        with (out/(mode+".csv")).open("w") as log, (out/(mode+".txt")).open("w") as diag:
            subprocess.run([out/"capture",inputs/"public-morphs.f32",inputs/"compact.bin",
                build/"commands/preset-commands.bin",mode,out/mode],stdout=log,stderr=diag,check=True)
    old=args.authored_histories.with_suffix(".csv")
    assert (out/"original.csv").read_bytes()==old.read_bytes()
    assert (out/"original.txt").read_bytes()==(out/"bounded.txt").read_bytes()
    subprocess.run(["python3",HERE/"score.py",out],check=True)

if __name__=="__main__":
    main()
