import argparse,importlib.util,json,struct,subprocess,hashlib
from pathlib import Path
import numpy as np
from scipy.interpolate import PchipInterpolator
from scipy.signal import fftconvolve,find_peaks
L=11025;T=np.arange(L);G=np.linspace(0,L-1,9);AG=np.linspace(0,L-1,3);fs=44100
def track(x,midi):
    hz=440*2**((midi-69)/12);fft=8192;window=2048;cent=np.unique(np.append(np.arange(0,L,192),L-1));pad=np.pad(x,window//2,mode='edge');grid=np.fft.rfftfreq(fft,1/fs)
    prev=[];routes=[];freqs=[]
    for n in cent:
        v=pad[n:n+window]*np.hanning(window);spec=np.abs(np.fft.rfft(v,fft));pk=find_peaks(spec)[0];pk=pk[(grid[pk]>.19*hz)&(grid[pk]<2.1*hz)]
        if len(pk)==0:pk=np.array([np.argmin(abs(grid-hz))])
        pk=pk[np.argsort(spec[pk])[-8:]];a=np.log(np.maximum(spec[pk]/max(spec.max(),1e-12),1e-12))
        # Quadratic local interpolation of the center frequency.
        z=np.log(np.maximum(spec,1e-20));da=z[pk-1]-2*z[pk]+z[pk+1];frac=np.divide(.5*(z[pk-1]-z[pk+1]),da,out=np.zeros_like(a),where=abs(da)>1e-12)
        f=(pk+np.clip(frac,-.5,.5))*fs/fft
        if not prev:prev.append(a);routes.append(np.zeros(len(f),'i'))
        else:
            deltas=12*np.log2(f[:,None]/freqs[-1][None,:]);c=prev[-1][None,:]-.12*deltas*deltas
            j=c.argmax(axis=1);prev.append(a+c[np.arange(len(a)),j]);routes.append(j)
        freqs.append(f)
    k=np.argmax(prev[-1]);seq=[]
    for i in range(len(cent)-1,-1,-1):
        seq.append(freqs[i][k]);k=routes[i][k]
    f0=np.interp(T,cent,seq[::-1]);phase=np.cumsum(f0)/fs;phase-=phase[0]
    win=2*int(np.clip(1.5*fs/max(10,np.median(f0)),48,1536))+1;wnd=np.hanning(win)
    demod=fftconvolve(x*np.exp(-2j*np.pi*phase),wnd,'same');angle=np.unwrap(np.angle(demod))/(2*np.pi)
    return phase+angle-angle[0],abs(demod)/np.maximum(fftconvolve(np.ones(L),wnd,'same'),1e-12)
def decode_part(part,midi):
    waveform=np.frombuffer(part,dtype='i1',count=24).astype(float)
    off=np.frombuffer(part,dtype='<i2',count=9,offset=24)
    gain=np.frombuffer(part,dtype='u1',count=3,offset=42)
    scale=struct.unpack_from('<e',part,45)[0]
    ph=PchipInterpolator(G,G*(440*2**((midi-69)/12)/fs)+off/256)(T)
    u=(ph%1)*24;i=u.astype(int)%24;alpha=u-np.floor(u)
    return (waveform[i]+alpha*(waveform[(i+1)%24]-waveform[i]))*np.interp(T,AG,gain)*(scale/(127*255))
def encode_part(x,midi):
    hz=440*2**((midi-69)/12)
    if not np.any(x):return bytes(47),0
    if np.max(x)==np.min(x):
        z=float(x[0]);blob=np.full(24,127 if z>=0 else -127,dtype='i1').tobytes()+bytes(18)+bytes([255]*3)+struct.pack('<e',abs(z));return blob,0
    ph,amp=track(x,midi);corr=np.interp(G,T,ph)-G*hz/fs;q=np.rint(corr*256);clip=int(np.count_nonzero(abs(q)>32767))
    off=np.int16(np.clip(q,-32768,32767));recon=PchipInterpolator(G,G*hz/fs+off/256)(T)
    amp=np.interp(AG,T,amp);scale=float(max(amp.max(),1e-12));gain=np.uint8(np.rint(np.clip(amp/scale,0,1)*255));en=np.interp(T,AG,gain)*(scale/255)
    u=(recon%1)*24;i=u.astype(int)%24;j=(i+1)%24;frac=u-np.floor(u)
    left=en*(1-frac);right=en*frac
    bc=lambda idx,weights:np.bincount(idx,weights=weights,minlength=24)
    M=np.zeros((24,24));M.flat[::25]=bc(i,left*left)+bc(j,right*right)
    h=np.arange(24);M[h,(h+1)%24]+=bc(i,left*right);M[(h+1)%24,h]+=bc(i,left*right)
    w=np.linalg.lstsq(M,bc(i,left*x)+bc(j,right*x),rcond=1e-9)[0];s=max(np.max(abs(w)),1e-12)
    wave=np.int8(np.clip(np.rint(127*w/s),-127,127))
    blob=wave.tobytes()+off.astype('<i2').tobytes()+gain.tobytes()+struct.pack('<e',s*scale)
    assert len(blob)==47;return blob,clip
def encode(x,note,start):
    buf=start.to_bytes(3,'little')+bytes([note]);res=x.copy();clip=0
    for _ in range(2):
        part,c=encode_part(res,note);clip+=c;buf+=part;res=res-decode_part(part,note)
    assert len(buf)==98
    return buf,clip
def decode(record):
    note=record[3];return np.float32(decode_part(record[4:51],note)+decode_part(record[51:98],note))
def main():
    ap=argparse.ArgumentParser()
    for k in ('previous','observed','forecast','out'):ap.add_argument(k,type=Path)
    a=ap.parse_args();out=a.out.resolve();out.mkdir(exist_ok=False)
    spec=importlib.util.spec_from_file_location('prior',a.previous/'fit.py');prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
    result={'controls':{},'programs':{}}
    for n,x in [('silent',np.zeros(L)),('constant',np.full(L,.5)),('glide',.6*np.sin(2*np.pi*(T*(220*2**((60-69)/12))/fs+.30*(T/L)**2)+.6))]:
        b,c=encode(x,60,0);result['controls'][n]={'score':prior.score(x,decode(b)),'phase_saturations':c}
    for o in (1,8):
        f=a.observed/f'source-{o}.bin';v=np.memmap(f,dtype='<f4',mode='r').reshape(-1,4,5);d=v[:L*16,:2,0];mono=(d[:,0].astype(float)+d[:,1].astype(float))*.5
        encoded=[encode(mono[e*L:(e+1)*L],42+(17 if o==8 else 0)+e%5,e*L) for e in range(16)]
        records=b''.join(b for b,_ in encoded);(out/f'{o}.records').write_bytes(records)
        y=np.concatenate([decode(b) for b,_ in encoded]);y.tofile(out/f'{o}.dry')
        subprocess.run([a.previous/'result/wet',f,a.forecast/f'feedback-{o}.bin',out/f'{o}.dry',out/f'{o}.wet'],check=True)
        wet=np.fromfile(out/f'{o}.wet',dtype='<f4').reshape(-1,4)
        q=dict(record_bytes=len(records),record_sha256=hashlib.sha256(records).hexdigest(),phase_saturations=sum(c for _,c in encoded),dry=[prior.score(d[:,i],y) for i in range(2)],wet=[prior.score(v[242550:242550+512,i,4],wet[:,i]) for i in range(4)])
        result['programs'][o]=q;print(o,q['phase_saturations'],q['dry'][0]['snr_db'],[s['snr_db'] for s in q['wet']],flush=True)
    (out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':main()
