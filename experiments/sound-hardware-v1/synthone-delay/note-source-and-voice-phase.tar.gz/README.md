# Synth One dry history on two restored factory programs

The original 44.1 kHz fixture plays 16 note events on each owner, followed by the same legal abrupt delay-time edit at frame 242,550. Both comparisons keep the original feedback controls and score the four resulting wet delay taps before downstream effects. Each tap contains 512 binary32 words. The 1 dB absolute level, 3 dB spectral RMS and 24 dB signal-to-noise requirements apply together. Full result files include the dry channels, every wet tap and unequal word counts.

| Method | Historical record bytes per owner | Row 1 wet SNR (dB) | Row 8 wet SNR (dB) |
| --- | ---: | --- | --- |
| Two fitted tones per note | 1,568 | 8.02, 8.02, 8.67, 8.41 | 4.75, 4.75, 13.36, 10.20 |
| Original voice phases and amplitudes, 16-bin tables | 4,160 plus supplied voice trace | 18.21, 18.21, 20.94, 25.21 | 11.57, 11.57, 10.05, 7.83 |
| Original voice phases and amplitudes, 64-bin tables | 16,448 plus supplied voice trace | 20.71, 20.71, 24.71, 27.66 | 13.76, 13.76, 11.32, 8.96 |

The two-tone encoder fits each complete dry note independently before quantizing the two periodic curves. The decoder uses only its 98-byte records. Neither owner saturated its stored phase offsets. All eight wet taps missed the thresholds. This host test measures stored data and audio. Target encoder state and timing remain unmeasured.

The second test receives fully observed oscillator phases and amplitudes for seven voice slots. Its extra 29,635,200 bytes per owner are diagnostic input. Recording them left the two original full dry and delay traces byte-identical. Row 1 had one active voice for 165,375 frames and silence for the other 11,025. Row 8 had five concurrent active voices for 121,275 frames. Only one of the sixteen wet-tap comparisons passed all three criteria, the third row 1 tap at 64 bins. This characterizes a sum of four fitted carrier waveforms with supplied phase. It does not establish an implementation or exclude replaying the original sources.

Reproduce the original 16-note traces and the independent forecast files with the neighboring prewarm and bounded-periodic packets. Match the three digests per owner in source-inputs.json. The downstream include directory contains measured.hpp from that original capture, and the prepared factory build contains factory-build-commands.json. Use Python with NumPy and SciPy, a C++17 compiler, and single-threaded BLAS. OUTPUT paths below must be new directories. The tracked routine builds the wet decoder in tracked/result. The phase recorder expects the checked original capture at ORIGINAL/capture.cpp.

    export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
    python3 tracked/fit.py ORIGINAL FORECAST CHECKPOINT_HEADER_DIR tracked/result
    python3 two-tone/fit2.py tracked ORIGINAL FORECAST TWO_TONE_OUTPUT
    python3 phase/capture.py ORIGINAL FACTORY_BUILD DOWNSTREAM_INCLUDE PHASE_CAPTURE
    python3 phase/check.py tracked ORIGINAL FORECAST PHASE_CAPTURE PHASE_OUTPUT

Check two-tone/results.json and phase/results.json against the regenerated JSON. Executables, raw PCM, target firmware and vendor assets are regenerated from the pinned inputs.
