from pathlib import Path
import argparse,hashlib,subprocess,json
ap=argparse.ArgumentParser()
for k in ('source','build','downstream','out'):ap.add_argument(k,type=Path)
a=ap.parse_args();out=a.out.resolve();out.mkdir(exist_ok=False);b=a.build.resolve()
code=(a.source/'capture.cpp').read_text()
code=code.replace('FullPair pair; FILE *trace=nullptr;', 'FullPair pair; FILE *trace=nullptr; FILE *phases=nullptr;')
needle='        trace_file=x.trace;'
assert code.count(needle)==1
code=code.replace(needle,'''        if (x.absolute+frame<long_edit) {
            struct VoiceTrace { uint32_t active; float amp; uint32_t phase[4]; };
            static_assert(sizeof(VoiceTrace)==24,"binary trace field size");
            VoiceTrace voices[7]={};
            for(unsigned v=0;v<7;v++){
                const auto &note=(v==6 ? *s.monoNote : (*s.noteStates)[v]);
                bool live=(v==6)==(s.parameters[isMono]!=0.f) &&
                     note.rootNoteNumber!=-1 && note.stage!=S1NoteState::stageOff;
                if(live){ voices[v].active=1; voices[v].amp=note.amp;
                    voices[v].phase[0]=uint32_t(note.oscmorph1->lphs);
                    voices[v].phase[1]=uint32_t(note.oscmorph2->lphs);
                    voices[v].phase[2]=uint32_t(note.subOsc->lphs);
                    voices[v].phase[3]=uint32_t(note.fmOsc->cphs);
                }
            }
            CHECK(std::fwrite(voices,sizeof voices,1,x.phases)==1);
        }
'''+needle)
needle='        owners[i]->trace=std::fopen(path.c_str(),"wb");';assert code.count(needle)==1
code=code.replace(needle,needle+'\n        owners[i]->phases=std::fopen((path+".phase").c_str(),"wb");CHECK(owners[i]->phases);')
(out/'capture.cpp').write_text(code)
commands=json.loads((b/'factory-build-commands.json').read_bytes())
cc=next(x.copy() for x in commands if '-c' in x and x[x.index('-c')+1].endswith('/preset_audio.cpp'))
old=cc[cc.index('-o')+1];cc[cc.index('-c')+1]=str(out/'capture.cpp');cc[cc.index('-o')+1]=str(out/'capture.o');cc[cc.index('-MF')+1]=str(out/'capture.d');cc.insert(1,'-I'+str(a.downstream.resolve()))
subprocess.run(cc,check=True);ld=[str(out/'capture.o') if v==old else v for v in commands[-1]];ld[ld.index('-o')+1]=str(out/'capture');subprocess.run(ld,check=True)
assets=b/'factory-inputs';subprocess.run([out/'capture',assets/'public-morphs.f32',assets/'compact.bin',b/'commands/preset-commands.bin','late',out/'source'],check=True)
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
for owner in (1,8):
 f=out/f'source-{owner}.bin';o=a.source/f.name
 assert h(f)==h(o),owner
 ph=f.with_suffix('.bin.phase');assert ph.stat().st_size==176400*7*24
 print(owner,h(f),ph.stat().st_size,h(ph))
