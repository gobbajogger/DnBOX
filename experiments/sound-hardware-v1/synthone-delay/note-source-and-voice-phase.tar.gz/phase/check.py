import argparse,hashlib,importlib.util,json,subprocess
from pathlib import Path
import numpy as np
from scipy.sparse import coo_matrix
ap=argparse.ArgumentParser()
for k in ('prev','original','forecast','phases','out'):ap.add_argument(k,type=Path)
a=ap.parse_args();out=a.out.resolve();out.mkdir(exist_ok=False);n=11025;indices=np.arange(n)
spec=importlib.util.spec_from_file_location('base',a.prev/'fit.py');base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
res={}
for owner in (1,8):
 raw=a.original/f'source-{owner}.bin';orig=np.memmap(raw,dtype='<f4',mode='r').reshape(-1,4,5)
 pf=a.phases/(raw.name+'.phase')
 rowtype=np.dtype([('active','<u4'),('amp','<f4'),('ph','<u4',(4,))])
 info=np.memmap(pf,dtype=rowtype,mode='r').reshape(16,n,7)
 dry=orig[:16*n,:2,0];mean=np.mean(dry.astype('f8'),axis=1)
 res[owner]=dict(phase_sha256=h(pf),phase_bytes=pf.stat().st_size,active_voice_counts={str(i):int(np.count_nonzero(info['active'].sum(axis=2)==i)) for i in range(8)},trials={})
 for bins in (16,64):
  all_y=[];coefs=[]
  for e in range(16):
   x=mean[e*n:(e+1)*n];v=info[e];rr=[indices];cc=[np.zeros(n,'i')];dd=[np.ones(n)]
   for vid in range(7):
    have=v['active'][:,vid]!=0;idx=indices[have]
    if not len(idx):continue
    amp=v['amp'][have,vid].astype(float)
    for k in range(4):
     phase=(v['ph'][have,vid,k]%0x1000000)*(bins/float(0x1000000))
     lo=np.int64(phase);f=phase-lo
     rr.extend([idx,idx]);cc.extend([1+k*bins+lo,1+k*bins+(lo+1)%bins]);dd.extend([amp*(1-f),amp*f])
   A=coo_matrix((np.concatenate(dd),(np.concatenate(rr),np.concatenate(cc))),shape=(n,1+4*bins)).tocsr()
   m=(A.T@A).toarray();rhs=A.T@x;c=np.linalg.lstsq(m,rhs,rcond=1e-10)[0]
   # Binary32 coefficients are the measured coefficient store.
   c=np.float32(c);coefs.append(c)
   all_y.append(np.float32(A@c))
  y=np.concatenate(all_y);yf=out/f'{owner}-{bins}.dry';y.tofile(yf)
  cf=out/f'{owner}-{bins}.coefficients';np.array(coefs,'<f4').tofile(cf)
  wf=out/f'{owner}-{bins}.wet'
  subprocess.run([a.prev/'result/wet',raw,a.forecast/f'feedback-{owner}.bin',yf,wf],check=True)
  wet=np.fromfile(wf,dtype='<f4').reshape(512,4);ref=orig[242550:242550+512,:,4]
  q=dict(coefficient_bytes=cf.stat().st_size,coefficients_sha256=h(cf),dry=[base.score(dry[:,i],y) for i in range(2)],wet=[base.score(ref[:,i],wet[:,i]) for i in range(4)],wet_sha256=h(wf))
  res[owner]['trials'][bins]=q;print(owner,bins,res[owner]['active_voice_counts'],round(q['dry'][0]['snr_db'],2),[round(v['snr_db'],2) for v in q['wet']],flush=True)
(out/'results.json').write_text(json.dumps(res,indent=2)+'\n')
