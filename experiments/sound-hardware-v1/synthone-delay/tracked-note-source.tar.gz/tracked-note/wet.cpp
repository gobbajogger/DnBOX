#include "checkpoint_core.hpp"
#include <fstream>
#include <string>
static std::vector<Frame> load(const char *path) {
    std::vector<Frame> x(264600);FILE *f=fopen(path,"rb");assert(f);
    assert(fread(x.data(),sizeof(Frame),x.size(),f)==x.size()&&fgetc(f)==EOF);
    fclose(f);return x;
}
static void emit(FILE *f,float x){assert(fwrite(&x,sizeof x,1,f)==1);}
int main(int argc,char **argv) {
    assert(argc==5);
    const auto data=load(argv[1]),pred=load(argv[2]);
    FILE *wet=fopen(argv[4],"wb");assert(wet);
    std::vector<float> decoded(176400);FILE *f=fopen(argv[3],"rb");assert(f);
    assert(fread(decoded.data(),sizeof(float),decoded.size(),f)==decoded.size() && fgetc(f)==EOF);fclose(f);
    flash_witness_owner state{};
    /* The on-line owner sees authentic dry while it creates historical checkpoints. */
    for(unsigned t=0;t<4*stride;++t) {
        tick(state.active[0],data[t]);
        if(state.active[0].next%stride==0)state.saved[state.active[0].next/stride-1]=state.active[0];
    }
    unsigned want[2];
    auto advance=[&](unsigned k,unsigned limit) {
        auto &c=state.active[k];
        while(c.next<limit) {
            auto f=data[c.next];
            float v=(c.next<decoded.size()?decoded[c.next]:0.0f);
            for(unsigned p=0;p<3;++p)f[p].input=v;
            tick(c,f);
        }
    };
    for(unsigned k=0;k<2;++k) {
        Query q=at(first_wet,pred[first_wet][2*k].delay);want[k]=q.base+3;
        prepare(state,state.active[k],q.base-1);
        advance(k,want[k]);
    }
    for(unsigned t=first_wet;t<first_wet+512;++t) {
        for(unsigned k=0;k<2;++k) {
            Query q=at(t,data[t][2*k].delay);advance(k,q.base+3);
            for(unsigned p=2*k;p<2*k+2;++p)
                emit(wet,read(state.active[k],q,p,int(state.active[k].next)-1));
        }
    }
    fclose(wet);
}
