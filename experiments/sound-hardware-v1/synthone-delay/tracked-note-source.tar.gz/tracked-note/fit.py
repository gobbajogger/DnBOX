import argparse,collections,hashlib,json,struct,subprocess
from pathlib import Path
import numpy as np
from scipy.signal import fftconvolve
L=11025
G=np.linspace(0,L-1,9)
T=np.arange(L)
def rec(x,note,start,tracked):
    freq=220.0*2**((note-69)/12);base=T*(freq/44100)
    span=2*int(1.5*44100/freq)+1
    wnd=np.hanning(span);norm=fftconvolve(np.ones(L),wnd,'same')
    rms=np.sqrt(np.maximum(0,fftconvolve(x*x,wnd,'same')/norm))
    level=np.interp(G,T,rms);peak=float(np.float16(max(max(level),np.finfo('f2').tiny)))
    gain=np.uint8(np.rint(255*np.clip(level/peak,0,1)))
    amp=np.interp(T,G,gain)*(peak/255)
    delta=np.zeros(9)
    if tracked and np.any(x):
        osc=fftconvolve(x*np.exp(-2j*np.pi*base),wnd,'same')
        correction=np.unwrap(np.angle(osc))/(2*np.pi)
        delta=np.interp(G,T,correction-correction[0])
    off=np.int16(np.clip(np.rint(1024*delta),-32768,32767))
    phase=(base+np.interp(T,G,off)/1024)%1
    u=phase*64;i=np.int64(u)%64;j=(i+1)%64;alpha=u-np.floor(u)
    l=amp*(1-alpha);r=amp*alpha
    M=np.zeros((64,64))
    def bc(index,val):return np.bincount(index,weights=val,minlength=64)
    M.flat[::65]=bc(i,l*l)+bc(j,r*r)
    h=np.arange(64);M[h,(h+1)%64]+=bc(i,l*r);M[(h+1)%64,h]+=bc(i,l*r)
    w=np.linalg.lstsq(M,bc(i,l*x)+bc(j,r*x),rcond=1e-9)[0]
    # Transfer the independent table normalization into the encoded gain scale.
    scale=max(np.max(np.abs(w)),1e-12)
    cycle=np.asarray(np.clip(np.rint(w*127/scale),-127,127),dtype=np.int8)
    with np.errstate(under='ignore'): p=np.float16(peak*scale)
    buf=start.to_bytes(3,'little')+bytes([note])+cycle.tobytes()+off.astype('<i2').tobytes()+gain.tobytes()+p.astype('<f2').tobytes()
    assert len(buf)==97
    return buf
def decode(buf):
    note=buf[3];w=np.frombuffer(buf,dtype='i1',count=64,offset=4).astype(float)
    off=np.frombuffer(buf,dtype='<i2',count=9,offset=68);g=np.frombuffer(buf,dtype='u1',count=9,offset=86)
    scale=struct.unpack_from('<e',buf,95)[0]
    phase=(T*(220.0*2**((note-69)/12)/44100)+np.interp(T,G,off)/1024)%1
    u=phase*64;i=np.int64(u)%64;v=w[i]+(u-np.floor(u))*(w[(i+1)%64]-w[i])
    return np.float32(v*np.interp(T,G,g)*(scale/(127*255)))
def score(x,y):
    x=x.astype('f8');y=y.astype('f8')
    if not np.any(x):return dict(zero=True,passed=bool(np.array_equal(x,y)),different=int(np.count_nonzero(x!=y)))
    def rms(v):return np.sqrt(np.mean(v*v))
    def spec(v):return np.sqrt(np.mean(abs(np.fft.rfft(np.lib.stride_tricks.sliding_window_view(v,256)[::64]*np.hanning(256)))**2,axis=0))
    a,b=spec(x),spec(y);floor=max(a.max()*1e-4,1e-12);use=(a>floor)|(b>floor)
    d=float(rms(20*np.log10(np.maximum(b[use],floor)/np.maximum(a[use],floor))))
    lev=float(20*np.log10(max(rms(y),1e-30)/max(rms(x),1e-30)));snr=float(20*np.log10(rms(x)/max(rms(x-y),1e-30)))
    return dict(level_db=lev,spectral_db=d,snr_db=snr,passed=abs(lev)<=1 and d<=3 and snr>=24,different=int(np.count_nonzero(x.astype('<f4').view('<u4')!=y.astype('<f4').view('<u4'))))
def main():
    ap=argparse.ArgumentParser()
    for name in ('observed','forecast','headers','out'):ap.add_argument(name,type=Path)
    a=ap.parse_args();out=a.out.resolve();out.mkdir(exist_ok=False)
    src=Path(__file__).resolve().parent
    subprocess.run(['c++','-std=c++17','-O2','-fno-fast-math','-ffp-contract=off','-I'+str(a.headers),src/'wet.cpp','-o',out/'wet'],check=True)
    results={'controls':{},'programs':{}}
    hz=220*2**((60-69)/12)
    for label,x in [('silence',T*0),('constant',T*0+.5),('glide',.6*np.sin(2*np.pi*(T*hz/44100+0.30*(T/L)**2)+.6))]:
        results['controls'][label]=[score(x,decode(rec(x,60,0,mode))) for mode in (False,True)]
    for owner in (1,8):
        inp=a.observed/f'source-{owner}.bin';hist=a.forecast/f'feedback-{owner}.bin'
        frames=np.memmap(inp,dtype='<f4',mode='r').reshape(-1,4,5)
        dry=frames[:L*16,:2,0];mean=.5*(dry[:,0].astype(float)+dry[:,1].astype(float))
        results['programs'][owner]={}
        for label,mode in [('fixed',False),('tracked',True)]:
            records=[rec(mean[e*L:(e+1)*L],42+(17 if owner==8 else 0)+e%5,L*e,mode) for e in range(16)]
            allrec=b''.join(records);(out/f'{owner}-{label}.records').write_bytes(allrec)
            y=np.concatenate([decode(z) for z in records]);yp=out/f'{owner}-{label}.dry';y.tofile(yp)
            wp=out/f'{owner}-{label}.wet'
            subprocess.run([out/'wet',inp,hist,yp,wp],check=True)
            wet=np.fromfile(wp,dtype='<f4').reshape(512,4);ref=frames[242550:242550+512,:,4]
            r=dict(record_bytes=len(allrec),records_sha256=hashlib.sha256(allrec).hexdigest(),dry=[score(dry[:,ch],y) for ch in range(2)],wet=[score(ref[:,ch],wet[:,ch]) for ch in range(4)],dry_sha256=hashlib.sha256(yp.read_bytes()).hexdigest(),wet_sha256=hashlib.sha256(wp.read_bytes()).hexdigest())
            results['programs'][owner][label]=r
            print(owner,label,'dry',r['dry'][0]['snr_db'],'wet',[round(v['snr_db'],3) for v in r['wet']],flush=True)
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
if __name__=='__main__':main()
