# Per-event pitch tracking for the bounded delay source

This source experiment uses the same recorded dry frames and the same one-time legal delay edit on the two restored programs as the earlier periodic-source benchmark. Each completed note stores a 64-bin cycle, nine signed phase corrections and nine level anchors. The complete encoded records are 97 bytes each, 1,552 bytes for the 16 notes on each owner. The decoder reads only the packed bytes. A fixed-pitch control uses the identical level and waveform fit. The study permits a host encoder to analyze a whole completed note before storing its record. Native encoder work space and callback timing are unqualified.

| Original program row | Fixed pitch, four wet-tap SNRs (dB) | Tracked pitch, four wet-tap SNRs (dB) |
| --- | --- | --- |
| 1 | 7.41, 7.41, 16.69, 19.23 | 19.55, 19.55, 22.25, 25.71 |
| 8 | −0.01, −0.01, 10.47, 6.87 | −0.73, −0.73, −1.89, −2.24 |

All eight original wet streams failed at least one of the preregistered criteria. On row 1 even the tap reaching 25.71 dB SNR had 5.54 dB spectral error against the 3 dB limit. All 4,096 tracked wet sample words differed across the two parts. Silence and constant controls were exact. Tracking raised the synthetic gliding-tone SNR from 5.65 to 31.73 dB, but its spectral error remained 8.83 dB. No physical firmware includes these records.

Run the original prewarm/periodic generators to supply the two source-N.bin and two feedback-N.bin inputs. They are the same captures identified in the adjacent delay packets. Run the following from this unpacked directory with Python, NumPy, SciPy and a C++17 compiler.

    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 fit.py CHANGED_TRACE_DIRECTORY FORECAST_TRACE_DIRECTORY source NEW_OUTPUT

The wet decoder starts from authentic early feedback checkpoints. It replaces only later random-access historical dry reads with the decoded note. results.json reports every dry channel, wet tap and control. The 97-byte records are included for direct checking.
