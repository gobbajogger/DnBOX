/* The second compressed record crosses two discontiguous owner-owned ranges.
 * Decode its XOR residual directly into the second mutable slot. */
struct archive_parts {const uint8_t *head,*tail;};
static uint8_t byte_at(struct archive_parts in,unsigned n){
    return n<EXTRA_PREFIX?in.head[n]:in.tail[n-EXTRA_PREFIX];
}
static unsigned unpack_parts(struct archive_parts in,unsigned size,uint8_t *out,unsigned limit){
    unsigned pos=4,w=0,end=4+size;
    while(pos<end){
        unsigned tag=byte_at(in,pos++);
        if(tag<128){
            unsigned n=tag+1;if(n>limit-w || n>end-pos)return 0;
            for(unsigned j=0;j<n;j++)out[w++]=byte_at(in,pos++);
        }else{
            unsigned n=(tag&127u)+3u;if(n>limit-w || end-pos<2)return 0;
            unsigned distance=byte_at(in,pos);distance|=(unsigned)byte_at(in,pos+1)<<8;pos+=2;
            if(!distance || distance>w)return 0;
            for(unsigned j=0;j<n;j++){out[w]=out[w-distance];w++;}
        }
    }
    return w;
}
int restore_both(int part){
    if(!active(part))return 0;
    uint8_t *i=insert_base(part),*b=backend_base(part),*a=i+OFFSET(insert,archive);
    struct archive_parts second={i+sizeof(struct retained_insert),free_workspace(part)};
    unsigned raw0=a[0]+256u*a[1], packed0=a[2]+256u*a[3];
    unsigned raw1=byte_at(second,0)+256u*byte_at(second,1);
    unsigned packed1=byte_at(second,2)+256u*byte_at(second,3);
    if(!raw0||!raw1||raw0>SOURCE_SLOT||raw1>SOURCE_SLOT||packed0+4>STORED_ANCHOR||packed1+4>extra_size(part))return 0;
    uint8_t *l=i+OFFSET(insert,long_source),*r=b+OFFSET(backend,short_source);
    memset(l,0x9c,SOURCE_SLOT);memset(r,0xce,SOURCE_SLOT);
    if(unpack_snapshot(a+4,packed0,l,SOURCE_SLOT)!=raw0||unpack_parts(second,packed1,r,SOURCE_SLOT)!=raw1)return 0;
    for(unsigned j=0;j<raw1&&j<raw0;j++)r[j]^=l[j];
    return 1;
}
