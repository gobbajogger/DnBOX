enum { EXTRA_PREFIX=96, DRUM_METAL_BYTES=4*256*sizeof(float) };
_Static_assert(sizeof(struct retained_insert)+EXTRA_PREFIX<=sizeof(((original_chicago_fx2_compact*)0)->arena),"insert trailer");
_Static_assert(sizeof(original_runtime_workspace)>=DRUM_METAL_BYTES+1024,"metal suffix");
static uint8_t *free_workspace(int p){return (uint8_t*)(p?&original_workspace_b:&original_workspace)+(p?0:DRUM_METAL_BYTES);}
unsigned extra_size(int p){if(!active(p))return 0;return EXTRA_PREFIX+sizeof(original_runtime_workspace)-(p?0:DRUM_METAL_BYTES);}
int extra_record(int p,const uint8_t *ref,unsigned n,int write){
    if(!active(p)||n!=extra_size(p))return 0;
    uint8_t *head=insert_base(p)+sizeof(struct retained_insert), *tail=free_workspace(p);
    if(write){memcpy(head,ref,EXTRA_PREFIX);memcpy(tail,ref+EXTRA_PREFIX,n-EXTRA_PREFIX);}
    return !memcmp(head,ref,EXTRA_PREFIX)&&!memcmp(tail,ref+EXTRA_PREFIX,n-EXTRA_PREFIX);
}
static unsigned split_seen,drum_planes;
void inspect_metal(void){
    if(!eng_808_split)return;
    const float (*raw)[256]=(const float (*)[256])(const void*)&original_workspace;
    split_seen++;
    for(unsigned p=0;p<4;p++)for(unsigned i=0;i<256;i++)if(raw[p][i]!=0.f){drum_planes|=1u<<p;break;}
}
unsigned split_observed(void){return split_seen;}
unsigned planes_observed(void){return drum_planes;}
