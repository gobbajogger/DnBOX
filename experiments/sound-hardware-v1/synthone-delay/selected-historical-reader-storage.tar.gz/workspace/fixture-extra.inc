extern int extra_record(int,const uint8_t*,unsigned,int);
extern unsigned extra_size(int),split_observed(void),planes_observed(void);
extern void inspect_metal(void);
static uint8_t storage_data[2][5280];
static unsigned words[2],registered[2],exercise;
static void prepare_extra(int p,const char*path) {
    char filename[1024];REQUIRE(snprintf(filename,sizeof filename,"%s.xor",path)>0);
    FILE*f=fopen(filename,"rb");REQUIRE(f);unsigned needed=p?5216:1120;
    for(unsigned i=0;i<needed;i++)storage_data[p][i]=(uint8_t)(31+p*63+i*79);
    unsigned n=fread(storage_data[p],1,needed,f);REQUIRE(n>100&&n<=1120&&feof(f));REQUIRE(!fclose(f));words[p]=needed;
}
static void verify_extras(void){
    for(int p=0;p<2;p++)if(registered[p]){
        if(extra_size(p)){REQUIRE(extra_record(p,storage_data[p],words[p],0));}
        else registered[p]=0;
    }
}
static void drums(void){
    if(exercise && blocks%10==0){
       engine_drum(PART_909,0,0.9f);
       for(int v=0;v<11;v++)engine_drum(PART_808,v,0.85f);
    }
}
