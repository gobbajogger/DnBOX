from pathlib import Path
import hashlib,json,subprocess,sys
base,out=(Path(x).resolve() for x in sys.argv[1:]);out.mkdir(exist_ok=False)
assigned=[1,0];report=json.loads((base/'report.json').read_bytes());expected={}
for p,chosen in enumerate(assigned):
    row=(1,8)[chosen];d=report['rows'][str(row)];n=d['actual_content_bytes']
    regular=(base/'records1.bin').read_bytes();orig_offset=report['rows']['1']['actual_content_bytes'] if chosen else 0
    initial=regular[orig_offset:orig_offset+n]
    packed=(base/f'owner-{chosen}.bin').read_bytes();a,b=d['decoded']
    changed=initial[:a+b]+packed[-1024:]+initial[a+b+1024:]
    expected[p]=[initial,changed]
q=subprocess.run([base/'host','1',out/'pcm.bin',out/'project.bin',base/'owner-1.bin',base/'owner-0.bin',out/'records.bin'],cwd=base/'src',capture_output=True,text=True,check=True)
(out/'run.log').write_text(q.stderr)
seq=[(0,0),(1,0),(0,1),(1,0),(1,1),(0,1),(0,1),(1,1),(1,1)]
truth=b''.join(expected[o][k] for o,k in seq);assert (out/'records.bin').read_bytes()==truth
for k in ('pcm','project'):assert (out/f'{k}.bin').read_bytes()==(base/f'{k}0.bin').read_bytes()
r=dict(part_A=8,part_B=1,terminal=q.stderr,verified_bytes=len(truth),sha256=hashlib.sha256(truth).hexdigest());(out/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(r)
