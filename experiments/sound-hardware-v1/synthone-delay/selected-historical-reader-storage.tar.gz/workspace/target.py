from pathlib import Path
import subprocess,sys,json,hashlib
here=Path(__file__).resolve().parent
src,tool,records,out=(Path(x).resolve() for x in sys.argv[1:]);out.mkdir(exist_ok=False)
cc=tool/'pi32v2/bin/clang';dump=tool/'common/bin/objdump'
incs=[records,src,src/'firmware/src',src/'experiments/original_synth',src/'experiments/wobble',src/'build/gen']
cmd=[cc,'-target','pi32v2','-mcpu=r3','-mfprev1','-ffreestanding','-fno-common','-Oz','-idirafter',tool/'pi32v2/include',*['-I'+str(p) for p in incs],'-DX0X_ORIGINAL_SYNTH=1','-c',here/'layout.c','-o',out/'layout.o']
subprocess.run(cmd,check=True);syms=subprocess.check_output([dump,'-t',out/'layout.o'],text=True);(out/'layout.txt').write_text(syms)
sizes={r.split()[-1]:int(r.split()[-2],16) for r in syms.splitlines() if '.bss' in r};assert sizes['workspace_a_suffix']==1024 and sizes['workspace_b']==5120 and sizes['owner_a_conditional']==7884 and sizes['owner_b_conditional']==11980 and sizes['fixed_record_reservation']==7628,sizes
boards={};h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
for board,folder in [('Elite','smk37-elite'),('Pro','smk37')]:
    elf=src/'build'/folder/'x0x.elf';app=elf.with_suffix('.bin');sym=subprocess.check_output([dump,'-t',elf],text=True)
    rows={r.split()[-1]:r for r in sym.splitlines() if r.split() and r.split()[-1] in ('original_workspace','original_workspace_b','original_fx','original_bass')}
    assert len(rows)==4 and all(int(rows[k].split()[-2],16)==5120 for k in ('original_workspace','original_workspace_b'))
    assert '.pool' in rows['original_workspace'] and '.xpool' in rows['original_workspace_b']
    boards[board]=dict(app_bytes=app.stat().st_size,app_sha256=h(app),elf_sha256=h(elf),symbols=rows)
res=dict(target_layout=sizes,boards=boards,compiler_sha256=h(cc));(out/'results.json').write_text(json.dumps(res,indent=2)+'\n');print(sizes)
