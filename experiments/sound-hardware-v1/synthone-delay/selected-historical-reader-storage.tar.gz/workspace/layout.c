#include <stddef.h>
#include "experiments/original_synth/chicago_fx2_compact.h"
#include "firmware/src/app/original_runtime.h"
#include "records.h"
#define CAPACITY(name,n) unsigned char name[n]
#define OWNER_A (sizeof(original_runtime_workspace)-4u*256u*sizeof(float))
#define OWNER_B (sizeof(original_runtime_workspace))
#define BACKEND_TAIL (sizeof(original_runtime_backend)-sizeof(s1_dry_part))
#define INSERT_BYTES sizeof(((original_chicago_fx2_compact*)0)->arena)
CAPACITY(workspace_a_suffix,OWNER_A);
CAPACITY(workspace_b,OWNER_B);
CAPACITY(insert_records,sizeof(struct retained_insert));
CAPACITY(backend_records,sizeof(struct retained_backend));
CAPACITY(first_region_offset,offsetof(original_chicago_fx2_compact,arena));
CAPACITY(second_region_offset,sizeof(s1_dry_part));
CAPACITY(owner_a_conditional,OWNER_A+INSERT_BYTES+BACKEND_TAIL);
CAPACITY(owner_b_conditional,OWNER_B+INSERT_BYTES+BACKEND_TAIL);
CAPACITY(fixed_record_reservation,sizeof(struct retained_insert)+sizeof(struct retained_backend)+1120u);
