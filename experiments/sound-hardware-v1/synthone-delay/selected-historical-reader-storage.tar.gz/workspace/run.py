from pathlib import Path
import subprocess,sys,shutil
here=Path(__file__).resolve().parent
active,first,codec,fork,feedback,src,out=(Path(x).resolve() for x in sys.argv[1:8])
out.mkdir(exist_ok=False);code=out/'sources';code.mkdir()
for n in ('seed.cpp','records.h'):shutil.copy(active/n,code/n)
prefix=(active/'hook-prefix.c').read_text()+'\n'+(here/'extra.c').read_text()+'\n'+(here/'restore.c').read_text()
(code/'hook-prefix.c').write_text(prefix)
fix=(active/'fixture.inc').read_text()
fix='extern int restore_both(int);\n'+fix
fix=fix.replace('int main(int argc', (here/'fixture-extra.inc').read_text()+'\nint main(int argc')
fix=fix.replace('read_owner(1,argv[5]);boot();','read_owner(1,argv[5]);prepare_extra(0,argv[4]);prepare_extra(1,argv[5]);boot();plat_cpu2_set(1);')
fix=fix.replace('        play_note(p,47+p*12);','        if(fill){REQUIRE(extra_size(p)==words[p]&&extra_record(p,storage_data[p],words[p],1));registered[p]=1;REQUIRE(restore_both(p));}exercise++;\n        play_note(p,47+p*12);')
fix=fix.replace('int algorithms=compare_effects();','REQUIRE(split_observed()>0 && planes_observed()==15); fprintf(stderr,"observed %u active split renders; nonzero metal plane mask %u\\n",split_observed(),planes_observed());int algorithms=compare_effects();')
if '--forced' not in sys.argv:fix=fix.replace('REQUIRE(split_observed()>0 && planes_observed()==15); ', '')
(code/'fixture.inc').write_text(fix)
base=out/'base';base.mkdir();shutil.copy(first/'hook.c',base/'hook.c')
txt=(first/'fixture.c').read_text().replace('static void emit(void){','static void drums(void);static void verify_extras(void);extern void inspect_metal(void);\nstatic void emit(void){drums();').replace('engine_render(sound,256);','engine_render(sound,256);inspect_metal();verify_extras();')
(base/'fixture.c').write_text(txt)
s=(active/'run.py').read_text()
s=s.replace("(out/f'owner-{part}.bin').write_bytes", "xor=(codec/'results'/f'{row}-xor.packed').read_bytes()\n    (out/f'owner-{part}.bin.xor').write_bytes(struct.pack('<HH',len(b),len(xor))+xor)\n    assert len(xor)+4<=1120\n    (out/f'owner-{part}.bin').write_bytes")
s=s.replace('["cc","-I.",*','["cc","-I.","-DX0X_CORE_PLAN=1",*') if '--forced' in sys.argv else s
(code/'execute.py').write_text(s)
subprocess.run([sys.executable,code/'execute.py',src,base,codec,fork,feedback,out/'run'],check=True)
