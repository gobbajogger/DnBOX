from pathlib import Path
import hashlib,subprocess,json,sys,struct,tempfile
here=Path(__file__).resolve().parent
cold,pre,voices,fx,capture,build,occupied,original,out=[Path(x).resolve() for x in sys.argv[1:10]]
out.mkdir(exist_ok=False);hashf=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
measure=lambda blob:hashlib.sha256(blob).hexdigest()
# Use only the physical host-firmware readback for the four numerical seeds.
allbytes=(occupied/'records1.bin').read_bytes();receipt=json.loads((occupied/'report.json').read_bytes());pos=0
for r in (1,8):
    desc=receipt['rows'][str(r)]
    for k,n in enumerate(desc['decoded']):
        (out/f'source-{r}-{k}.state').write_bytes(allbytes[pos:pos+n]);pos+=n
    pos+=desc['feedback_workers']+desc['feedback_anchor']+desc['source_anchor']
s=(capture/'capture.cpp').read_text()
names=('malloc','calloc','realloc','free')
s='\n'.join('#define __wrap_'+n+' fixture_'+n for n in names)+'\n'+s
s=s.replace('#include "reader.hpp"','\n'.join('#undef __wrap_'+n for n in names)+'\n#include "profile.hpp"\n#include "reader.hpp"')
s=s.replace('rep<5','rep<1')
s=s.replace('FullOracle rd;SourceFx prefix(hz);','CHECK(nrange==0);group=1;FullOracle rd;group=2;SourceFx prefix(hz);group=1;')
s=s.replace('Reader record{saved[k].bytes};','group=0;std::string path=location+"-"+std::to_string(row)+"-"+std::to_string(k)+".state";\n            FILE* state=std::fopen(path.c_str(),"rb");CHECK(state);std::vector<unsigned char> material(2060);size_t length=std::fread(material.data(),1,material.size(),state);CHECK(std::fgetc(state)==EOF&&std::fclose(state)==0);material.resize(length);Reader record{material};')
s=s.replace('const uint64_t setup=','begin_tracking(&rd,sizeof rd,&prefix,sizeof prefix);\n            const uint64_t setup=').replace('actual+=n;blocks++;start+=n;','inspect_ranges();actual+=n;blocks++;start+=n;')
s=s.replace('CHECK(count==length[k]);','end_tracking(row,k);CHECK(count==this->length[k]);')
# Avoid shadowing the existing span length with the on-disk checkpoint length.
s=s.replace('size_t length=std::fread','size_t seed_bytes=std::fread').replace('material.resize(length)','material.resize(seed_bytes)')
if '--lean' in sys.argv:
    from lean import create
    create(pre/'prefix-state.hpp',fx/'measured.hpp',out)
    s=s.replace('#include "prefix-state.hpp"','#include "live-prefix.hpp"').replace('SourceFx prefix(hz);','LivePrefix prefix(hz,fx);')
(out/'reader.cpp').write_text(s)
c=json.loads((build/'factory-build-commands.json').read_bytes())
cc=next(v.copy() for v in c if '-c' in v and v[v.index('-c')+1].endswith('/preset_audio.cpp'));old=cc[cc.index('-o')+1]
for flag,name in [('-c','reader.cpp'),('-o','reader.o'),('-MF','reader.d')]:cc[cc.index(flag)+1]=str(out/name)
cc[1:1]=['-I'+str(x) for x in (here,fx,pre,cold,voices)]
ld=[str(out/'reader.o') if p==old else p for p in c[-1]];ld[ld.index('-o')+1]=str(out/'reader')
if '--embedded' in sys.argv:
    import importlib.util
    spec=importlib.util.spec_from_file_location('static_prefix',here/'static-prefix.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    s=module.install(fx,s,out,c,ld);(out/'reader.cpp').write_text(s)
subprocess.run(cc,check=True);subprocess.run(ld,check=True)
assets=build/'factory-inputs'
with (out/'terminal.log').open('w') as log:
    subprocess.run([out/'reader',assets/'public-morphs.f32',assets/'compact.bin',build/'commands/preset-commands.bin','late',out/'source'],stdout=log,stderr=log,check=True)
rows=[];digests=[]
for line in (out/'terminal.log').read_text().splitlines():
    if line.startswith('LIVE '):
        fields=list(map(int,line.split()[1:]));rows.append(dict(zip('owner cursor group count bytes changed_allocations bytes_in_changed_allocations changed_byte_positions'.split(),fields)))
for row in (1,8):
    assert hashf(out/f'source-{row}.bin')==hashf(original/f'source-{row}.bin')
    for k in (0,1):
        f=out/f'source-{row}-{k}-0.f32';assert hashf(f)==hashf(original/f.name)
        digests.append(dict(owner=row,cursor=k,seed=hashf(out/f'source-{row}-{k}.state'),stereo=hashf(f),frames=f.stat().st_size//8))
assert len(rows)==16
(out/'results.json').write_text(json.dumps(dict(ranges=rows,outputs=digests),indent=2)+'\n')
for r in rows:print(r)
