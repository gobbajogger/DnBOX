from pathlib import Path
import re,subprocess
def install(srcdir,source,build,ccmds,ld):
    inc=(build/'live-prefix.hpp').read_text()
    a=inc.index('struct LivePrefix:FxSpOwner');b=inc.index('    int sampleRate()const',a)
    controls=inc[inc.index('    *phaser0->MinNotch1Freq'):inc.index('    ~LivePrefix')]
    controls=controls[:controls.rfind('    }')]
    raw=next(c for c in ccmds if '-c' in c and c[c.index('-c')+1].endswith('/phaser.c'))
    ph=Path(raw[raw.index('-c')+1]).read_text()
    init=ph[ph.index('int sp_phaser_init('):ph.index('int sp_phaser_compute(')]
    init=init.replace('int sp_phaser_init(sp_data *sp, sp_phaser *p)','int s6_init_phaser(sp_data *sp, sp_phaser *p,void *buffer,unsigned bytes)').replace('phaser *dsp = newphaser();','if(sizeof(phaser)!=bytes)return 0; phaser *dsp=buffer;')
    (build/'phaser-inline.c').write_text(ph+'\n'+init)
    obj=build/'phaser-inline.o'; cc=raw.copy();old=cc[cc.index('-o')+1]
    for flag,path in [('-c',build/'phaser-inline.c'),('-o',obj),('-MF',build/'phaser-inline.d')]:cc[cc.index(flag)+1]=str(path)
    subprocess.run(cc,check=True);ld[ld.index(old)]=str(obj)
    head='''#include "phaser-state-size.hpp"
extern "C" int s6_init_phaser(sp_data*,sp_phaser*,void*,unsigned);
struct LivePrefix {
    const float *parameters=nullptr,*lows=nullptr,*highs=nullptr;
    sp_data *sp;
    float bitcrushIncr=1.f,bitcrushIndex=0.f,bitcrushSampleIndex=0.f,bitcrushValue=0.f;
    sp_osc osc{}; sp_pan2 pan_value{}; sp_phaser phaser_control{}; PinnedPhaserLayout phaser_values{};
    sp_moogladder low[2]{};
    sp_osc *panOscillator=&osc;sp_pan2 *pan=&pan_value;sp_phaser*phaser0=&phaser_control;
    sp_moogladder *loPassInputDelayL=low,*loPassInputDelayR=low+1;
    LivePrefix(int rate,const SourceFx& tables):lows(tables.lows),highs(tables.highs),sp(tables.sp){
        CHECK(sp->sr==rate);
        CHECK(s6_init_phaser(sp,phaser0,&phaser_values,sizeof phaser_values)==SP_OK);
        sp_osc_init(sp,panOscillator,tables.sine,0.f);sp_pan2_init(sp,pan);
        sp_moogladder_init(sp,loPassInputDelayL);sp_moogladder_init(sp,loPassInputDelayR);
''' + controls + '    }\n'
    (build/'live-prefix.hpp').write_text(inc[:a]+head+inc[b:])
    (build/'prefix-shared-test.txt').write_text('The borrowed Soundpipe sample-rate context and pan sine table must retain every byte across the complete independent replay.\n')
    anchor='begin_tracking(&rd,sizeof rd,&prefix,sizeof prefix);'
    source=source.replace(anchor,'sp_data before_context=*fx.sp;std::vector<float> before_sine(fx.sine->tbl,fx.sine->tbl+fx.sine->size);'+anchor)
    source=source.replace('end_tracking(row,k);','CHECK(!std::memcmp(&before_context,fx.sp,sizeof before_context)&&!std::memcmp(before_sine.data(),fx.sine->tbl,before_sine.size()*sizeof(float)));end_tracking(row,k);')
    return source
