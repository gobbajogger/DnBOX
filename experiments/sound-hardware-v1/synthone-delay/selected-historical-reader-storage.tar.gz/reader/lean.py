"""Generate a prefix-only reader from the exact prefix body and checked initialization."""
from pathlib import Path
def create(prefix,measured,build):
    implementation=measured.read_text()
    begin=implementation.index(' void input_prefix(');end=implementation.index(' void frame(',begin)
    body=implementation[begin:end].replace('panOscillator, nil,', 'panOscillator, nullptr,')
    fields=implementation[implementation.index(' sp_ftbl*sine='):implementation.index(' sp_vdelay*delayL=')]
    controls=implementation[implementation.index('    *phaser0->MinNotch1Freq = 100;'):implementation.index('    loPassInputDelayL->freq = getSynthParameter(cutoff);')]
    out='''#pragma once
struct LivePrefix:FxSpOwner {
    const float *parameters=nullptr, *lows=nullptr,*highs=nullptr;
    float bitcrushIncr=1.f,bitcrushIndex=0.f,bitcrushSampleIndex=0.f,bitcrushValue=0.f;
'''+fields+'''
    LivePrefix(int rate,const SourceFx& tables):FxSpOwner(rate),lows(tables.lows),highs(tables.highs) {
        sine=tables.sine;
        sp_phaser_create(&phaser0);sp_phaser_init(sp,phaser0);
        sp_osc_create(&panOscillator);sp_osc_init(sp,panOscillator,sine,0.f);
        sp_pan2_create(&pan);sp_pan2_init(sp,pan);
        sp_moogladder_create(&loPassInputDelayL);sp_moogladder_init(sp,loPassInputDelayL);
        sp_moogladder_create(&loPassInputDelayR);sp_moogladder_init(sp,loPassInputDelayR);
'''+controls+'''
    }
    ~LivePrefix(){
        sp_osc_destroy(&panOscillator);sp_pan2_destroy(&pan);sp_phaser_destroy(&phaser0);
        sp_moogladder_destroy(&loPassInputDelayL);sp_moogladder_destroy(&loPassInputDelayR);
    }
    int sampleRate()const{return sp->sr;}
    float maximum(S1Parameter i)const{return highs[i];}
    float clampedValue(S1Parameter i,float v)const{return std::min(std::max(v,lows[i]),highs[i]);}
'''+body+'};\n'
    state=prefix.read_text().replace('void restore(SourceFx& x) const','template<class FX> void restore(FX& x) const').replace('SourceFx& processor;','LivePrefix& processor;').replace('std::memcpy(s.processor.parameters.data(),kernel.parameters,sizeof(float)*150);','s.processor.parameters=kernel.parameters;')
    (build/'live-prefix.hpp').write_text(out+state)
