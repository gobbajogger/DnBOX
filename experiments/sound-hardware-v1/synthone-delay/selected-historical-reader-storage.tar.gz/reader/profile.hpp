#pragma once
#include <new>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <algorithm>
struct Range {void*p;size_t n;unsigned group;unsigned char *base,*changed;};
static Range ranges[4096];
static unsigned nrange,group;
static void *record_alloc(void*p,size_t n){
    if(p&&group){if(nrange==4096)std::abort();ranges[nrange++]={p,n,group,nullptr,nullptr};}
    return p;
}
static void discard_alloc(void*p){
    if(!p)return;
    for(unsigned j=0;j<nrange;j++)if(ranges[j].p==p){
        __real_free(ranges[j].base);__real_free(ranges[j].changed);
        ranges[j]=ranges[--nrange];return;
    }
}
extern "C" void *__wrap_malloc(size_t n){return record_alloc(fixture_malloc(n),n);}
extern "C" void *__wrap_calloc(size_t n,size_t s){return record_alloc(fixture_calloc(n,s),n*s);}
extern "C" void *__wrap_realloc(void*p,size_t n){void *q=fixture_realloc(p,n);if(q||!n)discard_alloc(p);return q?record_alloc(q,n):q;}
extern "C" void __wrap_free(void*p){discard_alloc(p);fixture_free(p);}
void* operator new(size_t n){void*p=__real_malloc(n?n:1);if(!p)throw std::bad_alloc();return record_alloc(p,n);}
void* operator new[](size_t n){return ::operator new(n);}
void operator delete(void*p) noexcept{discard_alloc(p);__real_free(p);}
void operator delete[](void*p) noexcept{::operator delete(p);}
void operator delete(void*p,size_t) noexcept{::operator delete(p);}
void operator delete[](void*p,size_t) noexcept{::operator delete(p);}
static void begin_tracking(void*rd,size_t rn,void*prefix,size_t pn){
    group=3;record_alloc(rd,rn);group=4;record_alloc(prefix,pn);group=0;
    for(unsigned i=0;i<nrange;i++){
        auto&r=ranges[i];r.base=(unsigned char*)__real_malloc(r.n);r.changed=(unsigned char*)__real_calloc(r.n,1);
        if(!r.base||!r.changed)std::abort();std::memcpy(r.base,r.p,r.n);
    }
}
static void inspect_ranges(){
    for(unsigned i=0;i<nrange;i++){
        auto&r=ranges[i];auto p=(const unsigned char*)r.p;
        if(r.base&&std::memcmp(r.base,p,r.n)!=0)for(size_t j=0;j<r.n;j++)r.changed[j]|=(p[j]!=r.base[j]);
    }
}
static void end_tracking(unsigned row,unsigned k){
    unsigned cnt[5]{},ac[5]{};size_t size[5]{},access[5]{},diff[5]{};
    for(unsigned i=0;i<nrange;i++){
        auto&r=ranges[i];size[r.group]+=r.n;cnt[r.group]++;size_t altered=std::count(r.changed,r.changed+r.n,1);
        if(altered){access[r.group]+=r.n;diff[r.group]+=altered;ac[r.group]++;}
        __real_free(r.base);__real_free(r.changed);
    }
    for(int g=1;g<=4;g++)std::fprintf(stderr,"LIVE %u %u %d %u %zu %u %zu %zu\n",row,k,g,cnt[g],size[g],ac[g],access[g],diff[g]);
    nrange=0;
}
