from pathlib import Path
import subprocess,json,sys
here=Path(__file__).resolve().parent
embedded,reference,soundpipe,tool,out=(Path(x).resolve() for x in sys.argv[1:]);out.mkdir(exist_ok=False)
h=(embedded/'live-prefix.hpp').read_text();a=h.index('struct LivePrefix {');b=h.index('    LivePrefix(int rate',a)
p=(reference/'phaser-state-size.hpp').read_text().replace('#include <cstddef>','#include <stddef.h>')
p=p[p.index('typedef struct'):p.index('constexpr size_t')]
fields=h[a:b].replace('=nullptr','').replace('=1.f','').replace('=0.f','').replace('{}','')
for f in ('=&osc','=&pan_value','=&phaser_control','=low+1','=low'):fields=fields.replace(f,'')
source='#include "soundpipe.h"\n'+p+'\n'+fields+'};\nunsigned char live_prefix[sizeof(struct LivePrefix)];\nunsigned char phaser_state[sizeof(PinnedPhaserLayout)];\n'
(out/'prefix-layout.c').write_text(source)
cc=tool/'pi32v2/bin/clang';dump=tool/'common/bin/objdump'
args=[cc,'-target','pi32v2','-mcpu=r3','-mfprev1','-fno-common','-Oz','-idirafter',tool/'pi32v2/include','-I'+str(soundpipe),'-I'+str(soundpipe/'lib/dr_wav'),'-c',out/'prefix-layout.c','-o',out/'prefix.o']
subprocess.run(args,check=True);z=subprocess.check_output([dump,'-t',out/'prefix.o'],text=True);(out/'symbols.txt').write_text(z)
sizes={r.split()[-1]:int(r.split()[-2],16) for r in z.splitlines() if '.bss' in r}
# Check the extraction against the original C++ class's measured host sizeof before accepting target evidence.
subprocess.run(['cc','-fno-common','-I'+str(soundpipe),'-I'+str(soundpipe/'lib/dr_wav'),'-c',out/'prefix-layout.c','-o',out/'host.o'],check=True)
syms=subprocess.check_output(['nm','-td','-S',out/'host.o'],text=True);hostsz=next(int(r.split()[1]) for r in syms.splitlines() if r.endswith('live_prefix'))
assert hostsz==624 and 0<sizes['live_prefix']<624,(hostsz,sizes)
res=dict(target=sizes,host_validated=hostsz);(out/'report.json').write_text(json.dumps(res,indent=2)+'\n');print(res)
