# Restoring two historical Synth One source cursors in selected firmware storage

Both real production images allocate a Chicago insert and a backend union for each part, plus one 5,120-byte render workspace per part. On Synth One INIT, the Chicago insert's 4,096-byte buffer and 2,764 bytes after the selected backend are available. Part A must also guarantee four 256-float scratch lanes for the 808 metal split, leaving only 1,024 bytes of its render workspace. Part B has no such drum alias and its 5,120-byte workspace is available. The resulting conditional capacities are 7,884 and 11,980 bytes. The Elite and Pro ELF symbol tables and a freestanding target layout reproduce these counts. These capacities apply per selected Synth One part.

The common reservation in this test is 7,628 bytes. Two slots reserve 2,060 bytes each. Each receives independently decodable source state including the original pre-delay effects. The fixture retains the complete 1,024-byte two-core feedback state, one 460-byte original feedback checkpoint and two original numerical source anchors. The second anchor is a compressed XOR residual extending across one physical array boundary. The test destroys both decoded slots and restores them directly from their resident archives, then compares nine complete storage readbacks. Moving the measured two-core feedback state forward leaves the independent part intact. The common reservation leaves 256 conditional bytes for A and 4,352 for B.

In the ordinary host planner the stimulus selected zero metal splits. A separate fixture using the existing fixed-plan build option exercised 352 genuine 808 splits, with nonzero values in all four metal planes. Both fixtures ran the same 362 application renders with and without occupancy and produced the same complete 92,672 stereo frames and 36,420-byte project. Both assignments of the two tested factory records also passed the forced split. All twelve Chicago algorithms were tested after cold re-selection.

A fresh original source graph reads its four seeds back from the occupied firmware fixture. It regenerates the original 17,556 and 9,034 requested stereo input frames for the edited part and 511 at each cursor for the other part. Replacing every other historical address with a NaN pattern and feeding only these independently produced ranges to the two unmodified target feedback workers preserves every output, write and worker state word. Zeroing either range changes 511 or 512 mixed words. Regeneration and feedback simulation were measured separately. The recorded 9,406.277 and 887.723 microseconds are the feedback kernels alone, with captured regenerated audio supplied in emulator memory.

## Live prefix workspace

The diagnostic full-effects object allocated 7,182,412 host bytes in 40 allocations when initialized solely to generate the input to the delay. Building only the pan, crusher, phaser and two input filters used 780 host heap bytes and a 96-byte descriptor. Embedding the necessary original objects in a single structure reduced the descriptor plus heap to 624 host bytes with zero separately allocated heap blocks. The matching PI32v2 layout is 492 bytes including 192 bytes of original phaser state. Both the shared sine table and sample-rate context stayed byte-identical throughout replay. Bounds are immutable source metadata. The physical stored input record includes 224 bytes for this prefix. The expanded prefix and the full active source voice graph must be counted when running the reader.

All three host variants consumed records returned by the application and reproduced the original continuous 4-cursor audio word for word. The original scheduler/voice object still occupies 16,656 host bytes and requested two further allocations totalling 24,576 bytes during construction. The before/after memory observations distinguish bytes that changed at real block boundaries from bytes that merely existed. They cannot identify every read or transient write. Native real-time execution of the source is still open, as are XIP, stack high-water, factory selection and full simultaneous effects. The reserve remains 8,972 bytes in the current stock images.

## Reproduction

Use the same pinned project sources as the neighboring independent-original-input, lossless-source-records, selected-insert-ownership and cascade-work-and-future-reads packets. The former two provide the independent dry/prefix source, records and codec. The cascade packet provides the real two-core worker, seeds and warm inputs. Preserve its data layout as FORK next to its dual/source headers. SLOT_SOURCE is the production INIT checkout with normal stock build/gen and both links. Use new output directories. The record fixtures use two actual owner IDs, 1 and 8. Restore the full original factory build with its generated compiler commands before executing the source replay. Inspect the expected JSON alongside each output.

    python slots/run.py SLOT_SOURCE BASE_OWNERSHIP CODEC FORK ORIGINAL_TRACE STORE
    python workspace/run.py slots BASE_OWNERSHIP CODEC FORK ORIGINAL_TRACE SLOT_SOURCE UNFORCED
    python workspace/run.py slots BASE_OWNERSHIP CODEC FORK ORIGINAL_TRACE SLOT_SOURCE FORCED --forced
    python workspace/swapped.py FORCED/run SWAPPED
    python workspace/target.py SLOT_SOURCE JIELI_TOOLCHAIN slots LAYOUT

Run the earlier continuous original reader with its prefix output argument retained on disk. Its first independent repeat supplies SOURCE_CAPTURE/source-{1,8}-{0,1}-0.f32. CONTINUOUS is the earlier compile directory containing capture.cpp. The live reader compares the read-back seeds and every emitted stereo word, while the composed target test evaluates the unmodified two-core workload.

    python reader/run.py DRY_SOURCE PREFIX_SOURCE VOICE_SOURCE PREFIX_BUILD CONTINUOUS FACTORY_BUILD FORCED/run SOURCE_CAPTURE FULL
    python reader/run.py DRY_SOURCE PREFIX_SOURCE VOICE_SOURCE PREFIX_BUILD CONTINUOUS FACTORY_BUILD FORCED/run SOURCE_CAPTURE LEAN --lean
    python reader/run.py DRY_SOURCE PREFIX_SOURCE VOICE_SOURCE PREFIX_BUILD CONTINUOUS FACTORY_BUILD FORCED/run SOURCE_CAPTURE EMBEDDED --lean --embedded
    python reader/abi.py EMBEDDED PREFIX_BUILD ORIGINAL_SOUNDPIPE_DIR JIELI_TOOLCHAIN PREFIX_LAYOUT
    python slots/compose.py FORK EMBEDDED COMPOSED

All transfers in the firmware fixture use the host application and private scratch files. The target workspace checks read the existing stock ELFs. Neither operation writes a device.
