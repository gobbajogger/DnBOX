#include "firmware/src/app/engine.c"
#include <string.h>
#include <stdlib.h>
#include "records.h"
typedef struct { uint16_t raw[2], packed[2]; } entry_header;
extern unsigned unpack_snapshot(const uint8_t *,unsigned,uint8_t *,unsigned);
static int active(int part){
    return (unsigned)part<NBASS && original_bass[part].kind==ORIGINAL_SOUND_SYNTHONE &&
        original_bass[part].status==ORIGINAL_RUNTIME_OK && !original_fx[part].selected;
}
static unsigned char *insert_base(unsigned part){return (unsigned char*)&original_fx[part].arena;}
static unsigned char *backend_base(unsigned part){return (unsigned char*)&original_bass[part].dsp+sizeof original_bass[part].dsp.synthone;}
_Static_assert(sizeof(struct retained_insert)<=sizeof(((original_chicago_fx2_compact*)0)->arena),"insert capacity");
_Static_assert(sizeof(struct retained_backend)<=sizeof(original_runtime_backend)-sizeof(s1_dry_part),"backend capacity");
#define OFFSET(T,F) offsetof(struct retained_##T,F)
int setup_records(int part,const uint8_t* input,unsigned n){
    if(!active(part)||n<sizeof(entry_header))return 0;
    entry_header h; memcpy(&h,input,sizeof h);
    size_t need=sizeof h+(size_t)h.packed[0]+h.packed[1]+FEEDBACK_WORKERS+FEEDBACK_ANCHOR;
    if(n!=need || !h.raw[0] || !h.raw[1] || h.raw[0]>SOURCE_SLOT || h.raw[1]>SOURCE_SLOT || h.packed[0]+4u>STORED_ANCHOR)return 0;
    uint8_t *i=insert_base(part),*b=backend_base(part);
    const uint8_t *compressed=input+sizeof h;
    if(unpack_snapshot(compressed,h.packed[0],i+OFFSET(insert,long_source),SOURCE_SLOT)!=h.raw[0] ||
       unpack_snapshot(compressed+h.packed[0],h.packed[1],b+OFFSET(backend,short_source),SOURCE_SLOT)!=h.raw[1])return 0;
    memcpy(i+OFFSET(insert,archive),h.raw,2);
    memcpy(i+OFFSET(insert,archive)+2,h.packed,2);
    memcpy(i+OFFSET(insert,archive)+4,compressed,h.packed[0]);
    memcpy(b+OFFSET(backend,source_size),h.raw,sizeof h.raw);uint16_t archive_size=h.packed[0]+4u;
    memcpy(b+OFFSET(backend,archive_size),&archive_size,sizeof archive_size);
    const uint8_t *feedback=compressed+h.packed[0]+h.packed[1];
    memcpy(i+OFFSET(insert,workers),feedback,FEEDBACK_WORKERS);
    memcpy(b+OFFSET(backend,feedback_anchor),feedback+FEEDBACK_WORKERS,FEEDBACK_ANCHOR);
    return 1;
}
int output_records(int part,FILE* f,const unsigned char *new_workers){
    if(!active(part))return 0;
    uint8_t *i=insert_base(part),*b=backend_base(part);
    uint16_t n[3];memcpy(n,b+OFFSET(backend,source_size),sizeof n);
    if(!n[0]||n[0]>SOURCE_SLOT||!n[1]||n[1]>SOURCE_SLOT||n[2]>STORED_ANCHOR)return 0;
    if(new_workers)memcpy(i+OFFSET(insert,workers),new_workers,FEEDBACK_WORKERS);
    return fwrite(i+OFFSET(insert,long_source),1,n[0],f)==n[0] &&
        fwrite(b+OFFSET(backend,short_source),1,n[1],f)==n[1] &&
        fwrite(i+OFFSET(insert,workers),1,FEEDBACK_WORKERS,f)==FEEDBACK_WORKERS &&
        fwrite(b+OFFSET(backend,feedback_anchor),1,FEEDBACK_ANCHOR,f)==FEEDBACK_ANCHOR &&
        fwrite(i+OFFSET(insert,archive),1,n[2],f)==n[2];
}
