from pathlib import Path
import sys,struct,subprocess,shutil,json,os,hashlib
here=Path(__file__).resolve().parent
src,first,codec,fork,feedback,out=(Path(x).resolve() for x in sys.argv[1:])
out.mkdir(exist_ok=False);run=lambda a,**kw:subprocess.run(a,check=True,**kw)
sha=lambda data:hashlib.sha256(data).hexdigest()
(here/'fixture.c').write_text((first/'fixture.c').read_text().split('int main(int argc')[0]+(here/'fixture.inc').read_text())
(here/'hook.c').write_text('#include <stdio.h>\n#include <stddef.h>\n'+(here/'hook-prefix.c').read_text()+(codec/'codec.c').read_text()+'\nint compare_effects('+ (first/'hook.c').read_text().split('int compare_effects(')[1])
run(['c++','-O2','-std=c++17','-ffp-contract=off','-fno-fast-math','-I'+str(fork.parent/'dual/source'),here/'seed.cpp','-o',out/'seed'])
views={};rows={}
for part,row in enumerate((1,8)):
    original=(codec/'data'/f'source-{row}.bin.records').read_bytes();ofs=0;at={}
    while ofs<len(original):
        t,n=struct.unpack_from('<IH',original,ofs);ofs+=6;rec=original[ofs:ofs+n];ofs+=n
        if t in (22050,132300):at[t]=rec
    a,b=at[22050],at[132300]
    da,db=[(codec/'results'/f'{row}-{k}.packed').read_bytes() for k in ('first','second')]
    states=fork/'data'/f'ideal-{row}-256';pre=(states/'initial.bin').read_bytes();end=(states/'native-state-512.bin').read_bytes()
    assert len(pre)==len(end)==1024 and pre!=end
    ck=out/f'feedback-{row}.bin';run([out/'seed',feedback/f'source-{row}.bin',ck])
    saved=ck.read_bytes();assert len(saved)==460
    header=struct.pack('<HHHH',len(a),len(b),len(da),len(db))
    archive=struct.pack('<HH',len(a),len(da))+da
    (out/f'owner-{part}.bin').write_bytes(header+da+db+pre+saved+end)
    views[part]=[a+b+w+saved+archive for w in (pre,end)]
    rows[row]=dict(decoded=[len(a),len(b)],feedback_workers=len(pre),feedback_anchor=len(saved),source_anchor=len(archive),actual_content_bytes=len(views[part][0]),fixed_records_bytes=3980+2528,metadata_bytes=8)
work=out/'src';work.mkdir()
for f in ('firmware','tools','experiments','host','assets','tests','reference','docs'):
    if (src/f).is_dir():(work/f).symlink_to(src/f,target_is_directory=True)
(work/'build').mkdir();shutil.copytree(src/'build/gen',work/'build/gen')
cc=out/'compiler.py'
replace={'firmware/src/app/engine.c':str(here/'hook.c'),'host/x0x_host.c':str(here/'fixture.c')}
cc.write_text('#!'+sys.executable+'\nimport sys,os\nr='+repr(replace)+'\nos.execvp("cc",["cc","-I.",*[r.get(x,x) for x in sys.argv[1:]]])\n');cc.chmod(0o755)
with (out/'build.log').open('w') as log:run(['sh','host/build_host.sh'],cwd=work,env=dict(os.environ,CC=str(cc),X0X_HOST_OUT=str(out/'host')),stdout=log,stderr=log)
results=[]
for mode in (0,1):
    names=[out/(kind+str(mode)+'.bin') for kind in ('pcm','project','records')]
    q=run([out/'host',str(mode),*names[:2],out/'owner-0.bin',out/'owner-1.bin',names[2]],cwd=work,capture_output=True,text=True)
    (out/f'run-{mode}.log').write_text(q.stderr)
    sequence=[(0,0),(1,0),(0,1),(1,0),(1,1),(0,1),(0,1),(1,1),(1,1)]
    expected=b''.join(views[p][after] for p,after in sequence) if mode else b''
    assert names[2].read_bytes()==expected
    results.append(dict(mode=mode,terminal=q.stderr,frames=names[0].stat().st_size//8,project_bytes=names[1].stat().st_size,pcm=sha(names[0].read_bytes()),project=sha(names[1].read_bytes()),checked_storage_views=len(sequence)*mode,checked_storage_bytes=len(expected),checked_storage_hash=sha(expected)))
assert results[0]['pcm']==results[1]['pcm'] and results[0]['project']==results[1]['project']
report=dict(rows=rows,results=results);(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
