#include "checkpoint_core.hpp"
int main(int argc,char**argv){
    assert(argc==3);FILE *in=std::fopen(argv[1],"rb"),*out=std::fopen(argv[2],"wb");assert(in&&out);
    float d=0,f=0;flash_witness_cursor c{};static_assert(sizeof c==452);
    for(unsigned n=0;n<105840;n++){
        Frame row;assert(std::fread(&row,sizeof row,1,in)==1);
        d=0x1.e9d920p-25f+0x1.ffeb66p-1f*d;f=0x1.cd799ap-14f+0x1.ffeb66p-1f*f;
        assert(d==row[2].delay&&f==row[0].feedback);tick(c,row);
    }
    assert(std::fwrite(&c,sizeof c,1,out)==1&&std::fwrite(&d,sizeof d,1,out)==1&&std::fwrite(&f,sizeof f,1,out)==1);
    assert(std::fclose(in)==0&&std::fclose(out)==0);
}
