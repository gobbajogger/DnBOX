#ifndef S6_ACTIVE_RECORDS_H
#define S6_ACTIVE_RECORDS_H
#include <stdint.h>
enum { SOURCE_SLOT = 2060, FEEDBACK_WORKERS = 1024, FEEDBACK_ANCHOR = 460, STORED_ANCHOR = 896 };
struct retained_insert {
    uint8_t long_source[SOURCE_SLOT];
    uint8_t workers[FEEDBACK_WORKERS];
    uint8_t archive[STORED_ANCHOR];
};
struct retained_backend {
    uint8_t short_source[SOURCE_SLOT];
    uint8_t feedback_anchor[FEEDBACK_ANCHOR];
    uint16_t source_size[2], archive_size;
    uint8_t reserved[2];
};
#endif
