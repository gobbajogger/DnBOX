extern int setup_records(int,const uint8_t*,unsigned);
extern int output_records(int,FILE*,const uint8_t*);
static unsigned char incoming[2][8192],later_state[2][1024];
static unsigned in_size[2];
static FILE *proof;
static void read_owner(unsigned p,const char *path){
    FILE *f=fopen(path,"rb");REQUIRE(f);unsigned n=fread(incoming[p],1,sizeof incoming[p],f);
    REQUIRE(n>1024&&n<sizeof incoming[p]&&feof(f));in_size[p]=n-1024;
    memcpy(later_state[p],incoming[p]+in_size[p],1024);REQUIRE(fclose(f)==0);
}
int main(int argc,char **argv){
    REQUIRE(argc==7);int fill=atoi(argv[1]);output=fopen(argv[2],"wb");proof=fopen(argv[6],"wb");REQUIRE(proof&&output);
    read_owner(0,argv[4]);read_owner(1,argv[5]);boot();run_ms(50);
    select_bank(0,ORIGINAL_SOUND_CHICAGO,0);select_bank(1,ORIGINAL_SOUND_CHICAGO,0);
    for(unsigned p=0;p<2;p++){
        REQUIRE(!setup_records(p,incoming[p],in_size[p]));
        REQUIRE(engine_bass_select_preset(p,ORIGINAL_SOUND_SYNTHONE,255,&proj.sound)<0);
        REQUIRE(engine_bass_select_preset(p,ORIGINAL_SOUND_SYNTHONE,0,&proj.sound)==0);
        REQUIRE(!setup_records(p,incoming[p],in_size[p]));
        for(unsigned n=0;engine_bass_preset_pending(p)&&n<700;n++)emit();
        REQUIRE(engine_bass_bank(p)==ORIGINAL_SOUND_SYNTHONE);
        if(fill){REQUIRE(!setup_records(p,incoming[p],in_size[p]-1));REQUIRE(setup_records(p,incoming[p],in_size[p]));}
        play_note(p,47+p*12);
    }
    if(fill){
        REQUIRE(output_records(0,proof,0)&&output_records(1,proof,0));
        REQUIRE(output_records(0,proof,later_state[0])&&output_records(1,proof,0));
        REQUIRE(output_records(1,proof,later_state[1])&&output_records(0,proof,0));
    }
    for(unsigned p=0;p<2;p++){
        REQUIRE(engine_bass_select_preset(p,ORIGINAL_SOUND_CHICAGO,0,&proj.sound)==0);
        if(fill)REQUIRE(output_records(p,proof,0));
        for(unsigned n=0;engine_bass_preset_pending(p)&&n<700;n++)emit();
        REQUIRE(engine_bass_bank(p)==ORIGINAL_SOUND_CHICAGO&&!output_records(p,proof,0));
        play_note(p,55+p);if(!p&&fill)REQUIRE(output_records(1,proof,0));
        select_bank(p,ORIGINAL_SOUND_MIAMI,0);REQUIRE(!output_records(p,proof,0));play_note(p,50+p);
        select_bank(p,ORIGINAL_SOUND_JUNO,0);REQUIRE(!output_records(p,proof,0));play_note(p,53+p);
    }
    REQUIRE(fclose(proof)==0&&fclose(output)==0);FILE *f=fopen(argv[3],"wb");REQUIRE(f&&fwrite(&proj,sizeof proj,1,f)==1&&fclose(f)==0);
    int algorithms=compare_effects();fprintf(stderr,"blocks=%u nonzero=%u project=%zu algorithms=%d\n",blocks,nonzero,sizeof proj,algorithms);
    REQUIRE(algorithms==12&&nonzero);return 0;
}
