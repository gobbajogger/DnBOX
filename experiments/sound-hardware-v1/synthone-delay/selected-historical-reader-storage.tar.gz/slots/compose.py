"""Give unmodified target feedback workers only samples from independent source replays."""
from pathlib import Path
import sys,struct,subprocess,json,hashlib,shutil
here=Path(__file__).resolve().parent;fork,source,out=(Path(x).resolve() for x in sys.argv[1:]);out.mkdir(exist_ok=False)
res=[];prefix=512*(8+8+16+16+8);hashf=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for row in (1,8):
 origin=fork/'data'/f'ideal-{row}-256'
 for mode in ('restored','zero-long','zero-short'):
    dest=out/f'{row}-{mode}';dest.mkdir();shutil.copyfile(origin/'initial.bin',dest/'initial.bin')
    live=(origin/'io.bin').read_bytes()[:prefix];assert len(live)==prefix
    past=bytearray(struct.pack('<I',0x7fc00099)*(176400*2))
    for k,start in enumerate((22136,132344)):
        v=(source/f'source-{row}-{k}-0.f32').read_bytes()
        assert len(v)==(17556 if k==0 else 9034)*8 if row==1 else len(v)==511*8
        if mode==('zero-long','zero-short')[k]:v=bytes(len(v))
        past[start*8:start*8+len(v)]=v
    (dest/'io.bin').write_bytes(live+past)
    t=subprocess.check_output([fork/'dual-run',fork/'data/ideal-long.raw',fork/'data/ideal-short.raw',dest,'512'],text=True)
    ticks=[int(x) for x in t.strip().split(',')]
    entry=dict(row=row,mode=mode,target_feedback_us=max(ticks[4:6])/5760,independent_input_pair_sha256=[hashf(source/f'source-{row}-{k}-0.f32') for k in (0,1)])
    for label in ('mix','detail','state'):
        name=f'native-{label}-512.bin';actual=(dest/name).read_bytes();ref=(origin/name).read_bytes();assert len(actual)==len(ref)
        bad=sum(a!=b for a,b in zip(struct.iter_unpack('<I',actual),struct.iter_unpack('<I',ref)))
        entry[label+'_unequal_words']=bad
    if mode=='restored':assert not any(entry[k+'_unequal_words'] for k in ('mix','detail','state'))
    else:assert entry['mix_unequal_words']>0 and entry['detail_unequal_words']>0
    (dest/'io.bin').unlink();print(entry,flush=True);res.append(entry)
(out/'results.json').write_text(json.dumps(res,indent=2)+'\n')
