# Restarting the original seven voice slots

On each owner, before each of 2,087 subsequent original render blocks, the test saved seven scalar voice records, restored all seven voices and their twelve DSP objects to their initialized values, then reloaded only the recorded state. The original note, oscillator, envelope and filter code calculated the next samples. The six-second score included the same 16 note starts and both live delay edits as the preceding published histories.

| Owner | Compared binary32 words | Unequal with full voice record | Unequal when oscillator phases omitted | Unequal when filter memory omitted |
| --- | ---: | ---: | ---: | ---: |
| Program 1 | 5,292,000 | 0 | 2,624,698 | 2,402,090 |
| Program 8 | 5,292,000 | 0 | 3,012,838 | 2,988,158 |

Both complete trace hashes match the separately retained originals. The PI32v2 compiler measured 216 bytes per voice, or 1,512 bytes for all seven voice slots. That includes the two envelopes, five oscillator phase values, control state and the persistent state of all three filters. Cold voice wiring and waveform tables are reused. Restoring the filters invalidates derived coefficients, which the original DSP reconstructs on first use. The code retains inactive voice histories as well as active ones.

The original sequencer, global random generator, tuning, smoothed controls, pre-delay effects, and delay histories continue running in place during this test. A complete independent seek needs those dependencies and a measured replay schedule. A single 1,512-byte voice checkpoint and two independently advancing dry readers have different storage requirements. Native execution for this experiment covers the record layout. Audio comparison ran on the host.

Run trial.py ORIGINAL_CAPTURE_DIR FACTORY_BUILD DOWNSTREAM_INCLUDE NEW_OUT as for the neighboring source-and-phase experiment. ORIGINAL_CAPTURE_DIR holds capture.cpp and the pinned source-1.bin and source-8.bin. Run target-layout.py JIELI_TOOLCHAIN_ROOT OTHER_NEW_OUT for the ABI. The script extracts the persisted scalar declarations directly from the checked C++ type. Compare ready/results.json and abi/receipts.json. The two negative controls erase the relevant numerical states after resetting each voice.
