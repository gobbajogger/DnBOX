import argparse, hashlib,json,subprocess,tempfile
from pathlib import Path
import numpy as np
ap=argparse.ArgumentParser()
for k in ('source','build','downstream','out'):ap.add_argument(k,type=Path)
a=ap.parse_args();here=Path(__file__).resolve().parent;b=a.build.resolve();out=a.out.resolve();out.mkdir(exist_ok=False)
code=(a.source/'capture.cpp').read_text().replace('constexpr unsigned hz', '#include "checkpoint.hpp"\nconstexpr unsigned hz')
key='    void block(unsigned start,unsigned n) {'
assert code.count(key)==1
code=code.replace(key,'''    std::array<Pristine,7> initial{};
    unsigned resumed=0;
    void remember() {
        pair.o.initializeNoteStates();
        CHECK(pair.o.monoNote->adsr && (*pair.o.noteStates)[0].oscmorph1);
        for(unsigned k=0;k<7;k++) initial[k].remember(k==6?*pair.o.monoNote:(*pair.o.noteStates)[k]);
    }
'''+key+'''
        const char* mode=std::getenv("VOICE_CHECK");
        if(start && mode && std::strcmp(mode,"control")) {
            ++resumed;
            for(unsigned k=0;k<7;k++){
                auto& v=(k==6?*pair.o.monoNote:(*pair.o.noteStates)[k]);
                VoiceHistory checkpoint{};checkpoint.read(v);initial[k].clear(v);
                checkpoint.restore(v,std::atoi(mode));
            }
        }''').replace('    for(unsigned pos=0;pos<end_at;)', '    for(auto*x:owners)x->remember();\n    for(unsigned pos=0;pos<end_at;)').replace('    return word;', '    return word;')
key='        CHECK(std::fclose(x.trace)==0);'
assert code.count(key)==1;code=code.replace(key,'        std::fprintf(stderr,"voice_history=%zu slots=7 restores=%u\\n",sizeof(VoiceHistory),x.resumed);\n'+key)
(out/'capture.cpp').write_text(code)
commands=json.loads((b/'factory-build-commands.json').read_bytes())
cc=next(c.copy() for c in commands if '-c' in c and c[c.index('-c')+1].endswith('/preset_audio.cpp'))
old=cc[cc.index('-o')+1];cc[cc.index('-o')+1]=str(out/'capture.o');cc[cc.index('-MF')+1]=str(out/'capture.d');cc[cc.index('-c')+1]=str(out/'capture.cpp')
cc[1:1]=['-I'+str(here),'-I'+str(a.downstream.resolve())]
subprocess.run(cc,check=True)
ld=[str(out/'capture.o') if v==old else v for v in commands[-1]];ld[ld.index('-o')+1]=str(out/'capture');subprocess.run(ld,check=True)
assets=b/'factory-inputs';import os
results={}
for mode in ('control','0','1','2'):
    with tempfile.TemporaryDirectory(dir=out) as scratch:
        files=Path(scratch)
        p=subprocess.run([out/'capture',assets/'public-morphs.f32',assets/'compact.bin',b/'commands/preset-commands.bin','late',files/'source'],env=dict(os.environ,VOICE_CHECK=mode),check=False,capture_output=True,text=True)
        print(p.stderr,flush=True);p.check_returncode()
        r={'log':p.stderr,'owners':{}};print(mode,p.stderr.strip(),flush=True)
        for owner in (1,8):
            fn=f'source-{owner}.bin';observed=(files/fn).read_bytes();original=(a.source/fn).read_bytes();assert len(observed)==len(original)==21168000
            base=np.frombuffer(original,'<u4');new=np.frombuffer(observed,'<u4');idx=np.flatnonzero(base!=new)
            row={'words':len(new),'different':int(len(idx)),'first_frame':int(idx[0]//20) if len(idx) else None,'sha256':hashlib.sha256(observed).hexdigest(),'reference_sha256':hashlib.sha256(original).hexdigest()}
            r['owners'][owner]=row;print(owner,row,flush=True)
        results[mode]=r
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
