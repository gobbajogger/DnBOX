#pragma once
#include <cstring>
#include <cstdint>
#include <cstdlib>
#include <array>

// A scratch copy of initial, factory-independent object wiring. Kept by the
// test so each reset has the same semantics as resetting an independent voice.
#define DSP_FIELDS(X) X(adsr) X(fadsr) X(oscmorph1) X(oscmorph2) X(subOsc) X(fmOsc) X(noise) X(loPass) X(hiPass) X(bandPass) X(morphCrossFade) X(filterCrossFade)
#include <type_traits>
struct Pristine {
    S1NoteState initial;
#define FIELD(n) std::remove_reference_t<decltype(*initial.n)> n;
    DSP_FIELDS(FIELD)
#undef FIELD
    void remember(S1NoteState& v) {
        initial=v;
#define SAVE(n) n=*v.n;
        DSP_FIELDS(SAVE)
#undef SAVE
    }
    void clear(S1NoteState& v) const {
        v=initial;
#define RESET(n) *v.n=n;
        DSP_FIELDS(RESET)
#undef RESET
    }
};
#undef DSP_FIELDS
struct EnvelopeHistory {
    float atk,dec,sus,rel,a,b,y,prev;
    int32_t mode;
    void read(const sp_adsr& e) { *this={e.atk,e.dec,e.sus,e.rel,e.a,e.b,e.y,e.prev,e.mode}; }
    void put(sp_adsr& e) const { e.atk=atk;e.dec=dec;e.sus=sus;e.rel=rel;e.a=a;e.b=b;e.y=y;e.prev=prev;e.mode=mode; }
};
struct VoiceHistory {
    int32_t stage,velocity,root,transpose;
    float gate,amp,filter;
    float frequency[4],level[5];
    int32_t phase[5];
    EnvelopeHistory envelope[2];
    float ladder[6],nonlinear[3],highpass[2],bandpass[2],bandwidth,band_resonance;
    void read(const S1NoteState& v) {
        stage=v.stage;velocity=v.velocity;root=v.rootNoteNumber;transpose=v.transpose;
        gate=v.internalGate;amp=v.amp;filter=v.filter;
        frequency[0]=v.oscmorph1->freq; frequency[1]=v.oscmorph2->freq;frequency[2]=v.subOsc->freq;frequency[3]=v.fmOsc->freq;
        level[0]=v.oscmorph1->amp;level[1]=v.oscmorph2->amp;level[2]=v.subOsc->amp;level[3]=v.fmOsc->amp;level[4]=v.noise->amp;
        phase[0]=v.oscmorph1->lphs;phase[1]=v.oscmorph2->lphs;phase[2]=v.subOsc->lphs;phase[3]=v.fmOsc->mphs;phase[4]=v.fmOsc->cphs;
        envelope[0].read(*v.adsr);envelope[1].read(*v.fadsr);
        std::memcpy(ladder,v.loPass->delay,sizeof ladder);std::memcpy(nonlinear,v.loPass->tanhstg,sizeof nonlinear);
        std::memcpy(highpass,v.hiPass->a+6,sizeof highpass);std::memcpy(bandpass,v.bandPass->a+6,sizeof bandpass);
        bandwidth=v.bandPass->bw;band_resonance=v.loPass->res;
    }
    void restore(S1NoteState& v,int omit) const {
        v.stage=static_cast<S1NoteState::NoteStateStage>(stage);v.velocity=velocity;v.rootNoteNumber=root;v.transpose=transpose;
        v.internalGate=gate;v.amp=amp;v.filter=filter;
        v.oscmorph1->freq=frequency[0];v.oscmorph2->freq=frequency[1];v.subOsc->freq=frequency[2];v.fmOsc->freq=frequency[3];
        v.oscmorph1->amp=level[0];v.oscmorph2->amp=level[1];v.subOsc->amp=level[2];v.fmOsc->amp=level[3];v.noise->amp=level[4];
        if(omit!=1){v.oscmorph1->lphs=phase[0];v.oscmorph2->lphs=phase[1];v.subOsc->lphs=phase[2];v.fmOsc->mphs=phase[3];v.fmOsc->cphs=phase[4];}
        envelope[0].put(*v.adsr);envelope[1].put(*v.fadsr);
        if(omit!=2){
            std::memcpy(v.loPass->delay,ladder,sizeof ladder);std::memcpy(v.loPass->tanhstg,nonlinear,sizeof nonlinear);
            std::memcpy(v.hiPass->a+6,highpass,sizeof highpass);std::memcpy(v.bandPass->a+6,bandpass,sizeof bandpass);
        }
        v.bandPass->bw=bandwidth;v.loPass->res=band_resonance;
        v.loPass->oldres=-1;v.hiPass->lkf=-1;v.bandPass->lkb=-1;
    }
};
