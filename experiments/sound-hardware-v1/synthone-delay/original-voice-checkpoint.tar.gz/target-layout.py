"""Evaluate the actual same persisted fields with the project's target compiler."""
from pathlib import Path
import argparse,hashlib,json,re,subprocess
ap=argparse.ArgumentParser()
ap.add_argument('tools',type=Path);ap.add_argument('out',type=Path)
a=ap.parse_args();p=Path(__file__).resolve().parent;out=a.out.resolve();out.mkdir(exist_ok=False)
hdr=(p/'checkpoint.hpp').read_text()
types=[]
for name in ('EnvelopeHistory','VoiceHistory'):
 start=hdr.index('struct '+name+' {')
 end=hdr.index('    void read(',start)
 fields=hdr[start:end]
 assert '(' not in fields
 types.append(fields+'};\n')
src=out/'layout.cpp';src.write_text('#include <stdint.h>\n'+''.join(types)+'\nextern "C" { VoiceHistory one_voice; VoiceHistory all_seven[7]; }\n')
tools=a.tools.resolve();cc=tools/'pi32v2/bin/clang';obj=out/'layout.o'
cmd=[str(cc),'-target','pi32v2','-mcpu=r3','-mfprev1','-Oz','-idirafter',str(tools/'pi32v2/include'),'-c',str(src),'-o',str(obj)]
subprocess.run(cmd,check=True);dump=subprocess.check_output([tools/'common/bin/objdump','-t',obj],text=True);(out/'layout.txt').write_text(dump)
sizes={m.group(2):int(m.group(1),16) for l in dump.splitlines() if (m:=re.search(r'([a-fA-F0-9]+)\s+(one_voice|all_seven)$',l))}
assert sizes==dict(one_voice=216,all_seven=1512),sizes
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
(out/'receipts.json').write_text(json.dumps(dict(target='pi32v2 r3 mfprev1',sizes=sizes,source_sha256=h(src),header_sha256=h(p/'checkpoint.hpp'),compiler_sha256=h(cc),object_sha256=h(obj),command=cmd),indent=2)+'\n')
print(sizes)
