#include <stdint.h>
struct EnvelopeHistory {
    float atk,dec,sus,rel,a,b,y,prev;
    int32_t mode;
};
struct VoiceHistory {
    int32_t stage,velocity,root,transpose;
    float gate,amp,filter;
    float frequency[4],level[5];
    int32_t phase[5];
    EnvelopeHistory envelope[2];
    float ladder[6],nonlinear[3],highpass[2],bandpass[2],bandwidth,band_resonance;
};

extern "C" { VoiceHistory one_voice; VoiceHistory all_seven[7]; }
