#include "app/original_runtime.h"
#include <assert.h>
#include <stdio.h>
int main(void) {
    static original_runtime_part parts[2];
    static original_runtime_workspace work;
    float l[64],r[64];
    uint8_t cell[32];
    assert(original_sound_init(cell,ORIGINAL_SOUND_SYNTHONE,0));
    for (unsigned p=0;p<2;p++) assert(original_runtime_init(&parts[p],cell,120,0,0)==1);
    for(unsigned b=0;b<2000;b++) for(unsigned p=0;p<2;p++){
        if (b%21==1) assert(original_runtime_key(&parts[p],ORIGINAL_INPUT_KEYS,40+p*14+b%7,95+p*12)==1);
        if (b%21==18) assert(original_runtime_key(&parts[p],ORIGINAL_INPUT_KEYS,40+p*14+(b-17)%7,0)==1);
        if (b%50==0) assert(original_runtime_param(&parts[p],0,(b%11)*.1f)==1);
        if (b%84==0) assert(original_runtime_param(&parts[p],1,(b%168)?1.f:0.f)==1);
        if (b==775) assert(original_runtime_all_off(&parts[p])==1);
        assert(original_runtime_render(&parts[p],&work,l,r,64)==1);
        assert(fwrite(l,sizeof *l,64,stdout)==64 && fwrite(r,sizeof *r,64,stdout)==64);
    }
}
