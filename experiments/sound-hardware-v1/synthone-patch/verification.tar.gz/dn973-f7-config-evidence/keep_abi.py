from pathlib import Path
import sys,os,subprocess,json,re,hashlib
model=sys.argv[1]; root=Path.cwd()
sys.argv=['build.py']
tc=Path(os.environ['JIELI_TOOLCHAIN'])
os.environ.update(BOARD='smk37',MODEL=model,JIELI_DOCKER='0',X0X_JOBS='2',JIELI_TOOLCHAIN=str(tc),AC79_SDK=os.environ['AC79_SDK'])
sys.path.insert(0,str(root/'tools'))
import build
base=build.tc
symbols=['s1_patch_at','s1_patch_physical','engine_s1_patch_read','engine_s1_patch_set','engine_s1_patch_snapshot']
def retain(tool,*args):
    if tool=='pi32v2/bin/ld' and any(isinstance(a,Path) and a.name=='x0x.elf' for a in args):
        for name in symbols: args=('-u',name,*args)
    return base(tool,*args)
build.tc=retain
rc=build.main()
if rc: raise SystemExit(rc)
out=build.OUT
table=subprocess.check_output([str(tc/'common/bin/objdump'),'-t',str(out/'x0x.elf')],text=True)
for name in symbols:
    assert re.search(r'\s'+name+r'$',table,re.M),name
print('ABI symbols retained:',','.join(symbols))
print('app_sha256',hashlib.sha256((out/'x0x.bin').read_bytes()).hexdigest())
