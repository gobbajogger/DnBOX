#!/bin/sh
set -eu
# Usage: sh unchanged.sh SOURCE_TREE OUTPUT_DIRECTORY
here=$(CDPATH='' cd "$(dirname "$0")" && pwd)
out=$2
mkdir -p "$out"
out=$(CDPATH='' cd "$out" && pwd)
cd "$1"
. tests/host/original_build.sh
backends=$(python3 -c 'import tools.build as b; print(" ".join(b.ORIGINAL_SYNTH_UNITS + b.ORIGINAL_SYNTH_BACKENDS))')
${CC:-cc} -std=c11 -O2 -ffunction-sections -fdata-sections -DX0X_HOST -DX0X_SYNTHONE_PATCH=${X0X_SYNTHONE_PATCH:-0} $ORIGINAL_FLAGS \
    -Ifirmware/src -Ifirmware/src/app -Ifirmware/src/dsp -Ibuild/gen \
    "$here/unchanged.c" $backends -Wl,--gc-sections -lm -o "$out/test"
"$out/test" > "$out/pcm.f32"
sha256sum "$out/pcm.f32"
