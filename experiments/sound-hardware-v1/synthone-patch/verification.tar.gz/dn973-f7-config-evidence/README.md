# Synth One INIT patch build option

Base `03f92a7d94ad29bdb4a6bb238311ba12776401ea`. Candidate patch SHA-256 `1b037f37436553e25f966f390e488ce8bf0d59e73058b6b42769f0200184b185`. This sound-lane experiment binds the controls already consumed by the 44.1 kHz dry INIT voice on either part. Additional factory engines, banks and effects require their production backends.

Set `X0X_SYNTHONE_PATCH=1` for native or host firmware builds. The default firmware excludes the provider and remains byte-identical on both models. Existing OS11 INIT and legacy projects load in both configurations. Only the opt-in build accepts a patch saved with an edit to one of these 13 parameters. The stock validator refuses it. Run the feature suite from the patched tree.

```sh
sh tests/host/synthone_patch_test.sh
```

The whole firmware simulator checked 13 parameter IDs at all 128 positions, with pending/busy/invalid edits, cross-part tokens, applied readback, note-lock admission and release, same-preset reset, and a save/load through the project store. The original 150-entry descriptor table agrees with all 13 exposed physical range endpoints in binary32. The audible-control test compares identically triggered independent parts and includes note, release and retrigger stages. A separate test comparing 2,048,000 bytes of unchanged INIT output against the pinned base also matched. Both traces SHA-256 `97869ae62fee93761802b1bca629fb275e4648abbfe59404c7c833f75cda4223`. Run `sh unchanged.sh BASE_TREE BASE_OUT` followed by `X0X_SYNTHONE_PATCH=1 sh unchanged.sh PATCHED_TREE PATCHED_OUT` and compare the PCM files. The full feature test passed AddressSanitizer and UndefinedBehaviorSanitizer with LeakSanitizer disabled. The existing original sound cell suite's separate leak check reported its ptrace failure.

Default and opt-in model links used the stock SDK and 20260730.1 toolchain. The independent caller-retention build forces the five UI symbols through dead-code elimination. For that build, run `X0X_SYNTHONE_PATCH=1 python3 /path/to/keep_abi.py elite` or `pro` from the patched checkout with JIELI_TOOLCHAIN and AC79_SDK set.

| Result | Elite | Pro |
| --- | ---: | ---: |
| Opt-in occupied application | 547,952 B | 547,944 B |
| Opt-in free XIP | 4,720 B | 4,728 B |
| Free XIP retaining the full editor ABI | 4,080 B | 4,088 B |
| Free pool, both link variants | 8,972 B | 8,972 B |
| Saved Clip startup physical frames matching stock | 30,208 | 30,208 |
| Shift +1 ms strict peak | 11,320 µs | 11,328 µs |
| Raw late / scene late | 1 / 0 | 1 / 0 |
| Changed project bytes out of 36,420 | 11 | 4 |
| First different absolute stereo frame | 120,896 | 120,896 |

The physical +1 ms comparison used the uninstrumented opt-in firmware packages and the existing pinned 922-event stock scene. On both models the saved Clip startup matches stock, including ten nonzero words in its fourth physical half. With physical inputs both parts change the recorded project. Elite changes ten sound bytes and one 909 pattern byte. Pro changes three sound bytes and one 909 pattern byte. These results preclude promotion as a stock-equivalent timing build. All four default artifacts (ELF, raw application, FWSC and linker script) match the pinned stock hashes on each model. The `off-result.json` and `stock-reference.json` records identify each file. The unmodified factory INIT test measures the isolated live engine behavior.
