"""Generate the native verification note from independently validated receipts."""
import json
from pathlib import Path

base = Path(__file__).resolve().parent
data = json.loads((base/'results.json').read_text())
names = ['Chicago', 'Miami', 'Synth One', 'Juno']
lines = ['# Selected-instrument playback on the combined firmware', '',
         'The Elite and Pro packages enable both the SuperJ6 factory loader and the Synth One width editor. These captures exercise the shipping preset selector at preset zero. The SuperJ6 factory mailbox and Synth One width edits have separate host tests.', '',
         '## Native physical PLAY captures', '',
         '| Model | Sounding parts | Part meters, 909 / 808 / A / B / BREAK | DAC peak | Peak callback, µs | Late / xruns | DAC identical to ordinary #985 |',
         '| --- | --- | --- | ---: | ---: | --- | --- |']
short = []
heavy = []
for board, b in data['boards'].items():
    for key, row in b['selected'].items():
        parts = (names[row['bass_kinds'][0]] + ' A, ' + names[row['bass_kinds'][1]] + ' B, BREAK'
                 if key.startswith('bass') else key[3:])
        peaks = ' / '.join(str(i) for i in row['peak_meter_909_808_A_B_BREAK'])
        same = 'yes' if row['pr985_ordinary_comparison']['pcm_sha256_equal'] else 'no'
        lines += [f"| {board.title()} | {parts} | {peaks} | {row['peak_pcm16']:,} | {row['peak_callback_us']:,} | {row['raw_late']} / {row['audio_xruns']} | {same} |"]
        short.append(row)
    heavy.extend((board,k,r) for k,r in b['populated'].items())
assert all(r['runtime_status']==[1,1] for r in short)
assert all(r['stereo_frames']==96768 and r['observed_halves']==188 for r in short)
assert all(r['first_half_second_nonzero_words']==0 and r['last_half_second_nonzero_words']>0 for r in short)
assert all(r['triggered_rows_909_808']==[11,0] or r['triggered_rows_909_808']==[0,11] or r['triggered_rows_909_808']==[0,0] for r in short)
npass=sum(r['passed'] for r in short)
lines += ['',f'{npass} of 8 short scenes passed the original selected-native assertions. Each physical PLAY capture delivered 96,768 stereo frames at 44.1 kHz and 188 guest callbacks, with silence before playback and audible output after playback. Both loaded basses reported ready. Each isolated kit fired all eleven of its rows. All BREAK scenes used the checked-in 909FL loop, re-encoded and verified byte-for-byte in the second user-sample slot.', '',
          '## Populated 922-event scenes', '',
          '| Model | Bass A / B | Completed halves | Peak callback, µs | Actual margin to 11,609 µs | Raw late | Scene late | DMA xruns | All five parts active |',
          '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |']
for board,key,row in heavy:
    s=row['shot']; guest=row['guest']
    ids=' / '.join(names[x] for x in guest['bass_kinds'])
    lines += [f"| {board.title()} | {ids} | {s['halves']} | {s['max_us']:,} | {11609-s['max_us']:+,} | {s['raw_late']} | {row['scene_late']} | {s['audio_xruns']} | {'yes' if row['all_active'] else 'no'} |"]
lines += ['',f"{sum(r['timing_ok'] for _,_,r in heavy)} of 4 populated, unshifted eight-second scenes passed the callback, late-transfer and xrun tests. The stricter sound-lane margin requires a peak of 10,909 µs or less. The WAV payload, both populated kit patterns, bass assignments and 922 physical input events are fixed by the archived fixture.", '',
          '## Reproduction and identities', '',
          'Run the existing selected-native project generator and physical PLAY commands from the fixture README. Set ELF and FWSC to the matching combined-profile board build and SEED to its warmed empty X0X image. For the populated scenes, stage the same bass pairs with both kits, then run heavy.py with each staged seed. The archive includes the actual eight shell commands per board, complete receipts, package and selected input hashes. Each selected shot and both heavy seed copies were verified against their exact 643,072 protected package bytes. The heavy shots also checked the original scene digest, RAM and captured stereo PCM.', '',
          '| Model | Firmware build source | Package SHA-256 | ELF SHA-256 |', '| --- | --- | --- | --- |']
for board,b in data['boards'].items():
    lines += [f"| {board.title()} | `{b['build_head']}` | `{b['package_sha256']}` | `{b['elf_sha256']}` |"]
lines += ['',f"Emulator source `{data['emulator_source']}`. Emulator executable `{short[0]['emulator_sha256']}`. Fixture source `{data['fixture_source']}`. Each emulator ran in strict mode at 360 MHz. These measurements are emulated native firmware results. Original-preset fidelity requires the corresponding reference renders."]
if (base/'stock909-comparison.json').is_file():
    controls=json.loads((base/'stock909-comparison.json').read_text())
    lines += ['', '## Same-source ordinary 909 control', '',
              '| Model | Frames compared | Differing signed PCM16 words | Peak absolute PCM16 difference | Ordinary peak callback, µs | Combined peak callback, µs |',
              '| --- | ---: | ---: | ---: | ---: | ---: |']
    for board,c in controls.items():
        lines += [f"| {board.title()} | {c['ordinary']['stereo_frames']:,} | {c['different_pcm16_words']:,} | {c['max_abs_pcm16']:,} | {c['ordinary']['peak_callback_us']:,} | {c['combined']['peak_callback_us']:,} |"]
    if all(c['equal_pcm_words'] for c in controls.values()):
        lines += ['', 'On both models the current ordinary and combined packages rendered the complete 909 pattern identically. The observed difference from the archived #985 capture is already present in the current ordinary packages. Its underlying cause was not established by this comparison.']
(base/'README.md').write_text('\n'.join(lines)+'\n')
