"""Compare the same 909 project across ordinary and combined native packages."""
from pathlib import Path
import hashlib, json, sys
import numpy as np

base = Path(__file__).resolve().parent
root = base.parents[1]
sys.path.insert(0, str(root / 'joined/tools'))
from fm1_rescue import package_flash_image

rows={}
for board in ('elite','pro'):
    dest=base / ('joined-'+board)
    reads=[]
    captures=[]
    result={}
    for name,profile in [('stock909','ordinary'),('kit909','combined')]:
        scene=dest / name
        build=root / 'delivery-run' / ('joined-'+board+'-'+('stock' if profile=='ordinary' else 'wide'))
        package,=build.glob('*.fwsc')
        r=json.loads((scene/'results.json').read_text())
        ram=scene/'flash.bin'
        payload=package_flash_image(package.read_bytes())
        assert len(payload)==0x9d000 and ram.read_bytes()[:len(payload)]==payload
        pcm=(scene/'stereo.s16le').read_bytes()
        assert hashlib.sha256(pcm).hexdigest()==r['pcm_sha256']
        assert hashlib.sha256(package.read_bytes()).hexdigest()==r['firmware_sha256']
        assert r['passed'] and r['stereo_frames']==96768 and r['triggered_rows_909_808']==[11,0]
        assert r['peak_meter_909_808_A_B_BREAK'][1:]==[0]*4
        reads.append(r)
        captures.append(np.frombuffer(pcm,'<i2').astype(np.int32).reshape(-1,2))
        result[profile]=dict(source_head=(build/'source-head').read_text().strip(),**r)
    assert reads[0]['project_objects_sha256']==reads[1]['project_objects_sha256']
    assert reads[0]['stock_seed_sha256']==reads[1]['stock_seed_sha256']
    assert reads[0]['source_sample_sha256']==reads[1]['source_sample_sha256']
    delta=captures[0]-captures[1]
    changed=np.flatnonzero(np.any(delta!=0,axis=1))
    result.update(equal_pcm_words=not np.any(delta).item(),different_pcm16_words=int(np.count_nonzero(delta)),
                  first_different_stereo_frame=int(changed[0]) if changed.size else None,
                  mismatched_frames=int(changed.size),max_abs_pcm16=int(np.max(np.abs(delta))),
                  rms_pcm16=float(np.sqrt(np.mean(delta.astype(float)**2))))
    rows[board]=result
    print(board, result['equal_pcm_words'],result['different_pcm16_words'],result['first_different_stereo_frame'],result['max_abs_pcm16'],result['ordinary']['peak_callback_us'])
(base/'stock909-comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
