#!/usr/bin/env bash
set -eu
root=$(cd "$(dirname "$0")/../.." && pwd)
board=$1
case "$board" in
    elite) name=smk37-elite; first=(0 1); second=(3 2);;
    pro)   name=smk37;       first=(1 0); second=(2 3);;
    *) exit 2;;
esac
src="$root/joined"
out="$root/superj6/native-smoke/joined-$board"
build="$root/delivery-run/joined-$board-wide"
testdir="$src/experiments/sound-hardware-v1/selected-native"
emu="$root/timing/emu/target/release/fm1-live"
elf="$build/x0x.elf"
fwsc="$build/x0x-$name.fwsc"
seed="$root/delivery-run/wide-sweep-$board/seed/flash.bin"
builder="$root/superj6/native-smoke/joined-builder"
export TMPDIR="$root/superj6/native-smoke/tmp" PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1
mkdir -p "$out"
while [ ! -e "$build/exit" ] || [ ! -x "$builder" ]; do sleep 4; done
test "$(cat "$build/exit")" = 0
(cd "$build" && sha256sum -c SHA256SUMS) >"$out/package-verification.log"
git -C "$src" rev-parse HEAD >"$out/harness-head"
cp "$build/source-head" "$out/build-head"
sha256sum "$builder" "$testdir/project.c" "$testdir/run.py" "$testdir/heavy.py" "$emu" "$elf" "$fwsc" "$seed" >"$out/inputs.sha256"
run() {
    local scene=$1
    local status=0
    shift
    printf '%q ' "$@" >>"$out/commands.log"
    printf '\n' >>"$out/commands.log"
    "$@" >"$out/$scene.log" 2>&1 || status=$?
    printf '%s %s\n' "$scene" "$status" >>"$out/exits"
}
common=("$emu" "$elf" "$fwsc" "$seed" "$builder")
run bass1 python3 "$testdir/run.py" "${common[@]}" "$out/bass1" "${first[@]}"
run bass2 python3 "$testdir/run.py" "${common[@]}" "$out/bass2" "${second[@]}"
run kit909 python3 "$testdir/run.py" --kit 909 "${common[@]}" "$out/kit909" 0 1
run kit808 python3 "$testdir/run.py" --kit 808 "${common[@]}" "$out/kit808" 0 1
run stage1 python3 "$testdir/run.py" --ensemble --stage-only "${common[@]}" "$out/ensemble1-seed" "${first[@]}"
run stage2 python3 "$testdir/run.py" --ensemble --stage-only "${common[@]}" "$out/ensemble2-seed" "${second[@]}"
heavy=(--emulator "$emu" --elf "$elf" --fwsc "$fwsc")
run heavy1 python3 "$testdir/heavy.py" "${heavy[@]}" --seed "$out/ensemble1-seed/flash.bin" --output "$out/ensemble1-heavy" --owners "${first[@]}"
run heavy2 python3 "$testdir/heavy.py" "${heavy[@]}" --seed "$out/ensemble2-seed/flash.bin" --output "$out/ensemble2-heavy" --owners "${second[@]}"
