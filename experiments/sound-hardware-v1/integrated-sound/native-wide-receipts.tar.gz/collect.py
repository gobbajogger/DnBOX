"""Check all expected evidence files and assemble the two-board receipt."""
import hashlib
import json
import sys
from pathlib import Path

base = Path(__file__).resolve().parent
root = base.parents[1]
sys.path.insert(0, str(root / 'joined' / 'tools'))
from fm1_rescue import package_flash_image


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def collect(board):
    capture = base / ('joined-' + board)
    build = root / 'delivery-run' / ('joined-' + board + '-wide')
    package, = build.glob('*.fwsc')
    protected = package_flash_image(package.read_bytes())
    assert len(protected) == 0x9d000
    digest_package = digest(package)
    digest_elf = digest(build / 'x0x.elf')
    digest_emulator = digest(root / 'timing/emu/target/release/fm1-live')
    exits = dict(line.split() for line in (capture / 'exits').read_text().splitlines())
    board_results = dict(build_head=(capture / 'build-head').read_text().strip(),
                         package=package.name, package_sha256=digest_package,
                         elf_sha256=digest_elf, protected_extent_bytes=len(protected),
                         protected_extent_sha256=hashlib.sha256(protected).hexdigest(),
                         selected={}, populated={})
    prior_path = root / 'joined/experiments/sound-hardware-v1/selected-native/results.json'
    prior = read(prior_path)
    for name in ('bass1', 'bass2', 'kit909', 'kit808'):
        scene = capture / name
        result = read(scene / 'results.json')
        flash = scene / 'flash.bin'
        assert result['firmware_sha256'] == digest_package
        assert result['elf_sha256'] == digest_elf
        assert result['emulator_sha256'] == digest_emulator
        assert flash.read_bytes()[:len(protected)] == protected
        assert result['initial_flash_sha256'] == digest(flash)
        assert result['pcm_sha256'] == digest(scene / 'stereo.s16le')
        assert int(exits[name]) == (0 if result['passed'] else 1)
        suffix = name[3:] if name.startswith('kit') else ''.join(map(str, result['bass_kinds']))
        ordinary = prior[board + '-' + suffix]
        result['pr985_ordinary_comparison'] = {
            'reference_key': board + '-' + suffix,
            'reference_package_sha256': ordinary['firmware_sha256'],
            'pcm_sha256_equal': ordinary['pcm_sha256'] == result['pcm_sha256'],
            'project_objects_sha256_equal': ordinary['project_objects_sha256'] == result['project_objects_sha256'],
            'reference_peak_us': ordinary['peak_callback_us'],
        }
        board_results['selected'][name] = result
    for i in (1, 2):
        label = f'ensemble{i}'
        scene = capture / (label + '-heavy')
        seed = capture / (label + '-seed')
        result = read(scene / 'results.json')
        provenance = read(seed / 'inputs.json')
        assert result['fwsc_sha256'] == digest_package
        assert result['elf_sha256'] == digest_elf
        assert result['emulator_sha256'] == digest_emulator
        assert result['seed_sha256'] == provenance['initial_flash_sha256'] == digest(seed / 'flash.bin')
        assert (seed / 'flash.bin').read_bytes()[:len(protected)] == protected
        assert int(exits[f'stage{i}']) == 0
        assert int(exits[f'heavy{i}']) == (0 if result['passed'] else 1)
        for shotname, key in (('boot', 'boot'), ('heavy', 'shot')):
            shot = result[key]
            assert shot['initial_flash_sha256'] == result['seed_sha256']
            assert shot['final_flash_sha256'] == digest(scene / shotname / 'flash.bin')
            assert shot['pcm_sha256'] == digest(scene / shotname / 'stereo.s16le')
            assert shot['scene_sha256'] == digest(scene / shotname / 'scene.keys')
        assert result['guest']['pcm_sha256'] == result['shot']['pcm_sha256']
        board_results['populated'][label] = dict(project=provenance, **result)
    return board_results


def main():
    data = dict(profile='Widest native SuperJ6 factory loader and Synth One width option',
                fixture_source='7597ce1ca32c188d4bb8c44acbdf4823391c1538',
                emulator_source='ba83317aa55cbcdb2830c5da97d5f64b763499e2',
                boards={board: collect(board) for board in ('elite', 'pro')})
    (base / 'results.json').write_text(json.dumps(data, indent=2) + '\n')
    for board, receipts in data['boards'].items():
        for name, r in receipts['selected'].items():
            print(board,name,r['passed'],r['bass_kinds'],r['peak_meter_909_808_A_B_BREAK'],r['triggered_rows_909_808'],
                  r['observed_halves'],r['peak_callback_us'],r['raw_late'],r['audio_xruns'],r['peak_pcm16'])
        for name, r in receipts['populated'].items():
            s = r['shot']
            print(board,name,r['passed'],r['guest']['bass_kinds'],r['guest']['peak_meter_909_808_A_B_BREAK'],
                  r['guest']['triggered_rows_909_808'],s['halves'],s['max_us'],s['raw_late'],r['scene_late'],s['audio_xruns'])
if __name__ == '__main__':
    main()
