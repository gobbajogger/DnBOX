#!/usr/bin/env bash
set -eu
root=$(cd "$(dirname "$0")/../.." && pwd)
board=$1
name=smk37
if [ "$board" = elite ]; then name=smk37-elite; fi
out="$root/superj6/native-smoke/joined-$board"
build="$root/delivery-run/joined-$board-stock"
while [ ! -f "$out/exits" ] || ! rg -q '^heavy2 ' "$out/exits" || [ ! -f "$build/exit" ]; do sleep 5; done
test "$(cat "$build/exit")" = 0
(cd "$build" && sha256sum -c SHA256SUMS) >"$out/stock-verification.log"
export TMPDIR="$root/superj6/native-smoke/tmp" PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1
args=(python3 "$root/joined/experiments/sound-hardware-v1/selected-native/run.py" --kit 909 "$root/timing/emu/target/release/fm1-live" "$build/x0x.elf" "$build/x0x-$name.fwsc" "$root/delivery-run/wide-sweep-$board/seed/flash.bin" "$root/superj6/native-smoke/joined-builder" "$out/stock909" 0 1)
printf '%q ' "${args[@]}" >"$out/stock909-command.log"
printf '\n' >>"$out/stock909-command.log"
status=0
"${args[@]}" >"$out/stock909.log" 2>&1 || status=$?
echo "$status" >"$out/stock909-exit"
