# Selected-instrument playback on the combined firmware

The Elite and Pro packages enable both the SuperJ6 factory loader and the Synth One width editor. These captures exercise the shipping preset selector at preset zero. The SuperJ6 factory mailbox and Synth One width edits have separate host tests.

## Native physical PLAY captures

| Model | Sounding parts | Part meters, 909 / 808 / A / B / BREAK | DAC peak | Peak callback, µs | Late / xruns | DAC identical to ordinary #985 |
| --- | --- | --- | ---: | ---: | --- | --- |
| Elite | Chicago A, Miami B, BREAK | 0 / 0 / 6326 / 8253 / 28672 | 13,124 | 7,064 | 0 / 0 | yes |
| Elite | Juno A, Synth One B, BREAK | 0 / 0 / 1362 / 2429 / 32767 | 13,129 | 7,226 | 0 / 0 | yes |
| Elite | 909 | 24487 / 0 / 0 / 0 / 0 | 13,113 | 7,979 | 0 / 0 | no |
| Elite | 808 | 0 / 16008 / 0 / 0 / 0 | 13,122 | 8,974 | 0 / 0 | yes |
| Pro | Miami A, Chicago B, BREAK | 0 / 0 / 9516 / 7229 / 32767 | 13,116 | 7,272 | 0 / 0 | yes |
| Pro | Synth One A, Juno B, BREAK | 0 / 0 / 2622 / 1996 / 32767 | 13,129 | 7,182 | 0 / 0 | yes |
| Pro | 909 | 24487 / 0 / 0 / 0 / 0 | 13,113 | 7,968 | 0 / 0 | no |
| Pro | 808 | 0 / 16008 / 0 / 0 / 0 | 13,122 | 8,968 | 0 / 0 | yes |

8 of 8 short scenes passed the original selected-native assertions. Each physical PLAY capture delivered 96,768 stereo frames at 44.1 kHz and 188 guest callbacks, with silence before playback and audible output after playback. Both loaded basses reported ready. Each isolated kit fired all eleven of its rows. All BREAK scenes used the checked-in 909FL loop, re-encoded and verified byte-for-byte in the second user-sample slot.

## Populated 922-event scenes

| Model | Bass A / B | Completed halves | Peak callback, µs | Actual margin to 11,609 µs | Raw late | Scene late | DMA xruns | All five parts active |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| Elite | Chicago / Miami | 565 | 13,706 | -2,097 | 72 | 72 | 72 | yes |
| Elite | Juno / Synth One | 609 | 12,901 | -1,292 | 27 | 27 | 27 | yes |
| Pro | Miami / Chicago | 536 | 15,576 | -3,967 | 100 | 100 | 100 | yes |
| Pro | Synth One / Juno | 517 | 14,790 | -3,181 | 119 | 119 | 119 | yes |

0 of 4 populated, unshifted eight-second scenes passed the callback, late-transfer and xrun tests. The stricter sound-lane margin requires a peak of 10,909 µs or less. The WAV payload, both populated kit patterns, bass assignments and 922 physical input events are fixed by the archived fixture.

## Reproduction and identities

Run the existing selected-native project generator and physical PLAY commands from the fixture README. Set ELF and FWSC to the matching combined-profile board build and SEED to its warmed empty X0X image. For the populated scenes, stage the same bass pairs with both kits, then run heavy.py with each staged seed. The archive includes the actual eight shell commands per board, complete receipts, package and selected input hashes. Each selected shot and both heavy seed copies were verified against their exact 643,072 protected package bytes. The heavy shots also checked the original scene digest, RAM and captured stereo PCM.

| Model | Firmware build source | Package SHA-256 | ELF SHA-256 |
| --- | --- | --- | --- |
| Elite | `0d1314234e539d5a129608c8aeb80cbb232c5ad4` | `8dd6d34f489b4513e00b0510b87f80ddc605cd37e08d5364425f19b58c8e5b1f` | `f73101e69ccc36c021be0efcb2f46539d787bfd230d329a855db707b6c43b565` |
| Pro | `ce89f1d529e656430f4cec5b5b71012d59bd3afd` | `1ca8a369608d7c175a3c7e43c156cb68dbe7f2918ed1b34c35242ca66f18ab77` | `9e508e21aee67d382f184ce55f18feeaf5beea2e60f2e5bcef2adcce33c1e7d7` |

Emulator source `ba83317aa55cbcdb2830c5da97d5f64b763499e2`. Emulator executable `086c9134b9e1047c99401d367a45d7906f6bd1a0342af3273efae15fd7c00b6e`. Fixture source `7597ce1ca32c188d4bb8c44acbdf4823391c1538`. Each emulator ran in strict mode at 360 MHz. These measurements are emulated native firmware results. Original-preset fidelity requires the corresponding reference renders.

## Same-source ordinary 909 control

| Model | Frames compared | Differing signed PCM16 words | Peak absolute PCM16 difference | Ordinary peak callback, µs | Combined peak callback, µs |
| --- | ---: | ---: | ---: | ---: | ---: |
| Elite | 96,768 | 0 | 0 | 7,875 | 7,979 |
| Pro | 96,768 | 0 | 0 | 7,876 | 7,968 |

On both models the current ordinary and combined packages rendered the complete 909 pattern identically. The observed difference from the archived #985 capture is already present in the current ordinary packages. Its underlying cause was not established by this comparison.
