#define _POSIX_C_SOURCE 200809L
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "chicago_packed.h"
extern int chicago_raw_bits(uint32_t, uint32_t *, uint32_t *);
static pthread_barrier_t paused, written;
void force_test_interleaving(void) {
    pthread_barrier_wait(&paused);
    pthread_barrier_wait(&written);
}
static void *first(void *unused) {
    float a,e;
    (void)unused;
    original_chicago_packed_lookup(NULL,31,&a,&e);
    return NULL;
}
int main(void) {
    pthread_t owner;
    pthread_barrier_init(&paused,NULL,2);
    pthread_barrier_init(&written,NULL,2);
    pthread_create(&owner,NULL,first,NULL);
    pthread_barrier_wait(&paused);
    float a,e;
    original_chicago_packed_lookup(NULL,16383,&a,&e);
    pthread_barrier_wait(&written);
    pthread_join(owner,NULL);
    original_chicago_packed_lookup(NULL,31,&a,&e);
    uint32_t ra,re,got_a,got_e;
    chicago_raw_bits(31,&ra,&re);
    memcpy(&got_a,&a,4); memcpy(&got_e,&e,4);
    printf("Index 31 returned a=%08x,e=%08x after controlled interleaving; expected a=%08x,e=%08x\n",got_a,got_e,ra,re);
    return got_a==ra && got_e==re;
}
