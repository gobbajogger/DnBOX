"""Record candidate/qualified binary identities, resource budgets and physical comparisons."""
from pathlib import Path
import json, re, hashlib, subprocess
base=Path(__file__).resolve().parent
root=base.parents[1]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read_build(p):
    assert (p/'exit').read_text().strip()=='0'
    report=(p/'build.log').read_text()
    return dict(sha256={x.name:sha(x) for x in [p/'x0x.elf',p/'x0x.bin',p/'ota.bin',*p.glob('*.fwsc')]},
                xip_free=int(re.findall(r'XIP free: (\d+) B',report)[-1]),
                pool_free=int(re.findall(r'pool raw free: (\d+) B',report)[-1]),
                binary_size=(p/'x0x.bin').stat().st_size)
results=dict(candidate_patch_sha256=sha(base/'owner-cache.patch'),base_commit=subprocess.check_output(['git','-C',str(base.parent/'reader-review'),'rev-parse','HEAD'],text=True).strip(),builds={},ordinary_plus1={})
for board in ('elite','pro'):
    for profile in ('wide','stock'):
        name=board+'-'+profile
        old=read_build(root/'delivery-run'/('joined-'+name))
        new=read_build(base/name)
        results['builds'][name]=dict(reference=old,candidate=new,all_images_byte_identical=old['sha256']==new['sha256'])
    results['ordinary_plus1'][board]=json.loads((base/(board+'-plus1')/'comparison.json').read_text())
(base/'qualification.json').write_text(json.dumps(results,indent=2)+'\n')
print(results['base_commit'],results['candidate_patch_sha256'])
for k,x in results['builds'].items():
    print(k,x['all_images_byte_identical'],x['reference']['xip_free'],x['candidate']['xip_free'],x['reference']['pool_free'],x['candidate']['pool_free'])
for b,r in results['ordinary_plus1'].items(): print(b,r['old']['max_us'],r['new']['max_us'],r['new']['raw_late'],r['first_different_stereo_frame'],r['changed_frames_in_common_prefix'],len(r['different_project_offsets']))
