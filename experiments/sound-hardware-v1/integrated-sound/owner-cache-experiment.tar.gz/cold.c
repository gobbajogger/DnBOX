#include <stdio.h>
#include <stdint.h>
#include "chicago_packed.h"
int main(void) {
 float a=1.0f,e=2.0f;
 int ok=original_chicago_packed_lookup(NULL,UINT32_MAX,&a,&e);
 printf("cold UINT32_MAX -> %d, %.1f, %.1f\n",ok,(double)a,(double)e);
 return 0;
}
