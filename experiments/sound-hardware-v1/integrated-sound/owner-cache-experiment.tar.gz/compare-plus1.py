"""Run the original +1 ms physical scenario with identical user-state bytes."""
from pathlib import Path
from types import SimpleNamespace
import argparse, json, sys, time, hashlib
import numpy as np

here=Path(__file__).resolve().parent
root=here.parents[1]
repo=here.parent/'reader-review'
base=repo/'experiments/sound-hardware-v1'
sys.path[:0]=[str(base/'strict-timing'),str(base/'sj6-factory/native'),str(repo/'tools')]
from score_scene import read_project
from fm1_rescue import package_flash_image
import replay

board=sys.argv[1]
new=here/(board+'-stock')
while not (new/'exit').exists(): time.sleep(3)
assert (new/'exit').read_text().strip()=='0'
old=root/'delivery-run'/('joined-'+board+'-stock')
src=root/'delivery-run'/('joined-stock-sweep-'+board)
out=here/(board+'-plus1')
out.mkdir()
old_pkg,=old.glob('*.fwsc'); new_pkg,=new.glob('*.fwsc')
old_image=package_flash_image(old_pkg.read_bytes()); new_image=package_flash_image(new_pkg.read_bytes())
old_seed=(src/'seed/flash.bin').read_bytes()
assert len(old_image)==len(new_image)==0x9d000 and len(old_seed)==0x100000 and old_seed[:len(old_image)]==old_image
new_seed=out/'seed.bin'; new_seed.write_bytes(new_image+old_seed[len(old_image):])
assert new_seed.read_bytes()[len(old_image):]==old_seed[len(old_image):]
scene=base/'strict-timing/heavy.keys'
assert replay.digest(scene)=='d08718b1521119b252b5cca0c5e1db6981ea25a5a0b31b6ead60dceccb3f6271'
events=[(int(t.split(':',1)[0]),t.split(':',1)[1]) for t in scene.read_text().strip().split(',')]
args=SimpleNamespace(output=out,elf=new/'x0x.elf',fwsc=new_pkg,emulator=root/'timing/emu/target/release/fm1-live')
run=replay.run(args,replay.read_symbols(args.elf),events,'shift1',8000,1,new_seed)
ref=json.loads((src/'shift1/result.json').read_text())
report=json.loads((src/'sweep.json').read_text())
assert report['fwsc_sha256']==replay.digest(old_pkg) and report['elf_sha256']==replay.digest(old/'x0x.elf') and report['emulator_sha256']==replay.digest(args.emulator)
assert ref['initial_flash_sha256']==replay.digest(src/'seed/flash.bin')
assert ref['scene_sha256']==run['scene_sha256']
def hashbytes(x): return hashlib.sha256(x).hexdigest()
pp=read_project(old/'x0x.elf',src/'shift1'); qq=read_project(new/'x0x.elf',out/'shift1')
assert len(pp)==len(qq)
a=np.fromfile(src/'shift1/stereo.s16le',dtype='<i2').reshape(-1,2); b=np.fromfile(out/'shift1/stereo.s16le',dtype='<i2').reshape(-1,2)
n=min(len(a),len(b))
diff=(a[:n]!=b[:n]).any(axis=1); changed=np.flatnonzero(diff)
result=dict(board=board,matched_user_region_sha256=hashbytes(old_seed[len(old_image):]),old_package_sha256=replay.digest(old_pkg),new_package_sha256=replay.digest(new_pkg),old_elf_sha256=replay.digest(old/'x0x.elf'),new_elf_sha256=replay.digest(args.elf),old=ref,new=run,
 first_different_stereo_frame=int(changed[0]) if len(changed) else (n if len(a)!=len(b) else None),changed_frames_in_common_prefix=int(diff.sum()),old_frames=len(a),new_frames=len(b),project_size=len(pp),old_project_sha256=hashbytes(pp),new_project_sha256=hashbytes(qq),different_project_offsets=[i for i,(x,y) in enumerate(zip(pp,qq)) if x!=y])
(out/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(board,result['first_different_stereo_frame'],result['different_project_offsets'],run['max_us'],run['raw_late'],run['audio_xruns'])
