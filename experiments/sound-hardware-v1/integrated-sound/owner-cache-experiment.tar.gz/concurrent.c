/* Diagnostic: both threads check their entire output pair against the original binary32 provider. */
#define _POSIX_C_SOURCE 200809L
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "chicago_packed.h"
extern int chicago_raw_bits(uint32_t idx, uint32_t *a, uint32_t *e);
static pthread_barrier_t barrier;
typedef struct {
    unsigned owner, failures;
#if CHECK_OWNER
    original_chicago_packed_cache cache;
#endif
} worker;
static const uint32_t indices[4] = {15998, 15999, 14334, 14335};
static uint32_t expected[4][2];
static void *drive(void *arg) {
    worker *w=arg;
    pthread_barrier_wait(&barrier);
    for (unsigned n=0;n<600000;++n) {
        unsigned which=2 * w->owner + ((n>>1)&1);
        float a=0,e=0;
#if CHECK_OWNER
        int ok=original_chicago_owned_lookup(&w->cache,indices[which],&a,&e);
#else
        int ok=original_chicago_packed_lookup(NULL,indices[which],&a,&e);
#endif
        if (!ok || memcmp(&a,&expected[which][0],4) || memcmp(&e,&expected[which][1],4)) ++w->failures;
    }
    return NULL;
}
int main(void) {
    worker w[2]={{.owner=0},{.owner=1}};
    pthread_t th[2];
    for (int i=0;i<4;++i) if (!chicago_raw_bits(indices[i],&expected[i][0],&expected[i][1]))return 2;
    if (pthread_barrier_init(&barrier,NULL,2))return 2;
    for (int i=0;i<2;++i)if(pthread_create(&th[i],NULL,drive,&w[i]))return 2;
    for (int i=0;i<2;++i)if(pthread_join(th[i],NULL))return 2;
    printf("%u wrong pairs of 1200000 (owner0 %u, owner1 %u)\n",w[0].failures+w[1].failures,w[0].failures,w[1].failures);
    return (w[0].failures+w[1].failures)!=0;
}
