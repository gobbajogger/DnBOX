#include "original_runtime.h"
unsigned char check_chicago_backend[sizeof(original_chicago_backend)];
unsigned char check_runtime_part[sizeof(original_runtime_part)];
