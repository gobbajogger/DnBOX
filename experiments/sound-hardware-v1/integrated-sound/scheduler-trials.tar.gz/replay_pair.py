#!/usr/bin/env python3
"""Compare an independent scheduler build to a same-board, same-profile capture."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys
from types import SimpleNamespace


def stack_snapshot(symbols, memory):
    base = 0x01c00000
    begin = symbols["_c1_ustack"] - base
    top = symbols["_c1_ustack_top"] - base
    if top - begin != 4352:
        raise ValueError("Unexpected CPU1 stack extent")
    untouched = 0
    for offset in range(begin, top, 4):
        if memory[offset:offset+4] != struct.pack("<I", 0x43314d4b):
            break
        untouched += 4
    crash = symbols["fm1_crash"] - base
    return dict(stack_bytes=4352, untouched_bytes=untouched,
                used_upper_span=4352-untouched, headroom_above_256_byte_guard=untouched-256,
                crash_magic=memory[crash:crash+4].hex(),
                crash_count=int.from_bytes(memory[crash+4:crash+8], "little"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("checkout", "emulator", "reference_elf", "reference_fwsc", "reference_run",
                 "reference_seed", "candidate_elf", "candidate_fwsc", "output"):
        parser.add_argument("--" + name.replace("_", "-"), required=True,
                            type=lambda s: Path(s).resolve())
    parser.add_argument("--existing", action="store_true", help="Verify existing boot and live captures")
    parser.add_argument("--populated", action="store_true", help="Measure the saved ensemble and sample")
    args = parser.parse_args()
    if not __debug__:
        parser.error("Run with Python assertions enabled")
    evidence = args.checkout / "experiments/sound-hardware-v1"
    sys.path.insert(0, str(evidence/"strict-timing"))
    import replay
    from fm1_rescue import package_flash_image
    sys.path.insert(0, str(evidence/"sj6-factory/native"))
    from score_scene import read_project, compare_raw

    digest = replay.digest
    ref = json.loads((args.reference_run/"result.json").read_bytes())
    assert (ref["duration_ms"], ref["strict"], ref["mhz"], ref["events"]) == (8000, 1, 360, 922)
    replay.validate_seed(args.reference_fwsc, args.reference_seed)
    assert digest(args.reference_seed) == ref["initial_flash_sha256"]
    source = args.reference_seed.read_bytes()
    protected = package_flash_image(args.candidate_fwsc.read_bytes())
    assert len(protected) == 0x9d000
    merged = protected + source[len(protected):]
    seed = args.output/"flash-seed.bin"
    if not args.existing:
        args.output.mkdir(parents=True)
        seed.write_bytes(merged)
    replay.validate_seed(args.candidate_fwsc, seed)
    assert seed.read_bytes() == merged
    canonical = evidence/"strict-timing/heavy.keys"
    assert digest(canonical) == "d08718b1521119b252b5cca0c5e1db6981ea25a5a0b31b6ead60dceccb3f6271"
    events = [(int(t), e) for t, e in (word.split(":", 1) for word in canonical.read_text().strip().split(","))]
    shift = ref["shift_ms"]
    syms = replay.read_symbols(args.candidate_elf)
    if not args.existing:
        engine = SimpleNamespace(emulator=args.emulator, elf=args.candidate_elf,
                                 fwsc=args.candidate_fwsc, output=args.output)
        replay.run(engine, syms, events, "boot", 2000, 0, seed)
        replay.run(engine, syms, events, "live", 8000, shift, seed)
    live = args.output/"live"
    row = json.loads((live/"result.json").read_bytes())
    boot = json.loads((args.output/"boot/result.json").read_bytes())
    assert (boot["duration_ms"], boot["strict"], boot["mhz"],boot["initial_flash_sha256"]) == (2000,1,360,digest(seed))
    assert (row["duration_ms"], row["strict"], row["mhz"], row["shift_ms"], row["events"]) == (8000,1,360,shift,922)
    assert row["initial_flash_sha256"] == digest(seed)
    expected_scene = ",".join(f"{t+shift}:{e}" for t,e in events) + "\n"
    assert all((path/"scene.keys").read_text() == expected_scene for path in (args.reference_run,live))
    ref_symbols = replay.read_symbols(args.reference_elf)
    for path, summary, fw, symbols in ((args.output/"boot",boot,args.candidate_fwsc,syms),
                                        (live,row,args.candidate_fwsc,syms),
                                        (args.reference_run,ref,args.reference_fwsc,ref_symbols)):
        log_text = (path/"run.log").read_text()
        assert f"panel.ppm at {summary['duration_ms']} ms" in log_text and "skipped 0 cycles" in log_text
        replay.validate_seed(fw, path/"flash.bin")
        assert digest(path/"flash.bin") == summary["final_flash_sha256"]
        assert digest(path/"scene.keys") == summary["scene_sha256"]
        assert digest(path/"stereo.s16le") == summary["pcm_sha256"]
        assert (path/"stereo.s16le").stat().st_size == summary["pcm_bytes"]
        memory = (path/"ram.bin").read_bytes()
        debug = struct.unpack_from("<13I", memory, symbols["x0x_dbg"]-0x01c00000)
        assert (debug[0], debug[1], debug[2], debug[5]) == (0x44424731,summary["halves"],summary["max_us"],summary["raw_late"])
        assert struct.unpack_from("<I",memory,symbols["audio_xruns"]-0x01c00000)[0] == summary["audio_xruns"]
    project = read_project(args.candidate_elf, live)
    original = read_project(args.reference_elf, args.reference_run)
    original_hash = hashlib.sha256(original).hexdigest()
    result = compare_raw(args.reference_run, args.reference_elf, {**ref, "elf_sha256": digest(args.reference_elf)},
                         original_hash, (live/"stereo.s16le").read_bytes(), project)
    result.update(reference=ref, candidate=row, boot=boot, headroom_us=11609-row["max_us"],
                  source_scene_sha256=digest(canonical), emulator_sha256=digest(args.emulator),
                  reference_elf_sha256=digest(args.reference_elf), reference_package_sha256=digest(args.reference_fwsc),
                  candidate_elf_sha256=digest(args.candidate_elf), candidate_package_sha256=digest(args.candidate_fwsc),
                  initial_identical_user_area_sha256=hashlib.sha256(source[len(protected):]).hexdigest(),
                  candidate_project_sha256=hashlib.sha256(project).hexdigest(), reference_project_sha256=original_hash,
                  stack=stack_snapshot(syms,(live/"ram.bin").read_bytes()),
                  reference_stack=stack_snapshot(ref_symbols,(args.reference_run/"ram.bin").read_bytes()))
    if args.populated:
        sys.path.insert(0, str(evidence/"selected-native"))
        from run import measure
        result["runtime"] = measure(args.candidate_elf,live,duration_ms=8000)
    print(json.dumps(result,indent=2))


if __name__ == "__main__":
    main()
