# Joined-source scheduler trials

Both patches apply independently to DnBOX commit `5837c73f754a667c526edd420aefbe7cf3a071bf`. The strict dual-core emulator records the stereo words sent to its modeled DAC. The controls have identical firmware, tool, asset and original-synth sources to that commit. `measurements.json` identifies each actual ELF, package, matched user area, physical stereo capture and final 36,420-byte project. It also records the measured timing and any changed stereo frames or project bytes.

## Changes

- `planner-only.patch` suppresses downward updates to Chicago’s estimated cost during sequenced rests when the smoothed load is at or above its existing 65% guard-release threshold. It changes the planner’s cost estimate.
- `all-job-eligibility.patch` allows the planner to assign any render job to CPU1. The previous planner admitted Miami and blocked the other bass engines. Its comment describes a 2,816-byte stack. The current native ELF reserves 4,352 bytes and the platform protects the lowest 256. The initial stack fill permits measurement of the untouched lower prefix in each captured run. The observed upper span covers these fixtures and does not establish a worst-case bound. The two changes were tested separately.

The ordinary scene replays 922 panel input events shifted +1 ms. Populated scenes use the same 922 inputs unshifted. Ensemble 1 runs Miami and Chicago. Ensemble 2 runs Juno and SynthOne. The populated user projects also contain the user-slot BREAK sample and patterns covering all eleven rows in both kits. The wide profile uses `X0X_SUPERJ6_FACTORY=1`, `X0X_SYNTHONE_PATCH=1` and `X0X_SYNTHONE_WIDEN=1`. Raw late and xrun counters are from the full eight seconds. Each active profile also has a two-second boot control with its same seed.

## Reproduction

1. Check out the source above twice and apply one patch in the candidate checkout. For each board, build the matching reference and trial with `BOARD=smk37 MODEL=elite sh build.sh` or `BOARD=smk37 MODEL=pro sh build.sh`, adding the three flags above for wide. Preserve each ELF and board-specific FWSC. Build `fm1-live` at `ba83317aa55cbcdb2830c5da97d5f64b763499e2` with Rust 1.85.1 and `cargo build --locked --release -p fm1-live`.
2. For the ordinary reference, use `experiments/sound-hardware-v1/strict-timing/replay.py --offsets 1` and retain `seed/flash.bin` and `shift1`. For a populated reference, stage its project with `experiments/sound-hardware-v1/selected-native/run.py --ensemble --stage-only` using the checkout’s fixture builder and the specified owner IDs. Use `selected-native/heavy.py --owners 1 0` or `--owners 2 3` and retain the staged flash and `heavy` output directory.
3. Run `python replay_pair.py --help` for the explicit image, capture, seed and output arguments. Standard mode records fresh two-second and eight-second trial captures. `--existing` rechecks existing recordings. Add `--populated` for instrument status, part and kit meters, and final sample state. The script validates the protected FWSC bytes below 0x9d000, copies the entire user area from the matched reference, checks the full input stream and re-reads native counters before comparing every stereo frame and project byte. Each image starts with its own package code.

The timing budget is 11,609 µs per half. The requested 700 µs margin requires a peak at or below 10,909 µs. Physical preservation requires complete stereo and final project equality for the paired stimulus.

## Matched results

All measured candidates changed the physical stereo stream or project. Both experiments remain off the production path. The table counts one difference per stereo frame, including unmatched trailing frames.

### planner-only.patch

| Model | Profile | Scene | Peak µs, reference → trial | Raw late, reference → trial | Changed stereo frames | Changed project bytes |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| Elite | stock | ordinary +1 ms | 11,386 → 10,362 | 0 → 0 | 52,392 | 2 |
| Pro | stock | ordinary +1 ms | 11,390 → 10,358 | 0 → 0 | 43,452 | 10 |
| Elite | wide | ordinary +1 ms | 10,986 → 10,396 | 0 → 0 | 162,133 | 12 |
| Pro | wide | ordinary +1 ms | 11,047 → 10,399 | 0 → 0 | 173,666 | 12 |
| Elite | wide | Miami / Chicago | 13,706 → 13,609 | 72 → 71 | 171,078 | 4 |
| Pro | wide | Miami / Chicago | 15,576 → 15,527 | 100 → 100 | 178,099 | 4 |
| Elite | wide | Juno / SynthOne | 12,901 → 12,915 | 27 → 34 | 186,610 | 14 |
| Pro | wide | Juno / SynthOne | 14,790 → 14,848 | 119 → 120 | 165,133 | 7 |

### all-job-eligibility.patch

| Model | Profile | Scene | Peak µs, reference → trial | Raw late, reference → trial | Changed stereo frames | Changed project bytes |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| Elite | wide | ordinary +1 ms | 10,986 → 10,172 | 0 → 0 | 47,724 | 10 |
| Pro | wide | ordinary +1 ms | 11,047 → 10,163 | 0 → 0 | 105,279 | 10 |
| Elite | wide | Miami / Chicago | 13,706 → 18,588 | 72 → 121 | 176,708 | 5 |
| Pro | wide | Miami / Chicago | 15,576 → 19,074 | 100 → 122 | 134,137 | 3 |
| Elite | wide | Juno / SynthOne | 12,901 → 16,784 | 27 → 120 | 234,914 | 11 |
| Pro | wide | Juno / SynthOne | 14,790 → 12,416 | 119 → 10 | 217,347 | 12 |

Across the six broad-eligibility captures, the smallest untouched CPU1 stack prefix was 1,388 bytes. The smallest measured margin above the 256-byte guard was 1,132 bytes. The crash record stayed clear in all six captures.

The two additional Pro observations cover the first 3,400 ms of each populated trial. The observer counted CPU1 stores of stages 3 and 4 for completed A and B mixes, and writes to job-cost offsets 8 and 12 for active A and B estimates. It confirmed the whole physical stereo prefix matched the corresponding eight-second capture. Use `observe_remote.py --help` to reproduce or recheck those traces.

| Ensemble | CPU1 A mixes | CPU1 B mixes | Matching physical prefix |
| --- | ---: | ---: | ---: |
| Miami / Chicago | 479 | 0 | 122,880 frames |
| Juno / SynthOne | 479 | 0 | 122,880 frames |
