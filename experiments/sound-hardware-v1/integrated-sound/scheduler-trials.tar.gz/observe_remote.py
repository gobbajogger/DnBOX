#!/usr/bin/env python3
"""Verify CPU1 bass mix stores against a matching physical prefix."""
import argparse
from collections import Counter
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

WATCHES = {
    "x0x_dbg": 52, "audio_xruns": 4, "eng_prof": 32, "eng_prof_frames": 4,
    "eng_job_cost": 20, "eng_plan": 1, "eng_c1_mask": 1, "eng_stage": 4,
    "eng_mastered": 4, "eng_do_master": 1, "eng_job_arg": 4,
    "brk_silent_now": 4, "usr_nz": 3, "nloops": 4, "pack_n": 4,
    "kbuf": 1024, "dry_l": 1024, "dry_r": 1024,
}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for field in ("checkout","elf","fwsc","seed","primary","emulator","output"):
        parser.add_argument("--"+field, required=True, type=lambda s: Path(s).resolve())
    parser.add_argument("--duration", type=int, default=3400)
    parser.add_argument("--existing", action="store_true")
    args = parser.parse_args()
    if not __debug__:
        parser.error("Run with Python assertions enabled")
    sys.path.insert(0,str(args.checkout/"experiments/sound-hardware-v1/strict-timing"))
    import replay
    elf,package,seed,out = args.elf,args.fwsc,args.seed,args.output
    if not args.existing:
        out.mkdir(parents=True)
        (out / "work").mkdir()
    replay.validate_seed(package,seed)
    syms = {}
    for row in subprocess.check_output(["nm", "-S", elf], text=True, stderr=subprocess.DEVNULL).splitlines():
        fields = row.split()
        if len(fields) == 4 and fields[-1] in WATCHES:
            syms[fields[-1]] = int(fields[0], 16), int(fields[1], 16)
    assert {name: n for name, (address, n) in syms.items()} == WATCHES
    mapping = out / "symbols.map"
    watch_text = "".join(f"{name} {address:x} {n}\n" for name, (address, n) in syms.items())
    if args.existing:
        assert mapping.read_text() == watch_text
    else:
        mapping.write_text(watch_text)
    trace, pcm = out / "trace.jsonl", out / "stereo.s16le"
    flash = out / "flash.bin"
    env = {k: v for k, v in os.environ.items() if not k.startswith("FM1_")}
    env.update(FM1_STRICT="1", FM1_BENCH_KEYS="@" + str(args.primary / "scene.keys"),
               FM1_DNBOX_PCM=str(pcm), FM1_DNBOX_MAP=str(mapping), FM1_DNBOX_TRACE=str(trace))
    duration = args.duration
    if not args.existing:
        shutil.copyfile(seed, flash)
        with (out / "run.log").open("w") as log:
            subprocess.run([args.emulator, "--mhz", "360",
                        "--shot", str(duration), "--fwsc", package, "--flash", flash],
                       env=env, cwd=out, stdout=log, stderr=subprocess.STDOUT, check=True)
    remote_mixes, remote_costs = Counter(), Counter()
    max_us = 0
    with trace.open() as lines:
        for line in lines:
            entry = json.loads(line)
            if entry["event"] == "half":
                max_us = max(max_us, entry["last_us"])
            if entry["event"] == "store" and entry["core"] == 1:
                if entry["name"] == "eng_stage" and entry["value"] in (3, 4):
                    remote_mixes[entry["value"] - 3] += 1
                if entry["name"] == "eng_job_cost" and entry["offset"] in (8, 12):
                    remote_costs[entry["offset"]//4 - 2] += 1

    log_text = (out / "run.log").read_text()
    assert f"panel.ppm at {duration} ms" in log_text and "skipped 0 cycles" in log_text
    assert entry["event"] == "finish" and entry["resets"] == 0
    primary = json.loads((args.primary / "result.json").read_bytes())
    assert primary["initial_flash_sha256"] == replay.digest(seed)
    assert primary["pcm_sha256"] == replay.digest(args.primary / "stereo.s16le")
    assert replay.digest(args.primary / "scene.keys") == primary["scene_sha256"]
    assert primary["duration_ms"] >= duration and primary["strict"] == 1
    observed = pcm.read_bytes()
    assert len(observed) > 0 and len(observed) % 4 == 0
    assert observed == (args.primary / "stereo.s16le").read_bytes()[:len(observed)]
    print(json.dumps(dict(duration_ms=duration, elf_sha256=replay.digest(elf),
          package_sha256=replay.digest(package), emulator_sha256=replay.digest(args.emulator),
          observer_map_sha256=replay.digest(mapping), observer_sha256=replay.digest(trace),
          physically_matched_prefix_frames=len(observed)//4, prefix_sha256=replay.digest(pcm),
          remote_mix_completions=dict(remote_mixes), remote_cost_updates=dict(remote_costs),
          peak_us_within_window=max_us),indent=2))

if __name__ == "__main__":
    main()
