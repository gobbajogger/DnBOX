#define main simulator_main
#include "host/x0x_host.c"
#undef main
int test_seq_cost_lifetime(void);
int main(void)
{
    boot();
    return test_seq_cost_lifetime();
}
