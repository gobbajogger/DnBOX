from pathlib import Path
import hashlib,json,subprocess,sys
r=Path(__file__).resolve().parent
work=r.parents[2]
source=r.parent/'source'
closure=work/'s1-work/stock-workload-build'
host=work/'s1-work/stock-workload-src'
fixture=r/'fixture.c';check=r/'checks.c'
engine=source/'firmware/src/app/engine.c'
augmented=r/'production-with-fixture.c';augmented.write_bytes(engine.read_bytes()+b'\n'+check.read_bytes())
build=json.loads((closure/'build.json').read_bytes())
flags=['-I'+str(source/'firmware/src/app'),*build['flags'][:-1],'-I'+str(closure)]
objects=sorted(closure.glob('*.c.o'));assert len(objects)==70
cmds=[]
for i in (fixture,augmented):
    cmd=['cc',*flags,'-c',str(i),'-o',str(i.with_suffix('.o'))];subprocess.run(cmd,cwd=host,check=True);cmds.append(cmd)
exe=r/'lifetime';cmd=['cc',str(fixture.with_suffix('.o')),str(augmented.with_suffix('.o')),*map(str,objects),'-lm','-o',str(exe)]
subprocess.run(cmd,cwd=host,check=True);cmds.append(cmd)
out=subprocess.check_output([exe],cwd=host,text=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(r/'result.json').write_text(json.dumps(dict(output=out,production_source_sha256=sha(engine),fixture_sha256=sha(fixture),checks_sha256=sha(check),closure_sha256=sha(closure/'build.json'),executable_sha256=sha(exe),commands=cmds),indent=2)+'\n')
print(out)
