/* Diagnostic entry compiled into a private copy of production engine.c. */
#include <assert.h>
#include <stddef.h>
#include <stdio.h>
int test_seq_cost_lifetime(void)
{
    const int chicago = 1, miami = 0;
    const uint32_t work = 59123;
    assert(original_bass[chicago].kind == ORIGINAL_SOUND_CHICAGO);
    assert(original_bass[miami].kind == ORIGINAL_SOUND_MIAMI);
    assert(original_bass[chicago].seq_cost_8ticks == 0);
    assert(original_seq_note[chicago] == -1);
    uint32_t *charged = &eng_job_cost[JB_A + chicago];
    *charged = 23;
    s_boff(NULL, chicago);
    assert(original_bass[chicago].seq_cost_8ticks == 0);
    assert(s_bon(NULL, chicago, 45, 0, 0, 99) == 1);
    assert(*charged == 23);
    *charged = work;
    s_boff(NULL, chicago);
    assert(original_bass[chicago].seq_cost_8ticks == work / 8u);
    *charged = 13248;
    assert(s_bon(NULL, chicago, 45, 0, 0, 99) == 1);
    assert(*charged == (work / 8u) * 8u);
    *charged = 888;
    assert(s_bon(NULL, chicago, 46, 0, 1, 99) == 1);
    assert(*charged == 888); /* ongoing gate cannot apply a past release */
    *charged = UINT32_MAX;
    s_boff(NULL, chicago);
    assert(original_bass[chicago].seq_cost_8ticks == UINT16_MAX);
    *charged = 4321;
    prob[PART_303B][0] = 0; /* deterministically rejected probability */
    assert(s_bon(NULL, chicago, 45, 0, 0, 99) == 0);
    assert(*charged == 4321);
    prob[PART_303B][0] = 100;
    assert(s_bon(NULL, chicago, 45, 0, 0, 99) == 1);
    assert(*charged == (uint32_t)UINT16_MAX * 8u);
    s_boff(NULL, chicago);
    assert(bass_restore_part(mot_base_snd, chicago) == ORIGINAL_RUNTIME_OK);
    assert(original_bass[chicago].seq_cost_8ticks == 0);
    *charged = 123;
    assert(s_bon(NULL, chicago, 45, 0, 0, 99) == 1);
    assert(*charged == 123);
    s_boff(NULL, chicago);
    uint32_t *separate = &eng_job_cost[JB_A + miami];
    *separate = 100;
    assert(s_bon(NULL, miami, 40, 0, 0, 80) == 1);
    *separate = 62000;
    s_boff(NULL, miami);
    assert(original_bass[miami].seq_cost_8ticks == 0);
    *separate = 10;
    assert(s_bon(NULL, miami, 40, 0, 0, 80) == 1);
    assert(*separate == 10);
    assert(*charged == 123);
    printf("owner_bytes=%zu scheduler_offset=%zu status_offset=%zu rebound_ticks=%u saturated_ticks=%u\n",
           sizeof(original_runtime_part), offsetof(original_runtime_part,seq_cost_8ticks),
           offsetof(original_runtime_part,status),(work / 8u) * 8u,(uint32_t)UINT16_MAX * 8u);
    return 0;
}
