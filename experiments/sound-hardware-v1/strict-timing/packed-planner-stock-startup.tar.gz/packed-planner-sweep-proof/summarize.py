"""Compare every exact 922-contact, 8-second sweep row to the same physical stock stimulus."""
from collections import Counter
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def problem(first,second):
    for off in range(0,min(len(first),len(second)),4):
        if first[off:off+4]!=second[off:off+4]:
            return off//4
    return None if len(first)==len(second) else min(len(first),len(second))//4

def gather(model,shift):
    primary = e/f'baseline-{model}'/('shift0-trace' if model=='elite' and shift==0 else f'shift{shift}')
    contender = e/r.name/model/f'shift{shift}'
    if not (contender/'result.json').exists():return None
    stock=json.loads((primary/'result.json').read_bytes())
    candidate=json.loads((contender/'result.json').read_bytes())
    for key in ['model','shift_ms','scene_events','scene_sha256','shot_ms','emulator_sha256']:
        assert stock[key]==candidate[key],key
    assert candidate['scene_events']==922 and candidate['shot_ms']==8000 and candidate['env']['FM1_STRICT']=='1'
    assert all(src['command'][3:7]==['--mhz','360','--shot','8000'] for src in (stock,candidate))
    key=f'{model}-{shift}'
    root=r/'sweep';root.mkdir(exist_ok=True)
    project_file=root/(key+'-project.json')
    if not project_file.exists():
        cmd=[sys.executable,base/'emu-proof/scripts/compare_project.py',primary,e/'input'/(model+'.elf'),contender,r/'images'/(model+'.elf')]
        project_file.write_bytes(subprocess.check_output(cmd))
    project=json.loads(project_file.read_bytes())
    assert project['bytes']==36420 and project['candidate_elf_sha256']==candidate['elf_sha256'] and project['stock_elf_sha256']==stock['elf_sha256']
    row={'model':model,'shift_ms':shift,'target_us':10909,'limit_us':11609,'scene_sha256':candidate['scene_sha256'],'stock_elf_sha256':stock['elf_sha256'],'candidate_elf_sha256':candidate['elf_sha256'],'candidate_fwsc_sha256':candidate['fwsc_sha256'],'emulator_sha256':candidate['emulator_sha256']}
    for name,j in [('stock',stock),('candidate',candidate)]:
        for k,field in [('halves','halves'),('max_us','us'),('late','raw_late')]:
            row[f'{name}_{field}']=j['debug'][k]
        row[f'{name}_boot_late']=j['boot_late']
        row[f'{name}_scene_late']=j['late_during_test']
        row[f'{name}_pcm_sha256']=j['pcm_sha256']
    row['headroom_us']=row['limit_us']-row['candidate_us']
    row['different_project_bytes']=project['different_bytes']
    row['different_sections']={p['section']:p['different_bytes'] for p in project['different_sections']}
    row['stock_project_sha256']=project['stock_project_sha256'];row['candidate_project_sha256']=project['candidate_project_sha256']
    row['first_different_absolute_stereo_frame']=problem((primary/'stereo.s16le').read_bytes(),(contender/'stereo.s16le').read_bytes())
    return row

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--wait',action='store_true');args=p.parse_args()
    r=Path(__file__).resolve().parent;base=r.parent;e=base/'emu360'
    seen={}
    while True:
        for model in ('elite','pro'):
            for shift in range(6):
                if (model,shift) not in seen:
                    row=gather(model,shift)
                    if row:
                        seen[model,shift]=row
                        print(model,shift,row['candidate_us'],row['candidate_raw_late'],row['candidate_scene_late'],row['different_project_bytes'],flush=True)
        rows=[seen[k] for k in sorted(seen)]
        if rows:
            out={'source':'fcf82f607cd35a263c9923071aaa25066ff6d60f','patch_sha256':sha(r/'source.patch'),'complete_rows':len(rows),'expected_rows':12,'max_us':max(y['candidate_us'] for y in rows),'all_current_rows_max_10909':all(y['candidate_us']<=10909 for y in rows),'all_current_rows_complete_648':all(y['candidate_halves']==648 for y in rows),'all_current_rows_zero_raw_late':all(y['candidate_raw_late']==0 for y in rows),'all_current_rows_same_project':all(y['different_project_bytes']==0 for y in rows),'rows':rows}
            tmp=r/'sweep.progress.tmp';tmp.write_text(json.dumps(out,indent=2)+'\n');tmp.rename(r/'sweep-progress.json')
        if not args.wait or len(rows)==12:break
        time.sleep(10)
