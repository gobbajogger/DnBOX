#!/usr/bin/env python3
import csv, hashlib, json, os, re, shutil, struct, subprocess, sys, time
from pathlib import Path
r=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def symbols(elf):
    out=subprocess.check_output(['nm','-S',str(elf)],text=True,stderr=subprocess.DEVNULL)
    return {p[-1]:(int(p[0],16),int(p[1],16) if len(p)==4 else 0) for line in out.splitlines() if len(p:=line.split()) in (3,4)}
def run(label,ms,shift):
    dest=r/label
    dest.mkdir()
    (dest/'work').mkdir()
    (dest/'scene.keys').write_text(re.sub(r'(^|,)(\d+):',lambda m:m[1]+str(int(m[2])+shift)+':',(r/'input/heavy.keys').read_text()))
    shutil.copy2(r/'seed/fresh.flash',dest/'flash.bin')
    s=symbols(r/'input/elite.elf')
    env=dict(FM1_STRICT='1',FM1_BENCH_KEYS='@'+str(dest/'scene.keys'),FM1_CORE_LOAD=f"{s['_c1_start'][0]:x}-{s['_c1_end'][0]:x}",FM1_CORE_LOAD_CSV=str(dest/'core.csv'),FM1_DUMPRAM=str(dest/'ram.bin'))
    cmd=[str(r/'bin/fm1-live'),'--fwsc',str(r/'input/elite.fwsc'),'--mhz','360','--shot',str(ms),'--flash',str(dest/'flash.bin')]
    if label.startswith('profile'):env['FM1_TPROF']=f"{dest}/tprof.txt,7000,8000"
    meta=dict(label=label,ms=ms,offset_ms=shift,environment=env,command=cmd,scene_sha256=sha(dest/'scene.keys'),initial_flash_sha256=sha(dest/'flash.bin'),package_sha256=sha(r/'input/elite.fwsc'),elf_sha256=sha(r/'input/elite.elf'),emulator_sha256=sha(r/'bin/fm1-live'))
    (dest/'command.json').write_text(json.dumps(meta,indent=2)+'\n')
    t=time.monotonic()
    with (dest/'run.log').open('w') as log:
        subprocess.run(cmd,env={**{k:v for k,v in os.environ.items() if not k.startswith('FM1_')},**env},cwd=dest,stdout=log,stderr=subprocess.STDOUT,check=True)
    ram=(dest/'ram.bin').read_bytes()
    def words(sym,n):return struct.unpack_from('<'+'I'*n,ram,s[sym][0]-0x01c00000)
    dbg=dict(zip(('magic','halves','max_us','nested','in_audio','late','timer_irqs','ui_frames','last_us','cpu_q8','boots','stage','crash_seen'),words('x0x_dbg',13)))
    assert dbg['magic']==0x44424731 and dbg['halves']>0
    profile=words('eng_prof',s['eng_prof'][1]//4)
    result=dict(**meta,debug=dbg,audio_xruns=words('audio_xruns',1)[0],eng_prof_frames=words('eng_prof_frames',1)[0],eng_prof=profile,host_seconds=time.monotonic()-t,final_flash_sha256=sha(dest/'flash.bin'))
    if label!='boot':
        boot=json.loads((r/'boot/result.json').read_text())['debug']
        result.update(late_during_test=dbg['late']-boot['late'],within_target=dbg['max_us']<=10909 and dbg['late']-boot['late']==0,raw_zero_late=dbg['late']==0)
    (dest/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(label,dbg,'host secs',result['host_seconds'],flush=True)
if __name__=='__main__':
    if len(sys.argv)>1:run(sys.argv[1],int(sys.argv[2]),int(sys.argv[3]))
    else:
        run('boot',2000,0)
        for shift in range(6):run('shift'+str(shift),8000,shift)
