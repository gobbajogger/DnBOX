from pathlib import Path
import argparse,os,subprocess,hashlib,json,datetime
here=Path(__file__).resolve().parent
ap=argparse.ArgumentParser()
ap.add_argument('tree',type=Path);ap.add_argument('destination',type=Path);ap.add_argument('model',choices=['elite','pro']);args=ap.parse_args()
tree=args.tree.resolve();dst=args.destination.resolve();dst.mkdir(parents=True,exist_ok=False);(dst/'home').mkdir();(dst/'tmp').mkdir()
tc=here/'tools'/'jieli-linux-toolchains-20260730.1'; sdk=next((here/'inputs/sdk').iterdir())
env={'HOME':str(dst/'home'),'TMPDIR':str(dst/'tmp'),'PATH':'/usr/local/bin:/usr/bin:/bin','PYTHON':'python3','JIELI_DOCKER':'0','X0X_JOBS':'2','BOARD':'smk37','MODEL':args.model,'JIELI_TOOLCHAIN':str(tc),'AC79_SDK':str(sdk)}
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (dst/'build.log').open('w') as log:rc=subprocess.call(['sh','build.sh'],cwd=tree,env=env,stdout=log,stderr=subprocess.STDOUT)
record={'model':args.model,'command':['sh','build.sh'],'environment':env,'start':started,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':rc}
if rc==0:
 target='smk37-elite' if args.model=='elite' else 'smk37';out=tree/'build'/target;elf=out/'x0x.elf'
 paths=[elf,out/'x0x.bin',tree/'build'/f'x0x-{target}.fwsc',out/'app.ld'];record['outputs']={str(p.relative_to(tree)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 with (dst/'symbols-sections.txt').open('w') as f:subprocess.run([tc/'common/bin/objdump','-t','-h',elf],stdout=f,check=True)
(dst/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print((dst/'build.log').read_text()[-1400:]);raise SystemExit(rc)
