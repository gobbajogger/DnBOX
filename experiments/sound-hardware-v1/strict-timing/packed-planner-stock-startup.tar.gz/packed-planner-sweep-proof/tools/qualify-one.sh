#!/usr/bin/env bash
set -eu
d=$(realpath "$(dirname "$0")")
name=$1
model=$2
images=$(realpath "$3")
shift 3
seed=$d/$name/$model/seed/flash.bin
boot=$d/$name/$model/boot/result.json
run() { python3 "$d/capture.py" --model "$model" --image-dir "$images" "$@"; }
run --name "$name/$model/seed" --ms 2000 --cold
run --name "$name/$model/boot" --ms 2000 --seed "$seed"
for offset in "$@"; do
  run --name "$name/$model/shift$offset" --shift "$offset" --ms 8000 --seed "$seed" --boot "$boot"
done
