# Original-startup Chicago scheduling estimator, independent board sweep

The frozen source patch applies to fcf82f607cd35a263c9923071aaa25066ff6d60f. It retains the measured active Chicago cost per sequencer owner in the original two trailing bytes of the runtime object. Release records the current estimate in units of eight 24 MHz ticks. A future accepted Chicago gate restores its own measured estimate if silence lowered it. New instrument adoption clears it with the ordinary runtime initialization. The normal planner chooses the core, with every original audio job present and Chicago still on core zero.

Cold board build logs record both independent native packages and ELF hashes. Flash is 546,676 bytes Elite and 546,668 Pro, both 160 bytes over stock. Ordinary RAM remains 97,204 bytes and pool use is 335,092 of 344,064 bytes, preserving the 8,192-byte reserve with 780 bytes further margin. The 17-scene host test matched all 50 fixed-input payloads, and the focused owner fixture checked successful and rejected notes, ongoing slides, independent Miami parts, bounded saturation and cold reset.

Each row below used its own board-specific cold 2 s seed, matching 2 s warm baseline and the unchanged strict 8 s scene of 922 physical inputs. The score is the guest maximum at 360 MHz. The 512-frame deadline is 11,609 µs and the requested maximum is 10,909 µs. All rows retained 648 completed halves. Raw and in-scene lateness are both reported.

| Model | Offset ms | Stock µs | Candidate µs | Raw late | Scene late | Project bytes changed | First changed native DAC frame |
|---|---:|---:|---:|---:|---:|---:|---:|
| elite | 0 | 11402 | 10290 | 1 | 0 | 2 | 289856 |
| elite | 1 | 11323 | 10220 | 1 | 0 | 11 | 199811 |
| elite | 2 | 11319 | 10410 | 1 | 0 | 14 | 199808 |
| elite | 3 | 11282 | 10258 | 1 | 0 | 2 | 102402 |
| elite | 4 | 11297 | 10334 | 1 | 0 | 0 | 102402 |
| elite | 5 | 11272 | 10298 | 1 | 0 | 3 | 199278 |
| pro | 0 | 11289 | 10294 | 1 | 0 | 4 | 199811 |
| pro | 1 | 11318 | 10244 | 1 | 0 | 3 | 199811 |
| pro | 2 | 11087 | 10283 | 1 | 0 | 13 | 102402 |
| pro | 3 | 11241 | 10274 | 1 | 0 | 5 | 199284 |
| pro | 4 | 11303 | 10294 | 1 | 0 | 4 | 204564 |
| pro | 5 | 11272 | 10394 | 1 | 0 | 1 | 155712 |

The maximum was 10,410 µs, with 1,199 µs headroom. Complete same-offset stock project parity held on 1/12 and full raw DAC parity on 0/12. The original startup late and physical project/DAC differences remain material. This is independent timing and behavioral evidence for the scheduler change. It does not qualify this frozen source as the requested final firmware.

On a separate harder factory-persisted project captured through normal stock SAVE, identical physical PLAY at 2300 ms dispatched at absolute frame 80,384 on both images. All 276 logical events matched. The 206 common on-time native 512-frame blocks, 105,472 stereo frames, were bit-identical. The uninterrupted DMA stream diverged at transport-relative frame 82,432 in the presence of different overruns. Stock peaked at 12,923 µs, raw 34 / scene 33, and the candidate at 12,986 µs, raw 35 / scene 34. This separate stored-project experiment is outside the 922-event primary timing sweep.

To reproduce, apply the patch, cold-build the selected model with tools/run_build.py, supply the pinned fm1-live and device SDK and put its .elf/.fwsc pair in a fresh directory. Run tools/qualify-one.sh separately for each board over offsets 0 through 5. Its dependent tools, the shifted key files, 16 primary commands/results, executable and source identities and all 12 actual 36,420-byte project comparisons are included. The original unquantized causal trace package, which records the changed real 909 core assignment around both worst stock note resumes, is chicago-sequence-cost-proof-20261121.tar.gz, SHA256 075913e76fe3cfd982e26faf67890d5a17f8cb6b3f6d281788a5160e77f7624f.
