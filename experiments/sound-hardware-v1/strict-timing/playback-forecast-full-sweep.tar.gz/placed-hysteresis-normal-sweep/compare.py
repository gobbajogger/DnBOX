from pathlib import Path
import json,subprocess,sys,time,hashlib
r=Path(__file__).resolve().parent;e=r.parent/'emu360';m=sys.argv[1];normal=e/'placed-hysteresis'/m;images=r/'hysteresis-gate/images'
while not (normal/'shift1/result.json').exists():time.sleep(2)
out=r/'normal-sweep';out.mkdir(exist_ok=True)
for n in (1,0,2,3,4,5):
 d=normal/('shift'+str(n));old=e/('baseline-'+m)/('shift0-trace' if m=='elite' and n==0 else 'shift'+str(n))
 if not (d/'result.json').exists():
  subprocess.run([sys.executable,str(e/'capture.py'),'--model',m,'--image-dir',str(images),'--name','placed-hysteresis/'+m+'/shift'+str(n),'--shift',str(n),'--ms','8000','--seed',str(normal/'seed/flash.bin'),'--boot',str(normal/'boot/result.json')],check=True)
 result=json.loads((d/'result.json').read_bytes());proj=json.loads(subprocess.check_output([sys.executable,str(r.parent/'emu-proof/scripts/compare_project.py'),str(old),str(e/'input'/(m+'.elf')),str(d),str(images/(m+'.elf'))]));(out/(m+str(n)+'-project.json')).write_text(json.dumps(proj,indent=2)+'\n')
 stock=(old/'stereo.s16le').read_bytes();cand=(d/'stereo.s16le').read_bytes();frame=next((i//4 for i,(a,b) in enumerate(zip(stock,cand)) if a!=b),None)
 row={'board':m,'shift_ms':n,'halves':result['debug']['halves'],'max_us':result['debug']['max_us'],'raw_late':result['debug']['late'],'scene_late':result['late_during_test'],'project_different_bytes':proj['different_bytes'],'pcm_equal':stock==cand,'first_different_stereo_frame':frame,'candidate_pcm_sha256':result['pcm_sha256'],'stock_pcm_sha256':hashlib.sha256(stock).hexdigest(),'elf_sha256':result['elf_sha256'],'fwsc_sha256':result['fwsc_sha256']}
 (out/(m+str(n)+'.json')).write_text(json.dumps(row,indent=2)+'\n');print(row,flush=True)
