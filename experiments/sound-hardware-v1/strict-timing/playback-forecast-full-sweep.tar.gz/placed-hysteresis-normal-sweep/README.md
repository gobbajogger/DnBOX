# Original-startup Chicago forecast, two-board strict sweep

The actual hardware image uses the normal unaltered startup. It retains the previous sequenced Chicago owner's measured work across a rest and restores it only when the filtered estimate has decayed below half. The placed native kernels use private aliases resolved from each build's own ELF and the original PC-guard policy. The source patch applies on fcf82f607cd35a263c9923071aaa25066ff6d60f. Rebuild each board, seed blank NOR under strict 360 MHz, run the warmed 2 s baseline, then replay each original 922-event physical 8 s scene with all shifts. Every case compares against its board and offset's stock program, all 36,420 project bytes and the entire absolute unaligned stereo stream.

| Board | Shift ms | Peak µs | Raw/scene late | Project bytes changed | First different absolute stereo frame |
| --- | ---: | ---: | --- | ---: | --- |
| elite | 0 | 10230 | 1 / 0 | 12 | 160324 |
| elite | 1 | 10231 | 1 / 0 | 0 | entire stream matched |
| elite | 2 | 10292 | 1 / 0 | 6 | 155712 |
| elite | 3 | 10235 | 1 / 0 | 2 | 291945 |
| elite | 4 | 10286 | 1 / 0 | 0 | 155712 |
| elite | 5 | 10237 | 1 / 0 | 0 | 102402 |
| pro | 0 | 10399 | 1 / 0 | 4 | 289856 |
| pro | 1 | 10240 | 1 / 0 | 0 | 306752 |
| pro | 2 | 10350 | 1 / 0 | 10 | 289344 |
| pro | 3 | 10261 | 1 / 0 | 0 | 289856 |
| pro | 4 | 10285 | 1 / 0 | 4 | 288833 |
| pro | 5 | 10237 | 1 / 0 | 0 | 297536 |

All twelve measured 648 halves. Every row passed the 10,909 µs ceiling and retained the stock boot late. Six of twelve complete projects matched. One complete raw stereo stream matched (Elite +1, 333,312 stereo frames). The images consume 180 B above stock on Elite and the corresponding per-model build record gives Pro size. This is an independent scheduler margin result. Physical sound, occupied flash and zero raw late remain release requirements.
