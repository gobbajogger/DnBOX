"""Compare the exact fixed-drive oscillator on every distinct float-rounded folded phase."""
from pathlib import Path
import subprocess,sys,tempfile
base, candidate = map(Path,sys.argv[1:3])
output = Path(sys.argv[3]).resolve() if len(sys.argv)>3 else None
with tempfile.TemporaryDirectory() as temp:
    d=Path(temp)
    def run(*args): subprocess.run(args,check=True)
    for label,tree,expr in (('reference',base,'d9_diode20(d9_tri(phase))'),('candidate',candidate,'d9_triangle20(phase)')):
        src=tree.resolve()/'firmware/src/dsp'
        p=d/(label+'.c')
        p.write_text('#include "drum909.c"\nfloat '+label+'(uint32_t phase) {return '+expr+';}\n')
        run('cc','-O2','-ffunction-sections','-fdata-sections','-fno-fast-math','-ffp-contract=off','-DX0X_HOST','-I',src,'-I',tree.resolve()/'build/gen','-c',p,'-o',d/(label+'.o'))
    syms=subprocess.check_output(['nm','-g','--defined-only',d/'reference.o'],text=True).splitlines()
    (d/'map').write_text(''.join(n+' old_'+n+'\n' for r in syms if (n:=r.split()[-1])!='reference'))
    run('objcopy','--redefine-syms='+str(d/'map'),d/'reference.o',d/'ref.o')
    (d/'test.c').write_text("""
#include <inttypes.h>
#include <openssl/evp.h>
#include <stdio.h>
#include <string.h>
float reference(uint32_t),candidate(uint32_t);
int main(int argc, char **argv) {
    const uint32_t endian_check=1;
    if (*(const uint8_t *)&endian_check != 1) return 2;
    FILE *samples=argc==2?fopen(argv[1],"w"):NULL;
    if (argc==2 && !samples) return 2;
    if(samples) fputs("folded_phase_hex,reference_f32_bits,candidate_f32_bits\\n",samples);
    EVP_MD_CTX *sha[2]={EVP_MD_CTX_new(),EVP_MD_CTX_new()};
    if (!sha[0] || !sha[1]) return 2;
    for (int j=0;j<2;++j) if (!EVP_DigestInit_ex(sha[j],EVP_sha256(),NULL)) return 2;
    uint32_t buffers[2][8192]; unsigned pos=0;
    uint64_t count=0,digest=UINT64_C(14695981039346656037);
    uint32_t folded=0,step=1,next_boundary=UINT32_C(1)<<24;
    for (;;) {
        const uint32_t representative=folded==UINT32_C(0x80000000)?UINT32_C(0x7fffffff):folded;
        float before=reference(representative), after=candidate(representative);
        uint32_t bits; memcpy(&bits,&before,sizeof bits);
        if (memcmp(&before,&after,sizeof before)) {printf("mismatch folded %u\\n",folded);return 1;}
        uint32_t other; memcpy(&other,&after,sizeof other);
        if(samples && (count % 16384u == 0u || folded==0x7fffff80u || folded==0x80000000u))
            fprintf(samples,"%08"PRIx32",%08"PRIx32",%08"PRIx32"\\n",representative,bits,other);
        buffers[0][pos]=bits; buffers[1][pos]=other; ++pos;
        if(pos==8192u) {for(int j=0;j<2;++j) if (!EVP_DigestUpdate(sha[j],buffers[j],pos*4u)) return 2; pos=0;}
        digest=(digest^bits)*UINT64_C(1099511628211);++count;
        if (folded==UINT32_C(0x80000000)) break;
        if (folded==next_boundary){step*=2;next_boundary*=2;}
        folded+=step;
    }
    if(samples && fclose(samples)) return 2;
    for(int j=0;j<2;++j) {
        unsigned char out[32];unsigned n=0;
        if(!EVP_DigestUpdate(sha[j],buffers[j],pos*4u) || !EVP_DigestFinal_ex(sha[j],out,&n) || n!=32) return 2;
        printf("%s SHA-256 ",j?"candidate":"reference");
        for(unsigned i=0;i<n;++i) printf("%02x",(unsigned)out[i]); puts(""); EVP_MD_CTX_free(sha[j]);
    }
    printf("Covered all %"PRIu64" rounded integer inputs for all 2^32 phases; output FNV64 %016"PRIx64"\\n",count,digest);
    return 0;
}
""")
    run('cc','-O2','-Wl,--gc-sections',d/'test.c',d/'ref.o',d/'candidate.o','-lm','-lcrypto','-o',d/'grid')
    run(d/'grid',*([output] if output else []))
