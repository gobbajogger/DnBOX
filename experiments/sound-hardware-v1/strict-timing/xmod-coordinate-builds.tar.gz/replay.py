#!/usr/bin/env python3
"""Replay both frozen source compositions on a local ca0 Git checkout."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile

def sha(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()

def run(*cmd, cwd=None, env=None):
    subprocess.run(cmd,cwd=cwd,env=env,check=True)

pack=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument("repository",type=Path)
p.add_argument("work",type=Path, help="a new directory for checkouts and output")
p.add_argument("--sources-only",action="store_true",help="check all changed source hashes and patches without compiling")
args=p.parse_args()
repo=args.repository.resolve(); work=args.work.resolve()
work.mkdir(parents=True,exist_ok=False)
variants=["coordinate-xmod","coordinate-xmod-epoch"]

def restore(model_files, base, dst):
    dst.mkdir()
    if args.sources_only:
        for path in model_files:
            dest=dst/path; dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_bytes(subprocess.check_output(["git","-C",repo,"show",base+":"+path]))
        return
    arch=subprocess.Popen(["git","-C",repo,"archive",base],stdout=subprocess.PIPE)
    with tarfile.open(fileobj=arch.stdout,mode="r|") as tf:
        tf.extractall(dst,filter="data")
    arch.stdout.close()
    if arch.wait(): raise RuntimeError("git archive failed")

base_host=None
for name in variants:
    fragment=pack/name
    info=json.loads((fragment/"source-identities.json").read_text())
    assert info["patch_sha256"]==sha(fragment/"source.patch")
    tree=work/name
    restore(info["files"],info["base"],tree)
    for path,expected in info["files"].items():
        assert sha(tree/path)==expected["before"],path
    run("git","apply","--check",fragment/"source.patch",cwd=tree)
    run("git","apply",fragment/"source.patch",cwd=tree)
    for path,expected in info["files"].items():
        assert sha(tree/path)==expected["after"],path
    print(name,"all frozen before/after source identities verified",flush=True)
    if args.sources_only: continue
    native=json.loads((fragment/"native-identities.json").read_text())
    for model in ("elite","pro"):
        env=dict(os.environ,BOARD="smk37",MODEL=model,JIELI_DOCKER="0")
        run("sh","build.sh",cwd=tree,env=env)
        board="smk37-elite" if model=="elite" else "smk37"; folder=tree/"build"
        for ext,path in [("elf",folder/board/"x0x.elf"),("bin",folder/board/"x0x.bin"),("fwsc",folder/("x0x-"+board+".fwsc"))]:
            assert sha(path)==native[model]["sha256"][ext],(name,model,ext)
        assert (folder/board/"x0x.bin").stat().st_size==native[model]["image_bytes"]
    if base_host is None:
        base_tree=work/"ca0-host";restore([],info["base"],base_tree)
        base_host=work/"ca0-recordings"
        run("python3",base_tree/"tests/host/audio_path_identity.py","--output",base_host)
    capture=work/(name+"-recordings")
    run("python3",tree/"tests/host/audio_path_identity.py","--output",capture,"--baseline",base_host)
    assert json.loads((capture/"hashes.json").read_text())==json.loads((fragment/"production-host-hashes.json").read_text())
    print(name,"cold images and all production host identities verified",flush=True)
