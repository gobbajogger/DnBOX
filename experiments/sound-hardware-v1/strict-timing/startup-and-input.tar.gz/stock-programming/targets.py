"""Extract the first 16 drum steps from the real stock project after each heavy run."""
from pathlib import Path
import hashlib,json,struct,subprocess,sys
work=Path(sys.argv[1]).resolve()
dest=Path(sys.argv[2]).resolve();dest.mkdir(exist_ok=True)
layout=json.loads((work/'s1-work/emu-proof/inputs/project-layout.json').read_text())
records=[]
for model in ('elite','pro'):
 board='smk37-elite' if model=='elite' else 'smk37'
 elf=work/'native/final-init/build'/board/'x0x.elf'
 syms=subprocess.check_output(['nm','-S',elf],text=True,stderr=subprocess.DEVNULL).splitlines()
 a,n=map(lambda x:int(x,16),next(l.split()[:2] for l in syms if l.split()[-1]=='proj'))
 for offset in range(6):
  run=work/'s1-work/emu360'/('baseline-'+model)/('shift'+str(offset))
  if model=='elite' and offset==0:run=work/'s1-work/emu360/shift0'
  full=(run/'ram.bin').read_bytes();start=a-0x01c00000;raw=full[start:start+n];assert len(raw)==36420
  live=json.loads((run/'result.json').read_text())
  assert hashlib.sha256(elf.read_bytes()).hexdigest()==live['elf_sha256']
  pattern=layout['patterns']+layout['drum_offset']
  kits=[[struct.unpack_from('<I',raw,pattern+k*layout['drum_size']+8*v)[0]&65535 for v in range(11)] for k in (0,1)]
  records.append({'board':model,'shift_ms':offset,'firmware_elf_sha256':live['elf_sha256'],'project_sha256':hashlib.sha256(raw).hexdigest(),'kit_masks':kits})
(dest/'stock-targets.json').write_text(json.dumps(records,indent=2)+'\n')
header='static const uint16_t targets[12][2][11] = {\n'
for item in records:
 header+='    {'+', '.join('{'+', '.join(f'0x{v:04x}' for v in kit)+'}' for kit in item['kit_masks'])+'},\n'
(dest/'stock_targets.inc').write_text(header+'};\n')
