"""Replay all stock drum targets against the actual SMC UI input handler."""
import argparse
import os
from pathlib import Path
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("source", type=Path, help="pristine or candidate DnBOX checkout")
args = parser.parse_args()
source = args.source.resolve()
fixture = Path(__file__).resolve().parent / "stock_program_test.c"
with tempfile.TemporaryDirectory() as output:
    env = dict(os.environ)
    env.update(
        SMC_UI_OUT=output,
        SMC_UI_TEST_FILE=str(fixture),
        X0X_HOST_DEFS=f"-I{source}/tests/host",
    )
    subprocess.run(["sh", "tests/host/smc_ui_test.sh"], cwd=source, env=env, check=True)
