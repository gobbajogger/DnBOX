"""Apply the measured normal-DMA service during USB reset to an isolated ca0 tree."""
import sys
from pathlib import Path

root = Path(sys.argv[1])
path = root / "firmware/src/app/main_fm1.c"
source = path.read_text()
original = "    audio_init();\n    usb_start();"
replacement = """    audio_init();
    usb.timeouts = 0;
    fm1_usb_reset();
    {
        uint32_t reset_at = fm1_ticks();
        while (fm1_ticks() - reset_at < 25000u * FM1_TICKS_PER_US) {
            if (fm1_audio_pending() & FM1_AUDIO_HALF)
                fm1_alnk0_irq();
        }
    }
    usb_attach_ready();"""
assert source.count(original) == 1
path.write_text(source.replace(original, replacement))
