#define SMC_UI_MAIN retained_fixture_main
#include "smc_ui_test.c"
#include "stock_targets.inc"
static uint32_t white_mask(void) {
    uint32_t mask=0;
    for(int s=0;s<16;++s)mask|=1u<<WHITE_KEY[s];
    return mask;
}
static void sample_keys(uint32_t mask) {
    now_ms+=8;
    held_keys=mask;
    input();
    CHECK(ui.keys==mask);
}
static void tap(int key) {
    sample_keys(1u<<key);
    sample_keys(0);
}
static uint16_t grouped(int split) {
    setup(V_SEQ,PART_909);
    tap(BLACK_KEY[3]);
    CHECK(ui.sel[0]==3);
    dpart_t *d=&cur_pat()->drum[0];
    d->hit[3][0]=0xc000u;
    const uint32_t all=white_mask();
    if(split)sample_keys(all&~(1u<<WHITE_KEY[14]));
    sample_keys(all);sample_keys(0);
    return (uint16_t)d->hit[3][0];
}
int main(void) {
    const uint16_t together=grouped(0), split=grouped(1);
    printf("Same sixteen whites: single scan %04x, split scan %04x\n",together,split);
    CHECK(together==0x7fff && split==0xbfff);
    unsigned taps=0,checked=0;
    for(int t=0;t<12;++t)for(int kit=0;kit<2;++kit) {
        setup(V_SEQ,kit==0?PART_909:PART_808);
        dpart_t *d=&cur_pat()->drum[kit];
        for(int voice=0;voice<11;++voice) {
            tap(BLACK_KEY[voice]);
            CHECK(ui.sel[kit]==voice);
            const uint16_t wanted=targets[t][kit][voice];
            for(int step=0;step<16;++step) {
                const unsigned before=(d->hit[voice][0]>>step)&1u;
                if(before!=((wanted>>step)&1u)) {
                    tap(WHITE_KEY[step]); ++taps;
                    CHECK(((d->hit[voice][0]>>step)&1u)!=before);
                }
            }
            CHECK((uint16_t)d->hit[voice][0]==wanted);
            ++checked;
        }
    }
    printf("Matched every stock target through real UI input: %u drum masks, %u individually acknowledged toggles\n",checked,taps);
    return 0;
}
