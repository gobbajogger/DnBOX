"""Verify compact scan evidence, startup counts and causal host results."""
import csv
import gzip
import hashlib
import io
import json
from pathlib import Path
from statistics import median

root = Path(__file__).resolve().parent
def read(name):
    return json.loads((root / name).read_bytes())

for kind in ("stock", "split", "prime"):
    receipt = read(f"scan-{kind}.json")
    data = gzip.decompress((root / f"{kind}-columns.csv.gz").read_bytes()).decode()
    rows = list(csv.DictReader(io.StringIO(data)))
    phase = [((int(row["observer_tick"])-100*5760*int(row["column"])) % (1600*5760))/5760
             for row in rows]
    assert len(phase) == receipt["column_store_count"]
    assert (min(phase),median(phase),max(phase)) == (
        receipt["column_phase_us_min"],receipt["column_phase_us_median"],receipt["column_phase_us_max"])
    assert {int(r["column"]) for r in rows} == set(range(16))
startup = read("startup-results.json")
prime = startup["prime-8s"]
observed = startup["prime-8s-observed"]
assert all(prime[k] == observed[k] for k in prime if k != "steps_observed")
assert prime["debug"]["late"] == prime["audio_xruns"] == 0
assert prime["debug"]["halves"] == 650
assert prime["eng_prof_frames"] == 333056
assert read("prime-project.json")["different_bytes"] == 3
assert read("split-project.json")["different_bytes"] == 9
assert not read("prime-project.json")["equal"] and not read("split-project.json")["equal"]
scan = read("scan-prime.json")
assert scan["first_irq_entry_snapshot"]["x0x_dbg"][1:3] == [2,3663]
assert scan["first_irq_entry_snapshot"]["eng_prof_frames"] == [1024]
zero_half = hashlib.sha256(bytes(4096)).hexdigest()
for n in (465,475):
    trial = startup[f"prime-{n}ms"]
    assert trial["initial_1024_stereo_frames_zero"]
    assert trial["dma_buffer_sha256"] == [zero_half,zero_half]
    assert trial["eng_prof_frames"] == (512 if n==465 else 1024)
targets = read("stock-targets.json")
assert len(targets) == 12
for board, expect in (("elite",4),("pro",3)):
    selected = [r for r in targets if r["board"] == board]
    assert len({r["project_sha256"] for r in selected}) == 6
    assert len({str(r["kit_masks"]) for r in selected}) == expect
print("Verified three scanner traces, both real startup render counts, physical project differences and all twelve stock target identities.")
