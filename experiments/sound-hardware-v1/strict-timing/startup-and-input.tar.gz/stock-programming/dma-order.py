from pathlib import Path
import sys
r=Path(sys.argv[1])
p=r/'firmware/hal/fm1_audio.h';s=p.read_text()
a='    FM1_ALNK_CON0 |= 0x800u;\n    fm1_delay_ms(5);'
assert s.count(a)==1
s=s.replace(' *   fm1_audio_init(buf, half_words, isr, prio)  codec and ALNK0 bring-up;',' *   fm1_audio_prepare(buf, half_words, isr, prio) sets up the codec, channel and vector;')
s=s.replace('FM1_INLINE void fm1_audio_init(','FM1_INLINE void fm1_audio_prepare(')
s=s.replace(a,'''}

FM1_INLINE void fm1_audio_start(void)
{
    FM1_ALNK_CON0 |= 0x800u;
    fm1_delay_ms(5);''');p.write_text(s)
p=r/'firmware/src/app/main_fm1.c';s=p.read_text()
assert s.count('    audio_init();\n    usb_start();')==1
s=s.replace('static void audio_init(void)','static void audio_prepare(void)').replace('    fm1_audio_init(abuf,','    fm1_audio_prepare(abuf,')
s=s.replace('    audio_init();\n    usb_start();','''    audio_prepare();
    usb_start();
    fm1_audio_start();                              /* arm DMA after the blocking USB reset */''')
p.write_text(s)
