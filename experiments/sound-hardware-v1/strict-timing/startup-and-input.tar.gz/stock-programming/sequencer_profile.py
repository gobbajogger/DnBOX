"""Classify sampled PCs by standalone symbols from the sequencer source."""
import argparse
import bisect
from collections import Counter, defaultdict
import json
from pathlib import Path
import re
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("source", type=Path)
parser.add_argument("elf", type=Path)
parser.add_argument("sample", type=Path)
args = parser.parse_args()
c = (args.source / "firmware/src/seq/sequencer.c").read_text()
c = re.sub(r"/\*.*?\*/", "", c, flags=re.S)
functions = set(re.findall(r"\b(\w+)\s*\((?:[^(){};]|\([^()]*\))*\)\s*\{", c))
functions -= {"if", "for", "while", "switch"}
symbols = {}
for row in subprocess.check_output(["nm", "-n", "-S", str(args.elf)], text=True, stderr=subprocess.DEVNULL).splitlines():
    items = row.split()
    if len(items) == 4 and items[2] in ("t", "T") and int(items[1], 16):
        symbols[int(items[0],16)] = (int(items[1],16),items[3])
starts = sorted(symbols)
hits = defaultdict(Counter)
for row in args.sample.read_text().splitlines():
    core, pc, count = row.split()
    address = int(pc, 16)
    index = bisect.bisect_right(starts, address) - 1
    symbol = "[unmapped]"
    if index >= 0:
        base = starts[index]
        size, candidate = symbols[base]
        if address < base+size:
            symbol = candidate
    hits[core][symbol] += int(count)
result = {}
for core in ("0","1"):
    complete = hits[core]
    rows = dict((name, val) for name, val in complete.most_common() if name.split(".")[0] in functions)
    result[core] = dict(all_weighted_counts=sum(complete.values()), selected_counts=sum(rows.values()),
                        selected_percent=100*sum(rows.values())/sum(complete.values()), functions=rows)
print(json.dumps(result, indent=2))
