# Physical programming and measured startup

These isolated Elite experiments start from production source ca0c00a4e5863132de4a66f5d1c477c14d699be5 with the stock DSP, stopped-state rendering, sequencer and UI. Each used the original 922-event Elite heavy script, its own warm flash, the pinned 360 MHz runner and an 8-second unshifted trial. The acoustic workload and panel gesture times are identical. The production lane includes neither startup experiment.

| Elite trial | First two physical DMA edges | Measured complete renders | Raw late | Peak µs | TIMER5 IRQs | UI frames | Different native project bytes | Occupied bytes |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Stock | Both occur before first audio IRQ | 648 | 1 | 11,402 | 75,212 | 239 | 0 | 546,516 |
| Split startup | DMA starts after USB reset | 647 | 0 | 11,255 | 75,212 | 243 | 9 | 546,516 |
| Prime during USB reset | Genuine free halves serviced immediately | 650 | 0 | 11,427 | 75,212 | 241 | 3 | 546,660 |

Both candidates preserve 97,204 B of static RAM, a 335,092 B DSP allocation, the 8,192 B pool reserve and its 780 B margin. Each fails the physical project comparison. The source patches are independent alternatives against ca0.

## What the panel actually samples

The scanner advances one of sixteen matrix columns on each 10 kHz TIMER5 interrupt. The main loop and opportunistic LCD/input service call the foreground UI. The drum code owns one editable held step per target. A newly created step turns on during key-down. Releasing an existing tapped step can remove the step held by that latch. Splitting a simultaneous group across two foreground snapshots can change which white key owns the latch.

The full-application host input test begins with identical two existing steps, presents the same sixteen whites in one or two snapshots, and produces precisely 0x7fff and 0xbfff. On each of the two boards the six stock offsets have six distinct whole-project hashes. Among those projects, the two-kit step masks take four distinct combinations on Elite and three on Pro. Each stock target can be authored with the normal UI one acknowledged step at a time. The regression exercises 264 target voice masks with 1,997 confirmed white-key toggles. It covers drum masks. The production heavy run also changes parameters, bass steps and several other project fields.

All 6,885 stock and 6,869 split column-store observations cover all sixteen columns during sampled audio IRQs up to 3,400 ms. Reduced modulo 1,600 µs after subtracting the nominal 100 µs per column, their median observed store phases are 343.673 and 343.582 µs. In those same 3.4-second traces each firmware records 29,212 TIMER5 IRQs. Foreground UI counts already diverge at 132 stock and 133 split frames. The 6,854 observed prime stores have a 346.744 µs median phase. Timing is based on the original observer clock of 5,760 ticks/µs. IRQ scope and ordinary interrupts limit precision. The CSVs include every observed store through the cutoff. They do not observe foreground time between audio IRQs.

## Double-buffer priming

The stock ALNK engine starts, then blocks on USB reset before enabling interrupts. Its first callback enters with 743.557 µs of the current DMA half remaining and renders for 3,919 µs before it detects the late buffer. The alternative retains the original DMA start, the fully zeroed startup buffers and the 25 ms USB settle interval. During that interval it polls the actual free-half flag and invokes the existing complete audio render, acknowledgement and late check for every due half. Production frame, CPU and peak counters record all work. The first hardware IRQ sees two completed halves, 1,024 real rendered frames and a cumulative maximum of 3,663 µs. The second measured render was 1,900 µs. Its first physical DMA edge is 1.260 µs later than stock. Short independent snapshots at 465 and 475 ms verify one then two actual counted renders while both DMA buffers and the physical output contain the expected startup silence.

The primed unshifted run and its independent ordinary repeat produced the same 333,312 physical stereo frames, every debug counter and all 36,420 project bytes. Compared with stock, the first 79,424 stereo frames match. The 808 mixer level changes from 115 to 113 and 303B from 117 to 113. Stock has a 909 handclap at step 16 which is absent in the primed program. The remaining 36,417 bytes match. The startup design addresses real missed service. Its extra renders advance the entire musical engine. For instance the ordinary sequencer increments its external-frame clock during every stopped render and initial DSP state preparation also runs. Suppressing, resetting, or hiding those additional state transitions would break true accounting.

## Transport-only optimization scope

The full alternative trials already run the stock DSP on every pre-PLAY and playing frame. Choosing an optimized implementation only after PLAY cannot change a stored mask or mixer setting authored before that transition in these trials. Shared master, synthesizer and drum functions also render real physical auditions while stopped. A separate selected-symbol audit of stock Elite's 7,464–7,479 ms worst-half PC profile attributes 19,677/1,336,917 weighted core-0 samples and 118/1,336,917 core-1 samples to named sequencer-source functions. This includes shared stopped paths and misses inlined instructions attributed to callers. It measures sampling share, not a worst-case bound or promised speedup. The measured stock deadline gap is 493 µs.

To test DSP using the same authored performance, restore a genuine saved stock project and compare ordered events plus physical PCM at the same musical and DMA phase. Parent receipts cover that comparison. Qualification of the unchanged physical programming recipe still requires the full per-board, per-shift project also to match. Selecting distinct deterministic step taps is a viable authoring interface for the specific masks proven here, and changes the physical input experiment.

## Replay

Use the project's stock SDK/toolchain, USB build flags and the stock 360 MHz runner SHA 04c795b1961298cbd10d4bd9881ab97fde5eef7ff179f49a6b953dab78d43dc8. heavy.keys SHA is d08718b1521119b252b5cca0c5e1db6981ea25a5a0b31b6ead60dceccb3f6271.

1. Apply either split.patch or prime.patch to a clean ca0 tree. Invoke the ordinary stock build for MODEL=elite BOARD=smk37. The associated native JSON pins the ELF, .bin and FWSC SHA identities. The files named prime.py and dma-order.py also recreate the source changes.
2. The two capture driver sources are included under capture-drivers. Copy them to the runner directory containing bin/fm1-live and input/heavy.keys. Prepare an image folder with elite.elf and elite.fwsc from that build. Place the authentic heavy.keys in the pinned runner's input directory. In capture.py, use --cold --ms 2000 to prepare that image's seed flash. Run the full unshifted trial with --ms 8000 --seed pointing to that flash. Use --model elite and the same --image-dir for each paired run. Use a fresh output name every time.
3. scan-watch.py --capture-root PATH_TO_RUNNER accepts the same capture.py arguments. Add --trace and use --ms 3400 for the stock and split column trial or --ms 8000 for prime. scanner.py RUN_DIR recreates the public JSON for a completed trace. Both the instrumentation and instrumentation-free 8-second prime captures were run.
4. Run the stock project comparison utility on the ordinary stock and candidate run folders and their matching ELFs. split-project.json and prime-project.json contain every difference and both complete hashes. decoded-projects.json decodes the musical fields.
5. Run python3 replay_ui.py SOURCE_TREE to build and run the UI regression with a real full production host application. stock-targets.json retains the actual stock project and ELF SHA for every shift/board. targets.py independently extracts its input from real stock RAM outputs in this engineering workspace.
