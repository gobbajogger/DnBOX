"""Exercise the exact candidate handoff and IRQ against delayed clocks and labelled audio."""
from pathlib import Path
import sys, subprocess, tempfile
text = (Path(sys.argv[1])/'firmware/src/app/main_fm1.c').read_text()
irq = text[text.index('static volatile uint8_t audio_boot_output_ready;'):text.index('extern void isr_alnk0')]
prep = text[text.index('    render_block(x0x_scratch.boot_output)'):text.index('    while (fm1_ticks() - reset_at')]
arm = text[text.index('    fm1_audio_ack_half();\n    audio_boot_output_ready = 1;'):text.index('    fm1_timer5_start(isr_timer5, 4);\n    fm1_guard_lock_top();',text.index('    fm1_audio_ack_half();\n    audio_boot_output_ready = 1;'))]
harness = '''
#include <stdint.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>
#define HALF_WORDS 1024u
#define X0X_DEBUG 1
#define FM1_AUDIO_HALF 128
static int32_t abuf[2 * HALF_WORDS], park[HALF_WORDS];
static union { uint16_t main[2048]; int32_t boot_output[1024]; } x0x_scratch;
struct {unsigned late;} x0x_dbg;
struct {unsigned late_in;} x0x_worst;
static unsigned audio_xruns, pending, free_half, crossing, renders, acks;
static uint8_t fm1_audio_pending(void) { return pending; }
static void fm1_audio_ack_aux(uint8_t p) { (void)p; }
static unsigned fm1_audio_free_half(void) { return free_half; }
static void fm1_audio_ack_half(void) { acks++; pending=0; if(crossing) free_half^=1; }
static void *engine_boot_audio_workspace(void) {return park;}
static void render_block(int32_t *p) {
    ++renders;
    memset(park,0x6e,sizeof park);
    for(unsigned j = 0; j < HALF_WORDS; j++) p[j]=(int32_t)(renders*4096+j+1);
}
'''
body='''
static unsigned long tested;
static void run(unsigned early, unsigned fault) {
    renders=acks=crossing=pending=audio_xruns=x0x_dbg.late=x0x_worst.late_in=0;
    memset(abuf,0,sizeof abuf);
    PREPARE
    for(unsigned seq=1;seq<=early;seq++) {
        int32_t *p=abuf+((seq-1)&1)*HALF_WORDS;
        for(unsigned j=0;j<HALF_WORDS;j++) {assert(p[j]==0);++tested;}
        pending=FM1_AUDIO_HALF;
        free_half=(seq-1)&1;
    }
    ARM
    memset(&x0x_scratch,0xa5,sizeof x0x_scratch);
    for(unsigned k=1;k<=16;k++) {
        free_half=(early+k-1)&1;
        unsigned e=k>2 ? k-2:0;
        int32_t *p=abuf+free_half*HALF_WORDS;
        for(unsigned j=0;j<HALF_WORDS;j++) { assert(p[j]==(e ? (int32_t)(e*4096+j+1):0));++tested; }
        int32_t untouched[HALF_WORDS];
        int32_t *other=abuf+(1-free_half)*HALF_WORDS;
        memcpy(untouched,other,sizeof untouched);
        crossing=(k==fault);pending=FM1_AUDIO_HALF;fm1_alnk0_irq();
        assert(!pending && acks==1+k);
        assert(renders==k);
        assert(memcmp(untouched,other,sizeof untouched)==0);
        assert(audio_xruns == (fault!=0 && k>=fault));
        assert(audio_xruns==x0x_dbg.late && audio_xruns==x0x_worst.late_in);
    }
}
int main(void) {
    unsigned cases=0;
    for(unsigned early=0;early<=8;early++) for(unsigned late=0;late<=16;late++){run(early,late); ++cases;}
    printf("%u schedules and %lu individually verified source words, including faults crossing every service boundary\\n",cases,tested);
}
'''
with tempfile.TemporaryDirectory() as t:
    p=Path(t)/'driver.c';binary=Path(t)/'test'
    p.write_text(harness+irq+body.replace('PREPARE',prep).replace('ARM',arm))
    subprocess.run(['cc','-O2','-Wall','-Wextra','-Werror','-std=c11',p,'-o',binary],check=True)
    subprocess.run([binary],check=True)
