from pathlib import Path
import argparse,subprocess,shutil,json
p=argparse.ArgumentParser()
p.add_argument("run",type=Path)
p.add_argument("model",choices=["elite","pro"])
p.add_argument("offsets",type=int,nargs="+")
a=p.parse_args()
w=a.run.resolve()
model=a.model
src=w/'tree'/'build'
target='smk37-elite' if model=='elite' else 'smk37'
image=w/'image'
image.mkdir(exist_ok=True)
for f,s in [(src/target/'x0x.elf','elf'),(src/f'x0x-{target}.fwsc','fwsc')]:
    shutil.copyfile(f,image/f'{model}.{s}')
capture=Path('s1-work/emu360/capture.py').resolve()
scanner=Path('sj6-work/deliver/stock-programming/scan-watch.py').resolve()
seed=w/(model+'-seed')
def invoke(script,args):
    subprocess.run(['python3',str(script),*map(str,args)],check=True)
if not (seed/'result.json').exists():
    invoke(capture,['--model',model,'--name',seed,'--cold','--ms',2000,'--image-dir',image])
from concurrent.futures import ThreadPoolExecutor
def one(offset):
    dest=w/(model+f'-offset{offset}')
    invoke(scanner,['--capture-root',capture.parent,'--model',model,'--name',dest,'--ms',8000,'--image-dir',image,'--seed',seed/'flash.bin','--boot',seed/'result.json','--trace','--shift',offset])
    donor=Path('s1-work/emu360/events-stock') if model=='elite' and offset==0 else Path(f's1-work/emu360/baseline-{model}/shift{offset}')
    if not (donor/'result.json').exists(): donor=Path(f's1-work/emu360/baseline-{model}/shift{offset}-trace')
    if (donor/'result.json').exists():
        with (w/(model+f'-state{offset}.json')).open('w') as f:
            subprocess.run(['python3','s1-work/emu-proof/scripts/compare_project.py',donor,f's1-work/emu360/input/{model}.elf',dest,image/f'{model}.elf'],stdout=f,check=True)
with ThreadPoolExecutor(max_workers=2) as ex: list(ex.map(one,a.offsets))
