"""Add read-only matrix-column and current drum-mask fields to the pinned capture runner."""
import argparse
from pathlib import Path
import sys

parser = argparse.ArgumentParser(add_help=False)
parser.add_argument("--capture-root", type=Path, required=True)
location, capture_args = parser.parse_known_args()
runner = location.capture_root.resolve()
capture = runner / "capture.py"
source = capture.read_text()
insert_before = "    env.update(FM1_DNBOX_MAP="
assert source.count(insert_before) == 1
add_watches = """    assert s['smk_col'][1] == 1 and s['proj'][1] == 36420
    with (dest/'observer.map').open('a') as extra_map:
        print(f"scene_scan_col {s['smk_col'][0]:x} 1", file=extra_map)
        for voice in (0, 1, 3, 6):
            print(f"scene_hitmask{voice} {s['proj'][0]+2752+8*voice:x} 4", file=extra_map)
"""
source = source.replace(insert_before, add_watches + insert_before)
sys.path.insert(0, str(runner))
sys.argv = [str(capture), *capture_args]
exec(compile(source, str(capture), "exec"), {"__file__": str(capture), "__name__": "__main__"})
