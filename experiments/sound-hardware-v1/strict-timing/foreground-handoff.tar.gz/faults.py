"""Use the actual compact settle helper and IRQ in each portable ownership case."""
from pathlib import Path
import sys
driver=Path(__file__).with_name('faults-template.py')
if not driver.exists(): driver=Path(__file__).resolve().parents[1]/'foreground/faults.py'
s=driver.read_text()
begin=s.index('prep = text[')
end=s.index('arm = text[',begin)
s=s[:begin]+"""prep = '    x0x_usb_boot_settle();'
settle = text[text.index("static void x0x_usb_boot_settle(void)"):text.index("static volatile uint8_t audio_boot_output_ready;")]
"""+s[end:]
s=s.replace("static unsigned audio_xruns,",'''static unsigned safe_mode;
static uint32_t ticks;
#define FM1_TICKS_PER_US 24u
static uint32_t fm1_ticks(void) { ticks += 24000u; return ticks; }
static unsigned audio_xruns,''')
s=s.replace('unsigned cases=0;', '''unsigned cases=0;
    safe_mode=1;
    x0x_usb_boot_settle();
    assert(!renders && ticks>=600000u);
    safe_mode=0;''')
s=s.replace('harness+irq+body','harness+settle+irq+body')
exec(compile(s,str(driver),'exec'),{'__file__':str(driver),'__name__':'__main__'})
