"""Independent strict cold-time snapshots of a genuine warm flash before the first DMA IRQ."""
from pathlib import Path
import sys,os,shutil,tempfile,subprocess,json,struct
from concurrent.futures import ThreadPoolExecutor
root=Path(sys.argv[1]).resolve()
model=sys.argv[2]
capture=Path('s1-work/emu360').resolve()
sys.path.insert(0,str(capture))
from sweep import symbols,sha
image=root/'image'/f'{model}.fwsc';elf=image.with_suffix('.elf')
syms=symbols(elf)
seed=root/(model+'-seed')/'flash.bin'
def snap(ms):
    with tempfile.TemporaryDirectory(dir=root) as name:
        d=Path(name); (d/'work').mkdir()
        shutil.copyfile(seed,d/'flash.bin')
        env={k:v for k,v in os.environ.items() if not k.startswith('FM1_')}
        original=root/(model+'-offset'+sys.argv[3])
        env.update(json.loads((original/'command.json').read_text())['env'])
        for key,fn in {'FM1_CORE_LOAD_CSV':'core.csv','FM1_DUMPRAM':'ram.bin','FM1_DNBOX_PCM':'stereo.s16le','FM1_DNBOX_TRACE':'trace.jsonl'}.items():
            env[key]=str(d/fn)
        subprocess.run([capture/'bin/fm1-live','--fwsc',image,'--mhz','360','--shot',str(ms),'--flash',d/'flash.bin'],cwd=d,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
        ram=(d/'ram.bin').read_bytes()
        def words(n,k):return struct.unpack_from('<'+'I'*k,ram,syms[n][0]-0x1c00000)
        v=words('x0x_dbg',13)
        return dict(ms=ms,in_audio=v[4],halves=v[1],last_us=v[8],max_us=v[2],raw_late=v[5],panel_timer_irqs=v[6],engine_frames=words('eng_prof_frames',1)[0],
            audio_irq_ready=ram[syms['audio_boot_output_ready'][0]-0x1c00000])
with ThreadPoolExecutor(max_workers=2) as ex:
    samples=list(ex.map(snap,[448,449,450,451,452,453,454,455,456,457,479,480]))
receipt=dict(image=sha(image),elf=sha(elf),seed=sha(seed),runner=sha(capture/'bin/fm1-live'),snapshots=samples)
(root/(model+'-early.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(samples),flush=True)
