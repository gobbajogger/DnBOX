"""Summarize the 16-column sample phase and first DMA boundaries from a real firmware trace."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
from statistics import median

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("run", type=Path)
parser.add_argument("--end-ms", type=int, default=3400)
args = parser.parse_args()
raw = (args.run / "trace.jsonl").read_bytes()
records = [json.loads(line) for line in raw.splitlines()]
header = records[0]
ticks_per_us = header["hz"] // 1000000
assert ticks_per_us == 5760
columns = [row for row in records if row.get("name") == "scene_scan_col"
           and row["cycle"] <= args.end_ms * ticks_per_us * 1000]
assert columns and all(row["core"] == 0 and row["width"] == 1 and row["offset"] == 0
                       and 0 <= row["value"] < 16 for row in columns)
phase = sorted(((row["cycle"] - (100 * ticks_per_us) * row["value"]) % (1600 * ticks_per_us))
               / ticks_per_us for row in columns)
dma = [row for row in records if row["event"] == "dma"]
entries = [row for row in records if row["event"] == "irq_enter"]
halves = [row for row in records if row["event"] == "half"]
startup = []
for row in halves[:4]:
    edge = next(edge for edge in dma if edge["seq"] == row["seq"])
    startup.append({
        "dma_sequence": row["seq"],
        "dma_sequence_at_completion": row["dma_seq_at_completion"],
        "remaining_at_irq_entry_us": round((edge["deadline_cycle"] - row["entry_cycle"]) / ticks_per_us, 6),
        "measured_render_us": row["last_us"],
        "accumulated_complete_halves": row["snapshot"]["x0x_dbg"][1],
        "accumulated_late": row["snapshot"]["x0x_dbg"][5],
        "accumulated_engine_frames": row["snapshot"]["eng_prof_frames"][0],
    })
meta = json.loads((args.run / "result.json").read_text())
print(json.dumps({
    "model": meta["model"], "duration_ms": meta["shot_ms"],
    "raw_trace_sha256": hashlib.sha256(raw).hexdigest(),
    "emulator_sha256": meta["emulator_sha256"], "scene_sha256": meta["scene_sha256"],
    "elf_sha256": meta["elf_sha256"], "fwsc_sha256": meta["fwsc_sha256"],
    "scope": "Column writes during observed audio IRQs, cut at end_ms. Startup counters include completed foreground renders.",
    "end_ms": args.end_ms, "column_store_count": len(columns),
    "stores_by_column": dict(sorted(Counter(row["value"] for row in columns).items())),
    "column_phase_us_min": min(phase), "column_phase_us_median": median(phase),
    "column_phase_us_max": max(phase),
    "first_dma_edges": [{k:e[k] for k in ("seq","scheduled_cycle","deadline_cycle","half","words")} for e in dma[:5]],
    "first_irq_entry_snapshot": {k:entries[0]["snapshot"][k] for k in ("x0x_dbg","audio_xruns","eng_prof_frames")},
    "first_4_irq_halves": startup, "final_debug": meta["debug"],
    "physical_pcm_bytes": meta["pcm_bytes"], "physical_pcm_sha256": meta["pcm_sha256"],
},indent=2))
