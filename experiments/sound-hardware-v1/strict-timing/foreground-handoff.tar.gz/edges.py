"""Verify every DMA half, all charged audio IRQs and the application frame count at each gesture."""
import argparse
from bisect import bisect_right
import csv, gzip, hashlib, io, json, struct
from pathlib import Path

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('stock',type=Path)
parser.add_argument('candidate',type=Path)
parser.add_argument('dest',type=Path)
args=parser.parse_args(); dest=args.dest; dest.mkdir(exist_ok=True)
hash_bytes=lambda b:hashlib.sha256(b).hexdigest()
hz=5760000000
def summarize(folder, name):
    pcm=(folder/'stereo.s16le').read_bytes()
    boot={};edges=[];done=[];enters=[]; trace=folder/'trace.jsonl'
    with trace.open() as f:
        for row in map(json.loads,f):
            event=row['event']
            if event=='dma':edges.append(row)
            if event=='half':done.append(row)
            if event=='irq_enter':enters.append(row)
            if event=='finish':end=row
    assert len(pcm)==len(edges)*2048
    byseq={r['seq']:r for r in done}
    seqs=[e['seq'] for e in edges]
    assert seqs==list(range(1,len(edges)+1))
    stream=io.StringIO();w=csv.writer(stream,lineterminator='\n');w.writerow(('edge','physical_half','scheduled_tick','pcm_sha256','pcm_nonzero_words','entered_tick','exited_tick','render_last_us_writes','last_us','accumulated_application_halves','accumulated_render_frames','accumulated_late','dma_at_completion'))
    entry_count=0
    for e in edges:
        seq=e['seq']; start=(seq-1)*2048; raw=pcm[start:start+2048]; assert e['half']==((seq-1)&1) and e['words']==1024
        nonzero=sum(x[0]!=0 for x in struct.iter_unpack('<h',raw))
        r=byseq.get(seq);fields=[]
        if r:
            entry_count+=r['last_us_writes']
            fields=[r['entry_cycle'],r['completion_cycle'],r['last_us_writes'],r['last_us'],r['snapshot']['x0x_dbg'][1],r['snapshot']['eng_prof_frames'][0],r['snapshot']['x0x_dbg'][5],r['dma_seq_at_completion']]
        else:fields=['']*8
        w.writerow([seq,e['half'],e['scheduled_cycle'],hash_bytes(raw),nonzero,*fields])
        if seq<=6:
            boot[str(seq)]={'first_pcm_sha256':hash_bytes(raw),'dac_nonzero_words':nonzero,'scheduled_tick':e['scheduled_cycle'],
              'completed_audio_irq':bool(r),'charged_renders':r['last_us_writes'] if r else 0,
              'render_us':r['last_us'] if r and r['last_us_writes'] else None,'irq_elapsed_us':(r['completion_cycle']-r['entry_cycle'])*1e6/hz if r else None,
              'deadline_slack_us':(e['deadline_cycle']-r['completion_cycle'])*1e6/hz if r else None}
    (dest/(name+'-dma.csv.gz')).write_bytes(gzip.compress(stream.getvalue().encode(),mtime=0))
    result=json.loads((folder/'result.json').read_text())
    out_of_irq=enters[0]['snapshot']['x0x_dbg'][1]
    assert out_of_irq==(0 if name=='stock' else 1)
    start_snapshot=enters[0]['snapshot']
    assert start_snapshot['eng_prof_frames'][0]==512*out_of_irq
    assert entry_count+out_of_irq==result['debug']['halves']
    finish_times=[r['completion_cycle'] for r in done]
    half_ends={}
    for token in (folder/'scene.keys').read_text().strip().split(','):
        ts=int(token.split(':',1)[0]);i=bisect_right(finish_times,ts*hz//1000)-1
        d=done[i];half_ends[ts]=(d['snapshot']['x0x_dbg'][1],d['snapshot']['eng_prof_frames'][0],d['snapshot']['x0x_dbg'][7],d['seq'])
    return {'trace_sha256':hash_bytes(trace.read_bytes()),'image_sha256':result['fwsc_sha256'],'elf_sha256':result['elf_sha256'],
      'physical_stereo_frames':len(pcm)//4,'physical_sha256':hash_bytes(pcm),'first_six_edges':boot,'completed_renders_charged_inside_irq':entry_count,'foreground_renders_before_first_irq':out_of_irq,
      'foreground_render_us_before_first_irq':start_snapshot['x0x_dbg'][8] if out_of_irq else None,
      'audio_irqs_completed':len(done),'unfinished_irq':end['pending_seq'],'dma_edges':len(edges),'debug':result['debug']}, half_ends, pcm
stock,st,s_pcm=summarize(args.stock,'stock')
candidate,cd,c_pcm=summarize(args.candidate,'oneblock')
assert st.keys()==cd.keys()
phases=[]
for ms in st: phases.append({'ms':ms,'stock':st[ms],'candidate':cd[ms]})
first=next((i//4 for i,(a,b) in enumerate(zip(s_pcm,c_pcm)) if a!=b),None)
report={'stock':stock,'candidate':candidate,'matching_frames_before_first_pcm_difference':first,
     'gesture_timestamp_columns':['completed_application_halves','charged_engine_frames_at_previous_finished_irq','ui_frames','dma_edge'],
     'gesture_timestamps':len(st),'same_completed_application_frames_at_gesture_timestamps':sum(st[t][0:2]==cd[t][0:2] for t in st),
     'first_control':next(v for v in phases if v['ms']==min(st)),'play':next(v for v in phases if v['ms']==4934)}
(dest/'edge-summary.json').write_text(json.dumps(report,indent=2)+'\n')
(dest/'gesture-timestamps.json.gz').write_bytes(gzip.compress(json.dumps(phases,separators=(',',':')).encode(),mtime=0))
print(report['gesture_timestamps'],report['same_completed_application_frames_at_gesture_timestamps'],first)
