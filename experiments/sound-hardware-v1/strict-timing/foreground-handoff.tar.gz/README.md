# First output rendered during USB reset

These experiments use the normal 360 MHz Sound source at ca0c00a4e5863132de4a66f5d1c477c14d699be5. The app initializes both physical audio buffers to silence and starts ALNK at the original point. While the USB PHY must settle for at least 25 ms, CPU0 runs the entire first 512-frame application block with its normal CPU1 jobs. A 4,096-byte temporary lives in existing foreground scratch. When the render completes, the boot path moves the output to an existing, then-idle audio workspace. Future UI operations and even a stalled external audio clock cannot overwrite this owned output. The stock loader is untouched.

Just before the original TIMER5/vector/guard/IRQ-enable sequence, the app acknowledges the completed initialization-only DMA periods. The first subsequent real free-half IRQ copies the parked output and checks whether the physical half changed during service. After the transfer, the ordinary audio rendering loop continues. The application still runs the normal DSP on every application block, including the foreground block. Its telemetry records that work into the original peak, CPU load, and frame counters.

A whole-render CPU1 callback would overwrite its own only mailbox job when the engine dispatches core2_jobs and core2_fx. The existing worker then waits for its own completion or reaches the 24 ms fault timeout. Retaining CPU0 as orchestration owner lets CPU1 perform its original independent jobs without changing BLE and planner ownership.

## Source and measurements

Apply foreground.patch to the base for the standalone experiment. To reproduce the joint candidate, also apply chicago-shared.patch and estimator.patch. Each model used a fresh native build directory, the genuine model package and the pinned strict emulator. native.json and joint-native.json report hashes, occupied flash, model loader and RAM accounting. No binary or SDK is present in this packet.

| Source and board | Physical gesture offset, ms | Worst half, µs | Completed application halves | Raw late | Changed project bytes of 36,420 |
| --- | ---: | ---: | ---: | ---: | ---: |
| Standalone Elite | 0 | 11,300 | 648 | 0 | 6 |
| Standalone Elite | 1 | 11,304 | 648 | 0 | 12 |
| Standalone Pro | 1 | 11,314 | 648 | 0 | 4 |
| Joint Elite | 0 | 10,261 | 648 | 0 | 7 |
| Joint Elite | 1 | 10,359 | 648 | 0 | 11 |
| Joint Pro | 1 | 10,186 | 648 | 0 | 3 |
| Joint Pro | 3 | 10,358 | 648 | 0 | 6 |

Both standalone model images occupy exactly stock flash, 546,516 bytes on Elite and 546,508 on Pro. The joint images use 96 fewer bytes on each board. All four loaders are byte-identical to their stock reference and all retain 335,092 bytes in the 344,064-byte pool. Every reported timing case has zero scene overruns. Standalone and joint each matched 17 host scenarios and all 50 raw audio/state files. strict-results.json includes the exact same-offset reference and candidate bytes. Both joint +1 runs recover every programmed 909 and 808 step. Elite still changes ten sound bytes and the bass-B length byte (35 to 32); Pro changes two sound bytes and the bass-B length byte. The other tested offsets also retain genuine user-visible differences. Neither candidate passed the complete physical acceptance gate.

## Startup evidence

Both eight-second Elite unshifted records contain 651 physical DMA halves and 333,312 stereo frames. In the foreground candidate, hardware consumed real initialized zeroes on the four opening halves. The first post-USB IRQ, on physical edge 3, submitted all 4,096 independently observed bytes in 20.095 µs. Its starting snapshot shows one completed application block, 512 engine frames and 3,624 µs charged to the renderer. The later completed IRQs charged 647 additional real blocks. The final physical IRQ is still in progress at the screenshot in both stock and candidate. DMA CSV files cover every physical edge, including data hash, nonzero samples and service duration when applicable.

The sequencer had advanced exactly 76,800 application frames at the first control gesture and 196,608 at PLAY on both images. Counts match at 147 of 148 distinct gesture timestamps. At PLAY the stock foreground had presented 193 UI frames and this image 196. The first physical DAC difference was at stereo frame 97,856. The measured median matrix-column phase before 3,400 ms was 340.582 µs, versus 343.673 µs in stock; the first ALNK edge was 7.435 µs earlier. A separate series of short strict snapshots observes zero completed frames at 449 ms, the actual live renderer at 450–453 ms and the first completed half at 454 ms. The short-run tail mode charges 3,662 µs on these separate observations; the full-scene first IRQ snapshot is authoritative for that scene.

## Replay

1. Run the model's ordinary cold build for each patched source. Use the original genuine heavy.keys physical sequence and runner identified in strict-results.json, with separately seeded 2 s cold boots and 8 s same-offset trials. The archived run.py assumes the shared diagnostic workspace containing native, s1-work/emu360, and the same-offset original model references.
2. Execute faults.py PATCHED_SOURCE. It compiles the actual USB settle, first-handoff and regular IRQ logic. It verifies 153 schedules including missing clocks and deadline faults, 3,133,440 labelled source words, every physical-bank boundary, and safe-mode USB bring-up. The independent foreground scratch is deliberately overwritten before handoff.
3. Run the repository's tests/host/audio_path_identity.py with a stock reference capture. Both final host hash lists are included.
4. For a physical ledger, run edges.py STOCK_8S_TRACE CANDIDATE_8S_TRACE OUTPUT. For the first buffer stores, run watch-bank.py with --region dma0 on a 530 ms strict warm boot. For independent early snapshots, run early.py RUN_DIRECTORY MODEL OFFSET using the matching image, seed and observer map. The buffered strict observer logs memory writes only inside a real ALNK IRQ. The early-stop snapshots and first IRQ frame/time snapshot establish the foreground render separately.
