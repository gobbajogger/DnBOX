"""Submit the staged block at the next actual physical edge already occurring during USB reset."""
from pathlib import Path
import sys
root=Path(sys.argv[1]);p=root/'firmware/src/app/main_fm1.c';s=p.read_text()
old='''    while (fm1_ticks() - reset_at < 25000u * FM1_TICKS_PER_US) {}'''
new='''    while (fm1_ticks() - reset_at < 25000u * FM1_TICKS_PER_US) {
        /* The next genuine release is the first application's original bank.
         * No later application block is synthesized during USB reset. */
        if (audio_boot_phase == AUDIO_HANDOFF && (fm1_audio_pending() & FM1_AUDIO_HALF))
            fm1_alnk0_irq();
    }'''
assert s.count(old)==1;s=s.replace(old,new)
old='''    /* Completed pre-application DMA periods carried the initialized, valid silent buffers.
     * Commit the staged first output to the next physically released half. */
    if (audio_boot_phase == AUDIO_HANDOFF)
        fm1_audio_ack_half();
'''
assert s.count(old)==1;s=s.replace(old,'''    /* A delayed clock retains any pending genuine transfer for the regular ISR. */
''')
p.write_text(s)
