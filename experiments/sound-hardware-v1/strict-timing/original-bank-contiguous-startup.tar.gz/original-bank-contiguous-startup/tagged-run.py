"""Native diagnostic only. Label the first six complete stereo outputs after normal DSP/UAC processing."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,sys,shutil,hashlib,json
r=Path('sj6-work/wire-labels').resolve();base=Path.cwd();stock=base/'native/final-init';cap=base/'s1-work/emu360'
sources={'stock':stock,'owned':base/'sj6-work/lease/tree','protected':base/'sj6-work/real-edge/tree','fixed':base/'sj6-work/phase-edge/tree'}
insert='''            uac_out_mix(o + 2u * k, REND_FRAMES);   /* USB audio from the host, after the tap and MASTER */
#endif'''
extra='''
            /* DIAGNOSTIC ONLY: a unique real signed DAC sample for every word of each initial block. */
            if (x0x_dbg.halves < 6u) {
                uint32_t i, first = x0x_dbg.halves * HALF_WORDS + 2u * k + 1u;
                for (i = 0; i < 2u * REND_FRAMES; i++)
                    o[2u * k + i] = (int32_t)((first + i) * 256u);
            }'''
def run(name):
 w=r/name;w.mkdir(exist_ok=True);tree=w/'tree'
 # Copy the full genuine checkout except old generated binaries, traces and compilation outputs.
 subprocess.run(['cp','-a','--reflink=auto',sources[name],tree],check=True)
 if name=='corrected':subprocess.run([sys.executable,base/'sj6-work/correct-bank/apply.py',tree],check=True)
 m=tree/'firmware/src/app/main_fm1.c';s=m.read_text();assert s.count(insert)==1;m.write_text(s.replace(insert,insert+extra))
 with (w/'native.log').open('w') as log:
  subprocess.run([sys.executable,base/'native/run_build.py',tree,w/'native','elite'],stdout=log,stderr=subprocess.STDOUT,check=True)
 img=w/'image';img.mkdir();shutil.copyfile(tree/'build/smk37-elite/x0x.elf',img/'elite.elf');shutil.copyfile(tree/'build/x0x-smk37-elite.fwsc',img/'elite.fwsc')
 common=['--model','elite','--image-dir',str(img)]
 with (w/'runs.log').open('w') as log:
  subprocess.run([sys.executable,cap/'capture.py',*common,'--name',w/'seed','--cold','--ms','2000'],stdout=log,stderr=subprocess.STDOUT,check=True)
  for bank in (0,1):
   subprocess.run([sys.executable,r/'bank.py','--capture-root',cap,'--bank',str(bank),*common,'--name',w/f'bank{bank}','--ms','590','--seed',w/'seed/flash.bin','--trace'],stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'native complete',flush=True)
if __name__=='__main__':
 if 'corrected' in sys.argv[1:]:sources['corrected']=base/'sj6-work/edge-standalone/tree'
 with ThreadPoolExecutor(max_workers=2) as q:list(q.map(run,sys.argv[1:] or sources))
