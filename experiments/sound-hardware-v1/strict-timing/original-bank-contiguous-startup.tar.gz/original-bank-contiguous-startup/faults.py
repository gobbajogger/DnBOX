"""Compile unmodified candidate functions into a physical two-bank clock with predeclared due edges."""
from pathlib import Path
import subprocess,tempfile,sys
p=Path(sys.argv[1])/'firmware/src/app/main_fm1.c'
s=p.read_text();common=s[s.index('enum { AUDIO_NORMAL,'):s.index('static void audio_init(void)')]
h=r'''
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#define HALF_WORDS 1024u
#define HALF_FRAMES 512u
#define FS 44100u
#define FM1_TICKS_PER_US 1u
#define FM1_AUDIO_HALF 128u
#define X0X_DEBUG 1
enum { PERIOD=11605, NEVER=0x3fffffff };
static int32_t abuf[2048],workspace[1024];
static struct {int32_t boot_output[1024];} x0x_scratch;
static struct {unsigned late;} x0x_dbg;
static struct {unsigned late_in;} x0x_worst;
static unsigned audio_xruns,safe_mode;
static unsigned us,next,first_bank,free_half,edge,pending,values[32],due[32],timestamps[32],renders;
static unsigned phase_fault,delay_us,faulted,check_words;
static void service_time(unsigned n);
static int32_t word(unsigned block,unsigned i){return block?(int32_t)(block*4096+i+1):0;}
static unsigned group(const int32_t *v){
 unsigned g=v[0]?(v[0]-1)/4096:0;
 for(unsigned i=0;i<1024;i++){++check_words;if(v[i]!=word(g,i))return 999;}
 return g;
}
static void hardware_edge(void){
 ++edge;assert(edge<32);free_half=first_bank^((edge-1)&1);
 values[edge]=group(abuf+free_half*1024);
 /* At this physical boundary the other bank begins playing and must be complete. */
 due[edge]=group(abuf+(free_half^1)*1024);
 timestamps[edge]=us;pending=128;
}
static void service_time(unsigned n){
 unsigned end=us+n;
 while(next<=end){us=next;hardware_edge();next+=PERIOD;}
 us=end;
}
static unsigned fm1_ticks(void){service_time(1);return us;}
static unsigned fm1_audio_pending(void){return pending;}
static void fm1_audio_ack_aux(unsigned p){(void)p;}
static unsigned fm1_audio_free_half(void){return free_half;}
static void fm1_audio_ack_half(void){pending=0;}
static void *engine_boot_audio_workspace(void){return workspace;}
static void delay_at(unsigned f){if(f==phase_fault&&!faulted){service_time(delay_us);faulted=1;}}
static void render_block(int32_t *buf){
 assert(pending);unsigned g=++renders;memset(workspace,77,sizeof workspace);
 for(unsigned i=0;i<1024;i++){
  if(i==512){if(buf==x0x_scratch.boot_output)delay_at(1);else delay_at(4);service_time(3500);}
  buf[i]=word(g,i);
 }
}
static void *timed_copy(void *dst,const void *src,size_t n){
 assert(n==4096);
 uint8_t *d=dst;const uint8_t *q=src;
 memcpy(d,q,n/2);
 if(dst==workspace)delay_at(2);else delay_at(3);
 service_time(20);memcpy(d+n/2,q+n/2,n/2);return dst;
}
#define memcpy timed_copy
'''
b=r'''
#undef memcpy
static unsigned missed(unsigned last,unsigned assumed_submission){
 unsigned n=0;
 for(unsigned e=assumed_submission+1;e<=last;e++){
  unsigned expected=e-assumed_submission;
  if(due[e]!=expected)++n;
 }
 return n;
}
static void launch(unsigned first,unsigned bank,unsigned fault,unsigned lag,unsigned mode){
 us=renders=pending=edge=audio_xruns=faulted=x0x_dbg.late=x0x_worst.late_in=0;
 audio_boot_phase=AUDIO_NORMAL;safe_mode=mode?1:0;first_bank=bank;free_half=bank;
 next=first;phase_fault=fault;delay_us=lag;
 memset(abuf,0,sizeof abuf);memset(workspace,65,sizeof workspace);
 memset(due,0,sizeof due);memset(values,0,sizeof values);
 x0x_usb_boot_settle();
 /* The real app installs/arms TIMER5 and enables normal interrupts after USB reset. */
 if(!safe_mode){
  if(pending)fm1_alnk0_irq();
  while(edge<11){service_time(next-us);fm1_alnk0_irq();}
 }
 assert(x0x_dbg.late==audio_xruns&&x0x_worst.late_in==audio_xruns);
}
int main(void){
 unsigned clean=0,physical_words=0;
 const unsigned normal[]={1810,5000,6700,8200,10000,13000};
 for(unsigned i=0;i<sizeof normal/sizeof *normal;i++)for(unsigned bank=0;bank<2;bank++){
   launch(normal[i],bank,0,0,0);
   assert(!audio_xruns&&!missed(10,2));
   for(unsigned e=1;e<=10;e++)assert(values[e]==(e<4?0:e-3));
   physical_words+=10*1024; ++clean;
 }
 /* A single pending bit and the modulo-two free-bank ID cannot represent all crossed edges. */
 puts("case,first_us,bank,phase,stall_us,raw,due_edge3_group,wire_edge4_group,wire_edge5_group,missed_due_edges_3to10");
 const unsigned delays[]={1000,8500,11700,23500};
 for(unsigned phase=1;phase<=4;phase++)for(unsigned d=0;d<4;d++)for(unsigned bank=0;bank<2;bank++){
  launch(6700,bank,phase,delays[d],0);
  printf("fault,6700,%u,%u,%u,%u,%u,%u,%u,%u\n",bank,phase,delays[d],audio_xruns,due[3],values[4],values[5],missed(10,2));
 }
 const unsigned slow[]={0,13000,13385,13400,15000,24995,25001,40000};
 for(unsigned i=0;i<sizeof slow/sizeof *slow;i++)for(unsigned bank=0;bank<2;bank++){
  launch(slow[i],bank,0,0,0);
  printf("phase,%u,%u,0,0,%u,%u,%u,%u,%u\n",slow[i],bank,audio_xruns,due[3],values[4],values[5],missed(10,2));
 }
 launch(6700,0,0,0,1);assert(!renders&&!audio_xruns);
 fprintf(stderr,"%u nominal alternating-bank schedules and %u labelled wire words, 32 boundary-stall tests, 16 clock phase trials, 1 safe-mode test; %u total word inspections\n",clean,physical_words,check_words);
}
'''
with tempfile.TemporaryDirectory() as t:
 f=Path(t)/'timeline.c';x=f.with_suffix('');f.write_text(h+common+b)
 subprocess.run(['cc','-O2','-std=c11','-Wall','-Wextra','-Werror',f,'-o',x],check=True)
 subprocess.run([x],check=True)
