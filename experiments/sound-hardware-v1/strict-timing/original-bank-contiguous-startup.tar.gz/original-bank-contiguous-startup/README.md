# Original-bank continuous startup diagnostic

This experiment preserves the physical bank stock intended for its first application block. It runs that real first synthesis and output processing during the required USB reset. A second physical ALNK release within the same reset submits the completed first block to bank 1. The regular IRQ then renders the next block against the next actual transfer. Both target loaders are byte-identical to stock. No firmware or package is distributed here.

## Native delivery

The first six groups carry 1,024 individually identifiable nonzero words per block in two separately observed diagnostic images. Both retain the full regular DSP. The native captured DAC progression is 0,0,0,G1,G2,G3,G4,G5,G6 on edges 1–9. At the entry of the first normal handler at edge 3 all 4,096 bytes of bank 1 already contain G1 and all words of bank 0 are still initial silence. The separate TIMER4-stamped image produced exactly the same complete DAC and resolved the handoff as follows.

| Event | Edge | Bank | Absolute ms |
|---|---:|---:|---:|
| First eligible preparation edge | 1 | 0 | 456.269690 |
| Actual pending transfer release | 2 | 1 | 467.875024 |
| TIMER4 copy begins | 2 | 1 | 467.877768 |
| TIMER4 copy completes | 2 | 1 | 467.896351 |
| Original safe-write deadline | 3 | 1 | 479.480357 |
| Captured first complete physical G1 | 4 | 1 | 491.085690 |

The measured safe margin is 11,584.006 µs. TIMER4 runs at 24 MHz. Its stamp agrees with the first independently observed normal-IRQ RAM store to within one microsecond. The unstamped diagnostic edge 4 occurred at 491.104272 ms. Code layout changes the absolute boot time slightly. Per-image results and source are included.

## Actual stock state and absolute DAC

These runs use untouched production PCM, the original 922-event heavy.keys at +1 ms, separately seeded firmware flash, the pinned strict 360 MHz runner and a cold 8-second scene. At the first player action (2,221 ms), stock on both products had completed 150 application halves and 76,800 engine frames. The continuous candidate had completed 151 halves and 77,312 frames. The same one-half difference appears at 146 of the 148 distinct gesture timestamps. At the remaining two, the more expensive candidate was inside a render when stock had completed that block. At the last complete physical half stock/candidate had reached 331,776/332,288 completed frames on both models.

| Board | Application bytes | Worst µs | Completed halves | Raw late | Full-project bytes different | Equal stereo frames out of 333,312 | First different frame |
|---|---:|---:|---:|---:|---:|---:|---:|
| Elite | 546,676 | 10,990 | 649 | 0 | 0 of 36,420 | 106,973 | 79,424 |
| Pro | 546,668 | 11,096 | 649 | 0 | 1 of 36,420 | 111,184 | 79,424 |

Pro's changed byte is the bass-B pattern length, 35 → 32. Both application images grew by 160 bytes. Both retain the same 335,092-byte pool and use 97,204 bytes of the 98,304-byte linked RAM region. These isolated startup-only native runs exceed the 10,909 µs gate. The full SHA-256 values are in outcomes.json and the cold native build receipts.

The independent nonzero stock control observed G1 at physical edge 4, silence at edge 5 and G2 at edge 6. Achieving that original first bank and delivering every following distinct application block continuously consumes one more application block before a fixed physical time than stock consumed. The original startup gap, pattern bytes and physical DAC stream are three separately measured behaviors. Full startup state, absolute musical audio, every offset, and strict occupied size have not been qualified.

## Fault boundaries

The host test compiles the actual candidate startup and ALNK functions and drives them with a two-bank scheduler, a latched pending flag and a deadline observer independent of firmware counters. Each boundary records the bank starting playback and the bank just consumed. Each normal stereo render returns distinct individually labelled nonzero words. A callback can interrupt preparation (phase 1), the 4 KiB scratch-to-engine copy (2), the 4 KiB DMA transfer (3), or a normal render (4). CSV group 0 means silence and 999 means mixed words. The missed-group total counts mismatched chronological output groups at scheduled safe boundaries, including a persistent one-block displacement. It is not a count of unique initiating faults.

All 12 supported nominal schedules across both initial bank IDs delivered 122,880 exact labelled DAC words. Additional coverage included 32 timed stalls, 16 clock offsets, and safe mode, with 1,346,578 word inspections. An injected 11,700 µs handoff stall left a partially written active bank at its original due edge and raised raw late 1; the output eventually contained intact G1 at edge 4. A 23,500 µs stall spanning two bank flips could leave the due bank mixed with raw late 0. Delaying the scratch-to-engine copy across two edges also lost the original bank without a raw fault. The stock binary contains the same modulo-two free-half detector, but the candidate adds a staging interval. This route therefore fails admission for arbitrary missed boundaries. A peripheral-proven elapsed-period observation and explicit due-bank tracking would be required before claiming exhaustive accounting under clock stalls; it would not erase the separate observed extra application block.

## Replay

Use the recovered project workspace, the pinned native Linux toolchain and SDK, native/run_build.py, s1-work/emu360/capture.py and the original 360 MHz diagnostic runner. Apply candidate.patch to clean stock ca0c00a4e5863132de4a66f5d1c477c14d699be5 to produce sj6-work/correct-bank/tree. Cold-build both boards separately, then use normal-run.py with that directory, model and 1. Place the base obtained by applying startup-input.patch in sj6-work/edge-standalone/tree, copy tagged-run.py and bank.py to sj6-work/wire-labels as run.py/bank.py. Put apply.py, stamp.py, absolute.py, faults.py and measure.py in sj6-work/correct-bank. Run the labelled native observation with python3 sj6-work/wire-labels/run.py corrected and python3 sj6-work/correct-bank/stamp.py. Recover the recorded same-offset stock reference captures. Then run absolute.py and measure.py from project root. Run the fault schedules with python3 sj6-work/correct-bank/faults.py sj6-work/correct-bank/tree. ELF and firmware packages remain independent of these source-only receipts.
