from pathlib import Path
import hashlib,json,struct,csv,sys
import numpy as np
base=Path.cwd();w=base/'sj6-work/correct-bank';wire=base/'sj6-work/wire-labels/corrected';cap=base/'s1-work/emu360'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ref(p):return json.loads((p/'result.json').read_text())
def trace(p):
 for l in (p/'trace.jsonl').open():yield json.loads(l)
def primary(p):
 j=ref(p);return {k:j[k] for k in ('debug','eng_prof_frames','audio_xruns','pcm_sha256','pcm_bytes','fwsc_sha256','elf_sha256','scene_sha256','initial_flash_sha256','emulator_sha256')}
def stamps(p):
 return [(q['completion_cycle']/5760000,q['seq'],q['snapshot']['x0x_dbg'][1],q['snapshot']['eng_prof_frames'][0]) for q in trace(p) if q['event']=='half']
def comparisons(m):
 stock=cap/f'baseline-{m}'/'shift1';cand=w/f'{m}-offset1';ts=[2221,4936,4948,7999]
 c=stamps(cand);st=base/'s1-work/native-panel/stock' if m=='elite' else base/'sj6-work/phase-edge/pro-stock-notes';s=stamps(st);assert sha(st/'stereo.s16le')==ref(stock)['pcm_sha256']
 def observed(z,t):return next(i for i in reversed(z) if i[0]<=t)
 a=np.fromfile(stock/'stereo.s16le',dtype='<i2').reshape(-1,2);b=np.fromfile(cand/'stereo.s16le',dtype='<i2').reshape(-1,2);assert a.shape==b.shape
 same=(a==b).all(1);first=int(np.flatnonzero(~same)[0]) if not same.all() else None
 project=json.loads((w/f'{m}-state1.json').read_text());target='smk37-elite' if m=='elite' else 'smk37'
 folder=w/'tree/build'/target;oa=base/'native/final-init/build'/target;loader=folder/'loader/ota.bin';assert sha(loader)==sha(oa/'loader/ota.bin')
 # Check every distinct actual physical gesture timestamp; a boundary can have an in-flight block.
 gestures=sorted(set(int(i.split(':')[0]) for i in (cand/'scene.keys').read_text().strip().split(',')))
 diffs={}
 for t in gestures:
  ds=observed(c,t)[2]-observed(s,t)[2];diffs[ds]=diffs.get(ds,0)+1
 return dict(model=m,stock=primary(stock),candidate=primary(cand),project=project,bin_bytes=(folder/'x0x.bin').stat().st_size,stock_bin_bytes=(oa/'x0x.bin').stat().st_size,same_loader_sha256=sha(loader),native_line=[l.strip() for l in (w/f'{m}-cold/build.log').read_text().splitlines() if 'pool' in l and 'image' in l][-1],stereo=dict(total_frames=len(a),equal_frames=int(same.sum()),first_unequal=first,equal_channel_words=int((a==b).sum())),gesture_time_count=len(gestures),completed_half_delta_at_gestures=diffs,physical_submissions_at_ms=[dict(time=t,stock=observed(s,t),candidate=observed(c,t)) for t in ts])
def labeled():
 ps=[wire/f'bank{i}' for i in range(2)];sources=list(map(primary,ps));assert sources[0]==sources[1]
 edges=[q for q in trace(ps[0]) if q['event']=='dma'];ent=[next(q for q in trace(p) if q['event']=='irq_enter') for p in ps]
 v=np.fromfile(ps[0]/'stereo.s16le',dtype='<i2').reshape(-1,1024);words=np.arange(1,1025);rows=[]
 for i,(q,b) in enumerate(zip(edges,v)):
  tag=next((g for g in range(1,7) if np.array_equal(b,words+(g-1)*1024)),0 if not b.any() else None)
  rows.append(dict(edge=i+1,bank=q['half'],ms=q['scheduled_cycle']/5760000,group=tag))
 assert [r['group'] for r in rows[:9]]==[0,0,0,1,2,3,4,5,6]
 full=[b''.join(bytes(e['snapshot'][f'scene_bank_{j}']) for j in range(0,4096,512)) for e in ent];assert struct.unpack('<1024i',full[1])==tuple(words*256);assert not any(full[0]);assert ent[1]['seq']==3 and ent[1]['snapshot']['eng_prof_frames']==[512]
 return dict(identity=sources[0],wire=rows,first_normal_handler_edge=3,bank0_all_zero=True,bank1_all_G1=True,at_entry_ms=ent[1]['cycle']/5760000,whole_bank_sha256=[hashlib.sha256(b).hexdigest() for b in full],trace_sha256=[sha(p/'trace.jsonl') for p in ps])
m=dict(labelled=labeled(),primary=[comparisons(m) for m in ('elite','pro')]);(w/'outcomes.json').write_text(json.dumps(m,indent=2)+'\n')
for x in m['primary']:print(x['model'],x['candidate']['debug']['max_us'],x['project']['different_bytes'],x['stereo'],x['completed_half_delta_at_gestures'],x['physical_submissions_at_ms'][:1],x['native_line'])
print(m['labelled']['wire'][:6])
