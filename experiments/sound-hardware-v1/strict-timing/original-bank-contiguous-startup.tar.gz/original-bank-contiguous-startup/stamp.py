"""Separate tagged native diagnostic. Timestamp the real transfer with the same hardware timer as the application."""
from pathlib import Path
import shutil,subprocess,sys
base=Path.cwd();w=base/'sj6-work/correct-bank/stamp';w.mkdir(exist_ok=True);tree=w/'tree'
cap=base/'s1-work/emu360'
if not tree.exists():
 subprocess.run(['cp','-a','--reflink=auto','sj6-work/wire-labels/corrected/tree',tree],check=True)
 f=tree/'firmware/src/app/main_fm1.c';s=f.read_text().replace('static volatile uint8_t audio_boot_phase;','static volatile uint8_t audio_boot_phase;\nstatic volatile uint32_t boot_wire_stamp[4];')
 needle='            memcpy(out, engine_boot_audio_workspace(), sizeof x0x_scratch.boot_output);';assert s.count(needle)==1
 s=s.replace(needle,'            boot_wire_stamp[0] = fm1_ticks();\n'+needle+'\n            boot_wire_stamp[1] = fm1_ticks();\n            boot_wire_stamp[2] = half;')
 needle='        int32_t *out = &abuf[half * HALF_WORDS];';assert s.count(needle)==1
 f.write_text(s.replace(needle,needle+'\n        boot_wire_stamp[3] = fm1_ticks();'))
 subprocess.run([sys.executable,'native/run_build.py',tree,w/'native','elite'],check=True,stdout=(w/'native.log').open('w'),stderr=subprocess.STDOUT)
 img=w/'image';img.mkdir();shutil.copyfile(tree/'build/smk37-elite/x0x.elf',img/'elite.elf');shutil.copyfile(tree/'build/x0x-smk37-elite.fwsc',img/'elite.fwsc')
 subprocess.run([sys.executable,cap/'capture.py','--model','elite','--image-dir',img,'--name',w/'seed','--cold','--ms','2000'],check=True)
p=cap/'capture.py';s=p.read_text();needle="    env.update(FM1_DNBOX_MAP=";assert s.count(needle)==1
add="""    with (dest/'observer.map').open('a') as mapping:
        assert s['boot_wire_stamp'][1]==16
        print(f"scene_stamp {s['boot_wire_stamp'][0]:x} 16",file=mapping)
"""
sys.path.insert(0,str(cap));sys.argv=[str(p),'--model','elite','--image-dir',str(w/'image'),'--name',str(w/'wire'),'--ms','590','--seed',str(w/'seed/flash.bin'),'--trace']
exec(compile(s.replace(needle,add+needle),str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
