"""Locate the diagnostic TIMER4 copy interval on the external DMA timeline."""
from pathlib import Path
import hashlib,json,struct
root=Path('sj6-work/correct-bank');p=root/'stamp/wire';main=Path('sj6-work/wire-labels/corrected/bank1')
qs=[json.loads(x) for x in (p/'trace.jsonl').open()];edge={q['seq']:q for q in qs if q['event']=='dma'};ent=next(q for q in qs if q['event']=='irq_enter');entry=struct.unpack('<4I',bytes(ent['snapshot']['scene_stamp']));writes=[q for q in qs if q['event']=='store' and q['name']=='scene_stamp' and q['seq']==3];assert len(writes)==4 and [q['offset'] for q in writes]==[12,13,14,15] and len({q['cycle'] for q in writes})==1
anchor=struct.unpack('<I',bytes(q['value'] for q in writes))[0];ms=writes[0]['cycle']/5760000;st,en,bank,_=entry;assert bank==1
absolute=lambda v:ms-((anchor-v)&0xffffffff)/24000
start=absolute(st);finish=absolute(en);edge_ms=lambda e:edge[e]['scheduled_cycle']/5760000
b=(p/'stereo.s16le').read_bytes();b0=(main/'stereo.s16le').read_bytes();assert b==b0
receipt=dict(board='Elite',clock='24 MHz TIMER4, calibrated to the first normal IRQ3 guest store of an independent timing sample; uncertainty under one microsecond',first_eligible_edge=1,first_eligible_ms=edge_ms(1),G1_bank=bank,original_release_edge=2,original_release_ms=edge_ms(2),copy_begins_ms=start,copy_ends_ms=finish,original_due_edge=3,original_due_ms=edge_ms(3),safe_margin_us=(edge_ms(3)-finish)*1000,physical_G1_edge=4,physical_G1_at_ms=edge_ms(4),TIMER4_reads=dict(begin=st,end=en,anchor=anchor),anchor_cycle=writes[0]['cycle'],complete_output_same_as_unstamped=True,DAC_sha256=hashlib.sha256(b).hexdigest(),native=json.loads((p/'result.json').read_text()))
(root/'absolute.json').write_text(json.dumps(receipt,indent=2)+'\n');print({k:v for k,v in receipt.items() if k!='native'})
