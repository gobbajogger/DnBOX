"""Observe every byte in one actual 4096-byte DMA bank on the existing, pinned runner."""
import argparse,sys
from pathlib import Path
ap=argparse.ArgumentParser(add_help=False);ap.add_argument('--capture-root',type=Path,required=True);ap.add_argument('--bank',type=int,choices=(0,1),required=True)
a,rest=ap.parse_known_args();r=a.capture_root.resolve();p=r/'capture.py';s=p.read_text()
needle='    env.update(FM1_DNBOX_MAP=';assert s.count(needle)==1
code=f'''    assert s['abuf'][1] == 8192
    with (dest/'observer.map').open('a') as mapping:
        for j in range(0,4096,512):
            print(f"scene_bank_{{j}} {{s['abuf'][0]+4096*{a.bank}+j:x}} 512",file=mapping)
'''
sys.path.insert(0,str(r));sys.argv=[str(p),*rest];exec(compile(s.replace(needle,code+needle),str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
