# Stock occupied-size and hot render candidate

Both ordinary cold package builds match their original occupied application bytes. The frozen source for the full candidate is source.patch, relative to ca0c00a4e5863132de4a66f5d1c477c14d699be5. equal-occupied.patch contains the final two-file specialization alone, relative to the earlier candidate in timing-runs/combined/source.patch. The native hashes, complete linker checks and per-file before/after SHA-256s accompany the source.

| Model | Original occupied bytes | Earlier combined candidate | This candidate | Occupied RAM | Pool used | Margin over the 8192 B reserve |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Elite | 546516 | 546116 | 546516 | 97204 | 335092 | 780 |
| Pro | 546508 | 546108 | 546508 | 97204 | 335092 | 780 |

The 400-byte increase pays for real selected hot code. The DJF channel filter, coefficient smoothing and nonlinear limiter knee are inlined. At a fixed active filter setting, this removes two channel calls per stereo sample, with further calls removed when cutoff moves and when the signal enters the nonlinear knee. The 909 kick separately inlines the original bus setup for its known track, which eliminates that call when it sounds. All arithmetic statements, rounding order, voice order and stored histories remain intact within these specializations. Two comments above the limiter knee still refer to the earlier outlined implementation in this exact frozen patch.

The R3 object comparison uses the original live function names from the final image. Master variants D/G/K inline the channel tick, coefficient smoother and limiter knee. For 909, B/S/T/R/H/A inline the bus setup in the kick/snare/tom/rim/clap/sampler call sites, C inlines the clap renderer, W inlines the noise-filter warm-up, and P caches the stable main tom phase increment. Their byte sums are rankings only. Final sizes use the ordinary stock four sections and their four-byte end marker. The selected master DGK + drum B pair subsequently received separate full builds for each board.

The existing engine fixture returned 50 identical audio/state files across 17 scenarios. The master fixture compared every state and PCM byte at O0 and O2. The 909 fixture matched 23,280 blocks at each optimization level across four PCM buses and the complete 7648-byte drum state. Use master_replay.py BASELINE CANDIDATE and the adjacent 909-center/replay.py for the focused checks. The repository tests/host/audio_path_identity.py records the complete host engine. Native target timing requires the separate pinned 360 MHz scene. Use these exact ELF/FWSC pairs for those measurements.
