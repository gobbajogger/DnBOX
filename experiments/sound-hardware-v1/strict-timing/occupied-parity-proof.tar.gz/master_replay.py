"""Run the repository's complete master-state/PCM fixture on two supplied source trees."""
from pathlib import Path
import subprocess,sys
base, candidate=map(lambda x:Path(x).resolve(),sys.argv[1:3])
runner=(candidate/'tests/host/run_a3_dsp_equivalence.py').read_text()
runner=runner.replace("ROOT = Path(__file__).resolve().parents[2]","ROOT = Path("+repr(str(candidate))+")")
needle="old = subprocess.check_output(['git', 'show', BASE + ':' + source], cwd=ROOT, text=True)"
assert runner.count(needle)==1
runner=runner.replace(needle,"old = (Path("+repr(str(base))+") / source).read_text()")
sys.argv=['run_a3_dsp_equivalence.py','master']
exec(compile(runner,'run_a3_dsp_equivalence.py','exec'),{'__name__':'__main__','__file__':str(candidate/'tests/host/run_a3_dsp_equivalence.py')})
