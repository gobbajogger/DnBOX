from pathlib import Path
p=Path('s1-work/placed/fetch.py');s=p.read_text().replace("obs=r/'observer'","obs=r/'observer-cold'")
s=s.replace("assert hashlib.sha256(seed.read_bytes()).hexdigest()==cfg['initial_flash_sha256']","assert hashlib.sha256(seed.read_bytes()).hexdigest()==cfg['initial_flash_sha256']")
src="cmd=[str(obs/'fm1-live')"
s=s.replace(src,'''sym={f[3]:int(f[0],16) for l in subprocess.check_output(['nm','-S',elf],text=True,stderr=subprocess.DEVNULL).splitlines() if len(f:=l.split())==4}
names=['original_chicago_peaking_process','original_chicago_mastercomp_process','original_chicago_chorus_advance_zero']
for idx,key in enumerate(names):env['COLD_PC_'+str(idx)]=hex(sym[key])[2:]
env['COLD_PLAY']=hex(sym['seq']+8-0x01c00000)[2:]
cmd=[str(obs/'fm1-live')''').replace("if k.startswith(('AUD','FM1'))","if k.startswith(('AUD','FM1','COLD'))")
exec(compile(s,__file__,'exec'))
