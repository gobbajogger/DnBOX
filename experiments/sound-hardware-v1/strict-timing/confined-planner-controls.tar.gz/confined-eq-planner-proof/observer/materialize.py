from pathlib import Path
import shutil,os
r=Path(__file__).resolve().parent;o=r/'observer-cold';o.mkdir(exist_ok=True)
base=Path('/workspace/scratch/cc2e3d785d40/diag-emulator')
for c in ('fm1-soc','fm1-live','fm1-emu'):
 if not (o/'src/crates'/c).exists():shutil.copytree(base/'crates'/c,o/'src/crates'/c,copy_function=os.link)
(o/'lib').mkdir(exist_ok=True);shutil.copyfile(r/'observer/build_observer.py',o/'build_observer.py')
p=o/'src/crates/fm1-soc/src/lib.rs';s=(base/'crates/fm1-soc/src/lib.rs').read_text()
s=s.replace('pub struct Soc {','''pub struct Soc {
    cold_pc: [u32; 3],
    cold_mask: u8,
    cold_play: usize,
''')
s=s.replace('let mut soc = Self {','''let mut soc = Self {
            cold_pc: std::array::from_fn(|i|std::env::var(format!("COLD_PC_{i}")).ok().and_then(|s| u32::from_str_radix(&s,16).ok()).unwrap_or(0)),
            cold_mask: 0,
            cold_play: std::env::var("COLD_PLAY").ok().and_then(|s| usize::from_str_radix(&s,16).ok()).unwrap_or(0),''',1)
s=s.replace('fn fetch_cost(&mut self, pc: u32) {','''fn fetch_cost(&mut self, pc: u32) {
        if pc==self.cold_pc[0] || pc==self.cold_pc[1] || pc==self.cold_pc[2] {
            let i=if pc==self.cold_pc[0] {0} else if pc==self.cold_pc[1] {1} else {2};
            let playing=self.ram.read8(self.cold_play as u32)!=0;
            let bit=1u8 << (i+3*playing as u8);
            if self.cold_mask & bit == 0 {
                eprintln!("cold_entry,{:08x},{},{},{}",pc,self.periph.cycles,playing as u8,self.core1_charging as u8);
                self.cold_mask |= bit;
            }
        }''',1)
p.unlink();p.write_text(s)
