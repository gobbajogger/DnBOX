from pathlib import Path
r=Path(__file__).resolve().parent
s=(r/'probe-cold.py').read_text();s=s.replace("exec(compile(s,__file__,'exec'))","""s=s.replace("n=e/('baseline-elite/shift1' if label=='stock' else 'chicago-cost-packed/elite/shift1')","n=e/'placed-island/elite/shift1'").replace("seed=e/('seed/fresh.flash' if label=='stock' else 'chicago-cost-packed/elite/seed/flash.bin')","seed=e/'placed-island/elite/seed/flash.bin'").replace("names=['original_chicago_peaking_process','original_chicago_mastercomp_process','original_chicago_chorus_advance_zero']","names=['seq_budget_key','seq_budget_release','s_drum']")
exec(compile(s,__file__,'exec'))""")
exec(compile(s,__file__,'exec'))
