from pathlib import Path
import shutil,subprocess,sys,json,os,hashlib
r=Path(__file__).resolve().parent;obs=r/'observer';e=r.parent/'emu360';label=sys.argv[1];d=obs/label;d.mkdir();(d/'work').mkdir()
n=e/('baseline-elite/shift1' if label=='stock' else 'chicago-cost-packed/elite/shift1')
cfg=json.loads((n/'result.json').read_text());fw=Path(cfg['command'][2]);elf=fw.with_suffix('.elf')
pc=next(x.split()[0] for x in subprocess.check_output(['nm','-S',elf],text=True,stderr=subprocess.DEVNULL).splitlines() if x.endswith(' s_drum'))
seed=e/('seed/fresh.flash' if label=='stock' else 'chicago-cost-packed/elite/seed/flash.bin');shutil.copyfile(seed,d/'flash.bin')
assert hashlib.sha256(seed.read_bytes()).hexdigest()==cfg['initial_flash_sha256']
env={k:v for k,v in os.environ.items() if not k.startswith('FM1_')}
env.update(FM1_STRICT='1',AUD_TRACE_PC=pc,FM1_BENCH_KEYS='@'+str(n/'scene.keys'),FM1_CORE_LOAD=cfg['env']['FM1_CORE_LOAD'],FM1_CORE_LOAD_CSV=str(d/'core.csv'),FM1_DNBOX_PCM=str(d/'pcm.raw'),FM1_DUMPRAM=str(d/'ram.bin'))
cmd=[str(obs/'fm1-live'),'--fwsc',str(fw),'--mhz','360','--shot','8000','--flash',str(d/'flash.bin')]
with (d/'log').open('w') as f:subprocess.run(cmd,env=env,cwd=d,stdout=f,stderr=subprocess.STDOUT,check=True)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
res={'command':cmd,'seed_sha256':h(seed),'diagnostic_sha256':h(obs/'fm1-live'),'env':{k:v for k,v in env.items() if k.startswith(('AUD','FM1'))},'equivalent':{i:h(d/q)==h(n/i) for i,q in [('stereo.s16le','pcm.raw'),('ram.bin','ram.bin'),('flash.bin','flash.bin'),('core.csv','core.csv')]}}
(d/'result.json').write_text(json.dumps(res,indent=2));print(label,res['equivalent'])
