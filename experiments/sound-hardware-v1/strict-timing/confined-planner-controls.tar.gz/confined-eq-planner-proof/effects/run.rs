use fm1_core::{Bus,Cpu};
use std::{env,fs};
struct Memory { bytes: Vec<u8>, ticks: u64 }
impl Bus for Memory {
    fn read8(&mut self,a:u32)->u8 {self.bytes[a as usize]}
    fn read16(&mut self,a:u32)->u16 {u16::from_le_bytes(self.bytes[a as usize..a as usize+2].try_into().unwrap())}
    fn read32(&mut self,a:u32)->u32 {u32::from_le_bytes(self.bytes[a as usize..a as usize+4].try_into().unwrap())}
    fn write8(&mut self,a:u32,v:u8){self.bytes[a as usize]=v;}
    fn write16(&mut self,a:u32,v:u16){self.bytes[a as usize..a as usize+2].copy_from_slice(&v.to_le_bytes());}
    fn write32(&mut self,a:u32,v:u32){self.bytes[a as usize..a as usize+4].copy_from_slice(&v.to_le_bytes());}
    fn add_ticks(&mut self,n:u64){self.ticks+=n;}
}
fn call(m: &mut Memory, f: u32, arguments: [u32;4]) -> (u32,u64) {
    let mut c=Cpu::new(f);c.sp=0x1cffff0;c.rets=0xfffe;c.cost_model=true;
    c.regs[..4].copy_from_slice(&arguments);
    let start=m.ticks;
    while c.pc!=0xfffe {c.step(m).unwrap();m.ticks+=1;assert!(c.insn_count<4_000_000);}
    (c.regs[0],m.ticks-start)
}
fn main() {
    let args:Vec<String>=env::args().collect();let img=fs::read(&args[1]).unwrap();
    let mut m=Memory{bytes:vec![0u8;0x2200000],ticks:0};
    m.bytes[0x2000120..0x2000120+img.len()].copy_from_slice(&img);
    let syms:Vec<u32>=fs::read_to_string(&args[2]).unwrap().lines().map(|s|u32::from_str_radix(s,16).unwrap()).collect();
    const OWNER:u32=0x1ce0000;const L:u32=0x1ce1000;const R:u32=0x1ce1400;const DL:u32=0x1ce2000;const DR:u32=0x1ce2800;
    let env=[0u32,1,63,127];
    let mut results=Vec::new();
    println!("effect,preset,frames,signal,return,ticks,preparation_ticks");
    for effect in 0..3 {for preset in 0..4 {for n in [0,1,7,32,64,128,256,511] {for signal in 0..3 {
        m.bytes[OWNER as usize..(DR+2048) as usize].fill(0);
        let start=m.ticks;
        assert_eq!(call(&mut m,syms[effect*3],[OWNER,DL,DR,0]).0,1);
        for param in 1..=3 {call(&mut m,syms[effect*3+1],[OWNER,param,env[(param as usize +preset)%4],0]);}
        if effect==2 && signal!=0 {m.write16(if signal==1 {DL} else {DR+2046},99);}
        for i in 0..511 {
            let l=match signal {0=>0,1=>if i==0 {32767} else {0},_ => ((i*3169+67)%65536) as u16};
            let r=match signal {0=>0,1=>if i==0 {32768} else {0},_ => ((i*9513+499)%65536) as u16};
            m.write16(L+i*2,l);m.write16(R+i*2,r);
        }
        let setup=m.ticks-start;
        let a=if effect==2 {[OWNER,n,0,0]} else {[OWNER,L,R,n]};
        let (rc,t)=call(&mut m,syms[effect*3+2],a);
        results.extend_from_slice(&rc.to_le_bytes());
        results.extend_from_slice(&m.bytes[OWNER as usize..(OWNER+512) as usize]);
        results.extend_from_slice(&m.bytes[L as usize..(R+1024) as usize]);
        results.extend_from_slice(&m.bytes[DL as usize..(DR+2048) as usize]);
        println!("{effect},{preset},{n},{signal},{rc},{t},{setup}");
    }}}}
    fs::write(&args[3],results).unwrap();
}
