# Strict 360 MHz audio sweep

The stock pair comes from DnBOX commit `fcf82f607cd35a263c9923071aaa25066ff6d60f`. Both production model packages receive the same 922 physical-control and MIDI events. The six trials add 0, 1, 2, 3, 4 or 5 ms uniformly to every timestamp. The first unshifted event is at 2,220 ms, the last at 7,944 ms. Each measurement covers the full 8,000 ms on the dual-core emulator, with the default LCD and USB services. No physical controller was flashed.

A passing row needs at least 648 completed halves, a maximum firmware block time of 10,909 µs or less, a raw late count of zero and zero extra lates after the warmed boot. The oscillator, filter and effects kinds used by the heavy scene are selected through the actual application. The stock image contains no optional BREAK sample pack. The separately recorded fixed-input host scene loads a generated sample when exercising that engine.

## Repeat a model

Provide the pinned `fm1-live` executable and model ELF/package pairs as `elite.elf`, `elite.fwsc`, `pro.elf` and `pro.fwsc` in an input folder. The scripts require Python 3, GNU nm and a fresh output directory. Each model receives a separate cold formatting run followed by its own two-second warmed boot. The prepared flash includes the model's package code. The later heavy shots each start from a fresh copy of that model's prepared flash.

```sh
bash scripts/qualify-one.sh /path/to/fm1-live /path/to/images /tmp/fm1-stock elite 0 1 2 3 4 5
bash scripts/qualify-one.sh /path/to/fm1-live /path/to/images /tmp/fm1-stock pro 0 1 2 3 4 5
python3 scripts/report.py /tmp/fm1-stock /tmp/fm1-results
```

The capture reads 13 little-endian words from the tested image's `x0x_dbg` ELF symbol. The capture validates the native magic. The report validates the run settings, scene SHA and PCM SHA, then records exact block counts and both late measures. The primary measurements use the native guest timer. Local host contention changes the recorded wall duration. The two independent unshifted Elite runs agreed on the timing counters and final RAM. One added the passive trace and DAC capture. The isolated PC sampler changed the unshifted measured maximum by 11 µs and is used only for hotspot attribution.

`inputs/pins.json` records the local emulator binary SHA-256, base source revision, observer source hashes, input pair and scene hashes. The source revision includes host-side observer edits. The binary digest identifies the exact build used. `inputs/gen_heavy.py` reproduced the recorded `inputs/heavy.keys` byte for byte. The native import receipts identify the separately linked packages.

## Physical dispatch and fixed-input PCM

Root-A's unshifted DAC first differs at stereo frame 160,324. The separate 4.45-second observer runs record 20 early panel audition hits in each image. The ordered voice and value bytes match throughout. The K22 press at 4,055 ms dispatches the closed 909 hi-hat (kit 0, voice 7) in DMA IRQ 312 on stock and 313 on root-A. The time difference is 11.628 ms. DMA edge 314 first outputs a changed sample 68 frames after its beginning. This edge reads the same half address rendered at IRQ 312. The first DIN MIDI event occurs at 4,910 ms and the first PLAY press at 4,934 ms.

The fixed-input regular-engine comparison rendered the 17 existing audio-identity scenarios through each engine and compared 50 audio, routed and control output files. Every byte matched. Raw PCM from the physical panel scene differs when the changed execution cost moves a polled press across a block boundary. This evidence covers the traced onset and the listed fixed-input cases.

To reproduce the control observation, use the capture arguments from the corresponding stock or candidate recording and add `--trace --panel --ms 4450`. Run `python3 scripts/panel_dispatch.py STOCK_TRACE_DIR CANDIDATE_TRACE_DIR`. `scripts/compare.py` compares completed 8-second DAC recordings at the same model and offset. Fixed-input proof used `scripts/fixed_input_root_a.py QUALIFIED_STOCK_SOURCE HOST_BUILD_CLOSURE inputs/root-a.patch` with the object closure identified in `receipts/root-a-fixed-input.json`.

The published historical d4088e60 unshifted comparator reported 11,406 µs Elite, 11,410 µs Pro, 648 halves, one raw startup late and zero scene lates. Three repeats agreed on both models. Source: Gobbajogger/DnBOX pull request 869, issue comment 6846592540. The owner's earlier shifted Elite measurement was 11,440 µs. Historical reruns belong to the separate historical evidence.
