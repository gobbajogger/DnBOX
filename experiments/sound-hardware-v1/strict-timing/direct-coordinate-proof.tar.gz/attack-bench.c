#define _POSIX_C_SOURCE 200809L
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "drum909.h"
void ref_drum909_render_st_cleared(drum909_t *,float *,float *,float *,float *,int,uint16_t);
static uint64_t ticks(void) { struct timespec t; clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t); return (uint64_t)t.tv_sec*1000000000ull+t.tv_nsec; }
static double run(int ref,int dense) {
 drum909_t d={0}; drum909_init(&d);
 float out[4][256]; unsigned reps=1200;
 uint64_t start=ticks();
 for(unsigned j=0;j<reps;j++) {
   if(dense) {for(int i=0;i<DR_NUM;i++) drum909_trigger(&d,i,0.8f);}
   else {for(int i=DR_LT;i<=DR_HT;i++) drum909_trigger(&d,i,0.8f);}
   for(int b=0;b<2;b++) {
     memset(out,0,sizeof(out));
     if(ref) ref_drum909_render_st_cleared(&d,out[0],out[1],out[2],out[3],b?256:228,0x7ff);
     else drum909_render_st_cleared(&d,out[0],out[1],out[2],out[3],b?256:228,0x7ff);
   }
 }
 return (double)(ticks()-start)/reps;
}
static int cmp(const void*a,const void*b){double x=*(const double*)a,y=*(const double*)b;return (x>y)-(x<y);}
int main(void){
 for(int dense=0;dense<=1;dense++){
  double a[9],b[9];
  for(int k=0;k<9;k++){if(k&1){b[k]=run(0,dense);a[k]=run(1,dense);}else{a[k]=run(1,dense);b[k]=run(0,dense);}}
  qsort(a,9,sizeof(double),cmp);qsort(b,9,sizeof(double),cmp);
  printf("%s median thread CPU ns/retrigger + 228+256 frames: baseline %.0f candidate %.0f delta %.2f%%\n",dense?"dense":"three toms",a[4],b[4],100*(b[4]/a[4]-1));
 }
}
