from pathlib import Path
import sys, tempfile, subprocess
r=Path(sys.argv[1]).resolve(); c=Path(sys.argv[2]).resolve()
with tempfile.TemporaryDirectory() as tmp:
    d=Path(tmp); candsrc=c/'firmware/src/dsp'; origsrc=r/'firmware/src/dsp'
    def go(*a): subprocess.run(a,check=True)
    common=['cc','-O2','-std=c99','-ffp-contract=off','-fno-fast-math','-DX0X_HOST']
    for t,s,n in [(r,origsrc,'before'),(c,candsrc,'after')]:
        go(*common,'-I',s,'-I',t/'build/gen','-c',s/'drum909.c','-o',d/(n+'.o'))
    symbols=subprocess.check_output(['nm','-g','--defined-only',d/'before.o'],text=True).splitlines()
    (d/'map').write_text(''.join(line.split()[-1]+' ref_'+line.split()[-1]+'\n' for line in symbols))
    go('objcopy','--redefine-syms='+str(d/'map'),d/'before.o',d/'ref.o')
    (d/'test.c').write_bytes(Path(__file__).with_name('attack-bench.c').read_bytes())
    go(*common,'-I',candsrc,'-I',c/'build/gen',d/'test.c',d/'ref.o',d/'after.o',candsrc/'x0x_param.c','-lm','-o',d/'test')
    go(str(d/'test'))
