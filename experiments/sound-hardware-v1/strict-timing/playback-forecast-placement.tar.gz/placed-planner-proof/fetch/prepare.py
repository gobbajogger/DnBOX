from pathlib import Path
import shutil,os
r=Path(__file__).resolve().parent;o=r/'observer';o.mkdir(exist_ok=True)
base=Path('/workspace/scratch/cc2e3d785d40/diag-emulator')
if not (o/'src').exists():
 for crate in ('fm1-soc','fm1-live'):shutil.copytree(base/'crates'/crate,o/'src/crates'/crate,copy_function=os.link)
(o/'lib').mkdir(exist_ok=True)
shutil.copyfile(r.parent/'native-panel/build_observer.py',o/'build_observer.py')
p=o/'src/crates/fm1-soc/src/lib.rs';s=(base/'crates/fm1-soc/src/lib.rs').read_text()
s=s.replace('pub struct Soc {','''pub struct Soc {
    obs_start: u32,
    obs_count: u64,
    obs_after: u32,
    obs_seen: bool,
''')
s=s.replace('let mut soc = Self {','''let mut soc = Self {
            obs_start: std::env::var("AUD_TRACE_PC").ok().and_then(|s| u32::from_str_radix(&s,16).ok()).unwrap_or(0),
            obs_count: 0, obs_after: 0, obs_seen: false,''',1)
s=s.replace('fn fetch_cost(&mut self, pc: u32) {','''fn fetch_cost(&mut self, pc: u32) {
        if !self.core1_charging {
            self.obs_count += 1;
            if pc == self.obs_start && !self.obs_seen {
                self.obs_after = 100;
                self.obs_seen = true;
            }
            if self.obs_count <= 100 || self.obs_after > 0 {
                eprintln!("fetch,{},{} ,{:08x},{}",self.obs_count,self.ticks,pc,self.obs_after);
                self.obs_after = self.obs_after.saturating_sub(1);
            }
        }''',1)
p.unlink();p.write_text(s)
