"""Summarize an isolated +1 native replay and compare the physical outcomes against the matching stock run."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

work=Path(__file__).resolve().parents[2]
base=work/'s1-work'
gate=Path(sys.argv[1]).resolve()
label=sys.argv[2]
p=base/'emu360'
native=base/'native-panel'
draw=gate/'result'
draw.mkdir(exist_ok=True)
ordinary=p/label/'elite/shift1'
stock=p/'baseline-elite/shift1'
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
def run(name,script,*args):
    text=subprocess.check_output([sys.executable,str(base/'emu-proof/scripts'/script),*map(str,args)])
    (draw/(name+'.json')).write_bytes(text)
    return json.loads(text)
project=run('project','compare_project.py',stock,p/'input/elite.elf',ordinary,gate/'images/elite.elf')
def symbols(elf):
    rows=subprocess.check_output(['nm','-S',elf],text=True,stderr=subprocess.DEVNULL).splitlines()
    return {f[3]:{'address':f[0],'bytes':int(f[1],16)} for row in rows if len(f:=row.split())==4 and f[3] in {'s_drum','scale_glide','engine_render','seq_advance','ui','seq','proj','x0x_dbg','main'}}
def fields(elf,ram):
    start=int(symbols(elf)['proj']['address'],16)-0x1c00000
    raw=ram.read_bytes()
    return {'909_clap_steps9_to16_mask':raw[start+2801],'909_clap_step16':bool(raw[start+2801]&128),'bass_b_length':raw[start+3352]}
def timing(run):
    r=json.loads((run/'result.json').read_bytes())
    return {k:r['debug'][k] for k in ('halves','max_us','late','timer_irqs')}|{k:r[k] for k in ('shift_ms','shot_ms','scene_events','scene_sha256','pcm_sha256','late_during_test','elf_sha256','fwsc_sha256','emulator_sha256')}
def diff(a,b):
    for i in range(0,min(len(a),len(b)),4):
        if a[i:i+4]!=b[i:i+4]:return i//4
    return None if len(a)==len(b) else min(len(a),len(b))//4
first=(stock/'stereo.s16le').read_bytes()
second=(ordinary/'stereo.s16le').read_bytes()
elfa=p/'input/elite.elf'
elfb=gate/'images/elite.elf'
out=dict(stock=timing(stock),candidate=timing(ordinary),stock_fields=fields(elfa,stock/'ram.bin'),candidate_fields=fields(elfb,ordinary/'ram.bin'),
    project_different_bytes=project['different_bytes'],stock_project_sha256=project['stock_project_sha256'],candidate_project_sha256=project['candidate_project_sha256'],
    stock_symbols=symbols(elfa),candidate_symbols=symbols(elfb),full_pcm_bytes=[len(first),len(second)],first_different_absolute_stereo_frame=diff(first,second))
(draw/'summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out),flush=True)
if len(sys.argv)<4:sys.exit()
overlay=native/'overlay'/label
overlay.mkdir(exist_ok=True)
for name,target in [('trace.jsonl',native/label/'trace.jsonl'),('result.json',ordinary/'result.json')]:
    link=overlay/name
    if not link.is_symlink():link.symlink_to(target)
event=run('events','compare_live_events.py',native/'overlay/stock',overlay,stock,ordinary)
pcm=run('eligible-pcm','eligible_pcm.py',native/'stock',native/label)
sys.path.insert(0,str(native))
from analyze import summarize
for name in ('stock',label):
    d=summarize(native/name)
    out[name+'_physical_dispatch']={'first_dac':d['first_signal'],'first_hit':d['hits'][0],
       'clap_and_length_writes':[e for e in d['events'] if e['tag'] in ('clap','bass_len') and e['ms']>2100]}
for c in ('stock','candidate'):
    out[c]['transport']=event[c]['transport']
out['post_play']={k:v for k,v in event.items() if k in {'common_post_play_frames','post_play_count_stock','post_play_count_candidate','post_play_ordered_rows_equal','post_play_shared_rows','pre_play_ordered_event_bytes_equal'}}|{k:v for k,v in pcm.items() if k!='eligible_common_start_frames'}
(draw/'summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out['post_play']),flush=True)
