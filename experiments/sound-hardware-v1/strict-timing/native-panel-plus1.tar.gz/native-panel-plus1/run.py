"""Replay each exact +1 stock-input primary with a host-only foreground memory observer."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys

r=Path(__file__).resolve().parent
work=r.parents[1]
e=work/'s1-work/emu360'
label=sys.argv[1]
assert label in ('stock','xmod-real')
out=r/label;out.mkdir()
normal=e/('baseline-elite' if label=='stock' else 'root-xmod-real-elite')/'shift1'
cfg=json.loads((normal/'result.json').read_bytes())
assert cfg['shift_ms']==1 and cfg['shot_ms']==8000 and cfg['scene_events']==922
fwsc=Path(cfg['command'][2]);elf=fwsc.with_suffix('.elf')
seed=e/'seed/fresh.flash' if label=='stock' else e/'root-xmod-real-elite/seed/flash.bin'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert sha(fwsc)==cfg['fwsc_sha256'] and sha(elf)==cfg['elf_sha256'] and sha(seed)==cfg['initial_flash_sha256']
s={}
for line in subprocess.check_output(['nm','-S',str(elf)],text=True,stderr=subprocess.DEVNULL).splitlines():
    f=line.split()
    if len(f)==4:s[f[-1]]=(int(f[0],16),int(f[1],16))
ob=(e/'events-stock/observer.map').read_text().splitlines()
l=json.loads((r/'ui-layout.json').read_bytes())
def row(name,sym,off,n):
    addr,size=s[sym]
    assert off+n<=size
    return f'{name} {addr+off:x} {n}'
mapping=[]
for item in ob:
    n,_,size=item.split();size=int(size)
    sym=n.removeprefix('scene_');off=0
    if n=='scene_transport':sym='seq';off=8
    mapping.append(row(n,sym,off,size))
mapping.extend([row('scene_focus_raw_notes','fm1_in',0,4),row('scene_focus_ui_keys','ui',l['keys'],4),
    row('scene_focus_ui_held','ui',l['hold_step'],5),row('scene_focus_ui_sel','ui',l['sel'],2),
    row('scene_focus_ui_context','ui',0,2),row('scene_focus_clap_9_16','proj',2752+49,1),
    row('scene_focus_bassb_length','proj',2752+200+208+192,1)])
(out/'observer.map').write_text('\n'.join(mapping)+'\n')
shutil.copyfile(seed,out/'flash.bin');shutil.copyfile(normal/'scene.keys',out/'scene.keys')
(out/'work').mkdir()
env=dict(FM1_STRICT='1',FM1_BENCH_KEYS='@'+str(out/'scene.keys'),FM1_CORE_LOAD=cfg['env']['FM1_CORE_LOAD'],
    FM1_CORE_LOAD_CSV=str(out/'core.csv'),FM1_DUMPRAM=str(out/'ram.bin'),FM1_DNBOX_PCM=str(out/'stereo.s16le'),
    FM1_DNBOX_TRACE=str(out/'trace.jsonl'),FM1_DNBOX_MAP=str(out/'observer.map'))
runner=r/'fm1-live'
cmd=[str(runner),'--fwsc',str(fwsc),'--mhz','360','--shot','8000','--flash',str(out/'flash.bin')]
meta=dict(label=label,command=cmd,env=env,normal_runner_sha256=cfg['emulator_sha256'],diagnostic_runner_sha256=sha(runner),
          firmware_sha256=sha(fwsc),elf_sha256=sha(elf),initial_flash_sha256=sha(seed),scene_sha256=sha(out/'scene.keys'),map_sha256=sha(out/'observer.map'))
(out/'command.json').write_text(json.dumps(meta,indent=2)+'\n')
with (out/'run.log').open('w') as log:
    subprocess.run(cmd,env={**{k:v for k,v in os.environ.items() if not k.startswith('FM1_')},**env},cwd=out,stdout=log,stderr=subprocess.STDOUT,check=True)
files={}
for q in ['ram.bin','flash.bin','stereo.s16le','core.csv','run.log','scene.keys']:
    a,b=sha(normal/q),sha(out/q);files[q]=dict(primary=a,diagnostic=b,equal=a==b)
meta.update(equivalence=files,trace_sha256=sha(out/'trace.jsonl'))
(out/'result.json').write_text(json.dumps(meta,indent=2)+'\n')
assert all(v['equal'] for k,v in files.items() if k!='run.log'),files
