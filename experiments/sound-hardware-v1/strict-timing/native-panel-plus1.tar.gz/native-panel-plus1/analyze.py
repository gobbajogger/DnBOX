"""Extract the original hardware-contact, foreground edit and native note timeline from full traces."""
from pathlib import Path
import argparse
import array
import hashlib
import json
import struct
import sys

NAMES={'scene_focus_raw_notes':('raw',4),'scene_focus_ui_keys':('ui_keys',4),'scene_focus_ui_held':('hold',5),
  'scene_focus_ui_sel':('sel',2),'scene_focus_ui_context':('ctx',2),'scene_focus_clap_9_16':('clap',1),
  'scene_focus_bassb_length':('bass_len',1),'scene_transport':('transport',11)}
def pos(raw):return round(raw/5760000,6)
def keys(v):return [i+5 for i in range(27) if v&(1<<i)]
def summarize(folder):
 out={'events':[],'hits':[],'dma':{},'onto':{},'focus_writes':0}
 regs={tag:bytearray(n) for tag,n in NAMES.values()}
 frames=0;last=None;queue=None
 def mask(key):return int.from_bytes(regs[key],'little')
 def flush():
  nonlocal queue
  if queue is None:return
  d=queue;tag=d['tag'];val=bytes(regs[tag])
  event={'tag':tag,'ticks':d['ticks'],'ms':pos(d['ticks']),'dma':d['dma'],'path':d['path'],
    'value':int.from_bytes(val,'little') if tag in ('clap','raw','ui_keys','bass_len') else list(val)}
  if tag in ('raw','ui_keys'):event['keys']=keys(event['value'])
  if tag=='hold':event['step_1based']=int.from_bytes(val[:1],'little',signed=True)+1
  event.update(ctx=list(regs['ctx']),selected=list(regs['sel']),held_step_1based=int.from_bytes(regs['hold'][:1],'little',signed=True)+1,
    created=regs['hold'][3],ui_keys=keys(mask('ui_keys')),raw_keys=keys(mask('raw')),clap_mask=mask('clap'),bass_b_length=mask('bass_len'))
  out['events'].append(event)
  queue=None
 for line in (folder/'trace.jsonl').open():
  r=json.loads(line);kind=r['event']
  event_name=r.get('name')
  signature=(r.get('cycle'),event_name,kind)
  if signature!=last:flush()
  last=signature
  if kind=='dma':
   out['dma'][r['seq']]={'start_ticks':r['scheduled_cycle'],'start_ms':pos(r['scheduled_cycle']),'address':r['address']}
  if kind=='irq_enter':
   # Before the focus window, the original read-only state provides its initial values.
   if r['cycle']<12_000_000_000:
    for n,(tag,size) in NAMES.items(): regs[tag][:]=bytes(r['snapshot'][n])
  if kind not in ('foreground_store','store'):continue
  if event_name=='eng_job_arg':frames+=(r['value']&255) or 256
  if event_name=='scene_eng_hit':
   out['hits'].append({'part_voice_offset':r['offset'],'velocity_byte':r['value'],'ticks':r['cycle'],'ms':pos(r['cycle']),
       'dma_irq':r['seq'],'render_frame':frames})
  if event_name not in NAMES:continue
  tag,_=NAMES[event_name];off=r['offset']
  if regs[tag][off]==r['value']:continue
  regs[tag][off]=r['value']
  queue={'tag':tag,'ticks':r['cycle'],'dma':r['seq'],'path':kind}
  out['focus_writes']+=1
 flush()
 pcm=array.array('h');pcm.frombytes((folder/'stereo.s16le').read_bytes())
 if sys.byteorder!='little':pcm.byteswap()
 frame=next(i for i,v in enumerate(pcm) if v)//2
 dma=frame//512+1
 edge=out['dma'][dma]
 out['first_signal']={'absolute_dac_frame':frame,'dma_edge':dma,'frame_in_half':frame%512,'edge_ms':edge['start_ms'],
    'signal_ms':pos(edge['start_ticks']+(frame%512)*544*240)}
 out['primary_equivalence']=json.loads((folder/'result.json').read_bytes())['equivalence']
 return out
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('input',type=Path);p.add_argument('out',type=Path);args=p.parse_args()
 args.out.mkdir(exist_ok=True)
 for name in ['stock','xmod-real']:
  d=summarize(args.input/name)
  for item,rows in d.items():
   if item=='dma':continue
   (args.out/(name+'-'+item+'.json')).write_text(json.dumps(rows,indent=2)+'\n')
  print(name,d['first_signal'],d['hits'][:2],[(r['ms'],r['value'],r['held_step_1based']) for r in d['events'] if r['tag']=='clap'])
if __name__=='__main__':main()
