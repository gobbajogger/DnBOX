from pathlib import Path
import subprocess,os,json,hashlib,sys
r=Path(__file__).resolve().parent
base=Path('/workspace/scratch/cc2e3d785d40/build-tools')
rust=base/'rust/bin/rustc';deps=base/'cargo-target/release/deps'
def ext(name):return str(next(deps.glob('lib'+name+'-*.rlib')))
env={**os.environ,'FM1_GIT':'6b60618c8-native-panel-diagnostic','FM1_GIT_DATE':'','CARGO_PKG_VERSION':'0.4.0','CARGO_MANIFEST_DIR':str(r/'src/crates/fm1-live')}
cmd=[str(rust),'--edition=2021','-C','opt-level=3','-L','dependency='+str(deps)]
subprocess.run([*cmd,'--crate-name','fm1_soc','--crate-type','rlib','--extern','fm1_core='+ext('fm1_core'),str(r/'src/crates/fm1-soc/src/lib.rs'),'-o',str(r/'lib/libfm1_soc.rlib')],env=env,check=True)
liblinks=r/'lib'
for n in ('asound','X11','Xcursor','Xrandr','Xi','Xext','xkbcommon','wayland-client','wayland-cursor','dl','pthread','m'):
 dirs=list(Path('/usr/lib/x86_64-linux-gnu').glob('lib'+n+'.so.*'))
 if dirs and not (liblinks/('lib'+n+'.so')).exists():(liblinks/('lib'+n+'.so')).symlink_to(dirs[0])
extern=[]
for name in ['fm1_core','cpal','minifb','midir']:extern+=['--extern',name+'='+ext(name)]
for d in (base/'cargo-target/release/build').glob('*/out'):
 if any(d.glob('*.a')):cmd+=['-L','native='+str(d)]
subprocess.run([*cmd,'-C','lto=true','--crate-name','fm1_live',*extern,'--extern','fm1_soc='+str(r/'lib/libfm1_soc.rlib'),'-L','native='+str(liblinks),str(r/'src/crates/fm1-live/src/main.rs'),'-o',str(r/'fm1-live')],env=env,check=True)
