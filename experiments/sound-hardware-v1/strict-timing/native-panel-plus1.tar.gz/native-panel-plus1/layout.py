from pathlib import Path
import json,re,subprocess
r=Path(__file__).resolve().parent
src=(r.parents[1]/'native/final-init/firmware/src/app/ui.c').read_text()
start=src.index('typedef struct {\n    uint8_t view, part, prev_view;')
end=src.index('    uint32_t enc_t',start)
text='#include <stddef.h>\n#include <stdint.h>\n#include <stdio.h>\n#define NVIEWS 9\n#define NPARTS 5\n#define NKIT 2\n#define NBASS 2\n'+src[start:end]+'} prefix;\nint main(void){\n'
names=['view','part','sel','hold_step','hold_drum','hold_pat','hold_created','hold_used','keys','btn','held_step']
for n in names:text+='printf("'+n+' %zu\\n",offsetof(prefix,'+n+'));\n'
text+='}\n'
(r/'ui_layout.c').write_text(text)
subprocess.run(['cc',str(r/'ui_layout.c'),'-o',str(r/'ui_layout')],check=True)
out=subprocess.check_output([str(r/'ui_layout')],text=True)
(r/'ui-layout.json').write_text(json.dumps({s.split()[0]:int(s.split()[1]) for s in out.splitlines()},indent=2)+'\n')
