"""Validate the same real-edge fault workloads using the direct guarded regular-handler variant."""
from pathlib import Path
f=Path(__file__).with_name('faults-source.py')
if not f.exists():f=Path(__file__).resolve().parents[1]/'real-edge/faults.py'
s=f.read_text()
s=s.replace("s.index('static int32_t *audio_destination')","s.index('enum { AUDIO_NORMAL,')")
s=s.replace("s.index('    if (audio_staged) {\\n        fm1_audio_ack_half();')","s.index('    if (audio_boot_phase == AUDIO_HANDOFF)\\n        fm1_audio_ack_half();')")
s=s.replace('static void fm1_irq_','static __attribute__((unused)) void fm1_irq_').replace('static void fm1_guard_','static __attribute__((unused)) void fm1_guard_')
s=s.replace('audio_staged=0','audio_boot_phase=AUDIO_NORMAL').replace('audio_staged==prepared','(audio_boot_phase==AUDIO_HANDOFF)==prepared')
s=s.replace('    assert(audio_destination[0]==abuf&&audio_destination[1]==abuf+1024);','')
s=s.replace('if(service)fm1_audio_boot_irq();else fm1_alnk0_irq();','fm1_alnk0_irq();')
s=s.replace('and guarded handoff','and ordinary fixed IRQ vector')
exec(compile(s,str(f),'exec'),{'__name__':'__main__','__file__':str(f)})
