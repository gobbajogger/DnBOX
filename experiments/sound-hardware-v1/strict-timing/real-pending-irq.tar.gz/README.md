# Real pending audio service before USB attach

All code and compilations use DnBOX sources. Each complete patch applies directly to ca0c00a4e5863132de4a66f5d1c477c14d699be5. These are independent diagnostic candidates, tested only under the project's strict 360 MHz runner and host tests.

## Fixed-vector result

The compact phase-edge.patch on Pro at the +1 ms heavy.keys offset preserved all 36,420 project bytes and all 298 ordered post-PLAY note rows over 134,656 engine frames, including drum parts, both bass voices, accent and slide. Its worst half was 10,388 µs, with 648 application halves and no raw or scene overruns. Stock recorded 11,318 µs and one startup overrun. The actual PLAY transition advanced to engine frame 197,120 on physical half 388 in both runs. The stock transition occurred at 4,947.615 ms and the candidate transition at 4,947.625 ms.

All 54 pre-PLAY audition events after the first actual key contact match in order and value. Four occurred one 512-frame application block earlier or later. Two stock writes before any user interaction cleared bass key state during its first audio IRQ. The candidate ran that block in the foreground, outside the primary probe's RAM-write observation. Direct physical reaction first differed at stereo frame 97,856. From the PLAY half to the end, 229 of 264 physical halves matched exactly. The first of the 35 changed post-PLAY halves was 584. Across this precisely defined 135,168-frame physical window, 123,675 stereo frames and 247,962 of 270,336 individual signed 16-bit samples were exactly equal. The peak channel difference was 9,528 PCM16 counts and the channel-averaged RMS difference was 567.836. The finished project and note stream establish specific fidelity while these physical timing and PCM differences remain.

## Source choices

The real-edge and phase-edge candidates accept a genuine hardware ALNK half flag during the mandatory USB PHY settle. They reserve a full nominal 512-frame period before entering the actual regular audio handler through its sole DSP call. During preparation, the destination is private foreground scratch. The handler acknowledges the real flag and performs its ordinary late check. Both physical buffers continue to carry valid initialized silence. The completed output moves to an existing dormant engine workspace until the first post-USB free boundary. When the clock arrives too late or never arrives, firmware keeps the original ordinary first-edge render path.

The fixed-vector phase-edge.patch selects the private preparation and first handoff using one byte of state. It retains the original engine, interrupt vector, protected vector-table policy and resource owners throughout. The protected real-edge.patch uses two destination pointers, temporarily gives a legitimate one-time handler the physical vector, then restores the regular handler with interrupts disabled and the top-RAM guard restored before returning. It has a larger footprint. The earlier one-shot.patch routes the first block through two C render call sites and provides the comparison for native inlining. Its normal IRQ shrank to 248 bytes while the engine was outlined. The genuine pending-edge versions recover an inlined normal IRQ, 5,112 and 5,080 bytes on Elite respectively. The original normal IRQ was 4,992 bytes. startup-only.patch separates the compact fixed-vector startup from every DSP and planner edit. edge-planner.patch keeps the compact startup and the original packed cost estimator while restoring the original Chicago DSP. Its Elite +1 isolated result was 10,267 µs, 648 halves and zero overruns, with ten sound bytes and one bass-B byte different. Actual image, loader and symbol identities are in native.json.

Each real-edge implementation's compiled-source harness exercised 749 schedules and 13,789,184 checked physical words per implementation. They included either physical bank, absent and late-arriving clocks, both sides of the USB budget cutoff, safe-mode USB, foreground scratch reuse, a real first output containing distinct nonzero words, and injected half changes during preparation, first handoff and each normal callback. All injected late events reached the original counters. Short independent snapshots show no application render through 456 ms, real rendering at 457–459 ms, one finished half at 460 ms, retained private output at 461–479 ms and successful handoff at 480 ms. These millisecond probes have their own short-run sampling mode. The strict full-scene snapshots provide authoritative charges for each full scene.

Fixed-vector native images occupy 546,452 bytes on Elite and 546,444 on Pro, 64 bytes under stock on each board. Protected-vector native images use 546,732 and 546,724 bytes, 216 bytes over stock. All model loaders match their genuine originals byte for byte and each model retains the 335,092-byte working pool and 780-byte residual margin after the 8,192-byte reserve. All 17 fixed host scenarios and all 50 audio/state files are bit-identical to production on both real-edge implementations.

## Physical trials

Each result uses the same-model, same-offset genuine warm seed and its original 922 gestures at 360 MHz. The rightmost column counts changed bytes in the entire 36,420-byte project. trials.json includes each changed original and observed value, all native input identities and the physical PCM identity.

| Candidate | Model | Offset, ms | Worst half, µs | Application halves | Raw late | Changed project bytes |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| edge-planner | elite | 1 | 10,267 | 648 | 0 | 11 |
| one-shot | elite | 1 | 10,117 | 648 | 0 | 11 |
| phase-edge | elite | 0 | 10,339 | 648 | 0 | 4 |
| phase-edge | elite | 1 | 10,355 | 648 | 0 | 1 |
| phase-edge | pro | 0 | 10,392 | 648 | 0 | 6 |
| phase-edge | pro | 1 | 10,388 | 648 | 0 | 0 |
| phase-edge | pro | 2 | 10,042 | 648 | 0 | 12 |
| phase-edge | pro | 3 | 10,382 | 648 | 0 | 2 |
| phase-edge | pro | 4 | 10,258 | 648 | 0 | 4 |
| phase-edge | pro | 5 | 10,272 | 648 | 0 | 4 |
| real-edge | elite | 0 | 10,254 | 648 | 0 | 4 |
| real-edge | elite | 1 | 9,969 | 648 | 0 | 1 |
| real-edge | pro | 1 | 10,273 | 648 | 0 | 4 |

At +1 on Elite, both genuine-pending variants preserve every sound, arrangement, bass and 808 byte. The single difference removes 909 clap step 16. Stock held the step until its foreground saw K22 at 4,061.139 ms. The protected candidate sampled the all-released keys at 4,048.373 ms and wrote the clap byte from 255 to 127 at 4,048.478 ms, before it saw K22 at 4,061.039 ms. The host observer used for this diagnosis matched its untouched primary in all RAM, flash, core.csv and stereo PCM bytes. The interface's original hold/release policy remains intact.

## Reproduction

Apply one full patch to the stated base and use its native model build. Use faults-fixed.py PATCHED_SOURCE for phase-edge or faults-source.py PATCHED_SOURCE for real-edge. Both compile the actual candidate routines and require a hosted C11 compiler. Run the repository tests/host/audio_path_identity.py against the matching production baseline. Use the archived primary's emulator, heavy.keys and seed hashes for strict runs. To reproduce the live note comparison, use notes.py compare_live_events.py STOCK_EVENT_TRACE CANDIDATE_EVENT_TRACE STOCK_PRIMARY CANDIDATE_PRIMARY. It independently initializes frame position from the first hardware IRQ snapshot, including any already-charged foreground block. The note rows, pre-PLAY frame differences and exact post-PLAY physical block differences are retained. panel.py records the equivalent read-only diagnostic contact chronology with the existing native-panel observer. No firmware, runner, SDK, device package or factory instrument is included.
