"""Exercise the exact shared IRQ, the foreground real-edge budget and the guarded one-shot handoff."""
from pathlib import Path
import subprocess,sys,tempfile
p=Path(sys.argv[1])/'firmware/src/app/main_fm1.c'
s=p.read_text()
common=s[s.index('static int32_t *audio_destination'):s.index('static void audio_init(void)')]
setup=s[s.index('    if (audio_staged) {\n        fm1_audio_ack_half();'):s.index('    fm1_timer5_start(isr_timer5, 4);\n    fm1_guard_lock_top();',s.index('    if (audio_staged) {\n        fm1_audio_ack_half();'))]
h=r'''
#include <stdint.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#define HALF_WORDS 1024u
#define HALF_FRAMES 512u
#define FS 44100u
#define FM1_TICKS_PER_US 1u
#define FM1_AUDIO_HALF 0x80u
#define FM1_IRQ_ALNK0 11u
#define X0X_DEBUG 1
static int32_t abuf[2048],hold[1024];
static struct { int32_t boot_output[1024]; } x0x_scratch;
static uint8_t safe_mode;
static unsigned time_us,edge_at,pending,free_half,inj,global_on,guarded,service,early,was_edge;
static unsigned renders,acks,audio_xruns;
static struct {unsigned late;} x0x_dbg;
static struct {unsigned late_in;} x0x_worst;
static uint32_t fm1_ticks(void){time_us+=100;if(early&&edge_at&&time_us>=edge_at&&!was_edge){pending=0x80;was_edge=1;}return time_us;}
static uint8_t fm1_audio_pending(void){return pending;}
static void fm1_audio_ack_aux(uint8_t p){(void)p;}
static unsigned fm1_audio_free_half(void){return free_half;}
static void fm1_audio_ack_half(void){++acks;pending=0;if(inj)free_half^=1;}
static void fm1_irq_off(void){assert(global_on);global_on=0;}
static void fm1_irq_on(void){assert(!global_on&&guarded);global_on=1;}
static void fm1_guard_unlock_top(void){assert(!global_on&&guarded);guarded=0;}
static void fm1_guard_relock_top(void){assert(!global_on&&!guarded);guarded=1;}
void isr_alnk0(void){}
void isr_audio_boot(void){}
static void fm1_irq_attach(unsigned n,void (*isr)(void),unsigned priority){assert(n==11&&!global_on&&!guarded&&priority==3);service=(isr==isr_audio_boot);}
static void *engine_boot_audio_workspace(void){return hold;}
static void render_block(int32_t *out){assert(pending&0x80);++renders;memset(hold,0xa7,sizeof hold);for(unsigned i=0;i<1024;i++)out[i]=renders*4096+i+1;}
'''
b=r'''
static unsigned long checked;
static void exercise(unsigned first,unsigned fault,unsigned prep_fault,unsigned safe,unsigned bank) {
    time_us=pending=was_edge=renders=acks=audio_xruns=x0x_dbg.late=x0x_worst.late_in=0;
    global_on=guarded=service=0;audio_staged=0;
    safe_mode=safe;early=1;edge_at=first;free_half=bank;inj=prep_fault;
    memset(abuf,0,sizeof abuf);memset(hold,0x3f,sizeof hold);
    x0x_usb_boot_settle();
    early=0;inj=0;
    unsigned prepared=!safe && first && first<=13400;
    assert(audio_staged==prepared && renders==prepared && time_us>=25000);
    assert(x0x_dbg.late==(prepared&&prep_fault));
    assert(audio_destination[0]==abuf&&audio_destination[1]==abuf+1024);
    for(unsigned j=0;j<2048;j++){assert(abuf[j]==0);++checked;}
    if(safe)return;
    SETUP
    global_on=guarded=1;
    memset(&x0x_scratch,0xf2,sizeof x0x_scratch);
    for(unsigned k=1;k<=16;k++){
        free_half=(k-1)%2;pending=0x80;inj=(fault==k);
        unsigned e=k>2?k-2:0;
        int32_t *out=abuf+free_half*1024,*other=abuf+(1-free_half)*1024;
        int32_t protect[1024];memcpy(protect,other,sizeof protect);
        for(unsigned j=0;j<1024;j++){assert(out[j]==(e?(int32_t)(e*4096+j+1):0));++checked;}
        if(service)fm1_audio_boot_irq();else fm1_alnk0_irq();
        assert(guarded&&global_on&&!service&&!pending&&renders==k);
        assert(!memcmp(protect,other,sizeof protect));
        assert(audio_xruns==(prepared&&prep_fault)+(fault&&k>=fault));
        assert(x0x_dbg.late==audio_xruns&&x0x_worst.late_in==audio_xruns);
    }
}
int main(void){
    const unsigned t[]={0,100,2300,6700,13000,13300,13400,13500,15000,24200,30000};
    unsigned n=0;
    for(unsigned i=0;i<sizeof t/sizeof *t;i++)for(unsigned f=0;f<=16;f++)for(unsigned p=0;p<2;p++)for(unsigned b=0;b<2;b++){exercise(t[i],f,p,0,b);++n;}
    exercise(6700,0,0,1,1);++n;
    printf("%u schedules, %lu checked physical words including slow/missing clock, startup and ordinary deadline faults and guarded handoff\n",n,checked);
}
'''
with tempfile.TemporaryDirectory() as td:
    c=Path(td)/'check.c';exe=c.with_suffix('')
    c.write_text(h+common+b.replace('SETUP',setup))
    subprocess.run(['cc','-std=c11','-Wall','-Wextra','-Werror','-Wno-sign-compare','-O2',c,'-o',exe],check=True)
    subprocess.run([exe],check=True)
