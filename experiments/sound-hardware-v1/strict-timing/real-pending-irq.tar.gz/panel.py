"""Run the existing host-only panel watch using the given native primary as its identity."""
from pathlib import Path
import sys
work=Path.cwd()
root=Path(sys.argv[1]).resolve()
script=work/'s1-work/native-panel/run.py'
raw=script.read_text()
a=raw.index('label=sys.argv[1]');b=raw.index('cfg=json.loads',a)
raw=raw[:a]+"label='candidate'\nout=Path("+repr(str(root/'panel'))+"); out.mkdir()\nnormal=Path("+repr(str(root/'elite-offset1'))+")\n"+raw[b:]
a=raw.index("seed=e/'seed/fresh.flash'");b=raw.index('sha=lambda',a)
raw=raw[:a]+"seed=Path("+repr(str(root/'elite-seed/flash.bin'))+")\n"+raw[b:]
exec(compile(raw,str(script),'exec'),{'__file__':str(script),'__name__':'__main__'})
