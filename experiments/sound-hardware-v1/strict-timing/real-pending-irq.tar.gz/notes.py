"""Initialize the event frame counter from the observed first IRQ for foreground preparation."""
from pathlib import Path
import sys
source=Path(sys.argv[1]);sys.argv=sys.argv[1:]
s=source.read_text().replace('    rendered = 0','    rendered = None').replace('        if r["event"]=="irq_enter":\n            on =','''        if r["event"]=="irq_enter":
            if rendered is None:
                rendered = r["snapshot"]["eng_prof_frames"][0]
                assert rendered in (0,512)
            on =''')
exec(compile(s,str(source),'exec'),{'__file__':str(source),'__name__':'__main__'})
