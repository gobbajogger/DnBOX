# Playback-only 909 and durable first-block storage

Two private Elite candidates use the single-block startup source in the companion oneblock-startup-six-trials packet. The first fixes the clock-stall ownership issue and restores the original loader. The second adds a 909 implementation for partial playing spans. The stock heavy scene's two deadline misses have genuine sequencer splits of 4+252 and 28+228 in the first 256-frame call, followed by an unsplit 256. The 909 change therefore selects mathematically equivalent work only while transport plays and the current engine job contains fewer than 256 frames. The normal DAC invokes engine_render at width 256.

| Unshifted Elite, identical physical input script | App bytes | Pool margin B | App renders | Raw late | Peak µs | Different stock project bytes |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Stock application | 546,516 | 780 | 648 | 1 | 11,402 | 0 |
| Durable one-block startup, stock DSP | 546,628 | 780 | 648 | 0 | 11,311 | 3 |
| Durable startup plus playing split 909 | 549,332 | 780 | 648 | 0 | 11,127 | 3 |

The two comparisons used separate image-specific flash seeds and genuine cold native packages. Both loaders match the original byte for byte. The combined application exceeds the stock footprint by 2,816 bytes and the 10,909 µs target by 218 µs. It remains an experiment.

## Clock stall and ownership

The single-block startup uses the display canvas temporarily to hold a prepared output block. A stopped audio clock between preparing and publishing that block could allow a later display repaint to overwrite its samples. The negative regression reproduces that bug using a distinguishable nonzero output and an intervening repaint. The hardened startup copies the finished 512-frame result immediately into eng_bass_buf, a separate 4,096-byte audio-owned buffer. No new engine render runs before publication. A new bass render overwrites the relevant temporary sample range before using its samples. An unsuccessful bass render does not mix the buffer, and bass_adapt_post ignores its sample arguments. This leaves the prepared block intact for an arbitrarily delayed next callback, while allowing the UI to repaint freely.

The external target observation sees 4,096 separate bytes copied into the durable scratch after the real render ended, covering its entire address range. No writes occur there on edges 2 or 3. The engine uses this scratch again on edge 4. The first complete ISR takes 3,661.395 µs including render, stable copy, acknowledgement, checks and wrapper. The real render counter records 3,633 µs. The host regression recompiles the actual IRQ with a dirty canvas and passes all 2,448 physical halves and 2,506,752 words. The hardened application costs 112 bytes on Elite. Its unshifted physical project compares equal to all stock sequences, with three different sound parameters.

## Genuine 909 control path

The candidate runs the existing 909 rendering algorithm on stopped auditions and unsplit spans. For partial playing spans, the 909 can compute center-panned dry accumulation once, interpolate its bounded tom diode directly from folded phase and advance tom envelopes by their checked block boundaries. A unity-rate aligned sampler can consume the original IMA lookahead nibbles directly. Noncentral pan or fractional and endpoint sample cases remain supported. The conditional samplers, envelopes and serial voice mixes have the same state and sample results. Testing compares all four PCM buses and every byte of the 7,648-byte 909 state across 23,280 blocks at O0 and again at O2. All 17 full production host scenarios and 50 raw audio/state files match the frozen reference.

In the original physical-programming scene, the hardened and combined candidates produce identical DAC for the first 278,612 stereo frames, including every pre-PLAY audition. The first subsequent difference appears in DMA545 at approximately 6,769.583 ms. The combined stored project loses stock's 909 handclap at step 16 and changes two mixer levels. On the complete preceding hardened version all drum steps match. Compiled code around the selection changes layout even for ordinary full jobs. The stopped stereo wrapper occupies 152 rather than 148 bytes, and run_job occupies 6,392 rather than 6,314 bytes.

## Same saved performance

Both images loaded an identical 36,420-byte project that stock firmware actually saved. The saved object remained byte-identical before and after a single scripted PLAY action. All 276 ordered logical events match. Among 206 common, on-time, 512-frame DAC blocks, all 105,472 stereo frames are bit-identical. The donor creates a heavier workload than the physical programming trial. Under that separate test its maximum changed from 13,000 to 12,772 µs and raw late count from 34 to 33.

The matched raw span CSV aligns each 909 span at its exact transport-relative frame, width, executing core and planner mask. Across 276 matched partial spans the paired median time from publication of the audio job to its stage-1 notification falls 20.055 µs. Across 344 full spans it rises 34.417 µs. These figures include dispatch and real scheduling. They do not isolate the oscillator loop. The useful decrease on the selected path and the extra cost elsewhere were both present in the same unchanged project.

## Replay

1. Start with ca0c00a4e5863132de4a66f5d1c477c14d699be5. Apply oneblock.patch from the companion one-block packet, then hardened.patch. Clone this state to establish the controlled stock-DSP baseline. Apply split909.patch only to the second copy.
2. Run the ordinary Elite SDK build and verify the source patch and every output against two-cold-elites.json. Run stalled.py on each hardened source tree to exercise the real callback against nonzero application output and delayed screen overwrite. Running it on the earlier one-block source reproduces the assertion failure.
3. Run drum-parity.py ORIGINAL COMBINED and the repository's tests/host/audio_path_identity.py --output OUT --baseline STOCK_OUT. The verified filenames and hashes are in host-hashes.json.
4. Use the pinned 360 MHz runner and unchanged heavy.keys recorded in the companion startup packet. Prepare separate cold seeds. Run each original 8-second unshifted case. Match each final project against the true stock ELF and RAM snapshot to reproduce the JSON comparison.
5. replay-saved-project.py consumes each image and seed in the named engineering workspace, prepares the verified stock SAVE fixture and runs the genuine single-PLAY scene. paired.py takes the capture script directory, stock SAVE RAM folder and matching ELF, baseline and candidate work directories, then the receipt destination. matched.json and matched-spans.csv.gz preserve the differential.
6. Complete source and measurement receipts here permit the tests to be repeated without redistributing firmware, ELF, vendor SDK files or captured flash.
