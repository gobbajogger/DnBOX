from pathlib import Path
import csv,gzip,io,json,statistics
base=Path(__file__).resolve().parent
def read(n):return json.loads((base/n).read_bytes())
x=read('two-cold-elites.json');assert x['common_consecutive_identical_stereo_frames_before_difference']==278612
a,b=x['models']
assert (a['app_bytes'],b['app_bytes'])==(546628,549332)
assert all(r['hardware_scene']['debug']['late']==0 and r['hardware_scene']['debug']['halves']==648 and r['loader_equal_stock'] for r in (a,b))
assert [v['hardware_scene']['debug']['max_us'] for v in (a,b)]==[11311,11127]
data=read('audio-owned-stage.json');assert data['after_render_copy_writes']==data['unique_offsets_after_render']==4096
assert not ({'2','3'} & data['observed_stable_buffer_writes'].keys())
m=read('matched.json');assert m['ordered_event_counts']==[276,276] and m['ordered_events_match']
assert m['eligible_common_DAC_byte_equal'] and m['eligible_common_frames']==105472
assert m['both_images_project_equal_before_and_after_PLAY'] and m['project_bytes']==36420
rows=list(csv.DictReader(io.StringIO(gzip.decompress((base/'matched-spans.csv.gz').read_bytes()).decode())))
for mode,n in [('full',344),('partial',276)]:
 subset=[r for r in rows if (int(r['span'])==256)==(mode=='full') and r['reference_core']==r['new_core'] and r['reference_plan_mask']==r['new_plan_mask']]
 g=m['matched_job_groups'][mode+'_same_core_and_plan'];assert g['spans']==len(subset)==n
 delta=statistics.median(float(r['new_time_to_909_publication_us'])-float(r['reference_time_to_909_publication_us']) for r in subset);assert abs(delta-g['median_paired_delta_us'])<1e-8
assert len(read('host-hashes.json'))==50
print('Verified both native builds, complete first-block transfer, all 50 host outputs, 276 ordered donor events and 620 paired live spans.')
