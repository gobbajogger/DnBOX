"""Transfer startup storage ownership from the display to a dormant audio-only buffer."""
from pathlib import Path
import sys
root=Path(sys.argv[1])
def edit(n,b,a):
 p=root/n;s=p.read_text();assert s.count(b)==1,(n,b);p.write_text(s.replace(b,a))
engine='firmware/src/app/engine.c'
edit(engine,'static float eng_bass_buf[2 * NBASS][256] X0X_XPOOL;', '''static float eng_bass_buf[2 * NBASS][256] X0X_XPOOL;

void *engine_boot_audio_workspace(void)
{
    _Static_assert(sizeof eng_bass_buf == 1024u * sizeof(int32_t), "one 512-frame stereo half");
    return eng_bass_buf;
}''')
h='firmware/src/app/engine.h'
edit(h,'void engine_volume(','''/* After the boot render returns, before the next render starts. */
void *engine_boot_audio_workspace(void);
void engine_volume(''')
app='firmware/src/app/main_fm1.c'
edit(app,'''            render_block(cv_storage.boot_audio);
            audio_boot_phase = AUDIO_BOOT_SILENCE;''','''            render_block(cv_storage.boot_audio);
            memcpy(engine_boot_audio_workspace(), cv_storage.boot_audio, sizeof cv_storage.boot_audio);
            audio_boot_phase = AUDIO_BOOT_SILENCE;''')
edit(app,'''            memcpy(out, cv_storage.boot_audio, sizeof cv_storage.boot_audio);''','''            memcpy(out, engine_boot_audio_workspace(), sizeof cv_storage.boot_audio);''')
edit(app,'''    fm1_irq_enable_all();
    usb_start();
#if X0X_TRS''','''    fm1_irq_enable_all();
    usb.timeouts = 0;
    fm1_usb_reset();
    uint32_t reset_at = fm1_ticks();
    while (fm1_ticks() - reset_at < 25000u * FM1_TICKS_PER_US) {}
    usb_attach_ready();
#if X0X_TRS''')
edit('firmware/src/usb.c', '''    fm1_usb_reset();
    uint32_t reset_at = fm1_ticks();
    while (fm1_ticks() - reset_at < 25000u * FM1_TICKS_PER_US) {}
    usb_attach_ready();''','''    fm1_usb_reset();
    fm1_delay_ms(25);
    usb_attach_ready();''')
