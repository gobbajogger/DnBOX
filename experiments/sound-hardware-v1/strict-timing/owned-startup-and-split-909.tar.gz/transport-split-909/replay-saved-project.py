"""Replay the real stock SAVE/project via one PLAY gesture on a separately seeded candidate."""
from pathlib import Path
import subprocess, sys
kind=Path(sys.argv[1]).resolve()
top=Path.cwd()
r=top/'s1-work/emu360'
scripts=top/'s1-work/emu-proof/scripts'
flash=kind/'project.flash'
with (kind/'project-flash.json').open('w') as f:
 subprocess.run([sys.executable,str(scripts/'save_fixture.py'),str(r/'seed/fresh.flash'),str(r/'matched/stock-save/flash.bin'),str(kind/'seed/flash.bin'),str(flash)],stdout=f,check=True)
base=[sys.executable,str(scripts/'capture.py'),'--model','elite','--scene',str(r/'matched/play-only.keys'),'--supplemental','--image-dir',str(kind/'image'),'--runner',str(r/'bin/fm1-live'),'--out',str(kind),'--seed',str(flash)]
subprocess.run(base+['--name','matched-boot','--ms','2000'],check=True)
subprocess.run(base+['--name','matched-play','--ms','5500','--trace','--behavior','--boot',str(kind/'matched-boot/result.json')],check=True)
