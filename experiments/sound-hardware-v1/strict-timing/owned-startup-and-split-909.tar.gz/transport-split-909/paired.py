"""Compare the same genuine saved project, relative musical onsets, DAC blocks and 909 service spans."""
import argparse,csv,gzip,hashlib,io,json,statistics,sys
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('scripts',type=Path);p.add_argument('donor',type=Path);p.add_argument('donor_elf',type=Path);p.add_argument('baseline',type=Path);p.add_argument('candidate',type=Path);p.add_argument('output',type=Path)
a=p.parse_args();sys.path.insert(0,str(a.scripts.resolve()))
from compare_project import read_region
from compare_live_events import parse,relative_after
from eligible_pcm import chunks
sha=lambda b:hashlib.sha256(b).hexdigest()
donor=read_region(a.donor,a.donor_elf,'proj')
out=a.output;out.mkdir(exist_ok=True)
data=[]
def spans(run):
    rendered=0;transport=None; start=None;finished={};cur=None
    for line in (run/'trace.jsonl').open():
        r=json.loads(line);ev=r['event']
        if ev=='irq_enter':cur=r['snapshot']['eng_c1_mask'][0]
        if ev!='store':continue
        if r['name']=='eng_c1_mask':cur=r['value']
        if r['name']=='scene_transport' and r['offset']==0 and r['value']==1:transport=rendered
        if r['name']=='eng_job_arg':
            length=(r['value']&255) or 256
            start=(r['cycle'],rendered-transport,length,cur) if transport is not None else None
            rendered+=length
        elif r['name']=='eng_stage' and r['value']==1 and start:
            t,off,n,mask=start
            if r['cycle']>=t:finished[(off,n)]=(r['seq'],mask,r['core'],(r['cycle']-t)/5760)
            start=None
    return finished
for root in (a.baseline,a.candidate):
 run=root/'matched-play'; elf=root/'image/elite.elf'
 assert read_region(root/'matched-boot',elf,'proj')==donor==read_region(run,elf,'proj')
 trace=parse(run);d=trace['result']
 data.append((trace,spans(run),chunks(run),{'image_sha256':d['fwsc_sha256'],'transport':trace['transport'],'max_us':d['debug']['max_us'],'raw_late':d['debug']['late'],'halves':d['debug']['halves'],'pcm_sha256':d['pcm_sha256']}))
x,y=data
frames=min(z[0]['completed_rendered_frames']-z[0]['transport']['frame'] for z in data)
e0,e1=(relative_after(z[0],frames) for z in data)
common=sorted(x[2].keys()&y[2].keys());before=b''.join(x[2][k] for k in common);after=b''.join(y[2][k] for k in common)
groups={};csvdata=io.StringIO();w=csv.writer(csvdata,lineterminator='\n');w.writerow(('transport_frame','span','reference_dma','new_dma','reference_core','new_core','reference_plan_mask','new_plan_mask','reference_time_to_909_publication_us','new_time_to_909_publication_us'))
for key in sorted(x[1].keys()&y[1].keys()):
 off,n=key; d0,m0,c0,t0=x[1][key];d1,m1,c1,t1=y[1][key];w.writerow([off,n,d0,d1,c0,c1,m0,m1,t0,t1])
 grp=('partial' if n<256 else 'full')+('_same_core_and_plan' if (m0,c0)==(m1,c1) else '_different_core_or_plan')
 groups.setdefault(grp,[]).append((t0,t1))
report={'donor_sha256':sha(donor),'project_bytes':len(donor),'both_images_project_equal_before_and_after_PLAY':True,'baseline':x[3],'candidate':y[3],'common_rendered_frames_after_PLAY':frames,
 'ordered_event_counts':[len(e0),len(e1)],'ordered_events_match':e0==e1,'eligible_common_on_time_DAC_blocks':len(common),'eligible_common_frames':len(common)*512,
 'eligible_common_DAC_byte_equal':before==after if common else None,'eligible_common_raw_sha256':[sha(before),sha(after)] if common else [],
 'job_observation':'from guest eng_job_arg publication to first stage-1 store; includes dispatch and scheduling, not isolated DSP cycles',
 'matched_job_groups':{k:{'spans':len(v),'baseline_median_us':statistics.median(t for t,_ in v),'candidate_median_us':statistics.median(t for _,t in v),'median_paired_delta_us':statistics.median(b-a for a,b in v)} for k,v in groups.items()}}
(out/'matched.json').write_text(json.dumps(report,indent=2)+'\n');(out/'matched-spans.csv.gz').write_bytes(gzip.compress(csvdata.getvalue().encode(),mtime=0));print(json.dumps(report))
