"""Exercise the compiled candidate IRQ's buffer ownership with distinct nonzero app blocks."""
from pathlib import Path
import subprocess, sys, tempfile
source = (Path(sys.argv[1])/"firmware/src/app/main_fm1.c").read_text()
region = source[source.index("enum { AUDIO_RUN,"):source.index("extern void isr_alnk0")]
handoff = next(line.strip() for line in source.splitlines() if "audio_boot_phase = audio_boot_phase ==" in line)
common = r"""
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#define HALF_WORDS 1024u
#define FM1_AUDIO_HALF 0x80u
#define X0X_DEBUG 1
static struct { int32_t boot_audio[HALF_WORDS]; } cv_storage;
static int32_t abuf[2*HALF_WORDS];
static int32_t bass_workspace[HALF_WORDS];
static __attribute__((unused)) void *engine_boot_audio_workspace(void) { return bass_workspace; }
static uint32_t free_index, late_change, activity, render_count, ack_count;
static uint8_t pending;
static struct { unsigned late; } x0x_dbg;
static struct { unsigned late_in; } x0x_worst;
static unsigned audio_xruns;
static uint8_t fm1_audio_pending(void) { return pending; }
static void fm1_audio_ack_aux(uint8_t p) { (void)p; }
static uint32_t fm1_audio_free_half(void) { return free_index; }
static void fm1_audio_ack_half(void) { ++ack_count; pending = 0; if(late_change) free_index ^= 1; }
static void render_block(int32_t *out) {
    ++render_count;
    for (uint32_t word=0; word<HALF_WORDS; ++word)
        out[word] = (int32_t)(render_count*4096+word+1);
}
"""
body = r"""
static void exercise(unsigned settle, unsigned inject_late) {
    memset(abuf, 0, sizeof abuf);
    memset(&cv_storage, 0x33, sizeof cv_storage);
    render_count=ack_count=0; audio_xruns=x0x_dbg.late=x0x_worst.late_in=0;
    pending=0;
    audio_boot_phase=AUDIO_BOOT_PREPARE;
    for(unsigned seq=1;seq<=16;seq++) {
        if(seq==settle+1) {
            HANDOFF
            /* The stalled clock may allow arbitrarily many full-screen repaints. */
            memset(&cv_storage,0xA5,sizeof cv_storage);
        }
        unsigned half=(seq-1)%2;
        unsigned expected = settle ? (seq>settle+2 ? seq-settle-2 : 0) : (seq>2 ? seq-2 : 0);
        for(unsigned word=0;word<HALF_WORDS;word++)
            assert(abuf[half*HALF_WORDS+word] == (expected ? (int32_t)(4096*expected+word+1) : 0));
        free_index=half;pending=FM1_AUDIO_HALF;late_change=(inject_late==seq);
        int32_t before[HALF_WORDS];
        memcpy(before, abuf+(1-half)*HALF_WORDS, sizeof before);
        fm1_alnk0_irq();
        assert(!pending && ack_count==seq);
        assert(memcmp(before,abuf+(1-half)*HALF_WORDS,sizeof before)==0);
        assert(audio_xruns==(inject_late && seq>=inject_late));
        assert(x0x_dbg.late==audio_xruns && x0x_worst.late_in==audio_xruns);
    }
    assert(render_count==(settle ? 16-settle : 16));
}
int main(void) {
    unsigned cases=0;
    for(unsigned settle=0;settle<=8;settle++)
        for(unsigned inject=0;inject<=16;inject++) {
            exercise(settle,inject); cases++;
        }
    printf("%u startup sequences, 2448 physical halves, 2506752 individually verified words\n",cases);
    return 0;
}
"""
with tempfile.TemporaryDirectory() as t:
    src=Path(t)/"test.c";out=Path(t)/"test"
    src.write_text(common+region+body.replace("HANDOFF",handoff))
    subprocess.run(["cc","-std=c11","-O2","-Wall","-Wextra","-Werror","-Wno-unused-variable",str(src),"-o",str(out)],check=True)
    subprocess.run([str(out)],check=True)
