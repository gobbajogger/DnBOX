#!/usr/bin/env python3
import argparse, csv, hashlib, json, os, re, shutil, struct, subprocess, sys, time
from pathlib import Path
from sweep import sha, symbols
p=argparse.ArgumentParser()
p.add_argument('--model',choices=['elite','pro'],required=True)
p.add_argument('--name',required=True)
p.add_argument('--ms',type=int,default=8000)
p.add_argument('--shift',type=int,default=0)
p.add_argument('--cold',action='store_true')
p.add_argument('--image-dir',type=Path)
p.add_argument('--seed',type=Path)
p.add_argument('--boot',type=Path)
p.add_argument('--trace',action='store_true')
p.add_argument('--profile',help='begin_ms,end_ms')
a=p.parse_args()
r=Path(__file__).resolve().parent
src=a.image_dir.resolve() if a.image_dir else r/'input'
dest=r/a.name
dest.mkdir(parents=True)
(dest/'work').mkdir()
fwsc,elf=src/(a.model+'.fwsc'),src/(a.model+'.elf')
s=symbols(elf)
keys=(r/'input/heavy.keys').read_text()
events=keys.strip().split(',')
adjusted=','.join(f"{int(e.split(':',1)[0])+a.shift}:{e.split(':',1)[1]}" for e in events)+'\n'
(dest/'scene.keys').write_text(adjusted)
assert a.shift or adjusted==keys
if not a.cold:shutil.copy2(a.seed,dest/'flash.bin')
env=dict(FM1_STRICT='1',FM1_BENCH_KEYS='@'+str(dest/'scene.keys'),FM1_CORE_LOAD=f"{s['_c1_start'][0]:x}-{s['_c1_end'][0]:x}",FM1_CORE_LOAD_CSV=str(dest/'core.csv'),FM1_DUMPRAM=str(dest/'ram.bin'),FM1_DNBOX_PCM=str(dest/'stereo.s16le'))
if a.trace:
    expected={'x0x_dbg':52,'audio_xruns':4,'eng_prof':32,'eng_prof_frames':4,'eng_job_cost':20,'eng_plan':1,'eng_c1_mask':1,'eng_stage':4,'eng_mastered':4,'eng_do_master':1,'eng_job_arg':4,'brk_silent_now':4,'usr_nz':3,'nloops':4,'pack_n':4,'kbuf':1024,'dry_l':1024,'dry_r':1024}
    assert all(s[n][1]==v for n,v in expected.items())
    (dest/'observer.map').write_text(''.join(f"{n} {s[n][0]:x} {v}\n" for n,v in expected.items()))
    extra = {'eng_hit':22,'eng_hit_ms':88,'d8_trigger_frame':52,'cq_r':4,'cq_w':4,'bass_held':2,'original_seq_note':4,'bass_accent':2,'bass_slide':2,'part_off_live':1,'brk_applied':12}
    assert all(s[n][1]==v for n,v in extra.items())
    with (dest/'observer.map').open('a') as f:
        for n,v in extra.items():f.write(f"scene_{n} {s[n][0]:x} {v}\n")
        assert s['seq'][1]==440
        f.write(f"scene_transport {s['seq'][0]+8:x} 11\n")
    env.update(FM1_DNBOX_MAP=str(dest/'observer.map'),FM1_DNBOX_TRACE=str(dest/'trace.jsonl'))
if a.profile:env['FM1_TPROF']=str(dest/'profile.txt')+','+a.profile
cmd=[str(r/'bin/fm1-live'),'--fwsc',str(fwsc),'--mhz','360','--shot',str(a.ms),'--flash',str(dest/'flash.bin')]
meta=dict(model=a.model,shot_ms=a.ms,shift_ms=a.shift,env=env,command=cmd,scene_events=len(events),scene_sha256=sha(dest/'scene.keys'),initial_flash_sha256=None if a.cold else sha(dest/'flash.bin'),fwsc_sha256=sha(fwsc),elf_sha256=sha(elf),emulator_sha256=sha(r/'bin/fm1-live'))
(dest/'command.json').write_text(json.dumps(meta,indent=2)+'\n')
started=time.monotonic()
with (dest/'run.log').open('w') as log:
    subprocess.run(cmd,env={**{k:v for k,v in os.environ.items() if not k.startswith('FM1_')},**env},cwd=dest,stdout=log,stderr=subprocess.STDOUT,check=True)
ram=(dest/'ram.bin').read_bytes()
def words(sym,n):return struct.unpack_from('<'+'I'*n,ram,s[sym][0]-0x01c00000)
dbg=dict(zip(('magic','halves','max_us','nested','in_audio','late','timer_irqs','ui_frames','last_us','cpu_q8','boots','stage','crash_seen'),words('x0x_dbg',13)))
assert dbg['magic']==0x44424731 and dbg['halves']>0
pcm=dest/'stereo.s16le'
assert pcm.stat().st_size and pcm.stat().st_size%4==0
result=dict(**meta,debug=dbg,audio_xruns=words('audio_xruns',1)[0],eng_prof_frames=words('eng_prof_frames',1)[0],eng_prof=words('eng_prof',8),host_seconds=time.monotonic()-started,final_flash_sha256=sha(dest/'flash.bin'),pcm_sha256=sha(pcm),pcm_bytes=pcm.stat().st_size)
if a.boot:
    boot=json.loads(a.boot.read_text())['debug']
    result.update(boot_late=boot['late'],late_during_test=dbg['late']-boot['late'],within_target=dbg['max_us']<=10909 and dbg['late']-boot['late']==0 and dbg['halves']>=648,raw_zero_late=dbg['late']==0)
(dest/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(a.name,dbg,'host',result['host_seconds'],flush=True)
