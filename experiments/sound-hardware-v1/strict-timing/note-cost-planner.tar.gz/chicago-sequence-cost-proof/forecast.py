"""Replay measured planner inputs at stock Chicago resumption and calculate both legal core assignments."""
from pathlib import Path
import argparse
import hashlib
import json

def plan_cost(mask, cost):
    clocks=[0,240 if mask else 0]
    owner=mask&1
    clocks[owner]+=cost[0]
    previous=clocks[owner]
    for part in (1,2,3):
        owner=mask>>part&1
        mix=cost[part]>>4
        clocks[owner]+=cost[part]-mix
        clocks[owner]=max(clocks[owner],previous)+mix
        previous=clocks[owner]
    clocks[mask>>4&1]+=cost[4]
    return max(clocks)

def forecast(n,estimates,previous,allowed):
    c=[v*max(n,64)//256 for v in estimates]
    old=plan_cost(previous,c)
    b,choice=old,previous
    for mask in range(32):
        if mask&~allowed:continue
        check=plan_cost(mask,c)
        if check<b:b,choice=check,mask
    adopted=choice if b*8<old*7 or previous&~allowed else previous
    return dict(normalized_estimate=estimates,scaled=c,prior=previous,old_t24=old,best_t24=b,best=choice,adopted=adopted)

def rows(trace,halves):
    result=[];note=[0,0,255,255];cached=None;estimates=[0]*5;active=False;lastmask=0;lastoff=None;pending=None
    with trace.open() as f:
        for line in f:
            e=json.loads(line)
            if e['event']!='store':continue
            n,o,v=e['name'],e['offset'],e['value'];q=e['seq']
            if n=='eng_job_cost':estimates[o//4]=v
            if n=='eng_c1_mask':lastmask=v
            if n=='scene_original_seq_note':
                note[o]=v
                if o!=3:continue
                pitch=int.from_bytes(bytes(note[2:4]),'little',signed=True)
                if pitch<0:
                    if active:
                        cached=estimates[3];lastoff=(q,e['cycle']/5760000)
                    active=False
                else:
                    if q in halves and not active and cached is not None:
                        pending=(q,e['cycle']/5760000,pitch,cached,lastoff)
                    active=True
            if n=='eng_job_arg' and pending is not None:
                nframes=v%256 or 256;q0,ms,pitch,saved,off=pending
                assert q==q0
                cost=list(estimates);with_saved=cost.copy();with_saved[3]=max(cost[3],saved)
                result.append(dict(dma=q,ms=ms,frames=nframes,note=pitch,last_release_dma=off[0],last_release_ms=off[1],
                    previous_release_cost=saved,stock=forecast(nframes,cost,lastmask,23),restored=forecast(nframes,with_saved,lastmask,23)))
                pending=None
    assert len(result)==len(halves)
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('trace',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    rr=rows(a.trace,{419,605})
    a.output.write_text(json.dumps(dict(stock_trace_sha256=hashlib.sha256(a.trace.read_bytes()).hexdigest(),rows=rr),indent=2)+'\n')
    print(json.dumps(rr))
