# Original-bank startup and stock timing qualification

Source patches apply independently to DnBOX lane/sound at `03f92a7d94ad29bdb4a6bb238311ba12776401ea`. The production firmware at `ca0c00a4e5863132de4a66f5d1c477c14d699be5` is identical over the affected files. All builds and captures used the project’s native Linux toolchain and fm1-live SMK model. These experimental patches fail full stock equivalence.

## Startup change

The original engine now renders its first complete block during the USB reset settle, directly into the original DMA bank after the second observed release. The other initialized bank provides the single physical silent transfer that stock emits before its next block. The release variants preserve a pending DMA transfer when only one release occurs before the USB wait ends. Safe mode and a stopped audio clock remain bounded.

A genuine saved Clip project makes the first block distinguishable from silence. A snapshot after physical edge 2 at 486 ms shows all 1,024 original signed DMA words in bank 1, including 18 nonzero values between −7 and +9. The complete bank SHA-256 is `097a7c7f2209e4d423767c8c6d34aa9a28e0262eba720977c9baf45c7109a2b4`. The wire emits ten nonzero PCM16 samples on edge 4 and silence on edge 5. Both model images in exact-size reproduce all 30,208 captured stereo frames and all 36,420 saved project bytes through 1,150 ms. Every later timing comparison uses absolute frames.

## Complete strict timing sweep

Each 8-second test shifts all 922 physical input events together. Every exact-size run retired 648 audio halves and reported zero raw late transfers and zero audio xruns. The measured deadline is 11,609 µs and the requested margin is 700 µs. Both firmware images keep stock application/package lengths, byte-identical loaders, 1,100 free ordinary RAM bytes and 8,972 free pool bytes. The physical runner SHA-256 is `04c795b1961298cbd10d4bd9881ab97fde5eef7ff179f49a6b953dab78d43dc8`.

| Board | Offset ms | Max µs | Different project bytes | First project offset, zero-based | First different stereo frame |
|---|---:|---:|---:|---:|---:|
| elite | 0 | 10480 | 3 | 1960 | 97856 |
| elite | 1 | 10411 | 0 | — | 97856 |
| elite | 2 | 10185 | 13 | 1583 | 199286 |
| elite | 3 | 10471 | 5 | 1960 | 102402 |
| elite | 4 | 10428 | 10 | 1583 | 79424 |
| elite | 5 | 10406 | 0 | — | 79424 |
| pro | 0 | 10469 | 4 | 1960 | 97856 |
| pro | 1 | 10395 | 10 | 1583 | 97856 |
| pro | 2 | 10184 | 12 | 1583 | 102402 |
| pro | 3 | 10479 | 3 | 1960 | 199286 |
| pro | 4 | 10485 | 4 | 1960 | 79424 |
| pro | 5 | 10419 | 0 | — | 79424 |

Three of twelve projects match exactly. All twelve complete physical audio streams differ from stock. On Elite at +1 ms, stock and candidate emit the same first 97,856 stereo frames and save the same project. The native observer shows the raw note bit arriving in interval 189 on both. Stock foreground services it before edge 190 and candidate foreground after that edge. Full-velocity 909 drum index 4 therefore enters the render in half 190 and 191 respectively. At absolute frame 97,856 stock emits (−28, −28) and candidate emits (−667, −667). The observer’s RAM, PCM and flash hashes match the primary strict runs. See `live-first-difference.json` for the raw cycle timestamps and primary-versus-instrumented evidence.

## Patch comparisons

* `direct` renders the original startup block in place. It still exceeds the application size and timing target on the original scene.
* `compact-cost` also preserves the currently measured active Chicago job cost across sequencer rests, avoiding a planner underestimate on the next note. All twelve timings meet the target. All twelve physical projects differ.
* `release` adds bounded handling for an absent or delayed audio clock. `exact-size` pairs this with three Chicago effects compiled for smaller code. Full native effects state and output across 288 calls (1,918,080 bytes) match stock. Peaking EQ costs 18.94% more target ticks and chorus 78.43% more; master compression costs 0.036% more. The 17 standard host scenes match across 50 files. Retain these build and timing results as experimental evidence.
* `latched` acknowledges the current release before starting the block so a second physical edge remains observable even after two bank flips. `ramp` derives two setters’ exact original 128-entry gain ramps from integer arithmetic in place of the shared table. It leaves the three effect render kernels at stock optimization and produces applications 48 bytes smaller than stock on both boards. Each variant passes 258 controlled clock schedules, including 12 ms and 24 ms stalls. Both still fail live stock equivalence.
* `foreground`, `early-irq` and `simple-irq` record additional startup/IRQ scheduling comparisons. Each patch is relative to the same stock checkout. The build receipts record each actual app, loader and package.

## Reproduce

Start from two clean copies at the source commit above. Apply one source patch to the candidate tree. Build both for each board with the project’s Linux JieLi toolchain and AC79 SDK. Per-board build receipts record complete toolchain version names and options. Supply the matching ELF and FWSC from each build to the strict project emulator. Use a new output directory per board.

```sh
git apply "$PACKET/exact-size/source.patch"
BOARD=smk37 MODEL=elite JIELI_DOCKER=0 sh build.sh
python3 "$PACKET/check_clock.py" "$PWD"
python3 "$PACKET/qualify.py" --emulator "$FM1_LIVE" \
  --stock-elf "$STOCK_ELF" --stock-fwsc "$STOCK_FWSC" \
  --candidate-elf "$CANDIDATE_ELF" --candidate-fwsc "$CANDIDATE_FWSC" \
  --output "$RUN_DIR"
```

Use `MODEL=pro` for SMK-37 Pro. The qualifier regenerates a cold flash, separate warmed boot counter reference, and the supplied saved-project flash region for stock and candidate. It compares complete projects and physical channels and returns exit 1 for a reproducible mismatch. Use `--offsets 1` for a focused run. `independent-replay-elite-plus1.json` reproduces compact-cost’s Elite +1 result from clean seeds using this script. `results.json` indexes the full runs and per-offset source and capture hashes appear under each candidate/model directory. The packaged region contains the original saved project data, excluding firmware and loader.
