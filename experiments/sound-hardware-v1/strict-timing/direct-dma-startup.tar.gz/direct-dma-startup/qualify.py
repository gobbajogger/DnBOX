#!/usr/bin/env python3
"""Replay stock and candidate with the same hardware stimulus and compare raw outcomes."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import zlib

import replay

STOCK_G1 = '097a7c7f2209e4d423767c8c6d34aa9a28e0262eba720977c9baf45c7109a2b4'
PROJECT_BYTES = 36420
RAM_BASE = 0x01c00000

def read_project(ram, symbols):
    begin = symbols['proj'] - RAM_BASE
    project = ram[begin:begin + PROJECT_BYTES]
    if len(project) != PROJECT_BYTES or struct.unpack_from('<I', project)[0] != 0x50305830:
        raise ValueError('unexpected project layout')
    return project

def digest(value):
    return hashlib.sha256(value).hexdigest()

def data_check(stock, candidate, width):
    first = next((i for i, (x, y) in enumerate(zip(stock, candidate)) if x != y), None)
    if first is None and len(stock) != len(candidate):
        first = min(len(stock), len(candidate))
    return dict(stock_sha256=digest(stock), candidate_sha256=digest(candidate),
                stock_length=len(stock), candidate_length=len(candidate), equal=stock==candidate,
                first_different_unit=None if first is None else first//width)

def saved_boot(emulator, fwsc, symbols, seed, ram_type, output):
    region = zlib.decompress(Path(__file__).with_name('saved-project-region.zlib').read_bytes())
    assert len(region) == 0xb0000-0x9d000
    base = bytearray(seed.read_bytes())
    base[0x9d000:0xb0000] = region
    empty = output/'empty.keys'
    empty.write_text('\n')
    result = {}
    for duration in (486,1150):
        case = output/f'{ram_type}-saved-{duration}'
        case.mkdir()
        (case/'work').mkdir()
        flash = case/'flash.bin'
        flash.write_bytes(base)
        env = {k:v for k,v in os.environ.items() if not k.startswith('FM1_')}
        env.update(FM1_STRICT='1',FM1_BENCH_KEYS='@'+str(empty),FM1_DUMPRAM=str(case/'ram.bin'),FM1_DNBOX_PCM=str(case/'stereo.s16le'))
        with (case/'run.log').open('w') as log:
            subprocess.run([emulator,'--fwsc',fwsc,'--mhz','360','--shot',str(duration),'--flash',flash],
                           env=env,cwd=case,stdout=log,stderr=subprocess.STDOUT,check=True)
        if f'panel.ppm at {duration} ms' not in (case/'run.log').read_text() or 'skipped 0 cycles' not in (case/'run.log').read_text():
            raise ValueError('incomplete saved-project capture')
        ram = (case/'ram.bin').read_bytes()
        pcm = (case/'stereo.s16le').read_bytes()
        if len(pcm)%2048:
            raise ValueError('incomplete physical bank')
        if duration == 486:
            begin = symbols['abuf']-RAM_BASE+4096
            bank = ram[begin:begin+4096]
            result['physical_edges_before_snapshot'] = len(pcm)//2048
            result['bank1_before_due'] = digest(bank)
        else:
            result.update(pcm=pcm,project=read_project(ram,symbols),edge4_nonzero=sum(v!=0 for v in struct.unpack('<1024h',pcm[6144:8192])))
    return result

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for arg in ('emulator','stock-elf','stock-fwsc','candidate-elf','candidate-fwsc','output'):
        parser.add_argument('--'+arg,required=True,type=lambda v:Path(v).resolve())
    parser.add_argument('--offsets',type=int,nargs='+',default=list(range(6)))
    a=parser.parse_args()
    if not set(a.offsets)<=set(range(6)) or len(set(a.offsets))!=len(a.offsets):
        parser.error('distinct offsets in 0..5 required')
    a.output.mkdir(parents=True,exist_ok=False)
    run_data={}
    boots={}
    for kind,elf,fwsc in (('stock',a.stock_elf,a.stock_fwsc),('candidate',a.candidate_elf,a.candidate_fwsc)):
        folder=a.output/kind
        process=subprocess.run([sys.executable,Path(__file__).with_name('replay.py'),'--emulator',a.emulator,'--elf',elf,
                                '--fwsc',fwsc,'--output',folder,'--offsets',*map(str,a.offsets)])
        if process.returncode not in (0,1) or not (folder/'sweep.json').is_file():
            raise RuntimeError(f'{kind} firmware replay failed with exit {process.returncode}')
        result=json.loads((folder/'sweep.json').read_bytes())
        if [r['shift_ms'] for r in result['runs']]!=a.offsets:
            raise RuntimeError(f'{kind} incomplete sweep')
        symbols=replay.read_symbols(elf)
        run_data[kind] = (result,symbols)
        boots[kind]=saved_boot(a.emulator,fwsc,symbols,folder/'seed/flash.bin',kind,a.output)
    stock,ss=run_data['stock'];candidate,cs=run_data['candidate'];s,c=boots['stock'],boots['candidate']
    if s['edge4_nonzero']!=10 or s['physical_edges_before_snapshot']!=2:
        raise ValueError('stock nonzero saved-project fixture did not reproduce')
    boot={'stock_pcm':digest(s['pcm']),'candidate_pcm':digest(c['pcm']),'same_saved_project':c['project']==s['project'],
          'same_saved_pcm':s['pcm']==c['pcm'],'stock_nonzero_edge4':s['edge4_nonzero'],'candidate_nonzero_edge4':c['edge4_nonzero'],
          'physical_edges_before_candidate_snapshot':c['physical_edges_before_snapshot'],'original_complete_G1_before_deadline':c['physical_edges_before_snapshot']==2 and c['bank1_before_due']==STOCK_G1,
          'candidate_bank1_sha256':c['bank1_before_due']}
    rows=[]
    for prev,obs in zip(stock['runs'],candidate['runs']):
        if obs['scene_sha256']!=prev['scene_sha256'] or obs['events']!=922:raise ValueError('scene mismatch')
        a0=a.output/'stock'/f'shift{prev["shift_ms"]}';a1=a.output/'candidate'/f'shift{obs["shift_ms"]}'
        p0=read_project((a0/'ram.bin').read_bytes(),ss);p1=read_project((a1/'ram.bin').read_bytes(),cs)
        pcm=data_check((a0/'stereo.s16le').read_bytes(),(a1/'stereo.s16le').read_bytes(),4)
        rows.append(dict(offset_ms=obs['shift_ms'],halves=obs['halves'],max_us=obs['max_us'],raw_late=obs['raw_late'],scene_late=obs['scene_late'],
                         complete_project=data_check(p0,p1,1),different_project_bytes=sum(x!=y for x,y in zip(p0,p1)),
                         dac=pcm,passes=obs['target_pass'] and obs['halves']==prev['halves']==648 and p0==p1 and pcm['equal']))
    passed=all(r['passes'] for r in rows) and all(boot[k] for k in ('same_saved_pcm','same_saved_project','original_complete_G1_before_deadline'))
    result=dict(stock_elf=stock['elf_sha256'],candidate_elf=candidate['elf_sha256'],emulator=stock['emulator_sha256'],saved_boot=boot,
                physical_results=rows,all_requested_offsets_pass=passed)
    (a.output/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    return 0 if passed else 1

if __name__=='__main__':
    raise SystemExit(main())
