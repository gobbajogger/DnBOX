#!/bin/sh
set -eu
# Args: fm1-core release deps directory, rustc, baseline.bin, candidate.bin, newly created output directory
deps=$(realpath "$1")
rust=$(realpath "$2")
baseline=$(realpath "$3")
candidate=$(realpath "$4")
mkdir "$5"
out=$(realpath "$5")
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
set -- "$deps"/libfm1_core-*.rlib
test "$#" = 1
"$rust" --edition=2021 -C opt-level=2 -C lto=fat -C embed-bitcode=yes -C codegen-units=1 -L "$deps" --extern "fm1_core=$1" "$here/run.rs" -o "$out/run"
"$out/run" "$baseline" "$here/stock.symbols" "$out/stock.state" >"$out/stock.csv"
"$out/run" "$candidate" "$here/candidate.symbols" "$out/candidate.state" >"$out/candidate.csv"
cmp "$out/stock.state" "$out/candidate.state"
