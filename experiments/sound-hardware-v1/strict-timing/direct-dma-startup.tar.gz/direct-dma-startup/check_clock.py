"""Compile the actual startup and normal IRQ from release.patch against a controllable ALNK clock."""
import argparse
import shutil
import subprocess
import tempfile
from pathlib import Path

defs = r'''
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#define FM1_TICKS_PER_US 1u
#define FM1_AUDIO_HALF 128u
#define HALF_WORDS 1024u
#define X0X_DEBUG 0
static uint32_t clock_us, next, period, bank, pending, released, jobs, counted;
static int32_t abuf[2048];
static uint8_t safe_mode, boot_silent_half;
static struct {unsigned late;} x0x_dbg;
static unsigned audio_xruns, render_us;
static void edge(void){ bank ^= 1u;pending = FM1_AUDIO_HALF;released++; }
static void advance(void){ clock_us++; if(clock_us == next){edge();next+=period;} }
static uint32_t fm1_ticks(void){advance();return clock_us;}
static uint32_t fm1_audio_free_half(void){return bank;}
static uint8_t fm1_audio_pending(void){return pending;}
static void fm1_audio_ack_aux(uint8_t p){(void)p;}
static void fm1_audio_ack_half(void){pending=0;}
static void render_block(int32_t *o){
    jobs++;for(unsigned i=0;i<render_us;i++)advance();
    for(unsigned i=0;i<HALF_WORDS;i++){o[i]=(int32_t)(jobs*2048u+i+1u);counted++;}
}
void fm1_alnk0_irq(void);
'''
tests = r'''
static unsigned runs;
static void begin(unsigned first,unsigned initial,unsigned safe){
    clock_us=pending=released=jobs=counted=x0x_dbg.late=audio_xruns=0;
    boot_silent_half=0;safe_mode=(uint8_t)safe;render_us=1000;
    memset(abuf,0,sizeof abuf);bank=1u-initial;next=first;period=11605;
}
static void words(unsigned which,unsigned group){
    for(unsigned i=0;i<1024;i++)assert(abuf[which*1024+i]==(group?(int32_t)(group*2048+i+1):0));
}
static void boundary(void){do{advance();}while(!pending);fm1_alnk0_irq();}
int main(void){
 for(unsigned initial=0;initial<2;initial++){
    /* Missing or single edge before USB attaches: stock pending remains deliverable. */
    for(unsigned first=13500;first<=35000;first+=250){
        begin(first,initial,0);smk_usb_boot_settle();assert(clock_us>=25000);
        assert(jobs==0 && boot_silent_half==0);
        assert(pending==(first<=clock_us?FM1_AUDIO_HALF:0));words(0,0);words(1,0);
        if(pending)fm1_alnk0_irq();else boundary();
        assert(jobs==1);words(initial,1);runs++;
    }
    /* Exactly two releases before attach, then the initialized spacer and G2. */
    for(unsigned first=3000;first<=12500;first+=250){
        begin(first,initial,0);smk_usb_boot_settle();assert(clock_us>=25000);
        assert(jobs==1 && released==2 && !pending);
        words(1u-initial,1);words(initial,0);
        boundary();assert(jobs==1 && released==3);words(initial,0);
        boundary();assert(jobs==2 && released==4);words(1u-initial,2);
        assert(audio_xruns==0);runs++;
    }
    begin(2000,initial,1);smk_usb_boot_settle();assert(jobs==0);runs++;
 }
 printf("%u schedules passed on both initial banks, including a stopped clock during USB startup\n",runs);
}
'''
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('firmware_tree',type=Path)
    parser.add_argument('--latched',action='store_true',help='also verify an overrun that crosses two physical bank flips')
    a=parser.parse_args()
    s=(a.firmware_tree/'firmware/src/app/main_fm1.c').read_text()
    start=s.index('static void smk_usb_boot_settle(void)\n{')
    end=s.index('extern void isr_alnk0(void);',start)
    with tempfile.TemporaryDirectory() as temp:
        d=Path(temp)
        checks=tests
        if a.latched:
            marker='begin(2000,initial,1);smk_usb_boot_settle();assert(jobs==0);runs++;'
            checks=checks.replace(marker, marker + r"""
    /* No G1 should be charged twice. A late transfer remains pending for service,
     * including two changes that restore the initial free-bank index. */
    for(unsigned latency=12000;latency<=24000;latency+=12000){
        begin(7000,initial,0);render_us=latency;smk_usb_boot_settle();
        assert(jobs==1 && audio_xruns==1 && x0x_dbg.late==1 && pending);
        render_us=500;fm1_alnk0_irq();assert(!pending);
        assert(jobs==(latency<23210?1:2));runs++;
    }""")
        (d/'test.c').write_text(defs+'\n'+s[start:end]+'\n'+checks)
        subprocess.run([shutil.which('cc'),'-std=c11','-Wall','-Wextra','-Werror','-O2',d/'test.c','-o',d/'check'],check=True)
        subprocess.run([d/'check'],check=True)

if __name__=='__main__':main()
