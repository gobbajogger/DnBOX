from pathlib import Path
import sys
base=Path.cwd();sys.path.insert(0,str(base/'sj6-work/wire-labels'));import run
run.sources['spacer']=base/'sj6-work/original-spacer/tree'
run.run('spacer')
