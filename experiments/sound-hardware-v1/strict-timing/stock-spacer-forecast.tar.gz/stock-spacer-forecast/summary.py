from pathlib import Path
import csv,json,struct,hashlib,sys
import numpy as np
b=Path.cwd();w=b/'sj6-work/original-spacer';r=b/'s1-work/emu360';y=b/'sj6-work/boot-silence'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def meta(p):return json.loads(p.read_text())
def heavy(d,m):
 c=d/f'{m}-offset1';s=r/f'baseline-{m}/shift1';j=meta(c/'result.json');k=meta(s/'result.json');f=d/f'{m}-state1.json';pr=meta(f)
 a=np.fromfile(s/'stereo.s16le','<i2').reshape(-1,2);z=np.fromfile(c/'stereo.s16le','<i2').reshape(-1,2);eq=(a==z).all(1);first=np.flatnonzero(~eq)
 aa=z[:65536];bb=a[:65536];j1=d/'tree/build'/('smk37-elite' if m=='elite' else 'smk37');old=b/'native/final-init/build'/j1.name
 assert sha(j1/'loader/ota.bin')==sha(old/'loader/ota.bin')
 oldtrace=b/'s1-work/native-panel/stock/trace.jsonl' if m=='elite' else b/'sj6-work/phase-edge/pro-stock-notes/trace.jsonl'
 def events(p):
  es=[q for ln in p.open() if (q:=json.loads(ln))['event']=='half'];return [(t,next((dict(halves=q['snapshot']['x0x_dbg'][1],engine_frames=q['snapshot']['eng_prof_frames'][0],physical=q['seq']) for q in reversed(es) if q['completion_cycle']<=t*5760000),None)) for t in (2221,4936,7999)]
 return dict(model=m,image_sha=j['fwsc_sha256'],ELF=j['elf_sha256'],initial_flash=j['initial_flash_sha256'],normal_runner=j['emulator_sha256'],external_inputs=j['scene_sha256'],max_us=j['debug']['max_us'],raw_late=j['debug']['late'],scene_late=j['late_during_test'],halves=j['debug']['halves'],stereo_frames=len(a),equal_stereo=int(eq.sum()),first_different=int(first[0]) if len(first) else None,equal_sample_words=int((a==z).sum()),stock_pcm=k['pcm_sha256'],candidate_pcm=j['pcm_sha256'],genuine_project=pr,application_size=(j1/'x0x.bin').stat().st_size,stock_size=(old/'x0x.bin').stat().st_size,verified_loader=sha(old/'loader/ota.bin'),observed_application=dict(stock=events(oldtrace),candidate=events(c/'trace.jsonl')))
out=dict(quiet_pairs=[],heavy={},memory_deadline=[],labels={},faults={})
for m in ('elite','pro'):
 for c in ('default','saved','asym'):
  a,z=[w/'quiet'/f'{k}-{m}-{c}' for k in ('stock','spacer')];aa,zz=[meta(j/'receipt.json') for j in (a,z)]
  assert (a/'stereo.s16le').read_bytes()==(z/'stereo.s16le').read_bytes() and aa['first24']['sha256']==zz['first24']['sha256']
  prog=[dict(edge=e['edge'],bank=e['bank'],stock_at=e['ms'],candidate_at=f['ms'],same_pcm=e['sha256']==f['sha256'],nonzero=e['nonzero']) for e,f in zip(aa['physical'],zz['physical'])]
  assert all(x['same_pcm'] for x in prog)
  out['quiet_pairs'].append(dict(model=m,condition=c,frames=(a/'stereo.s16le').stat().st_size//4,stock_fw=aa['fw'],candidate_fw=zz['fw'],exact_project=aa['project_sha256']==zz['project_sha256'],project=aa['project_sha256'],first24=aa['first24'],captured_G1=aa['physical'][3],complete_DAC=aa['pcm'],physical=prog))
 for d in (w,b/'sj6-work/spacer-forecast'):
  if (d/f'{m}-state1.json').exists():out['heavy'].setdefault(d.name,[]).append(heavy(d,m))
for z in meta(w/'margin.json'):
 if z['image']!='spacer' or z['at_ms']%10:continue
 final=z['end_event']['cycle']/5760000;edge3=z['edges'][-1]+z['period_ms']
 assert len(z['edges'])==2 and z['phase']==3 and z['bank1_sha']==z['reference_G1_sha'] and z['completed']==1
 out['memory_deadline'].append(dict(model=z['m'],case=z['case'],release=z['edges'][1],ram_snapshot_ms=final,due=edge3,minimum_slack_us=(edge3-final)*1000,bank1_SHA=z['bank1_sha'],engine_frames_at_snapshot=z['engine']))
lr=b/'sj6-work/wire-labels/spacer';a,z=lr/'bank0',lr/'bank1';x=(a/'stereo.s16le').read_bytes();assert x==(z/'stereo.s16le').read_bytes();ids=[]
for j in range(0,len(x),2048):
 v=np.frombuffer(x[j:j+2048],'<i2');ref=np.arange(1,1025);g=next((k for k in range(1,7) if np.array_equal(v,ref+1024*(k-1))),0 if not v.any() else None);ids.append(g)
assert ids[:10]==[0,0,0,1,0,2,3,4,5,6]
out['forecast_quiet']=[]
for m in ('elite','pro'):
 for case in ('default','saved','asym'):
  aa,ff=[w/'quiet'/f'{k}-{m}-{case}' for k in ('stock','forecast')];base_ref=meta(aa/'receipt.json');j=meta(ff/'receipt.json')
  assert (aa/'stereo.s16le').read_bytes()==(ff/'stereo.s16le').read_bytes() and base_ref['first24']['sha256']==j['first24']['sha256']
  out['forecast_quiet'].append(dict(model=m,condition=case,frames=(ff/'stereo.s16le').stat().st_size//4,identical_24bit_G1=j['first24']['sha256'],identical_DAC=j['pcm'],identical_project=base_ref['project_sha256']==j['project_sha256'],fw=j['fw'],trace=j['trace']))
out['labels']=dict(physical_groups=ids,fw=meta(a/'result.json')['fwsc_sha256'],ELF=meta(a/'result.json')['elf_sha256'],pcm_sha=sha(a/'stereo.s16le'),both_traces=[sha(d/'trace.jsonl') for d in (a,z)])
fs=list(csv.DictReader((w/'faults.csv').open()));out['faults']=dict(schedules=len(fs),normal=(w/'faults.log').read_text().strip(),examples=[q for q in fs if q['case']=='fault' and q['bank']=='0' and q['stall_us'] in ('11700','23500')])
(w/'summary.json').write_text(json.dumps(out,indent=2)+'\n')
for name,ls in out['heavy'].items():print(name,[(a['model'],a['max_us'],a['halves'],a['raw_late'],a['genuine_project']['different_bytes'],a['equal_stereo'],a['first_different'],a['application_size']) for a in ls])
print(out['memory_deadline'])
