"""Run the corrected experimental startup against independently scheduled nonzero banks, including the cold spacer."""
from pathlib import Path
import sys
p=Path('sj6-work/correct-bank/faults.py')
s=p.read_text().replace('unsigned expected=e-assumed_submission;', 'unsigned expected=e==4?0:(e==3?1:e-3);')
s=s.replace('(e<4?0:e-3)','(e<4||e==5?0:(e==4?1:e-4))')
s=s.replace('printf("fault,6700,%u,%u,%u,%u,%u,%u,%u,%u','printf("fault,6700,%u,%u,%u,%u,%u,%u,%u,%u')
s=s.replace('static void fm1_audio_ack_half(void){pending=0;}', 'static void delay_at(unsigned f); static void fm1_audio_ack_half(void){if(edge==3)delay_at(5);pending=0;}')
s=s.replace('if(!safe_mode){\n  if(pending)', 'if(!safe_mode){\n  delay_at(6);\n  if(pending)')
s=s.replace('phase<=4','phase<=6').replace('32 boundary-stall tests','48 boundary-stall tests')
s=s.replace('next+=PERIOD;', 'next+=PERIOD;if(phase_fault>=7 && phase_fault<=9 && edge==phase_fault-6)next+=delay_us;')
s=s.replace('launch(6700,0,0,0,1);', 'for(unsigned f=7;f<=9;f++)for(unsigned k=0;k<2;k++){ launch(6700,k,f,33333,0); assert(!audio_xruns && !missed(10,2)); }\n launch(6700,0,0,0,1);')
s=s.replace('1 safe-mode test','6 physical clock-pause/resume tests, 1 safe-mode test')
exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
