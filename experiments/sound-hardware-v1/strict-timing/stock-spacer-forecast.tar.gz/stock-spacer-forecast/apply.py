"""Restore the original edge-three bank of initialized silence after timely G1. No application render is charged twice."""
from pathlib import Path
import sys
p=Path(sys.argv[1])/'firmware/src/app/main_fm1.c';s=p.read_text()
s=s.replace('enum { AUDIO_NORMAL, AUDIO_PREPARE, AUDIO_HANDOFF };','enum { AUDIO_NORMAL, AUDIO_PREPARE, AUDIO_HANDOFF, AUDIO_SPACER };')
old='''            memcpy(out, engine_boot_audio_workspace(), sizeof x0x_scratch.boot_output);
            audio_boot_phase = AUDIO_NORMAL;
        } else {'''
new='''            memcpy(out, engine_boot_audio_workspace(), sizeof x0x_scratch.boot_output);
            audio_boot_phase = AUDIO_SPACER;
        } else if (audio_boot_phase == AUDIO_SPACER) {
            /* The other bank still contains the genuine initialized cold interval.
             * Acknowledge this physical release. The original next application
             * block starts on the following edge, with its original state. */
            audio_boot_phase = AUDIO_NORMAL;
        } else {'''
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
