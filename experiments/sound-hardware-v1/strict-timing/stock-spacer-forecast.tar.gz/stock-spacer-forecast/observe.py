"""Load each valid native project under an explicitly empty input script. Compare first complete native bank and every physical DAC word."""
from pathlib import Path
import os,hashlib,struct,subprocess,sys,shutil,json,tempfile
from concurrent.futures import ThreadPoolExecutor
b=Path.cwd();r=b/'s1-work/emu360';w=b/'sj6-work/original-spacer';v=b/'sj6-work/boot-silence';sys.path.insert(0,str(r));from sweep import sha,symbols
def run(t):
 typ,m,case=t;out=w/'quiet'/f'{typ}-{m}-{case}'
 if (out/'receipt.json').exists():return
 out.mkdir(parents=True,exist_ok=True)
 build=(b/'sj6-work/spacer-forecast' if typ=='forecast' else w);img=r/'input' if typ=='stock' else build/'image';elf=img/f'{m}.elf';fw=img/f'{m}.fwsc';sym=symbols(elf)
 seed=((r/'seed/fresh.flash' if m=='elite' else r/'baseline-pro/seed/flash.bin') if case=='default' else v/f'{m}-{case}.flash')
 with tempfile.TemporaryDirectory(dir=w) as td:
  d=Path(td);(d/'work').mkdir();shutil.copyfile(seed,d/'flash');
  if typ!='stock':
   a=bytearray((build/(m+'-seed/flash.bin')).read_bytes());src=seed.read_bytes();a[0x9d000:0xb0000]=src[0x9d000:0xb0000];(d/'flash').write_bytes(a)
  input_sha=sha(d/'flash');(d/'empty.keys').write_text('\n')
  mp=(r/'baseline-elite/shift0-trace/observer.map').read_text().splitlines();lines=[]
  for ln in mp:
   n,_,length=ln.split();lines.append(f'{n} {sym[n][0]:x} {length}')
  for i in range(0,4096,512):lines.append(f'scene_dma_{i} {sym["abuf"][0]+4096+i:x} 512')
  (d/'map').write_text('\n'.join(lines)+'\n');env={k:v for k,v in os.environ.items() if not k.startswith('FM1_')}
  env.update(FM1_STRICT='1',FM1_BENCH_KEYS='@'+str(d/'empty.keys'),FM1_DNBOX_MAP=str(d/'map'),FM1_DNBOX_TRACE=str(d/'trace'),FM1_DNBOX_PCM=str(out/'stereo.s16le'),FM1_DUMPRAM=str(d/'ram'))
  with (out/'run.log').open('w') as log:subprocess.run([r/'bin/fm1-live','--fwsc',fw,'--mhz','360','--shot','1150','--flash',d/'flash'],env=env,cwd=d,stdout=log,stderr=subprocess.STDOUT,check=True)
  qs=(json.loads(l) for l in (d/'trace').open());edges=[];calls=[];native=[]
  for j in qs:
   k=j['event']
   if k=='dma':edges.append(dict(edge=j['seq'],bank=j['half'],ms=j['scheduled_cycle']/5760000))
   if k in ('irq_enter','half') and j['seq']<=14:
    snap=j['snapshot'];raw=b''.join(bytes(snap[f'scene_dma_{i}']) for i in range(0,4096,512));words=struct.unpack('<1024i',raw)
    native.append(dict(edge=j['seq'],kind=k,ms=j.get('cycle',j.get('completion_cycle'))/5760000,halves=snap['x0x_dbg'][1],engine=snap['eng_prof_frames'][0],raw_late=snap['x0x_dbg'][5],sha256=hashlib.sha256(raw).hexdigest(),nonzero=sum(bool(x) for x in words),minimum=min(words),maximum=max(words),first_nonzero_word=next((i for i,x in enumerate(words) if x),None)))
  ram=(d/'ram').read_bytes();addr,size=sym['proj'];project=ram[addr-0x01c00000:addr-0x01c00000+size];assert len(project)==36420
  (out/'project.bin').write_bytes(project);pcm=(out/'stereo.s16le').read_bytes();assert len(pcm)==2048*len(edges)
  for i,e in enumerate(edges):
   raw=pcm[i*2048:(i+1)*2048];vals=struct.unpack('<1024h',raw);e.update(sha256=hashlib.sha256(raw).hexdigest(),nonzero=sum(bool(x) for x in vals),min=min(vals),max=max(vals))
  first=next(z for z in native if (z['kind']=='half' and z['edge']==2) or (z['kind']=='irq_enter' and z['edge']==3))
  O=dict(model=m,image=typ,scenario=case,input='explicit empty event file',elf=sha(elf),fw=sha(fw),runner=sha(r/'bin/fm1-live'),seed=input_sha,source_project_seed=sha(seed),project_sha256=sha(out/'project.bin'),dist=project[40+4*12*32+1],drive=project[40+4*12*32+2],first24=first,physical=edges,native_bank1=native,pcm=sha(out/'stereo.s16le'),trace=sha(d/'trace'))
  (out/'receipt.json').write_text(json.dumps(O,indent=2)+'\n');print(typ,m,case,O['dist'],first['nonzero'],first['minimum'],first['maximum'],edges[3]['nonzero'],flush=True)
if __name__=='__main__':
 cases=[(sys.argv[1],m,z) for m in sys.argv[2:] for z in ('default','saved','asym')]
 with ThreadPoolExecutor(2) as q:list(q.map(run,cases))
