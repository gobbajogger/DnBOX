"""Bound original-bank handoff directly in unmodified production RAM on deterministic native short shots."""
from pathlib import Path
import os,struct,json,sys,tempfile,subprocess,hashlib
from concurrent.futures import ThreadPoolExecutor
b=Path.cwd();w=b/'sj6-work/original-spacer';r=b/'s1-work/emu360';v=b/'sj6-work/boot-silence';sys.path.insert(0,str(r));from sweep import sha,symbols
def one(args):
 m,case,kind,when=args;img=(r/'input' if kind=='stock' else w/'image');fw=img/(m+'.fwsc');elf=img/(m+'.elf');sym=symbols(elf)
 hist=json.loads((w/'quiet'/f'{kind}-{m}-{case}/receipt.json').read_text());due=hist['physical'][2]['ms'];orig=hist['first24']['sha256']
 with tempfile.TemporaryDirectory(dir=w) as t:
  d=Path(t);(d/'work').mkdir();(d/'none').write_text('\n')
  f=((r/'seed/fresh.flash' if m=='elite' else r/'baseline-pro/seed/flash.bin') if kind=='stock' else w/(m+'-seed/flash.bin'));raw=bytearray(f.read_bytes())
  if case=='asym':raw[0x9d000:0xb0000]=(v/(m+'-asym.flash')).read_bytes()[0x9d000:0xb0000]
  (d/'flash').write_bytes(raw);env={k:v for k,v in os.environ.items() if not k.startswith('FM1_')}
  # All pinned normal ranges. No guest timing operations or firmware changes.
  lines=[]
  for ln in (r/'baseline-elite/shift0-trace/observer.map').read_text().splitlines():
   n,_,j=ln.split();lines.append(f'{n} {sym[n][0]:x} {j}')
  (d/'map').write_text('\n'.join(lines)+'\n');env.update(FM1_STRICT='1',FM1_BENCH_KEYS='@'+str(d/'none'),FM1_DUMPRAM=str(d/'ram'),FM1_DNBOX_MAP=str(d/'map'),FM1_DNBOX_TRACE=str(d/'trace'))
  with (d/'log').open('w') as log:subprocess.run([r/'bin/fm1-live','--fwsc',fw,'--mhz','360','--shot',str(when),'--flash',d/'flash'],env=env,cwd=d,stdout=log,stderr=subprocess.STDOUT,check=True)
  ram=(d/'ram').read_bytes();reg=lambda n:ram[sym[n][0]-0x01c00000:sym[n][0]-0x01c00000+sym[n][1]];ph=reg('audio_boot_phase')[0] if 'audio_boot_phase' in sym else None
  edges=[j for l in (d/'trace').open() if (j:=json.loads(l))['event']=='dma'];em=[e['scheduled_cycle']/5760000 for e in edges]
  period=(edges[-1]['deadline_cycle']-edges[-1]['scheduled_cycle'])/5760000
  # The observer finish cycle can exceed shot_ms by one 16ms emulated batch; use the physical edge itself for a conservative bound.
  ending=[json.loads(l) for l in (d/'trace').open() if '"event":"end"' in l or '"event":"finish"' in l]
  tail=(d/'trace').read_text().splitlines()[-1];last=json.loads(tail)
  R=dict(m=m,case=case,image=kind,at_ms=when,end_event=last if last['event'] not in ('half','irq_enter','store') else {'last_event':last['event']},edges=em,period_ms=period,phase=ph,completed=struct.unpack_from('<I',reg('x0x_dbg'),4)[0],engine=struct.unpack('<I',reg('eng_prof_frames'))[0],bank1_sha=hashlib.sha256(reg('abuf')[4096:]).hexdigest(),reference_G1_sha=orig,quantified_deadline_full_run_ms=due,trace_sha=sha(d/'trace'))
  return R
cases=[(m,c,k,t) for m in ('elite','pro') for c in ('default','asym') for k in ('stock','spacer') for t in ([470,474] if c=='default' else [480,484])]
with ThreadPoolExecutor(2) as e:rows=list(e.map(one,cases))
(w/'margin.json').write_text(json.dumps(rows,indent=2)+'\n')
for x in rows:print(x['m'],x['case'],x['image'],x['at_ms'],x['phase'],x['completed'],[round(t,3) for t in x['edges']],x['end_event'].get('cycle'),x['reference_G1_sha']==x['bank1_sha'])
