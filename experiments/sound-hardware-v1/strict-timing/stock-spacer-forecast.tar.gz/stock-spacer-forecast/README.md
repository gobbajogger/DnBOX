# Original bank, original cold interval and guarded forecast

The startup submits the first genuine rendered application block G1 to bank 1 released on edge 2. Bank 0 still holds the initialized stock cold interval. On edge 3 the handler acknowledges that physical bank without running or charging an extra application block. On edge 4 the regular handler renders G2. Native tagged stereo output on both independently observed halves of Elite was 0,0,0,G1,0,G2,G3,G4,G5,G6 on physical edges 1–10. Every labelled block contains 1,024 distinct nonzero words. The original stock FIFO pattern is preserved.

## Unmodified application under a nonzero saved project

The stock-native saved Clip comparison from the companion production-first-block packet makes G1 nonzero before any physical input. On both boards the full 24-bit G1 is identical to stock, including all 18 nonzero words (−7 to +9). The native 16-bit DAC carries ten words of −1 at physical edge 4, the stock silence at edge 5, and the subsequent original output. With the explicitly empty event script, every stereo frame in default, physical SAVE, and saved Clip matches through the full 1.15-second run for both products. This comparison covers 30,720 default frames or 30,208 saved frames per board. The same six comparisons independently passed for the paired guarded forecast. All 12 comparisons have the original full project bytes.

Two additional deterministic snapshots per image and configuration read the actual DMA RAM bank and application phase before its original safe-write deadline. At the time of each snapshot only physical edges 1 and 2 had occurred. The application had executed 512 real engine frames. The phase verified the transfer had completed on default boots even with an all-zero payload. On the saved Clip boots the SHA-256 of the entire bank proves completion directly. The unchanged original bank was still zero in the saved Clip control at the later 484 ms snapshot. The margin is a measured lower bound, not an estimated memcpy duration.

| Boot | Original bank 1 release ms | Verified written by ms | Due ms | Minimum available µs |
|---|---:|---:|---:|---:|
|elite default|467.876008|470.000003|479.481341|9481.339|
|elite asym|477.600769|480.000002|489.206103|9206.101|
|pro default|467.884769|470.000002|479.490103|9490.101|
|pro asym|477.609802|480.000003|489.215135|9215.132|

## Complete +1 ms heavy scene

Each production image received its own flash seed before the 8-second 360 MHz scene with all 922 physical inputs. Both loader payloads are byte-identical to stock. Both builds retain pool 335,092/344,064 bytes and linked RAM 97,204/98,304 bytes. The candidate returns to exactly 150 completed application halves and 76,800 engine frames at the first real player action on both boards, matching stock. Full native size remains 176 bytes over stock. The guarded forecast is the isolated island-proof variant supplied by the Synth One lane. Its project verification includes every byte of the note and arrangement data. All sample comparisons use absolute positions.

| Firmware | Board | App bytes | Worst µs | Halves | Raw late | Different project bytes | Equal stereo frames / 333,312 | First unequal frame |
|---|---|---:|---:|---:|---:|---:|---:|---:|
|original-spacer|elite|546,692|11,308|648|0|10|206,431|97,856|
|original-spacer|pro|546,684|11,175|648|0|6|165,543|97,856|
|spacer-forecast|elite|546,692|10,386|648|0|10|206,432|97,856|
|spacer-forecast|pro|546,684|10,150|648|0|4|166,146|97,856|

The forecast meets the timing threshold for these two runs. On Elite 10 Sound bytes differ. On Pro two Sound bytes, one 909 pattern byte and one bass B byte differ. This candidate does not establish full stock behavior, exact image size or all-offset qualification. No twelve-scene sweep was started.

## Physical failure boundaries

The independent genuine-bank host scheduler compiles the actual startup and IRQ functions and checks nonzero output at both bank release and playback start. It passed 12 nominal schedules, 122,880 exact labelled wire words, six physical clock pause/resume cases, and the safe-mode check. An additional 48 timed failure trials and 16 initial clock phases distinguish actual missed due groups from a firmware counter. The 1,842,194 individual word inspections cover preparation, staging copy, DMA handoff, normal render, original silent spacer acknowledgement and the masked interval before IRQ enable. In the CSV, group 999 is a mixed physical bank and zero is silence. Count of mismatched chronological groups can include trailing one-block displacement, and does not equal a count of separate initiating stalls.

Injected handoff stall of 11.7 ms left a partially filled bank at its actual deadline and raised raw late 1. A 23.5 ms handoff stall crossed two bank flips; the active and eventually captured bank could be mixed with raw late 0. A 23.5 ms blind interval before IRQ enable also lost physical groups with raw late 0. These failures remain explicit exclusions. The SDK exposes ALNK CON0–3, write-only ADR0–3 and block LEN. The existing application detector compares one toggling bank bit; an arbitrary even number of unseen changes cannot be reconstructed from that bit and a latched pending flag. Failing the external observer establishes a real error even when the counter stayed clear.

## Reproduction

Use the recovered project source ca0c00a4e5863132de4a66f5d1c477c14d699be5, pinned Linux native build inputs and pinned emulator. Apply spacer.patch or forecast.patch to separate clean source trees in sj6-work/original-spacer/tree and sj6-work/spacer-forecast/tree. Cold-build both models independently and run normal-run.py with each candidate directory, model, and offset 1. The original input seed and saved project construction are in production-first-block. Put observe.py, margin.py, summary.py, labeled.py and faults.py in sj6-work/original-spacer. Place faults-base.py in sj6-work/correct-bank/faults.py, plus tagged-run.py and bank.py in sj6-work/wire-labels as run.py/bank.py. Run observe.py for stock/for spacer/for forecast with model IDs elite pro. Run margin.py, labeled.py, python3 sj6-work/original-spacer/faults.py sj6-work/original-spacer/tree, and summary.py; preserve the paths shown by the scripts. The code and receipts contain no board ELF, binary or firmware package.
