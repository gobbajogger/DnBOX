set -eu
w="$PWD/native/strict/history-emulation"
images="$PWD/native/strict/pinned-images"
r="$PWD/s1-work/emu360/capture.py"
python "$r" --model elite --name "$w/seed" --image-dir "$images" --ms 2000 --cold
python "$r" --model elite --name "$w/boot" --image-dir "$images" --ms 2000 --seed "$w/seed/flash.bin"
for shift in 0 1 2 3 4 5; do
  python "$r" --model elite --name "$w/shift$shift" --shift "$shift" --ms 8000 --image-dir "$images" --seed "$w/seed/flash.bin" --boot "$w/boot/result.json"
done
