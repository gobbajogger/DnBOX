import hashlib,json,os,subprocess
from pathlib import Path
here=Path(__file__).resolve().parent
src=here/'reference';src.mkdir(exist_ok=True)
tree=json.loads((here/'source-tree.json').read_text()); wanted={r['path']:r for r in tree['root'] if r['path'] in ('build.sh','LICENSE')}
for key,t in tree['trees'].items(): wanted.update({key+'/'+r['path']:r for r in t['tree'] if r['type']=='blob'})
def blob_id(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
missing={}
for path,r in wanted.items():
 expected=r['sha'];dest=src/path; raw=None
 for root in [src,Path('lane'),Path('recovered/DnBOX-Sound-final-recovery/canonical_source'), Path('native/actual-init')]:
  p=root/path
  if p.is_symlink():b=os.readlink(p).encode()
  elif p.is_file():b=p.read_bytes()
  else:continue
  if blob_id(b)==expected:raw=b;break
 if raw is None:
  p=subprocess.run(['git','-C','lane','cat-file','blob',expected],capture_output=True)
  if p.returncode==0:raw=p.stdout
 if raw is None:
  missing[path]=r;continue
 assert blob_id(raw)==expected
 dest.parent.mkdir(parents=True,exist_ok=True)
 if not dest.exists():
  if r['mode']=='120000':dest.symlink_to(raw.decode())
  else:dest.write_bytes(raw)
 if not dest.is_symlink():dest.chmod(0o755 if r['mode']=='100755' else 0o644)
(here/'missing.json').write_text(json.dumps(missing,indent=1))
print('reused',len(wanted)-len(missing),'of',len(wanted),'missing',len(missing))
for path,row in missing.items(): print(row['size'],path)
