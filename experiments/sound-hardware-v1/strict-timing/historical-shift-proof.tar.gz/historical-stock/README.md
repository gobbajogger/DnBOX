# Historical stock strict timing

The reconstruction uses commit d4088e60652adcd4b49d360c6fff7fd27f312494, tree 694051aff96d0cbd22b541d3180a8789ec2354c6. GitHub's compare returned this historical commit as the merge base of the sound lane at ca0c00a4e5863132de4a66f5d1c477c14d699be5, 195 lane commits ahead. The sparse source manifest validates Git blob hashes for 469 build inputs under build.sh, LICENSE, assets, experiments, firmware, tools and the selected BLE checker files. The required project JieLi toolchain and SDK come from the stock dry INIT native receipts.

For the two native builds, run BOARD=smk37 MODEL=elite X0X_DEV_PADCAL=0 JIELI_DOCKER=0 sh build.sh, then substitute MODEL=pro. The historical binary hashes reproduced the original #869 record exactly. The development identities are SMK-37 Elite_900 and SMK-37 Pro_900. The earlier historic native recipe explicitly sets X0X_DEV_PADCAL=0. Current source comparisons use the actual source and default settings of each current baseline.

| Model | Application B | XIP free B | Ordinary RAM B | Pool B | Pool free after 8,192 reserve B | Historical application SHA-256 |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| Elite | 544156 | 8516 | 95536 | 335724 | 148 | e091d14490ac33651048f160fbbee8073d9d2bf1bf366d7785a5302ba7a60697 |
| Pro | 544148 | 8524 | 95536 | 335724 | 148 | bab5eb7695ac42317868afffec7867bd66f2f33b2c605e46cfe4ffa22b6bf0bb |

Historical raw pool free is 8,340 bytes, 364 below the present 8,192+512 requirement. The stock dry INIT current pair used for performance comparison is 546516/546508 B, 97204 B ordinary RAM and 335092 B pool; each current image therefore uses 2360 B more application, 1668 B more ordinary RAM, and 632 B less pool than the historical reconstruction under its published build settings.

The historical Elite capture first seeded its flash for 2,000 ms, then booted a copy of that seed for 2,000 ms with the same image. Each eight-second capture independently copied the seed, ran the complete 922-event UI scene at 360 MHz under strict emulation, and dumped its RAM debug counters. Each shifted scene adds exactly its row's millisecond offset to every event. The boot counter is subtracted once when reporting in-scene lateness. Every scene had 648 halves. The maxima are raw x0x_dbg.max_us read directly from the historical ELF's symbols. None of these captures ran on a physical unit.

| Input shift ms | Maximum µs | Absolute late | In-scene late |
| ---: | ---: | ---: | ---: |
| 0 | 11406 | 1 | 0 |
| 1 | 11440 | 1 | 0 |
| 2 | 10921 | 1 | 0 |
| 3 | 11438 | 1 | 0 |
| 4 | 11438 | 1 | 0 |
| 5 | 10922 | 1 | 0 |

The original unshifted Elite report gave 11,406 µs, and the historical +1 ms run reproduces the owner's 11,440 µs. The original unshifted Pro report gave 11,410 µs. Only the historical Elite was run through the shifted sweep in this packet. [Original published native and unshifted timing record](https://github.com/gobbajogger/DnBOX/pull/869#issuecomment-6846592540)

Reproduction requires the original project toolchain/SDK and the pinned augmented fm1-live from the wider strict timing record. Restore each native build using its JSON. In the included capture/ directory place the executable at bin/fm1-live, and place the matching native package and ELF as elite.fwsc and elite.elf in an image directory. Run capture.py for a cold seed, a 2 s warmed boot, and the six independent 8 s shots. history-emu.sh records the exact calls. The relative input/heavy.keys is included. Original receipts retain their local output paths for audit. The two binaries match the previously published binaries, while ELF and package hashes identify the freshly rebuilt local outputs.
