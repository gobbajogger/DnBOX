# Strict timing and physical behavior on the verified xmod-real pair

The exact stock (unmodified) 922-event heavy recipe was replayed on both native model packages, with every timestamp uniformly shifted by 0–5 ms and an 8,000 ms endpoint. All 12 runs used 360 MHz emulation with FM1_STRICT=1, zero raw/scene lates, and 647 completed half buffers. The worst block was 10,909 µs on unshifted Pro, 700 µs below the 11,609 µs limit. The original stock reference completed 648 halves. The timing-plus-late predicate and historical minimum half count are recorded separately.

| Relative shift (ms) | 0 | 1 | 2 | 3 | 4 | 5 |
|---|---:|---:|---:|---:|---:|---:|
| Elite maximum (µs) | 10,899 | 10,536 | 10,892 | 10,591 | 10,893 | 10,663 |
| Pro maximum (µs) | 10,909 | 10,594 | 10,684 | 10,899 | 10,886 | 10,638 |
| Elite saved project byte differences from same-offset stock | 7 | 2 | 2 | 14 | 5 | 5 |
| Pro saved project byte differences from same-offset stock | 9 | 5 | 7 | 3 | 6 | 3 |

Every ordinary same-offset case changed some entered state. The control decoder identifies the exact mixer, FX and sequencer fields for each trial. For example, Elite +1 differs in the held 909 clap on step 16 and bass B pattern length. The stock UI reproducer shows how one extra foreground poll of the same chord can change which previously set step a short release removes.

## Genuine stock project and absolute render frame

The supplemental flow ran the complete unshifted recipe on stock, physically stopped playback and pressed the normal BT/SAVE key. The guest issued 36 erase/program operations, altering 4,855 bytes only in the native store partition. Stock and candidate flash fixtures use their own native code prefix and an identical copy of the genuine saved partition. Both end playback with identical complete 36,420-byte project SHA-256, 892c2e5e4657d690e4c7ba2f3e5c3eba11df735764b90480e31e575c8ecfd3e6.

| Elite case | PLAY physical time | Native render frame at PLAY | Worst (µs) | Raw late | Boot late | Scene late |
|---|---:|---:|---:|---:|---:|---:|
| Stock | 2,300 ms | 80,384 | 12,923 | 34 | 1 | 33 |
| Candidate | 2,300 ms | 79,872 | 12,222 | 4 | 0 | 4 |
| Candidate phase diagnostic | 2,308 ms | 80,384 | 12,190 | 4 | 0 | 4 |

Both candidate cases produced all 276 observed logical events at the same relative render frames as stock over 123,392 common frames. At the same wall-time key press, the candidate's 909 had accumulated 512 fewer silent frames before PLAY. The DUT advances the 909 noise generator during silence. The first PCM difference occurred at transport frame 64. At matched absolute rendered frame, all 207 commonly on-time 512-frame blocks matched the actual stock DAC bytes, covering 105,984 stereo frames, with peak difference zero. Both eligible PCM vectors have SHA-256 e9500ddd9a628fe030e97ebbeccf5856aa7460f6ef1711be8d5ba5d7b55d2106. The continuous streams include the different underruns; in the phase diagnostic they first differ at relative frame 512. This supplemental stored project and single-PLAY stimulus differ from the primary timing recipe.

## Repeat

1. Supply the hash-pinned fm1-live and the separately verified package/ELF pairs. Inputs and original absolute command receipts identify each artifact. Rebuild the genuine source patch against the base in inputs/genuine-source-identities.json if required. The calibrated primary test uses the specific executable in inputs/pins.json.
2. Run `bash scripts/qualify-one.sh /path/to/fm1-live /path/to/model-triples /tmp/fm1-run elite 0 1 2 3 4 5`, then run it with `pro`. Use a fresh directory for each firmware pair. The runner uses a format shot and a separate warm shot for each package before measuring 8 seconds from the same prepared model-specific flash.
3. Run `python3 scripts/report.py /tmp/fm1-run /tmp/fm1-report` to collect traceable timing, coverage, file hashes, peak and RMS. For the filesystem layout of the archived candidate use `--variant xmod-real`.
4. For the supplemental flow use `scripts/capture.py --supplemental --scene inputs/stock-save.keys --ms 9200` with the normal runner, stock package, model, own prepared flash, output and shot name. Use `scripts/save_fixture.py STOCK_FRESH STOCK_SAVED TARGET_FRESH OUTPUT_FLASH` for each candidate. It retains all target bytes outside [0x9d000,0xb0000).
5. Use `--supplemental --scene inputs/play-only.keys --ms 5500 --trace --behavior` for both packages with their own saved fixture and warmed boot. The separately-labelled control uses inputs/phase-play.keys on candidate only. Run `scripts/matched_playback.py ROOT STOCK_ELF CANDIDATE_ELF --candidate-label LABEL` and `scripts/eligible_pcm.py STOCK_PLAY_RUN CANDIDATE_PLAY_RUN`. The saved-project receipts retain original commands, working directory layout and runner settings, as well as the measured pre-2-second boot count. Native project offsets are derived from production headers and verified against the ELF symbol length.
