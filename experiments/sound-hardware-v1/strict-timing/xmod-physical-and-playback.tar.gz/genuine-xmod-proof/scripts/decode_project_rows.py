#!/usr/bin/env python3
"""Translate changed native project bytes into editable parameters and sequencer cells."""
import argparse
import json
from pathlib import Path

PARTS = ["909", "808", "303A", "303B", "BREAK"]
DRUMS = {
    "909":["kick","snare","low_tom","mid_tom","high_tom","rimshot","handclap","closed_hat","open_hat","crash","ride"],
    "808":["kick","snare","low_tom","mid_tom","high_tom","rimshot","handclap","cowbell","cymbal","open_hat","closed_hat"],
}
FX=["volume","dist","drive","comp","rev_decay","rev_tone","rev_hpf","rev_level","delay_time","delay_feedback","delay_tone","delay_level","delay_hpf","delay_ping"]
MASTER=["threshold","ratio","attack","release","makeup","mix","pump","pump_source","mode","cutoff","resonance","limiter","comp1","dj_filter"]
TARGET=["909","808","303","BREAK","FX","MIX","MASTER"]


def field(section,offset,stock,candidate):
    if section=="sound":
        obj,parameter=divmod(offset,32)
        target,voice=divmod(obj,12)
        if target>=len(TARGET):return {"storage":"bass_sound_tag"}
        result={"target":TARGET[target],"voice":voice,"parameter":parameter}
        if target==4 and voice==0 and parameter<len(FX):result["name"]=FX[parameter]
        if target==5 and voice<len(PARTS) and parameter==0:result["name"]=PARTS[voice]+"_level"
        if target==6 and voice==0 and parameter<len(MASTER):result["name"]=MASTER[parameter]
        return result
    if section.startswith("pattern_"):
        _,pattern,part=section.split("_",2)
        if part in DRUMS:
            if offset<88:
                voice=offset//8
                return {"instrument":DRUMS[part][voice],"changed_steps_1based":[{"step":8*(offset%8)+bit+1,"stock":(stock>>bit)&1,"candidate":(candidate>>bit)&1} for bit in range(8) if (stock^candidate)&(1<<bit)]}
            if offset==96:return {"field":"length"}
            if offset==97:return {"field":"rate"}
        if part in ("bass_a","bass_b") and offset<192:
            step,which=divmod(offset,3)
            info={"step_1based":step+1,"field":["note","flags","velocity"][which]}
            if which==1:info.update(stock_gate=stock&3,candidate_gate=candidate&3,stock_accent=bool(stock&4),candidate_accent=bool(candidate&4),stock_slide=bool(stock&8),candidate_slide=bool(candidate&8))
            return info
    return {}


p=argparse.ArgumentParser(description=__doc__);p.add_argument("receipts",type=Path);a=p.parse_args();rows=[]
for f in sorted(a.receipts.glob("*-project.json")):
    src=json.loads(f.read_bytes())
    if "different_sections" not in src:continue
    cells=[]
    for part in src["different_sections"]:
        for v in part["first_64_differences"]:
            cells.append({"section":part["section"],**v,"meaning":field(part["section"],v["offset_in_section"],v["stock"],v["candidate"])})
    rows.append({"trial":f.name,"model":src["model"],"shift_ms":src["shift_ms"],"different_bytes":src["different_bytes"],"cells":cells})
print(json.dumps(rows,indent=2))
