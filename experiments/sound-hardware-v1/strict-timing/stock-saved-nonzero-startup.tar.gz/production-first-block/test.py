"""Observe the first full production 24-bit application PCM and its actual 16-bit wire, with real boot stimuli."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os,subprocess,json,sys,hashlib,struct,shutil,tempfile
base=Path.cwd();r=base/'s1-work/emu360';w=base/'sj6-work/boot-silence';sys.path.insert(0,str(r));from sweep import symbols,sha
# A physically programmed, physically saved native project; isolate only its genuine store on the other model.
def seed_for(model,condition):
 seed=(r/'seed/fresh.flash' if model=='elite' else r/f'baseline-{model}/seed/flash.bin')
 if condition.startswith('asym'):return w/(model+'-asym.flash')
 if condition.startswith('saved'):
  out=w/(model+'-saved.flash')
  if not out.exists():
   with (w/(model+'-saved.json')).open('w') as log:subprocess.run([sys.executable,'s1-work/emu-proof/scripts/save_fixture.py',r/'seed/fresh.flash',r/'matched/stock-save/flash.bin',seed,out],stdout=log,check=True)
  return out
 return None if condition=='blank' else seed
modes=['asym','blank','warm','saved','saved-panel','saved-usb','saved-combined']
def work(t):
 m,case=t;seed=seed_for(m,case);elf=r/'input'/(m+'.elf');fw=r/'input'/(m+'.fwsc');sym=symbols(elf)
 with tempfile.TemporaryDirectory(dir=w) as td:
  d=Path(td);(d/'work').mkdir();env={k:v for k,v in os.environ.items() if not k.startswith('FM1_')}
  # Numeric key 5 is a real physical matrix contact; key/PLAY held across app startup; positive controls after initialization.
  keys='300:k5@127,345:PLAY,980:PLAY^,990:k5^,1030:k5@127,1080:k5^' if case in ('saved-panel','saved-combined') else ''
  if case=='saved-combined':keys+=',320:m993c7f,475:m993c7f'  # the SMK transport supplies output-only TRS, deliberately negative.
  (d/'inputs.keys').write_text(keys)
  env.update(FM1_STRICT='1',FM1_DNBOX_MAP=str(d/'map'),FM1_DNBOX_TRACE=str(d/'trace'),FM1_DNBOX_PCM=str(d/'dac'),FM1_DUMPRAM=str(d/'ram'))
  if keys:env['FM1_BENCH_KEYS']='@'+str(d/'inputs.keys')
  mp=(r/'baseline-elite/shift0-trace/observer.map').read_text().splitlines()
  lines=[]
  for ln in mp:
   n,_,length=ln.split();lines.append(f'{n} {sym[n][0]:x} {length}')
  for i in range(0,4096,512):lines.append(f'scene_first_bank_{i} {sym["abuf"][0]+4096+i:x} 512')
  (d/'map').write_text('\n'.join(lines)+'\n')
  args=[r/'bin/fm1-live','--fwsc',fw,'--mhz','360','--shot','1250','--flash',d/'flash']
  if seed:shutil.copyfile(seed,d/'flash')
  if case in ('saved-usb','saved-combined'):
   args+=['--usb'];env['FM1_USB_SEND']='300:99247f;440:99247f;478:99247f;620:99247f;700:99247f;760:992400;800:99247f;1020:992400'
  with (d/'log').open('w') as log:proc=subprocess.run(args,env=env,cwd=d,stdout=log,stderr=subprocess.STDOUT)
  if proc.returncode:raise RuntimeError((case,proc.returncode,(d/'log').read_text()[-2000:]))
  first=None;done=None;edges=[];first_queues=None;deltas=[]
  for line in (d/'trace').open():
   q=json.loads(line);k=q['event']
   if k=='dma':edges.append(q)
   if k=='irq_enter' and first is None:first=q
   if k=='half' and done is None:done=q
   if k=='store' and q['name'] in ('scene_mi_w','scene_cq_w') and q['value'] and first_queues is None:first_queues=dict(q)
  def dat(q):return b''.join(bytes(q['snapshot'][f'scene_first_bank_{i}']) for i in range(0,4096,512))
  def hashb(b):return hashlib.sha256(b).hexdigest()
  assert first and done and first['seq']==done['seq']==2
  before=dat(first);after=dat(done);native=struct.unpack('<1024i',after);pcm=(d/'dac').read_bytes();consumed=pcm[3*2048:4*2048];assert len(consumed)==2048
  nz=next((i//2 for i,v in enumerate(struct.iter_unpack('<h',pcm)) if v[0]),None)
  qnames=('scene_mi_r','scene_mi_w','scene_cq_r','scene_cq_w','scene_bass_held','scene_uo_w','scene_uo_r','eng_prof_frames','x0x_dbg')
  out=dict(model=m,condition=case,runner=sha(r/'bin/fm1-live'),elf=sha(elf),fw=sha(fw),seed=sha(seed) if seed else 'new blank initialized by runner',physical_schedule=keys,usb_schedule=env.get('FM1_USB_SEND'),first_edge=first['seq'],start_ms=first['cycle']/5760000,end_ms=done['completion_cycle']/5760000,first_us=done['last_us'],input_state_before={k:first['snapshot'][k] for k in qnames if k in first['snapshot']},input_state_after={k:done['snapshot'][k] for k in qnames if k in done['snapshot']},native_words=1024,native_nonzero=sum(v!=0 for v in native),native_before=hashb(before),native_after=hashb(after),wire_nonzero=sum(x[0]!=0 for x in struct.iter_unpack('<h',consumed)),wire_edge4_ms=edges[3]['scheduled_cycle']/5760000,first_nonzero_stereo_frame=nz,first_queue_store_inside_observed_IRQ=first_queues,trace=sha(d/'trace'),usb_log=[l for l in (d/'log').read_text().splitlines() if 'usb:' in l or 'usb out:' in l][:22])
  (w/f'{m}-{case}.json').write_text(json.dumps(out,indent=2)+'\n');print(m,case,out['native_nonzero'],out['wire_nonzero'],nz,out['start_ms'],flush=True)
if __name__=='__main__':
 for model in ('elite','pro'):seed_for(model,'saved')
 with ThreadPoolExecutor(max_workers=2) as ex:list(ex.map(work,[(m,mode) for mode in modes for m in ('elite','pro')]))
