"""Read both genuine stock IRQ endpoints for bounded named sound state; no guest instrumentation."""
import sys,json,os,shutil,tempfile,subprocess,hashlib,itertools
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
w=Path('sj6-work/boot-state').resolve();r=Path('s1-work/emu360').resolve();sys.path.insert(0,str(r));from sweep import symbols,sha
sym=symbols(r/'input/elite.elf')
roles=['d909','d808','original_bass','seq','mst','bfx_st','bfx_send_st','brk','bass_render_ok']
regions=[(name,i,min(4096,sym[name][1]-i)) for name in roles for i in range(0,sym[name][1],4096)]
def collect(spec):
 name,off,n=spec; scalar=bytearray();after=bytearray()
 with tempfile.TemporaryDirectory(dir=w) as dr:
  path=Path(dr);(path/'work').mkdir()
  raw=(r/'baseline-elite/shift0-trace/observer.map').read_text()
  base=sym[name][0]+off; special=[]
  for i in range(0,n,512):
   label='scene_'+name+'_'+str(off+i);special.append(label);raw+=f'{label} {base+i:x} {min(512,n-i)}\n'
  mp=path/'observer.map';mp.write_text(raw);shutil.copyfile(r/'seed/fresh.flash',path/'flash.bin')
  env={k:v for k,v in os.environ.items() if not k.startswith('FM1_')}
  env.update(FM1_STRICT='1',FM1_DNBOX_MAP=str(mp),FM1_DNBOX_TRACE=str(path/'trace.jsonl'),FM1_DNBOX_PCM=str(path/'pcm'),FM1_BENCH_KEYS='@'+str(r/'input/heavy.keys'),FM1_CORE_LOAD=f"{sym['_c1_start'][0]:x}-{sym['_c1_end'][0]:x}",FM1_CORE_LOAD_CSV=str(path/'core.csv'),FM1_DUMPRAM=str(path/'ram.bin'))
  cmd=[r/'bin/fm1-live','--fwsc',r/'input/elite.fwsc','--mhz','360','--shot','490','--flash',path/'flash.bin']
  with (path/'log').open('w') as st:subprocess.run(cmd,cwd=path,env=env,stdout=st,stderr=subprocess.STDOUT,check=True)
  before=None; stores=0
  for line in (path/'trace.jsonl').open():
   q=json.loads(line)
   if q['event']=='irq_enter' and before is None:before=q
   if q['event']=='store' and q['seq']==2 and q['name'] in special:stores+=1
   if q['event']=='half' and q['seq']==2:afterq=q;break
  assert before['seq']==2 and before['snapshot']['eng_prof_frames']==[0] and afterq['snapshot']['eng_prof_frames']==[512]
  for label in special:
   scalar.extend(before['snapshot'][label]);after.extend(afterq['snapshot'][label])
  assert len(scalar)==len(after)==n
  return dict(role=name,lo=off,n=n,before=bytes(scalar),after=bytes(after),stores=stores,checksum=sha(path/'pcm'),ticks=[before['cycle'],afterq['completion_cycle']],last=afterq['last_us'],profile=afterq['snapshot']['eng_prof'],cost=afterq['snapshot']['eng_job_cost'],trace=sha(path/'trace.jsonl'))
with ThreadPoolExecutor(max_workers=2) as ex: collected=list(ex.map(collect,regions))
assert len({x['checksum'] for x in collected})==len({tuple(x['ticks']) for x in collected})==len({x['last'] for x in collected})==1
out=dict(elf_sha256=sha(r/'input/elite.elf'),fwsc_sha256=sha(r/'input/elite.fwsc'),runner_sha256=sha(r/'bin/fm1-live'),seed_sha256=sha(r/'seed/fresh.flash'),shot_ms=490,regions={},observed_half=2,profile_24mhz_ticks=collected[0]['profile'],final_job_cost=collected[0]['cost'],first_elapsed_us=collected[0]['last'])
for role in roles:
 parts=[x for x in collected if x['role']==role];a=b''.join(x['before'] for x in parts);b=b''.join(x['after'] for x in parts);changed=[i for i,(v,u) in enumerate(zip(a,b)) if v!=u]
 ranges=[(u[0],u[-1]+1) for key,g in itertools.groupby(enumerate(changed),lambda p:p[1]-p[0]) if (u:=[t[1] for t in g])]
 out['regions'][role]=dict(bytes=len(a),sha256_before=hashlib.sha256(a).hexdigest(),sha256_after=hashlib.sha256(b).hexdigest(),changed_bytes=len(changed),ranges=ranges,stores=sum(x['stores'] for x in parts),traces=[x['trace'] for x in parts])
(w/'state.json').write_text(json.dumps(out,indent=2)+'\n');print(out['first_elapsed_us'],[(r,d['bytes'],d['changed_bytes'],d['stores']) for r,d in out['regions'].items()],flush=True)
