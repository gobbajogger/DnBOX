"""Prepare a valid Device Sound A/B: one supported FX selector changed in the existing physical SAVE."""
from pathlib import Path
import struct,zlib,json,hashlib
w=Path('sj6-work/boot-silence');rows=[]
for m in ('elite','pro'):
 f=w/(m+'-saved.flash');b=bytearray(f.read_bytes())
 for loc in (0x9f000,):  # serialized native SMK project SOUND0
  H='<IHH6I';h=list(struct.unpack_from(H,b,loc))
  assert h[0]==0x30583058 and h[1:3]==[1,0] and h[4]==2716 and h[8]==zlib.crc32(b[loc:loc+28])
  start=loc+256;end=start+h[4];assert h[5]==zlib.crc32(b[start:end])
  at=start+4+(4*12)*32+1    # FX voice0, FX_DIST parameter index1, see app/engine.h, dsp/fxbus.h
  prior=b[at];b[at]=2     # UI's asym soft clip; stored enum=2 selects waveshaper type1
  h[5]=zlib.crc32(b[start:end]);struct.pack_into('<I',b,loc+16,h[5]);struct.pack_into('<I',b,loc+28,zlib.crc32(b[loc:loc+28]))
  out=w/(m+'-asym.flash');out.write_bytes(b)
  rows.append(dict(model=m,old_dist=prior,new_dist=2,drive=b[at+1],offset=at,source=hashlib.sha256(f.read_bytes()).hexdigest(),result=hashlib.sha256(b).hexdigest(),changed=[i for i,(a,z) in enumerate(zip(f.read_bytes(),b)) if a!=z]))
(w/'preset.json').write_text(json.dumps(rows,indent=2)+'\n')
