"""Supplemental small, native contact and queue snapshots of the physical boot stimulus."""
from pathlib import Path
import sys
f=Path('sj6-work/boot-silence/test.py');s=f.read_text()
a=s.index('  for i in range(0,4096,512):lines.append(');b=s.index("  (d/'map')",a)
s=s[:a]+'''  for label,name,offset,n in [('raw_notes','fm1_in',0,4),('playing','seq',8,1),('mi_w','mi_w',0,1),('mi_r','mi_r',0,1),('live_w','live_key_w',0,1),('live_r','live_key_r',0,1),('cq_w','cq_w',0,4),('cq_r','cq_r',0,4)]:
   if name in sym:lines.append(f'scene_{label} {sym[name][0]+offset:x} {n}')
'''+s[b:]
s=s.replace("def dat(q):return b''.join(bytes(q['snapshot'][f'scene_first_bank_{i}']) for i in range(0,4096,512))","def dat(q):return bytes(4096) # The complete separately captured DAC must match.")
s=s.replace("('scene_mi_r','scene_mi_w'","('scene_raw_notes','scene_playing','scene_live_w','scene_live_r','scene_mi_r','scene_mi_w'")
s=s.replace("(w/f'{m}-{case}.json').write_text", "assert out['wire_nonzero']==json.loads((w/f'{m}-{case}.json').read_text())['wire_nonzero'];out.pop('native_words');out.pop('native_nonzero');out.pop('native_before');out.pop('native_after');(w/f'{m}-{case}-input.json').write_text")
s=s.replace("print(m,case,out['native_nonzero'],out['wire_nonzero'],nz,out['start_ms'],flush=True)","print(m,case,out['input_state_before'].get('scene_raw_notes'),out['input_state_after'].get('scene_raw_notes'),out['wire_nonzero'],flush=True)")
s=s.replace("for mode in modes for m", "for mode in ['saved-panel','saved-usb','saved-combined'] for m")
exec(compile(s,str(f),'exec'),dict(__name__='__main__',__file__=str(f)))
