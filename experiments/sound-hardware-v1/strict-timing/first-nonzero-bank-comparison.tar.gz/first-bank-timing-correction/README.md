# Corrected first-bank timing evidence

The first application block on stock targets physical bank 1 released at edge 2. It must finish before edge 3 and appears in the emulator DAC capture at edge 4. The instrumented stock output eventually appears there intact because the sampler reads the complete guest bank at the capture event. Its producer did miss the preceding safe-write deadline. The three previously tested staged implementations delivered their first application block on bank 0 at edge 5. Their counters and silent startup results established a later first handoff. They do not establish fidelity to the original bank or deadline.

The same nonzero diagnostic replaces each of the first six completed application outputs after the unmodified audio engine and USB mix run. It labels all 1,024 words per half, observes both 4,096-byte bank regions and compares the complete native DAC across two independent instrumented runs per image. Times below are milliseconds from emulated boot. Stage programs have opportunity to begin preparation at edge 1, approximately 456 ms.

|Build|Preparation requested|Release edge / bank / ms|Safe deadline edge / ms|First / last correct G1 word ms|DAC edge / bank / ms|Margin to own deadline µs|
|---|---:|---|---|---|---|---:|
|stock|2 / 467.884800|2 / 1 / 467.884800|3 / 479.490134|481.270831 / 482.728136|4 / 1 / 491.095467|-3238.002|
|owned|1 / 456.279016|3 / 0 / 479.489682|4 / 491.095016|479.490053 / 479.508281|5 / 0 / 502.700349|11586.735|
|protected|1 / 456.287201|3 / 0 / 479.497868|4 / 491.103201|479.499436 / 479.517664|5 / 0 / 502.708535|11585.537|
|fixed|1 / 456.284604|3 / 0 / 479.495271|4 / 491.100604|479.496894 / 479.515123|5 / 0 / 502.705938|11585.482|

Stock edges 1–10 carry silence, silence, silence, G1, silence, G2, G3, G4, G5, G6. The three staged variants carry silence, silence, silence, silence, G1, G2, G3, G4, G5, G6. For stock, the first enabled IRQ entered at 478.749107 ms. The safe deadline was 479.490134 ms. The marker changes execution cost slightly and serves only as a nonzero diagnostic. In the prior production image the same first IRQ also crossed edge 3. No new production image is supplied.

Replay from the original project workspace against stock ca0c00a4e5863132de4a66f5d1c477c14d699be5. Restore the three private source directories named in run.py from stock and their corresponding included patches. The native builder and pinned emulator/capture harness must already be present. Copy the four scripts/contracts into sj6-work/wire-labels, run python3 sj6-work/wire-labels/run.py stock owned protected fixed, then python3 sj6-work/wire-labels/analyze.py sj6-work/wire-labels. Use fresh diagnostic output directories. The exact ELF, package, emulator, seed, DAC, both trace hashes and the full physical half sequence are in measured.json.
