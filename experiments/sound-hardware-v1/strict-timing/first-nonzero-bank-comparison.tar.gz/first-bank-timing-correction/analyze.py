from pathlib import Path
import hashlib,json,struct,sys,csv
r=Path(sys.argv[1]).resolve();contract=json.loads((r/'contract.json').read_text());hz=5760000000
def digest(b):return hashlib.sha256(b).hexdigest()
def run(name):
 w=r/name
 cases=[w/'bank0',w/'bank1']
 metas=[json.loads((p/'result.json').read_text()) for p in cases]
 for k in ('fwsc_sha256','elf_sha256','pcm_sha256','emulator_sha256','initial_flash_sha256','debug','eng_prof_frames','pcm_bytes'):assert metas[0][k]==metas[1][k],(name,k)
 pcm=(cases[0]/'stereo.s16le').read_bytes()
 assert pcm==(cases[1]/'stereo.s16le').read_bytes()
 dmas=[];entries=[];halves=[];when={};first={};bank_by_tag={}
 for bank,path in enumerate(cases):
  buf=bytearray(4096);seen={};marked={}
  for ln in (path/'trace.jsonl').open():
   q=json.loads(ln);e=q['event']
   if bank==0 and e=='dma':dmas.append(q)
   if bank==0 and e=='irq_enter':entries.append(q)
   if bank==0 and e=='half':halves.append(q)
   if e!='store' or not q['name'].startswith('scene_bank_'):continue
   off=int(q['name'].removeprefix('scene_bank_'))+q['offset'];buf[off]=q['value'];i=off//4;raw=struct.unpack_from('<i',buf,4*i)[0]
   if raw<=0 or raw&255:continue
   idx=(raw>>8)-1;tag=idx//1024+1
   if not 1<=tag<=6 or idx%1024!=i:continue
   words=seen.setdefault(tag,set());words.add(i);first.setdefault((bank,tag),q['cycle'])
   if len(words)==1024 and tag not in marked:
    all_words=struct.unpack('<1024i',buf)
    if all(x==((tag-1)*1024+j+1)*256 for j,x in enumerate(all_words)):
     marked[tag]=q['cycle']; when[bank,tag]=q['cycle'];bank_by_tag[tag]=bank
 edge={q['seq']:q for q in dmas};assert len(pcm)==len(edge)*2048
 rows=[]
 for j in range(1,len(edge)+1):
  raw=pcm[(j-1)*2048:j*2048];v=struct.unpack('<1024h',raw);tags={((x-1)//1024+1 if x>0 and (x-1)%1024==i else 'zero' if x==0 else 'unknown') for i,x in enumerate(v)}
  rows.append(dict(edge=j,bank=edge[j]['half'],ms=edge[j]['scheduled_cycle']/(hz/1000),wire_label=next(iter(tags)) if len(tags)==1 else 'mixed',zero_words=sum(x==0 for x in v),sha256=digest(raw)))
 c=contract[name];release=c['first_transfer_release_edge'];due=c['safe_write_deadline_edge'];bank=c['first_target_bank']
 firstwrite=first[bank,1];last=when[bank,1]
 nonzero=next(t for t in rows if t['zero_words']!=1024)
 return {'expected':c,'primary_identity':{k:metas[0][k] for k in ('elf_sha256','fwsc_sha256','emulator_sha256','initial_flash_sha256','debug','eng_prof_frames','pcm_sha256')},
  'wire':rows,'first_nonzero':nonzero,'visible_request_ms':edge[c['expected_pending_edge']]['scheduled_cycle']/(hz/1000),'first_real_irq':{'edge':entries[0]['seq'],'ms':entries[0]['cycle']/(hz/1000),'charged_halves_before_entry':entries[0]['snapshot']['x0x_dbg'][1]},
  'released_ms':edge[release]['scheduled_cycle']/(hz/1000),'safe_deadline_ms':edge[due]['scheduled_cycle']/(hz/1000),
  'G1_first_correct_word_ms':firstwrite/(hz/1000),'G1_complete_ms':last/(hz/1000),'slack_before_original_edge3_us':(edge[3]['scheduled_cycle']-last)/(hz/1e6),'slack_before_own_deadline_us':(edge[due]['scheduled_cycle']-last)/(hz/1e6),
  'all_complete_physical_writes':[{'bank':bank,'tag':tag,'ms':clock/(hz/1000)} for (bank,tag),clock in sorted(when.items(),key=lambda x:x[1])],
  'first_callbacks':[dict(edge=q['seq'],dma_at_exit=q['dma_seq_at_completion'],charged=q['last_us_writes'],us=q['last_us'],late=q['snapshot']['x0x_dbg'][5]) for q in halves[:6]],
  'trace_sha256':[digest((p/'trace.jsonl').read_bytes()) for p in cases]}
all_data={}
for k in ('stock','owned','protected','fixed'):
 if not (r/k/'bank1/result.json').exists():continue
 x=run(k);all_data[k]=x;print(k,[(z['bank'],z['wire_label']) for z in x['wire'][:10]],x['slack_before_own_deadline_us'],flush=True)
(r/'measured.json').write_text(json.dumps(all_data,indent=2)+'\n')
