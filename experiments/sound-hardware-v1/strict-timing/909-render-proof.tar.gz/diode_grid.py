"""Compare both real fixed-drive diodes on every possibly reachable triangle value."""
from pathlib import Path
import subprocess
import sys
import tempfile

def command(*args):
    subprocess.run(args, check=True)

with tempfile.TemporaryDirectory() as tmp:
    work = Path(tmp)
    for label, arg in zip(("reference", "candidate"), sys.argv[1:], strict=True):
        root = Path(arg).resolve()
        src = root / "firmware/src/dsp"
        wrapper = work / (label + ".c")
        wrapper.write_text('#include "drum909.c"\n' +
            f'float {label}16(float x) {{ return d9_diode16(x); }}\n' +
            f'float {label}20(float x) {{ return d9_diode20(x); }}\n')
        command("cc", "-O2", "-std=c11", "-ffunction-sections", "-fdata-sections", "-ffp-contract=off",
                "-fno-fast-math", "-DX0X_HOST", "-I", src, "-I", root/"build/gen", "-c",wrapper,"-o",work/(label+".o"))
    original=work/"reference.o"
    syms=subprocess.check_output(["nm","-g","--defined-only",original], text=True).splitlines()
    remap=work/"names"
    remap.write_text("".join(f"{n} frozen_{n}\n" for row in syms if (n:=row.split()[-1]) not in ("reference16","reference20")))
    command("objcopy","--redefine-syms="+str(remap),original,work/"before.o")
    main=work/"main.c"
    main.write_text("""
#include <stdint.h>
#include <stdio.h>
#include <string.h>
float reference16(float), reference20(float), candidate16(float), candidate20(float);
int main(void) {
    uint64_t n = 0, digest = UINT64_C(14695981039346656037);
    for (int i = -16777216; i <= 16777216; ++i) {
        const float x = (float)i * 0x1p-24f;
        float a[2] = {reference16(x), reference20(x)};
        float b[2] = {candidate16(x), candidate20(x)};
        if (memcmp(a,b,sizeof a)) { printf("Mismatch at %a\\n", x); return 1; }
        for (unsigned j=0; j<2; ++j) {
            uint32_t bits;
            memcpy(&bits, &a[j], sizeof bits);
            digest = (digest ^ bits) * UINT64_C(1099511628211);
        }
        ++n;
    }
    printf("Matched %llu triangle grid values, %llu fixed-diode results, fnv64 %016llx\\n",
            (unsigned long long)n,(unsigned long long)(n*2),(unsigned long long)digest);
    return 0;
}
""")
    command("cc","-O2","-ffp-contract=off","-Wl,--gc-sections",main,work/"before.o",work/"candidate.o","-lm","-o",work/"grid")
    command(work/"grid")
