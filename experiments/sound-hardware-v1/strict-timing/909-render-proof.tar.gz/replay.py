"""Compare four exact 909 PCM buses and all voice state against the frozen source."""
import argparse
from pathlib import Path
import subprocess
import tempfile

def run(*args):
    subprocess.run(args, check=True)

parser = argparse.ArgumentParser()
parser.add_argument("baseline", type=Path)
parser.add_argument("candidate", type=Path)
args = parser.parse_args()
base = args.baseline.resolve()
candidate = args.candidate.resolve()
with tempfile.TemporaryDirectory() as tmp:
    work = Path(tmp)
    test = (base / "tests/host/drum909_emit_equivalence.c").read_text()
    test = test.replace("if (!strcmp(spec->name, \"Dist\")) val = dist;", """if (!strcmp(spec->name, "Dist")) val = dist;
                    if (!strcmp(spec->name, "Pan") && (block / 93) % 2 == 0) val = 64;""")
    test = test.replace("drum909_render_st_masked(&a, x[0], x[1], ar, ad, n, mask);", """if (block & 1) {
                    memset(x[0], 0, (size_t)n * sizeof(float));
                    memset(x[1], 0, (size_t)n * sizeof(float));
                    memset(y[0], 0, (size_t)n * sizeof(float));
                    memset(y[1], 0, (size_t)n * sizeof(float));
                    drum909_render_st_cleared(&a, x[0], x[1], ar, ad, n, mask);
                } else {
                    drum909_render_st_masked(&a, x[0], x[1], ar, ad, n, mask);
                }""")
    if "drum909_render_st_cleared" not in test:
        raise RuntimeError("test fixture changed")
    (work / "test.c").write_text(test)
    for level in ("-O0", "-O2"):
        common = ["cc", level, "-std=c99", "-ffp-contract=off", "-fno-fast-math", "-DX0X_HOST"]
        for root, obj in ((base, "before"),(candidate, "after")):
            dsp = root / "firmware/src/dsp"
            run(*common, "-I", str(dsp), "-I", str(root / "build/gen"), "-c", str(dsp / "drum909.c"), "-o", str(work / (obj + ".o")))
        old = work / "before.o"
        symbols = subprocess.check_output(["nm", "-g", "--defined-only", old],text=True).splitlines()
        names = [line.split()[-1] for line in symbols]
        remap = work / "symbols"
        remap.write_text("".join(f"{n} ref_{n}\n" for n in names))
        run("objcopy", "--redefine-syms=" + str(remap), str(old),str(work / "reference.o"))
        dsp = candidate / "firmware/src/dsp"
        run(*common, "-I", str(dsp), "-I", str(candidate / "build/gen"),str(work / "test.c"),str(work / "reference.o"),str(work / "after.o"),str(dsp / "x0x_param.c"), "-lm", "-o", str(work / "test"))
        print(level, flush=True)
        run(str(work / "test"))
