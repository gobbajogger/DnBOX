# 909 cleared stereo, native-rate samples and fixed-drive diodes

The cumulative candidate applies to the two stock production images listed in `native-images.json`. Its only change outside the 909 is the established engine job's call to a function declared for two distinct, already cleared dry buffers.

* The 909 can accumulate directly into the left buffer when all 11 current and target pan pairs equal unity. Under those conditions every audible voice contributes exactly the same floating-point value to each previously cleared bus, in the same order. The renderer copies the completed left side to the right side. The usual additive mono and stereo APIs remain available. Any noncentral or gliding pan uses the ordinary stereo path. Each send and each voice's state still advances through the normal render.
* The sampler has a fast path only for unit increment, zero fraction, an aligned decoder, and a complete block before the final sample. It decodes the original nibble sequence with the original predictor and index, including the one-sample lookahead. Linear interpolation with zero fraction gives precisely the current signed-16-bit sample scaled by 1/32768. Endpoints and all other rates use the original interpolation and decoder operations. The original per-voice drive processes the decoded block in chronological order and retains its separate crush history.
* Fixed 1.6 and 2.0 triangle-diode inputs have magnitude at most 2, so the absolute scaled table index is at most 256 against a saturation limit of 1024. Removing this unreachable saturation branch preserves the table reads and floating operations. General distortion retains its complete domain.

| Elite implementation | Application bytes | Difference from Elite baseline |
| --- | ---: | ---: |
| Frozen original | 546516 | 0 |
| Cleared centered bus | 546644 | +128 |
| Centered bus plus sampler | 546532 | +16 |
| All three changes | 546436 | −80 |

Pro decreases from 546508 to 546428 B. Both boards retain 97204 B occupied RAM, 335092 B of 344064 B pool and 780 B spare beyond the 8192 B reserve. The full ELF, application and FWSC hashes and linker check lines appear in `native-images.json`.

The full candidate matches all 50 audio/state artifacts across the 17 production engine scenarios. It passes 23,280 full 7648-byte drum-state and four-PCM-bus comparisons at each of O0 and O2, and 41,600 further sampler calls at O2. The attached diode test passed all 67,108,866 comparisons on the complete envelope of possible phase values. Folding the unsigned phase yields a nonnegative integer at most 2^31−1. For the scaled integer below 1/2 the rounded subtraction from 1 takes place in [−1,−1/2], whose binary32 values fall on the 2^-24 grid. At or above 1/2 the scaled input already lies on that grid, and subtraction from 1 is exact by Sterbenz's lemma. Testing every multiple of 2^-24 from −1 to +1 therefore covers every possible triangle output. The two diode output digests agreed at c1e0e2251aad06c5.

Apply `production-candidate.patch` with `git apply` in an isolated checkout. The two intermediate patches are independent from the same baseline. Verify the frozen sources with `sha256sum -c baseline-source.sha256`. With the stock generated headers in each checkout's build/gen, run:

```sh
python3 replay.py BASELINE CANDIDATE
python3 sample_rate_replay.py BASELINE CANDIDATE
python3 diode_grid.py BASELINE CANDIDATE
python3 BASELINE/tests/host/audio_path_identity.py --output baseline-output
python3 CANDIDATE/tests/host/audio_path_identity.py --output candidate-output --baseline baseline-output
```

An isolated Elite 360 MHz / zero-offset hardware-emulator run produced 648 halves, 11,108 µs peak, one raw warm-start late count and zero additional scene late count. Its paired original was 11,402 µs. The reduction is 294 µs and the strict 10,909 µs limit is still exceeded by 199 µs at that offset. The panel-driven DAC streams first differed at stereo frame 111,684. This timing result does not establish exact emulator audio or a physical-device measurement.
