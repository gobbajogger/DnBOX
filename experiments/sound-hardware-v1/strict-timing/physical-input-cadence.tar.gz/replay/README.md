# Strict 360 MHz heavy-scene sweep

Target runs use the frozen Sound-lane Elite and Pro firmware packages, a new disposable emulator flash initialized from each respective package, and the emulator's released-style dual-core interpreter. The scene schedules 922 events over 8 seconds. For offset N, add N milliseconds to every original event timestamp, including every release, leave token payloads unchanged, and retain the fixed 8,000 ms end. The historical recorded fixture is the named emu360 heavy scene. It programs drums and bass through physical controls, then sends MIDI. Stock images have no built-in optional BREAK sample pack.

Predeclared threshold for every offset (0, 1, 2, 3, 4, 5 ms) and each board: firmware `x0x_dbg.max_us <= 10909`, 648 complete audio halves for the 8-second shot, and zero additional `x0x_dbg.late` after subtracting the same-board warmed boot's raw count. Record raw late as an independent column. A strict raw-zero interpretation fails if any raw late count is positive. The original published hardware-emulator criterion required under 11,609 µs and zero late during the scene. No measured callback timings here establish physical-device deadlines.

The firmware's `x0x_dbg` is decoded at its own ELF address, little-endian, 13 32-bit words with magic 0x44424731. The simulator's default clocks, dual cores and timed display remain enabled. No scheduler override, JIT or IRQ shortcut is used. The recorded guest time is independent of the host's wall-clock duration. Original and optimized firmware always run from their own package-specific flash image. Reusing a flash from a different firmware overwrites its code. The model-specific fresh flash has an identical settings/samples SHA-256 from 0x9D000 through 0xFFFFF on both boards.

For another run, place the authorized emulator copy under `bin/fm1-live` and the matching package/ELF under `input/{elite,pro}.{fwsc,elf}`, together with the pinned `heavy.keys`. Pass the same model name to every command. Use fresh names to keep prior measurements.

```sh
python3 capture.py --model elite --name repeat/seed --cold --ms 2000
python3 capture.py --model elite --name repeat/boot --ms 2000 --seed repeat/seed/flash.bin
for shift in 0 1 2 3 4 5
do
  python3 capture.py --model elite --name repeat/shift$shift --shift $shift --seed repeat/seed/flash.bin --boot repeat/boot/result.json
done
```

To analyze a worst half, use the identical parameters in a separate run with `--trace`. Each of the 18 memory watches uses the tested ELF's own address and checked size. Firmware data, PCM, timer values and core-load CSV are compared with the primary run. Run `half_report.py TRACE.jsonl halves.csv` to get per-half counts and timing. The `eng_prof` guest counters exclude some core-1 work. The reported raw stage deltas use the 24 MHz timer where the runtime's `perf_cyc_ok` flag is zero. `--profile begin,end` invokes a separate host PC sampler for a short window; compare results and label it diagnostic because single-instruction stepping during that sample window may change guest timing.

The historical authenticated unshifted d4088e60 result is under PR #869, comment 6846592540. It reported Elite / Pro maxima of 11,406 / 11,410 µs with 648 halves, one raw startup late, zero during the scene, three identical repeats and each image's factory-warmed flash. The owner separately reported 11,440 µs on a shifted Elite scene. That specific shifted PCM and offset were not recovered in the historical post.
