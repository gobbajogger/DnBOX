"""Lossless column storage of the observer CSV (x86-independent, Python stdlib)."""
import csv, hashlib, io, json, lzma, struct, sys
from pathlib import Path

HEADER = ['guest_ticks', 'dma_seq', 'field', 'offset', 'value', 'observer_path']
FORMATS = ['q', 'i', 'B', 'B', 'B', 'B']

def pack(data):
    rows = list(csv.reader(io.StringIO(data.decode('ascii'))))
    assert rows.pop(0) == HEADER
    count = len(rows)
    fields = sorted({row[2] for row in rows}); paths = sorted({row[5] for row in rows})
    payload = bytearray((json.dumps([count, fields, paths], separators=(',', ':'))+'\n').encode())
    columns = list(map(list, zip(*rows)))
    for col, values in enumerate(columns):
        if col in (2,5): values = [(fields if col == 2 else paths).index(v) for v in values]
        else: values = list(map(int,values))
        if col < 2: values = [values[0], *(v-u for u,v in zip(values,values[1:]))]
        payload.extend(struct.pack('<'+str(count)+FORMATS[col], *values))
    return lzma.compress(payload, preset=6)

def unpack(data):
    header, payload = lzma.decompress(data).split(b'\n', 1)
    count, fields, paths = json.loads(header); pos=0; cols=[]
    for col, fmt in enumerate(FORMATS):
        size = struct.calcsize('<'+fmt) * count
        values = list(struct.unpack_from('<'+str(count)+fmt,payload,pos)); pos+=size
        if col < 2:
            for i in range(1,count): values[i] += values[i-1]
        if col in (2,5): values = [(fields if col==2 else paths)[i] for i in values]
        cols.append(values)
    assert pos == len(payload)
    out=io.StringIO(newline=''); writer=csv.writer(out);writer.writerow(HEADER);writer.writerows(zip(*cols))
    return out.getvalue().encode('ascii')

if __name__ == '__main__':
    root=Path(__file__).resolve().parent
    for d in sorted(root.glob('*/stores.columns.xz')):
        raw=unpack(d.read_bytes());receipt=json.loads(d.with_name('result.json').read_bytes())
        assert hashlib.sha256(raw).hexdigest()==receipt['stores_sha256'],d
        d.with_name('stores.csv').write_bytes(raw)
