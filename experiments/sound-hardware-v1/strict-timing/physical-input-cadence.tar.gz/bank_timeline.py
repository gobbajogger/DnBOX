"""Read the changing low bytes for the first bank/fader on the +1 physical replay."""
from pathlib import Path
import csv, json
root=Path(__file__).resolve().parent
out={}
for tag in ['elite0','elite1', 'pro1','island-elite1']:
    timeline={}; previous={}
    for row in csv.DictReader((root/tag/'stores.csv').open()):
        tagname=row['field']; tick=int(row['guest_ticks']);value=int(row['value']);idx=int(row['offset'])
        if tagname not in {'frame','bank','button','level0','level1','adc'} or idx!=0:continue
        if previous.get(tagname)==value:continue
        previous[tagname]=value
        if 6800*5760000<=tick<=7550*5760000:
            timeline.setdefault(tagname, []).append([tick,value])
    out[tag]=timeline
(root/'bank-timeline.json').write_text(json.dumps(out,indent=2)+'\n')
