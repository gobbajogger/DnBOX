from pathlib import Path
import bisect,csv,json,math,statistics,sys
r=Path(__file__).resolve().parent;H=5760000
stock=json.load((r/'stock.json').open());boards={};single={}
def changes(rows,name,off):
 prev=None;res=[]
 for t,k,o,v in rows:
  if k==name and o==off and v!=prev:res.append((t,v));prev=v
 return res
def loadcase(d,level):
 rows=sorted([(int(x['guest_ticks']),x['field'],int(x['offset']),int(x['value'])) for x in csv.DictReader((d/'stores.csv').open()) if x['offset'] and x['value'] and x['field']!='clock'])
 irqs=[(int(x['entry']),int(x['exit'])) for x in csv.DictReader((d/'irqs.csv').open()) if x['entry'] and x['exit']]
 btn=next(t for t,v in changes(rows,'button',0) if 6800*H<t<7140*H and v&2)
 release=next(t for t,v in changes(rows,'button',0) if btn<t<7200*H and not v&2)
 bank=next((t for t,v in changes(rows,'bank',0) if 6800*H<t<7300*H and v==1),None)
 adc=changes(rows,'adc',0);at=[t for t,v in adc];av=[v for t,v in adc]
 frames=[t for t,v in changes(rows,'frame',0) if 6500*H<t<7900*H]
 writes=changes(rows,'level0',0);last=next((q for q in reversed(writes) if q[0]<(bank or 8000*H)),None);assert last is not None and last[1]==level,(d,last,level)
 irqs.sort();ii=[t for t,z in irqs]
 def val(t):return av[bisect.bisect_right(at,t)-1]
 def defer(t):
  j=bisect.bisect_right(ii,t)-1
  return irqs[j][1] if j>=0 and t<irqs[j][1] else t
 gap=next((t for t,v in adc if t>last[0] and t<btn and v>level),None)
 counts=0;earliest=[]
 for prev,now in zip(frames,frames[1:]):
  threshold=prev+16*H;free=defer(threshold);earliest.append((now-free)/H)
 return dict(level=level,btn=btn,release=release,bank=bank,adc=adc,val=val,defer=defer,irqs=irqs,frames=frames,last=last,gap=gap,resid=earliest)
def phase_ranges(case,period_ms,hold):
 T=period_ms*H;D=case['btn'];lo=D-3*T
 points={0,T,case['release']%T}
 for v in [case['btn'],case['release'],*(a for a,_ in case['adc']),*(v for q in case['irqs'] for v in q)]:
  if lo<=v<=case['release']+T:points.add(v%T)
 pts=sorted(points);feasible=[]
 def outcome(phi):
  i=(D-1-phi)//T;t=phi+i*T
  observed=False
  for j in range(i-2,(case['release']-phi)//T+2):
   ready=phi+j*T;service=case['defer'](ready) if hold else ready
   if D<=service<case['release']:observed=True;break
  if observed!=(case['bank'] is not None):return -1
  if not observed:return case['level']
  while True:
   done=case['defer'](t) if hold else t
   if done<D:return case['val'](done)
   t-=T
 for x,y in zip(pts,pts[1:]):
  # All input, bank, IRQ and modulo boundaries are explicit. Integer tick
  # intervals are constant, except exact endpoints which we check separately.
  for lo,hi in [(x,x+1),(x+1,y)]:
   if hi<=lo:continue
   if outcome(lo)==case['level']:
    if feasible and feasible[-1][1]==lo:feasible[-1]=(feasible[-1][0],hi)
    else:feasible.append((lo,hi))
 return feasible
def intersect(a,b):
 return [(max(x,u),min(y,v)) for x,y in a for u,v in b if max(x,u)<min(y,v)]
for m in ('elite','pro'):
 cases={};rows=[]
 for n in range(6):
  d=r/(m+str(n))
  if not (d/'result.json').exists():continue
  case=loadcase(d,stock[m][1+n]['mixlevels'][0]);cases[n]=case
  row={'shift_ms':n,'stock_level':case['level'],'last_accepted_level_store_ms':case['last'][0]/H,'bank_down_ms':case['btn']/H,'bank_up_ms':case['release']/H,'bank_switch_ms':case['bank']/H if case['bank'] else None,'level_rose_again_ms':case['gap']/H if case['gap'] else None,'ui_frame_interval_range_ms':[min((y-x)/H for x,y in zip(case['frames'],case['frames'][1:])),max((y-x)/H for x,y in zip(case['frames'],case['frames'][1:]))],'delay_beyond_previous_frame_plus_16_and_actual_irq_us':{'minimum':round(min(case['resid'])*1000),'median':round(statistics.median(case['resid'])*1000),'maximum':round(max(case['resid'])*1000)},'16ms_free_phase_ticks':sum(y-x for x,y in phase_ranges(case,16,False)),'16ms_irq_aware_free_phase_ticks':sum(y-x for x,y in phase_ranges(case,16,True))}
  rows.append(row)
 boards[m]={'rows':rows}
 if not cases:continue
 for oracle in (False,True):
  choices={}
  for ms in range(16,65):
   viable=[(0,ms*H)]
   for case in cases.values():
    viable=intersect(viable,phase_ranges(case,ms,oracle))
    if not viable:break
   if viable:choices[ms]=viable
  boards[m]['shared_fixed_period_and_phase_with_audio_'+str(oracle)]=choices
island=r/'island-elite1';s=r/'elite1'
if (island/'result.json').exists() and (s/'result.json').exists():
 def halves(d):
  return {int(x['dma_seq']):(int(x['scheduled']),int(x['entry']),int(x['exit'])) for x in csv.DictReader((d/'irqs.csv').open()) if x['entry'] and x['exit']}
 a,b=halves(s),halves(island);shared=sorted(a.keys()&b.keys());assert all(a[n][0]==b[n][0] for n in shared)
 delta=[(n,round((a[n][2]-b[n][2])/5760,6),round((a[n][1]-b[n][1])/5760,6),(a[n][0]/H)) for n in shared]
 prior=[v for v in delta if v[3]<4935];first=next((v for v in delta if v[1] or v[2]),None)
 same_input=[v for v in delta if 4948<v[3]<6800]
 single={'common_halves':len(shared),'all_physical_dma_schedules_exact':True,'exact_ends_before_play_contact':sum(v[1]==v[2]==0 for v in prior),'halves_before_play_contact':len(prior),'first_different':[first] if first else [],'first_12_changed_completions': [v for v in delta if v[1]!=0][:12], 'pre_fader_interval':{'rows':len(same_input),'stock_minus_candidate_exit_us_min':min(v[1] for v in same_input),'max':max(v[1] for v in same_input),'negative':sum(v[1]<0 for v in same_input),'positive':sum(v[1]>0 for v in same_input),'exact':sum(v[1]==0 for v in same_input)},'all_rows_range_us':[min(v[1] for v in delta),max(v[1] for v in delta)]}
out={'clock_ticks_per_ms':H,'stock':boards,'stock_vs_equal_flash_candidate':single}
(r/'analysis.json').write_text(json.dumps(out,indent=2)+'\n')
for m,v in boards.items():print(m,'rows',len(v['rows']),'16-ms accepted phases by offset',[(r['shift_ms'],r['16ms_irq_aware_free_phase_ticks']) for r in v['rows']],'viable integer periods',list(v.get('shared_fixed_period_and_phase_with_audio_True',{})))
if single:print(single)
