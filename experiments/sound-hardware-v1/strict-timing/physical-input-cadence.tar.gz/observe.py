"""Read-only foreground sampling, normalized to source-matched stock primary and raw DMA intervals."""
from pathlib import Path
import os,sys,shutil,json,subprocess,hashlib,re,tempfile,threading,csv
r=Path(__file__).resolve().parent;e=r.parents[1]/'emu360';runner=r/'observer/fm1-live';m=sys.argv[1];shifts=list(map(int,sys.argv[2:]))
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for shift in shifts:
 normal=e/('baseline-'+m)/('shift0-trace' if m=='elite' and shift==0 else 'shift'+str(shift))
 dest=r/(m+str(shift));dest.mkdir(exist_ok=True)
 if (dest/'result.json').exists():continue
 cfg=json.loads((normal/'result.json').read_bytes());elf=e/'input'/(m+'.elf');fwsc=elf.with_suffix('.fwsc')
 seed=e/'seed/fresh.flash' if m=='elite' else e/'baseline-pro/seed/flash.bin'
 assert h(seed)==cfg['initial_flash_sha256'] and h(elf)==cfg['elf_sha256'] and h(fwsc)==cfg['fwsc_sha256']
 sy={v[3]:(int(v[0],16),int(v[1],16)) for l in subprocess.check_output(['nm','-S',elf],text=True,stderr=subprocess.DEVNULL).splitlines() if len(v:=l.split())==4}
 origrows=(e/'events-stock/observer.map').read_text().splitlines();lines=[]
 for l in origrows:
  name,_,size=l.split()
  if name.startswith('scene_'):continue
  lines.append(f'{name} {sy[name][0]:x} {size}')
 def add(name,s,off,size):lines.append(f'scene_focus_{name} {sy[s][0]+off:x} {size}')
 add('clock','fm1_ms',0,4);add('frame','x0x_dbg',28,4);add('bank','smk_fbank',0,1);add('pickup','smk_faders.last',0,4);add('held','smk_faders.held',0,1);add('button','fm1_in',12,4);add('adc','fm1_in',584,4);add('raw','fm1_in',598,8)
 for v in range(5):add('level'+str(v),'proj',40+(60+v)*32,1)
 (dest/'map').write_text('\n'.join(lines)+'\n')
 with tempfile.TemporaryDirectory(dir=dest) as temp:
  d=Path(temp);(d/'work').mkdir();shutil.copyfile(seed,d/'flash.bin');fifo=d/'raw-trace.jsonl';store=[];irqs={};pending={}
  def consume():
   with fifo.open() as f:
    for line in f:
     if '"event":"foreground_store"' in line or '"event":"scene_store"' in line or '"event":"store"' in line:
      if '"name":"scene_focus_' not in line:continue
      x=json.loads(line)
      if 'cycle' in x:store.append([x.get('cycle'),x.get('seq'),x['name'][12:],x.get('offset'),x.get('value'),x['event']]);continue
     if line.startswith('{"event":"irq_enter"'):
      v=re.match(r'\{"event":"irq_enter","seq":(\d+),"cycle":(\d+)',line)
      if v:irqs.setdefault(int(v[1]),{})['entry']=int(v[2])
     elif line.startswith('{"event":"dma"'):
      v=re.match(r'\{"event":"dma","seq":(\d+),"scheduled_cycle":(\d+)',line)
      if v:irqs.setdefault(int(v[1]),{})['scheduled']=int(v[2])
     elif line.startswith('{"event":"half"') or line.startswith('{"event":"irq_exit"'):
      x=json.loads(line);s=x.get('seq')
      if s is not None:irqs.setdefault(s,{})['exit']=x.get('cycle',x.get('completion_cycle',x.get('exit_cycle',x.get('return_cycle'))))

  env={k:v for k,v in os.environ.items() if not k.startswith('FM1_')};env.update(FM1_STRICT='1',FM1_BENCH_KEYS='@'+str(normal/'scene.keys'),FM1_CORE_LOAD=cfg['env']['FM1_CORE_LOAD'],FM1_CORE_LOAD_CSV=str(d/'core.csv'),FM1_DUMPRAM=str(d/'ram.bin'),FM1_DNBOX_PCM=str(d/'pcm'),FM1_DNBOX_TRACE=str(fifo),FM1_DNBOX_MAP=str(dest/'map'))
  cmd=[str(runner),'--fwsc',str(fwsc),'--mhz','360','--shot','8000','--flash',str(d/'flash.bin')]
  with (dest/'run.log').open('w') as log:subprocess.run(cmd,env=env,cwd=d,check=True,stdout=log,stderr=subprocess.STDOUT)
  consume()
  checks={n:h(d/q)==h(normal/n) for n,q in [('flash.bin','flash.bin'),('ram.bin','ram.bin'),('stereo.s16le','pcm'),('core.csv','core.csv')]};assert all(checks.values()),checks
 with (dest/'stores.csv').open('w') as f:
  writer=csv.writer(f);writer.writerow(['guest_ticks','dma_seq','field','offset','value','observer_path']);writer.writerows(store)
 with (dest/'irqs.csv').open('w') as f:
  writer=csv.writer(f);writer.writerow(['dma_seq','scheduled','entry','exit']);writer.writerows([[i,v.get('scheduled'),v.get('entry'),v.get('exit')] for i,v in sorted(irqs.items())])
 result={'board':m,'shift_ms':shift,'scene_sha256':cfg['scene_sha256'],'seed':h(seed),'elf':h(elf),'fwsc':h(fwsc),'observer_sha256':h(runner),'equivalence':checks,'records':len(store),'irqs':len(irqs),'frame_changes':sum(s[2]=='frame' and s[3]==0 for s in store),'map_sha256':h(dest/'map'),'stores_sha256':h(dest/'stores.csv'),'irqs_sha256':h(dest/'irqs.csv')}
 (dest/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(result,flush=True)
