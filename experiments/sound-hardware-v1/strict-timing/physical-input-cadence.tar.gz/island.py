from pathlib import Path
r=Path(__file__).resolve().parent;s=(r/'observe.py').read_text()
s=s.replace("normal=e/('baseline-'+m)/('shift0-trace' if m=='elite' and shift==0 else 'shift'+str(shift))","normal=e/'placed-island'/m/('shift'+str(shift))")
s=s.replace("dest=r/(m+str(shift))","dest=r/('island-'+m+str(shift))")
s=s.replace("elf=e/'input'/(m+'.elf')","elf=r.parent/'island-gate/images'/(m+'.elf')")
s=s.replace("seed=e/'seed/fresh.flash' if m=='elite' else e/'baseline-pro/seed/flash.bin'","seed=e/'placed-island'/m/'seed/flash.bin'")
exec(compile(s,__file__,'exec'))
