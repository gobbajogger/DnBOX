from pathlib import Path
import hashlib,subprocess,json,csv,statistics,gzip
r=Path(__file__).resolve().parent;e=r.parents[1]/'emu360';result={}
for m in ('elite','pro'):
 sym={f[-1]:int(f[0],16) for l in subprocess.check_output(['nm','-S',e/'input'/(m+'.elf')],text=True,stderr=subprocess.DEVNULL).splitlines() if len(f:=l.split())==4};p=sym['proj']-0x1c00000
 rows=[]
 for i in [None,0,1,2,3,4,5]:
  path=e/('boot' if m=='elite' else 'baseline-pro/boot') if i is None else e/('baseline-'+m)/('shift0-trace' if m=='elite' and i==0 else 'shift'+str(i))
  b=(path/'ram.bin').read_bytes()[p:p+36420];c=json.load((path/'result.json').open());dbg=c['debug']
  hashes=lambda block:hashlib.sha256(block).hexdigest()
  core=list(csv.DictReader((path/'core.csv').open()))
  rows.append(dict(shift=i,project=hashes(b),mixlevels=[b[40+(60+k)*32] for k in range(5)],bass_b_len=b[3352],clap16=bool(b[2801]&128),fader_bank1=list(b[40+2312:40+2319]),kit9=hashes(b[2752:2952]),timer_irqs=dbg['timer_irqs'],ui_frames=dbg['ui_frames'],halves=dbg['halves'],raw_late=dbg['late'],scene=c.get('scene_sha256'),audio_bins_sha256=hashes(','.join(x['ms_start'] for x in core).encode())))
 result[m]=rows
print('board offset level0 level1 bassLen clap16 UIFrames bins')
for m,rows in result.items():
 for a in rows:print(m,a['shift'],a['mixlevels'][:2],a['bass_b_len'],a['clap16'],a['ui_frames'],a['audio_bins_sha256'][:12])
(r/'stock.json').write_text(json.dumps(result,indent=2)+'\n')
