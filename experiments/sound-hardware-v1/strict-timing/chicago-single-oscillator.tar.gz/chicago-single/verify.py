"""Exercise every selected oscillator, all shapes, signed zeros and failure commits."""
import argparse
from pathlib import Path
import subprocess
ap=argparse.ArgumentParser()
for arg in ('harness','baseline','candidate','output'):ap.add_argument(arg,type=Path)
a=ap.parse_args();out=a.output.resolve();out.mkdir(exist_ok=False,parents=True)
ref=a.baseline.resolve();alt=a.candidate.resolve()
text=a.harness.read_text();anchor='        base.gains.stereo[0]=held(.5f);'
assert text.count(anchor)==1
text=text.replace(anchor,'''        unsigned selected=(iteration/4)%4;
        p.controls.xmod=fp(iteration%2?0x80000000:0);
        for (unsigned i=0;i<4;++i) {
            base.gains.oscillator[i]=held(0.0f);
            if(iteration&2)base.gains.oscillator[i].delta=fp(0x80000000);
            p.controls.increment[i]=(iteration&4)? 0x7ffffffdu : word()>>2;
            base.osc.phase[i]=word();
        }
        p.controls.shape[selected]=(iteration/16)%4;
        base.gains.oscillator[selected]=held(.375f);
        base.gains.oscillator[selected].target=(iteration&64)?0.0f:-.25f;
        base.gains.oscillator[selected].delta=(iteration&128)?-.03125f:-.005f;
        switch ((iteration/256)%7) {
            case 1: p.controls.width[selected]=fp(0x7f800000); break;
            case 2: p.triangle[selected]=fp(0xffc12345); break;
            case 3: p.correction[selected]=fp(0x7f7fffff); break;
            case 4: base.gains.oscillator[(selected+1)%4].current=fp(0x80000000); break;
            case 5: p.controls.xmod=.125f; break;
            case 6: base.gains.oscillator[(selected+2)%4]=held(.125f); break;
        }
'''+anchor)
(out/'test.c').write_text(text)
for root,label in ((ref,'ref'),(alt,'alt'),(alt,'mutant')):
 src=root/'experiments/original_synth/chicago_mp4.c'
 if label=='mutant':
  code=src.read_text();token='phase[master+1]=0x7fffffffu;'
  assert code.count(token)==1
  src=out/'bad.c';src.write_text(code.replace(token,'phase[master+1]=0;'))
 subprocess.run(['cc','-O2','-std=c11','-fno-fast-math','-ffp-contract=off','-fPIC','-shared','-I'+str(root/'experiments/original_synth'),'-I'+str(root/'firmware/src/app'),src,'-lm','-o',out/(label+'.so')],check=True)
subprocess.run(['cc','-O2','-std=c11','-I'+str(ref/'experiments/original_synth'),out/'test.c','-ldl','-lm','-o',out/'test'],check=True)
for label in ('alt','mutant'):
 r=subprocess.run([out/'test',out/'ref.so',out/(label+'.so')],capture_output=True,text=True)
 print(label,r.returncode,r.stdout.strip(),r.stderr.strip(),flush=True)
 if label=='alt':r.check_returncode()
 else:assert r.returncode==1 and 'mismatch' in r.stderr
