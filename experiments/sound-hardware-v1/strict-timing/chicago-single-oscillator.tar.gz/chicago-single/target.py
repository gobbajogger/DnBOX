"""Run exactly the same 60 captured-state target cases and check every output."""
from pathlib import Path
import argparse,subprocess,csv,hashlib,json
ap=argparse.ArgumentParser()
for arg in ('root','stock','build','capture','thunk','runner','out'):ap.add_argument(arg,type=Path)
a=ap.parse_args()
out=a.out.resolve();out.mkdir(exist_ok=False,parents=True)
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
fixture=a.capture.read_bytes();assert len(fixture)==5184
measure={}
for name,build in [('ref',a.stock),('single',a.build)]:
 dest=out/name;dest.mkdir()
 syms={r.split()[3]:int(r.split()[0],16) for r in subprocess.check_output(['nm','-S',build/'x0x.elf'],text=True).splitlines() if len(r.split())==4}
 owner=syms['original_bass'];span=syms['original_chicago_voice_span'];state=bytearray(1024*1024)
 start=owner-0x1c00000+len(fixture);state[start:start+len(fixture)]=fixture
 ram=out/(name+'.ram');ram.write_bytes(state)
 with (out/(name+'.csv')).open('w') as f:
  subprocess.run([a.runner,build/'x0x.bin',ram,a.thunk,format(span,'x'),format(owner,'x'),dest],check=True,stdout=f)
 measure[name]={(r['mode'],r['frames'],r['xmod_bits']):float(r['guest_us']) for r in csv.DictReader((out/(name+'.csv')).open())}
assert set(measure['ref'])==set(measure['single']) and len(measure['ref'])==60
rows=[]
for (mode,frames,xmod),base in measure['ref'].items():
 file=f'{mode}-{frames}-{xmod}.bin';p=out/'ref'/file;q=out/'single'/file
 assert p.stat().st_size==7232 and p.read_bytes()==q.read_bytes(),file
 now=measure['single'][(mode,frames,xmod)]
 rows.append(dict(mode=mode,frames=int(frames),xmod_bits=xmod,before_us=base,after_us=now,delta_us=now-base,equal_sha256=h(q)))
rec={'cases':rows,'fixture':h(a.capture),'entry':h(a.thunk),'baseline_bin':h(a.stock/'x0x.bin'),'candidate_bin':h(a.build/'x0x.bin'),'native_app_bytes':(a.build/'x0x.bin').stat().st_size}
(out/'result.json').write_text(json.dumps(rec,indent=2)+'\n')
for row in rows:
 if row['xmod_bits'] in ('00000000','3e800000') and row['frames'] in (1,64,256):print(row['mode'],row['frames'],row['xmod_bits'],row['before_us'],row['after_us'])
