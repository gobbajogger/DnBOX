from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
here=Path(__file__).resolve().parent;base=here.parents[1];emu=base/'s1-work/emu360';panel=base/'s1-work/native-panel'
label=sys.argv[1];root=emu/({'stock':'baseline-pro','candidate':'root-combined-note-pro'}[label]);primary=root/'shift1';dest=here/label;dest.mkdir()
h=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
c=json.loads((primary/'result.json').read_text());fw=Path(c['command'][2]);elf=fw.with_suffix('.elf');seed=root/'seed/flash.bin'
assert c['shift_ms']==1 and c['shot_ms']==8000 and c['model']=='pro' and c['scene_events']==922
assert [h(p) for p in (fw,elf,seed,primary/'scene.keys')]==[c[k] for k in ('fwsc_sha256','elf_sha256','initial_flash_sha256','scene_sha256')]
syms={}
for line in subprocess.check_output(['nm','-S',elf],text=True,stderr=subprocess.DEVNULL).splitlines():
    a=line.split()
    if len(a)==4:syms[a[3]]=(int(a[0],16),int(a[1],16))
layout=json.loads((here/'layout/layout.json').read_text())
watch=[]
def add(label,symbol,offset,size):
    address,n=syms[symbol];assert offset+size<=n
    watch.append(f'{label} {address+offset:x} {size}')
for line in (emu/'events-stock/observer.map').read_text().splitlines():
    label2,_,size=line.split()
    if label2.startswith('scene_'):continue
    add(label2,label2,0,int(size))
add('scene_focus_enc_contact','fm1_in',layout['enc_last'],8)
add('scene_focus_enc_hist','fm1_in',layout['enc_hist'],8)
add('scene_focus_enc_count','fm1_in',layout['enc_cnt'],16)
add('scene_focus_enc_steps','fm1_in',layout['enc_steps'],16)
add('scene_focus_raw_matrix','fm1_in',layout['raw'],16)
add('scene_focus_ui_time','ui',layout['ui_enc_t'],28)
add('scene_focus_ui_run','ui',layout['ui_enc_run'],7)
add('scene_focus_ui_context','ui',0,2)
add('scene_focus_bassb_length','proj',layout['bassb_len'],1)
assert syms['fm1_in'][1]==layout['hal_size'] and syms['proj'][1]==layout['proj_size']
(dest/'observer.map').write_text('\n'.join(watch)+'\n')
shutil.copyfile(seed,dest/'flash.bin');shutil.copyfile(primary/'scene.keys',dest/'scene.keys');(dest/'work').mkdir()
env=dict(FM1_STRICT='1',FM1_BENCH_KEYS='@'+str(dest/'scene.keys'),FM1_CORE_LOAD=c['env']['FM1_CORE_LOAD'],FM1_CORE_LOAD_CSV=str(dest/'core.csv'),FM1_DUMPRAM=str(dest/'ram.bin'),FM1_DNBOX_PCM=str(dest/'stereo.s16le'),FM1_DNBOX_TRACE=str(dest/'trace.jsonl'),FM1_DNBOX_MAP=str(dest/'observer.map'))
cmd=[panel/'fm1-live','--fwsc',fw,'--mhz','360','--shot','8000','--flash',dest/'flash.bin']
meta={'initial_flash':h(seed),'fwsc':h(fw),'elf':h(elf),'primary_emulator':h(Path(c['command'][0])),'diagnostic_emulator':h(cmd[0]),'scene':h(dest/'scene.keys'),'observer_map':h(dest/'observer.map'),'command':list(map(str,cmd)),'env':env}
(dest/'command.json').write_text(json.dumps(meta,indent=2)+'\n')
with (dest/'run.log').open('w') as log:
    subprocess.run(cmd,env={**{k:v for k,v in os.environ.items() if not k.startswith('FM1_')},**env},cwd=dest,stdout=log,stderr=subprocess.STDOUT,check=True)
checked={}
for name in ('ram.bin','flash.bin','stereo.s16le','core.csv','run.log','scene.keys'):
    observed=h(dest/name);wanted=h(primary/name);checked[name]={'primary':wanted,'diagnostic':observed,'equal':wanted==observed}
meta.update(files=checked,trace=h(dest/'trace.jsonl'))
(dest/'result.json').write_text(json.dumps(meta,indent=2)+'\n')
assert all(x['equal'] for x in checked.values()),checked
