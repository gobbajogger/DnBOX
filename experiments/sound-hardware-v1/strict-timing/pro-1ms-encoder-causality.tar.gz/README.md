# SMK37 Pro, +1 ms, encoder causality

The stock image reached 11,318 µs, with one raw startup late and zero late halves in the scene. The combined image reached 10,116 µs, with zero raw and in-scene late halves. Each original strict 360 MHz run completed 648 halves. Read-only observer replays reproduced each corresponding original's complete 1 MiB RAM, 1 MiB flash, all 333,312 stereo DAC frames, core-load CSV, complete run log and 922-event scene byte for byte. The physical images, input flash and primary and diagnostic emulator identities are in each result.json.

Within the 36,420-byte project in RAM, exactly one byte differs. It is the first pattern's second bass part length at offset 3,352, with 35 in stock and 32 in combined. Neither run programmed or erased flash, and its ending flash equals its own original warmed seed. The two waveform streams also differ starting at absolute DAC frame 97,856, well before this edit. The length trace explains the one-byte project mismatch.

## Physical contact and foreground chronology

At 4,561 ms the scene starts +80 turns on physical encoder index 4, printed K5 and mapped to UI knob 1. At 4,566 ms it starts +80 on index 6, printed K7. Physical index 2, printed K3 and mapped to part navigation, turns clockwise at 4,611 and 4,721 ms. The saved panel map and all seven directions matched the stock defaults in both RAM images. Each detent requests four Gray transitions with 4 ms per transition. The six original row-7 contact columns for e2/e4/e6 have matching ordered binary levels in both shots, with at most 8.953 µs difference at the guest's raw matrix sample. Both executed the same sampled Gray states, same accepted three-state history, and same accumulating quarter-step values. During the full scene e2 presented 16 transitions and emitted/consumed three detents, and e4/e6 each presented 320 transitions and emitted/consumed 79 detents in both images. The original decoder starts from its resting-state history. These counts include all its observed startup and completion transitions.

| Guest event | Stock, ms | Combined, ms |
| --- | ---: | ---: |
| e4 pending detent changes from zero to one | 4,723.550 | 4,723.545 |
| e2 pending navigation detent changes from zero to one | 4,725.150 | 4,725.156 |
| Foreground consumes e4 | 4,726.837 | 4,724.503 |
| Foreground consumes e2 | 4,726.797 | 4,734.280 |
| UI part changes from BREAK to bass B | 4,726.814 | 4,734.298 |
| First bass-B length write | 4,726.894 | 4,740.976 |

Stock drained both pending controls during the same input pass. The original input routine visits ALGORITHM/navigation before knob 1. Stock changed to bass B, then gave knob 1 its pending detent. The combined image visited knob 1 while the e2 detent was still acquiring its stable state. It consumed e4 in BREAK and selected bass B on a later pass. Physical contact order remained e4 then e2 in both, and both physical detents survived.

| Length edit index | Stock clock / run / new length | Combined clock / run / new length |
| ---: | --- | --- |
| 1 | 4726 / 1 / 17 | 4740 / 1 / 17 |
| 2 | 4744 / 2 / 18 | 4755 / 2 / 18 |
| 3 | 4755 / 3 / 19 | 4772 / 3 / 19 |
| 4 | 4772 / 4 / 22 | 4824 / 4 / 20 |
| 5 | 4825 / 5 / 23 | 4835 / 5 / 23 |
| 6 | 4835 / 6 / 26 | 4858 / 6 / 26 |
| 7 | 4852 / 7 / 29 | 4868 / 7 / 29 |
| 8 | 4868 / 8 / 32 | 4884 / 8 / 32 |
| 9 | 4884 / 9 / 35 | — |

Every length write consumed exactly one physical detent. The actual original acceleration rule for this length range of 63 caps gain at three and activates after four fast detents. Its clock records foreground milliseconds. At 4,772 ms stock was already on its fourth detent and added three, while the combined run was on its third and added one. The next length edits were separated by 53/52 ms and gained one on both. The three steps of final difference can be accounted for as one extra routed detent plus two extra increments from reaching that first acceleration threshold earlier.

This is an ordering property of the two independent HAL accumulators and their consumer. Equal scanned contacts and complete decoded detent counts do not establish equal target selection when a foreground pass can fall between two detent publications. Timestamping at stable detent acceptance and specifying cross-role priority at a fixed consumption boundary would define a reproducible interface. It would need explicit compatibility qualification with the historical same-pass navigation-first outcome, with uncapped/reversed turns, and across simultaneous key/encoder changes. This receipt makes no change to that policy.

## Reproduction and inputs

layout.py compiles the original HAL structure, UI prefix and production project headers for PI32v2 r3 with the stock floating-point and ABI settings. The generated layout matches the symbol sizes in both original physical ELFs. Both images give a 636-byte HAL state and a 36,420-byte project. The relevant target offsets and source-expanded layout are included. Each read-only runtime observer map pins the absolute target address in that image's own ELF.

run_trace.py uses the same s1-work/native-panel/fm1-live observer qualified against the stock fm1-live program, using its already-built sources and actual hash. It launches the same 8,000-ms primary input and warmed flash. Run the script on stock and candidate labels. analyze.py recreates the observed waveforms and expands guest stores, preserving separate writes at the same sample. qualify.py verifies all field identities and original acceleration math. The two primary result.json files, per-field timelines, the actual script and six artifact hashes per image are included. The original full observer traces remain available under their hashes in the diagnostics. CSV times are milliseconds from shot start. Original-clock integers are actual stored milliseconds. The observer's timestamp resolution is 1 / 5,760,000 ms.
