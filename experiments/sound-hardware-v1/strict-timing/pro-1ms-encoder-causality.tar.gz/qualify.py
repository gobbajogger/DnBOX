from pathlib import Path
import csv,json,hashlib,struct,subprocess
here=Path(__file__).resolve().parent;base=here.parents[1]
def sha(b):return hashlib.sha256(b).hexdigest()
layout=json.loads((here/'layout/layout.json').read_text())
products={};projects={};all_regs={};primary={}
for label,name in [('stock','baseline-pro'),('candidate','root-combined-note-pro')]:
    d=here/label;normal=base/'s1-work/emu360'/name/'shift1'
    meta=json.loads((d/'result.json').read_text())
    assert all(v['equal'] for v in meta['files'].values())
    c=json.loads((normal/'result.json').read_text());primary[label]=c
    elf=Path(c['command'][2]).with_suffix('.elf')
    syms={}
    for line in subprocess.check_output(['nm','-S',elf],text=True,stderr=subprocess.DEVNULL).splitlines():
        f=line.split()
        if len(f)==4:syms[f[3]]=(int(f[0],16),int(f[1],16))
    raw=(d/'ram.bin').read_bytes()
    def object(symbol):
        at,n=syms[symbol];return raw[at-0x1c00000:at-0x1c00000+n]
    panel=object('panel')
    assert len(panel)==32 and panel[18:25]==bytes(range(1,8)) and panel[25:32]==bytes([1])*7
    pr=object('proj');projects[label]=pr
    assert len(pr)==layout['proj_size'] and meta['initial_flash']==meta['files']['flash.bin']['primary']
    measures={}
    all_regs[label]={}
    for field in ('raw_matrix','enc_contact','enc_hist','enc_count','enc_steps','ui_time','ui_run','ui_context','bassb_length'):
        with (d/(field+'.csv')).open() as f:
            regs=[{k:int(v) if k not in ('ms','event','name') else (float(v) if k=='ms' else v) for k,v in x.items()} for x in csv.DictReader(f)]
        all_regs[label][field]=regs
    for i in (2,4,6):
        b=all_regs[label]
        events=lambda n:[v for v in b[n] if v['i']==i]
        accepted=events('enc_steps')
        rises=sum(max(x['v']-x['old'],0) for x in accepted)
        read=sum(x['old'] for x in accepted if x['v']==0)
        assert rises==read
        measures[i]={'contact_transitions':len(events('enc_contact')),'stable_gray_transitions':len(events('enc_hist')),'detents_emitted':rises,'detents_consumed':read,'foreground_batches':sum(x['v']==0 for x in accepted)}
    def latest(field,i,t):
        return next(v for v in reversed(b[field]) if v['i']==i and v['ticks']<t)
    edits=[]
    for edit in b['bassb_length']:
        if edit['ms']<4500:continue
        t0=edit['ticks']
        time=latest('ui_time',3,t0);run=latest('ui_run',3,t0);take=latest('enc_steps',4,t0);part=latest('ui_context',1,t0)
        assert part['v']==3 and take['v']==0
        ns=take['old'];dt=(time['v']-time['old'])//ns
        r=run['old']+ns if dt<60 else ns
        gain=1 if r<4 else (3 if dt<45 else 1)
        assert r==run['v'] and edit['old']+ns*gain==edit['v']
        edits.append({'ticks':t0,'ms':edit['ms'],'logical_clock_ms':time['v'],'detents':ns,'ms_per_detent':dt,'run':r,'multiplier':gain,'old':edit['old'],'length':edit['v']})
    products[label]={'scene_sha256':meta['scene'],'project_sha256':sha(pr),'panel_hex':panel.hex(),'project_len':pr[layout['bassb_len']],'detents':measures,'b_edits':edits,'primary':{'max_us':c['debug']['max_us'],'raw_late':c['debug']['late'],'in_scene_late':c['late_during_test'],'halves':c['debug']['halves']}}
diff=[[i,a,c] for i,(a,c) in enumerate(zip(projects['stock'],projects['candidate'])) if a!=c]
assert diff==[[layout['bassb_len'],35,32]],diff[:64]
control={}
for field in ('raw_matrix','enc_contact','enc_hist','enc_count'):
    comp={}
    for i in ([1,2,5,6,13,14] if field=='raw_matrix' else [2,4,6]):
        pairs=[]
        for label in ('stock','candidate'):
            pairs.append([v for v in all_regs[label][field] if v['i']==i])
        a,b=pairs
        assert [(v['old'],v['v']) for v in a]==[(v['old'],v['v']) for v in b],(field,i)
        comp[i]={'equal_ordered_values':len(a),'first_stock_ms':a[0]['ms'],'last_stock_ms':a[-1]['ms'],'max_timestamp_difference_us':round(max(abs(x['ms']-y['ms'])*1000 for x,y in zip(a,b)),5)}
    control[field]=comp
result={'scope':'Pro, +1 ms, target 360 MHz, 8000-ms warmed shot, 922 commands. Per-image physical layout validated against both exact ELFs.','primary_project_differences':diff,'aligned_contacts_per_input':control,'runs':products}
(here/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(products['stock']['detents'],products['candidate']['detents'])
