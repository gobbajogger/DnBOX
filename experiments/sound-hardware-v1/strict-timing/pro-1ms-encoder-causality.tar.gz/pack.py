import gzip,hashlib,io,tarfile
from pathlib import Path
here=Path(__file__).resolve().parent;base=here.parents[1]
files={}
def add(name,path): files[name]=path.read_bytes()
for name in ['README.md','analysis.json','analyze.py','layout.py','run_trace.py','qualify.py','pack.py','final-events.log']:
 add(name,here/name)
for p in (here/'layout').glob('*'):
 if p.suffix in ('.c','.json','.raw'):add('layout/'+p.name,p)
for label,primary in [('stock','baseline-pro'),('candidate','root-combined-note-pro')]:
 d=here/label
 for name in ('observer.map','run.log','core.csv','result.json','command.json'):
  add(label+'/'+name,d/name)
 for p in d.glob('*.csv'):
  if p.name!='core.csv':add(label+'/fields/'+p.name,p)
 add(label+'/primary-result.json',base/'s1-work/emu360'/primary/'shift1/result.json')
add('scene.keys',here/'stock/scene.keys')
files['FILES.sha256']=(''.join(hashlib.sha256(b).hexdigest()+'  '+s+'\n' for s,b in sorted(files.items()))).encode()
out=base/'native/publication/pro-1ms-encoder-causality.tar.gz'
with out.open('xb') as f,gzip.GzipFile(fileobj=f,filename='',mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w:') as tf:
 for n,b in sorted(files.items()):
  t=tarfile.TarInfo(n);t.size=len(b);t.mtime=0;tf.addfile(t,io.BytesIO(b))
with tarfile.open(out,'r:gz') as tf:
 for n,b in files.items():assert b==tf.extractfile(n).read(),n
print(out,hashlib.sha256(out.read_bytes()).hexdigest(),out.stat().st_size,len(files))
