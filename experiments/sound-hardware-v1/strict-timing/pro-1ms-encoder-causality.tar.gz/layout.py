from pathlib import Path
import json,re,subprocess,struct,sys
tree,tc,out=map(lambda p:Path(p).resolve(),sys.argv[1:]);out.mkdir(parents=True,exist_ok=True)
u=(tree/'firmware/src/app/ui.c').read_text()
h=(tree/'firmware/hal/smk_input.h').read_text()
def segment(s,a,b):
 start=s.index(a);return s[start:s.index(b,start)]
defs='\n'.join(line for line in h.splitlines() if re.match(r'#define (FM1_NCOL|FM1_NBTN|FM1_NKEY|FM1_NENC|SMK_NPAD) ',line))
ui=segment(u,'typedef struct {\n    uint8_t view, part, prev_view;','    uint32_t enc_t')+u[u.index('    uint32_t enc_t'):u.index(';',u.index('    uint8_t enc_run'))+1]+'\n} ui_prefix;'
hs=segment(h,'static volatile struct {\n    uint32_t notes;','} fm1_in;').replace('static volatile struct','typedef struct')+'} smk_in;'
views=re.search(r'enum \{ V_HOME[^;]+;',u)[0]
fields={}
for n in ('raw','enc_last','enc_hist','enc_cnt','enc_steps','frames'):fields[n]=f'__builtin_offsetof(smk_in,{n})'
for n in ('view','part','sel','page','enc_t','enc_run'):fields['ui_'+n]=f'__builtin_offsetof(ui_prefix,{n})'
fields.update(hal_size='sizeof(smk_in)',proj_size='sizeof(project_t)',bassb_len='__builtin_offsetof(project_t,pat[0].bass[1].len)',bassb_begin='__builtin_offsetof(project_t,pat[0].bass[1])',pattern_begin='__builtin_offsetof(project_t,pat[0])',part_len='__builtin_offsetof(bpart_t,len)')
src='#include <stdint.h>\n#include "x0x.h"\n#include "plat.h"\n'+defs+'\n'+views+'\n'+ui+'\n'+hs+'\nconst unsigned values[]={'+','.join(fields.values())+'};\n'
(out/'layout.c').write_text(src)
args=[tc/'bin/clang','-target','pi32v2','-mcpu=r3','-mfprev1','-Os','-ffp-contract=off','-ffunction-sections','-fdata-sections','-fno-builtin','-DBOARD_SMK37=1','-DX0X_ORIGINAL_SYNTH=1','-idirafter',tc/'include','-I',tree/'build/gen','-I',tree/'firmware/src/app','-c',out/'layout.c','-o',out/'layout.o']
subprocess.run(args,check=True)
subprocess.run([tc/'bin/objcopy','-O','binary','-j','.rodata.values',out/'layout.o',out/'values.raw'],check=True)
values=struct.unpack('<'+'I'*len(fields),(out/'values.raw').read_bytes())
layout=dict(zip(fields,values));(out/'layout.json').write_text(json.dumps(layout,indent=2)+'\n');print(layout)
