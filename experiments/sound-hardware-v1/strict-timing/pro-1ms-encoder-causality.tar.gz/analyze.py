"""Reconstruct each multi-byte store from observed guest bytes; verify original acceleration math."""
from collections import defaultdict
from pathlib import Path
import csv,hashlib,json,struct,subprocess,sys
here=Path(__file__).resolve().parent
TS=5760000.
def stores(path):
    state={}
    group=None
    history=[]
    for line in path.open('rb'):
        try:e=json.loads(line)
        except json.JSONDecodeError:continue
        event=e['event']
        if event=='irq_enter' and e['cycle']<12_000_000_000:
            for name,initial in e['snapshot'].items():
                if name.startswith('scene_focus_'):
                    state[name]=bytearray(initial)
            continue
        name=e.get('name','')
        if not name.startswith('scene_focus_') or event not in ('foreground_store','store') or e['cycle']<12_000_000_000:continue
        reg=state[name];offset=e['offset'];value=e['value']
        if value==reg[offset]: continue
        if 'old' in e: assert reg[offset]==e['old'],(e,reg[offset])
        k=(e['cycle'],name,event)
        if group!=k:
            prev=bytes(reg)
            item={'ticks':k[0],'ms':round(k[0]/TS,6),'event':k[2],'name':name[12:],'previous':prev,'after':None,'irq':e['seq']}
            history.append(item);group=k
        reg[offset]=value;item['after']=bytes(reg)
    return history
def decode(hist):
    events=[]; latest={}
    for v in hist:
        name=v['name'];width={'enc_count':2,'enc_steps':2,'ui_time':4}.get(name,1)
        for i in range(len(v['after'])//width):
            signed=name in ('enc_count','enc_steps')
            sl=slice(i*width,(i+1)*width)
            bef=int.from_bytes(v['previous'][sl],'little',signed=signed)
            aft=int.from_bytes(v['after'][sl],'little',signed=signed)
            if name=='raw_matrix':bef>>=7;aft>>=7
            if bef==aft:continue
            events.append({k:x for k,x in v.items() if k not in ('after','previous')}|{'i':i,'old':bef,'v':aft})
    return events
def get_events(label):
    d=here/label;comments=decode(stores(d/'trace.jsonl'))
    for group in ('raw_matrix','enc_contact','enc_hist','enc_count','enc_steps','ui_time','ui_run','ui_context','bassb_length'):
        with (d/(group+'.csv')).open('w') as f:
            w=csv.DictWriter(f,fieldnames=['ticks','ms','event','name','irq','i','old','v']);w.writeheader();w.writerows(v for v in comments if v['name']==group)
    return comments
def scan(label):
    e=get_events(label)
    selected=[v for v in e if 4540<=v['ms']<4925 and ((v['name']=='enc_steps' and v['i'] in (2,4,6)) or v['name'] in ('ui_context','bassb_length') or (v['name'] in ('ui_time','ui_run') and v['i']==3))]
    for v in selected:
        if v['name']=='enc_steps' and (v['i']!=4 or v['v']!=0):continue
        print(f"{v['ms']:12.6f} {v['name']:15s} {v['i']} {v['old']}→{v['v']}")
    return e
if __name__=='__main__':
    for label in sys.argv[1:] or ['stock','candidate']:
        print('\n'+label);scan(label)
