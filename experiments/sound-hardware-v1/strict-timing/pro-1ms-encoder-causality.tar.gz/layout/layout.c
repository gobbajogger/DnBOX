#include <stdint.h>
#include "x0x.h"
#include "plat.h"
#define FM1_NCOL 16u
#define FM1_NBTN 18u
#define FM1_NKEY 37u              /* the keybed */
#define FM1_NENC 8u
#define SMK_NPAD 16u
enum { V_HOME, V_PART, V_GEN, V_FX, V_MIX, V_GLO, V_SONG, V_PERF, V_SEQ, NVIEWS };
typedef struct {
    uint8_t view, part, prev_view;
    uint8_t home_live; /* runtime view only; never changes stored pattern assignment */
    uint8_t sel[NKIT];
    uint8_t page[NVIEWS][NPARTS];
    uint8_t spage;                     /* the 16 steps the white keys show: 0 = 1-16 .. 3 = 49-64 */
    uint8_t pbank;                     /* the 16 patterns HOME's white keys choose: 0 = 1-16, 1 = 17-32 */
    uint8_t mixsel;                    /* MIX's PARTS: the part the knobs set (black keys 1-5) */
    int8_t oct;
    uint8_t rec;
    uint8_t freeplay[NBASS];           /* SEQ > FREE PLAY: the keys play the 303, nothing written (not saved) */
    uint8_t wpos[NBASS];
    int8_t held_step;
    uint8_t held_step_part, held_step_pat; /* owner at key-down; a pattern can change before key-up */
    uint8_t step_edited;
    uint8_t paste_src[NPARTS];        /* source slots chosen with a paste target; stable through confirmation */
    uint8_t brk_choice_on, brk_choice_bank, brk_choice_slot, brk_choice_pat;
    uint8_t step_preview;              /* the held step is sounding (only while stopped) */
    uint8_t step_created;              /* the press turned the held step on (its release keeps it) */
    int8_t brk_held;                   /* BREAK: the white key (16th) held, -1 none */
    int8_t hold_step;                  /* a drum machine: the step (white key) held, -1 none */
    uint8_t hold_drum, hold_pat;       /* kit/track and pattern at key-down; navigation cannot retarget its release */
    uint8_t hold_created, hold_used;   /* drums / BREAK: the press turned the step on; a knob or a slice used it */
    int8_t chain_first;
    int8_t touched;                    /* knob cell being turned (4 = tempo), -1 none */
    uint8_t touch_view, touch_part, touch_page;
    uint8_t touch_kind, touch_a, touch_b, touch_c; /* exact edited ref for overlays */
    uint32_t step_t0;                  /* when the held 303 step went down: a tap toggles, a hold does not */
    uint32_t hold_t0;                  /* when it went down (a tap takes an old step off) */
    uint8_t brk_page, brk_count_target;
    uint16_t brk_localkeys;
    uint16_t brk_pinkeys;              /* BREAK: black keys used to give a held step its slice (their release is not live) */
    uint8_t gen_stale[NBASS];          /* TB-3PO's knobs changed since the line was written */
    uint32_t btn, keys, btn_used;
    uint32_t enc_t[NE];
    uint8_t enc_run[NE];
} ui_prefix;
typedef struct {
    uint32_t notes;              /* bit n = note key n (0 = F3 .. 26 = G5): keybed keys 5..31 | the pads */
    uint32_t knotes, pnotes;     /* (the two sources of notes: keybed keys 5..31, pads as white keys) */
    uint32_t buttons;            /* debounced: bit i = button i (0..17) */
    uint32_t pressed, released;  /* button edges since the last fm1_input_edges() */
    uint32_t notes_pressed;      /* note-key press edges since the last fm1_input_note_edges() */
    uint64_t keys;               /* all 37 keybed keys: bit k = key k (0 = lowest C) */
    uint8_t key_vel[FM1_NKEY];   /* MIDI velocity 1..127 of each key's last press (a pad: its white key's) */
    uint8_t raw[FM1_NCOL];       /* last frame, rows packed, 1 = closed */
    uint8_t cnt[FM1_NBTN];       /* button debounce */
    uint8_t ks_last[FM1_NKEY], ks_stab[FM1_NKEY], ks_rel[FM1_NKEY];
    uint32_t ks_t1[FM1_NKEY];    /* fm1_ticks() when contact 1 closed */
    uint8_t enc_last[FM1_NENC], enc_hist[FM1_NENC];
    int16_t enc_cnt[FM1_NENC];   /* transitions, + = B leads */
    int16_t enc_steps[FM1_NENC];
    uint16_t pad_raw[SMK_NPAD], pad_base[SMK_NPAD], pad_peak[SMK_NPAD];
    uint8_t pad_st[SMK_NPAD];    /* 0 idle, 1..SMK_PAD_PEAKN collecting the peak, 0x80 on */
    uint8_t pad_low[SMK_NPAD];
    uint8_t pad_vel[SMK_NPAD];   /* last strike, separate from the overlapping keybed velocity */
    uint8_t pad_press[SMK_NPAD]; /* pressure 0..127 while on */
    uint16_t fad_acc[4];         /* faders: 0..1023 IIR */
    uint8_t fader[4];            /* 0..127 */
    uint16_t wheel[2], pedal, batt;   /* raw 0..1023 (mux C addresses 4, 5, 6, 7) */
    uint16_t wheel_mod_seq;          /* accepted mod ADC publications, not foreground polls */
    uint16_t fad_raw[4];         /* (debug: the last raw fader readings) */
    uint16_t fad_hist[4][2];     /* the two readings before: a median of 3 drops a lone spike */
    uint32_t adc_ok, adc_miss;   /* (debug: conversions read / not finished within a tick) */
    uint32_t frames;
} smk_in;
const unsigned values[]={__builtin_offsetof(smk_in,raw),__builtin_offsetof(smk_in,enc_last),__builtin_offsetof(smk_in,enc_hist),__builtin_offsetof(smk_in,enc_cnt),__builtin_offsetof(smk_in,enc_steps),__builtin_offsetof(smk_in,frames),__builtin_offsetof(ui_prefix,view),__builtin_offsetof(ui_prefix,part),__builtin_offsetof(ui_prefix,sel),__builtin_offsetof(ui_prefix,page),__builtin_offsetof(ui_prefix,enc_t),__builtin_offsetof(ui_prefix,enc_run),sizeof(smk_in),sizeof(project_t),__builtin_offsetof(project_t,pat[0].bass[1].len),__builtin_offsetof(project_t,pat[0].bass[1]),__builtin_offsetof(project_t,pat[0]),__builtin_offsetof(bpart_t,len)};
