# Chicago unmodulated slave phase increments

The two slave phase increments depend only on immutable prepared increments when cross modulation is either sign of zero and the master waveform is finite. At the original operation boundaries the unsigned increment is first rounded to binary32, scaled by an exact power of two, clamped and scaled back. The candidate caches that exact rounded and saturated integer per slave, once at span entry. It preserves the signed phase-wrap test, reset-to-0x7fffffff sync, moving and held gain paths, stereo processing, filter history, public error behavior and four waveform shapes. A nonfinite master still takes the existing arithmetic path. Both incremental and combined patches are supplied.

| Native stock build | Application B | XIP free B | Ordinary RAM B | Pool B | Margin above pool reserve B |
| --- | ---: | ---: | ---: | ---: | ---: |
| Elite | 546452 | 6220 | 97204 | 335092 | 780 |
| Pro | 546444 | 6228 | 97204 | 335092 | 780 |

The combined application image shrinks by 64 bytes per model compared with the stock dry INIT source and grows by 32 bytes compared with the finite-tail-only candidate. The final source SHA-256 is ea6e8ac8a7a4e4ce4e32a0903d15838ef5d58706c6c965a0c00505ce35ffdf00. The independent native link pins identify every binary and package.

The host differential compared the exact full return, public state, prefix writes and stereo output across 840,000 inputs including +0, −0, subnormal, fractional and maximum valid XMod, held/moving gains, all shapes, signed wraparound, and rounding boundaries above 24 bits and near the signed integer maximum. All 116,516 successes and 723,484 rejections matched, including 10,068 failures with an already committed audio prefix. The repository's existing span/hold reference passed all 4,344 checks in both normal and ASan/UBSan modes.

Sixty PI32v2 vectors use the Elite's actual linked Chicago symbol and the real final Chicago B owner from a stock warm eight-second unshifted heavy scene. In the observed owner, one oscillator gain was nonzero, XMod was +0, shapes were 1/1/3/3 and several ramps were moving. Additional vectors exercised held ramps and all four gains, with 1, 16, 64 and 256 samples at each of five cross-modulation bit patterns. Every return succeeded and every complete 5,184-byte owner and 2,048-byte stereo/sentinel pair matched byte-for-byte. The timing probe uses the strict emulator core opcode table with a flat memory bus, giving isolated symbol costs. Full stock-scene and physical timing require separate qualification.

| Span scenario at 64 samples | Finite-tail only, µs | Plus cached increments, µs |
| --- | ---: | ---: |
| Captured moving gains, ±0 XMod | 114.122 | 108.217 |
| Captured moving gains, 0.25 XMod | 120.456 | 122.384 |
| Held captured gains, ±0 XMod | 79.794 | 71.617 |
| Held captured gains, 0.25 XMod | 87.427 | 86.551 |
| Four nonzero held gains, ±0 XMod | 111.110 | 105.501 |
| Four nonzero held gains, 0.25 XMod | 111.594 | 109.717 |

At one sample, the extra preparation costs up to 0.177 µs. At 256 samples, the observed moving zero-XMod owner saves 33.911 µs, while the moving nonzero-XMod control costs 3.092 µs more. Among these 60 executed cases the largest percentage saving is 10.54%, on the held 256-sample zero-XMod loop; the largest regression is 5.38%, on a one-sample moving nonzero-XMod loop. Both signs of zero agree. Both CSV files retain all cases.

Run `python3 host_cases.py fault_compare.c BASELINE_TREE CANDIDATE_TREE NEW_OUTPUT` for the host differential against the finite-tail baseline. Run `sh target-replay.sh BASELINE_TREE CANDIDATE_TREE JIELI_TOOLCHAIN FM1_RELEASE_DEPS NEW_OUTPUT` with linked Elite outputs and the matching Rust toolchain on PATH to repeat the target comparison. The packed owner is the exact 5,184-byte slice at RAM offset 0x3c150 + 5184, SHA-256 d06ea80e61d64117822103d295f0dd0b9df902d86bc611b6393836d97704f13e; the full source RAM dump had digest 47fd58626c18a2817bfe28c52941c72a9761bb8edb51bc2543502d566f8e6097. Each case independently resets this owner and clears output sentinels. Other RAM has no ownership in the isolated span.
