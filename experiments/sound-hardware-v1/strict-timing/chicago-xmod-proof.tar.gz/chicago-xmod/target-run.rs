use fm1_core::{Bus,Cpu};
use std::{env,fs};
struct Memory { bytes: Vec<u8>, ticks: u64 }
impl Bus for Memory {
    fn read8(&mut self,a:u32)->u8 {self.bytes[a as usize]}
    fn read16(&mut self,a:u32)->u16 {u16::from_le_bytes(self.bytes[a as usize..a as usize+2].try_into().unwrap())}
    fn read32(&mut self,a:u32)->u32 {u32::from_le_bytes(self.bytes[a as usize..a as usize+4].try_into().unwrap())}
    fn write8(&mut self,a:u32,v:u8){self.bytes[a as usize]=v;}
    fn write16(&mut self,a:u32,v:u16){self.bytes[a as usize..a as usize+2].copy_from_slice(&v.to_le_bytes());}
    fn write32(&mut self,a:u32,v:u32){self.bytes[a as usize..a as usize+4].copy_from_slice(&v.to_le_bytes());}
    fn add_ticks(&mut self,n:u64){self.ticks+=n;}
}
fn main() {
    // Locals/stack use separate scratch RAM; actual owner data and actual native
    // function execute at their firmware addresses under the same strict CPU.
    let args:Vec<String>=env::args().collect();
    let image=fs::read(&args[1]).unwrap();
    let ram=fs::read(&args[2]).unwrap();
    let entry=fs::read(&args[3]).unwrap();
    let function=u32::from_str_radix(&args[4],16).unwrap();
    let owner=u32::from_str_radix(&args[5],16).unwrap() as usize+5184;
    let dest=&args[6];
    let original=(owner-0x1c00000)..(owner-0x1c00000+5184);
    let output=0x1ce0000usize;
    let mut m=Memory{bytes:vec![0u8;0x2200000],ticks:0};
    m.bytes[0x2000120..0x2000120+image.len()].copy_from_slice(&image);
    m.bytes[0x1c00000..0x1c00000+ram.len()].copy_from_slice(&ram);
    m.bytes[0x1000..0x1000+entry.len()].copy_from_slice(&entry);
    assert_eq!(m.bytes[owner+0x2f0],1);
    println!("mode,frames,xmod_bits,result,instructions,cost_ticks,guest_us");
    for mode in ["live","held","all"] {for count in [1,16,64,256] {for xmod in [0u32,0x80000000,1,0x3e800000,0x3f666666] {
        m.bytes[owner..owner+5184].copy_from_slice(&ram[original.clone()]);
        m.bytes[owner+0x2cc..owner+0x2d0].copy_from_slice(&xmod.to_le_bytes());
        if mode!="live" {
            for r in [0x214usize,0x220,0x22c,0x238,0x244,0x250,0x25c+20,0x25c+32,0x25c+44,0x334] {
                let cur=m.read32((owner+r) as u32);
                m.write32((owner+r+4) as u32,cur);m.write32((owner+r+8) as u32,0x80000000);
            }
        }
        if mode=="all" {for j in 0..4 {
            let r=owner+0x214+j*12;
            let val=(0.17+j as f32*0.08).to_bits();
            m.write32(r as u32,val);m.write32((r+4) as u32,val);
        }}
        m.bytes[output..output+2048].fill(0xa3);
        m.ticks=0;
        let mut cpu=Cpu::new(0x1000);
        cpu.sp=0x1cffff0;cpu.rets=0xfffe;cpu.cost_model=true;
        cpu.regs[0]=function;cpu.regs[1]=owner as u32;cpu.regs[2]=output as u32;cpu.regs[3]=count;
        while cpu.pc!=0xfffe {
            cpu.step(&mut m).unwrap();m.ticks+=1;assert!(cpu.insn_count<4_000_000);
        }
        assert_eq!(cpu.regs[0],1);
        let mut result=m.bytes[owner..owner+5184].to_vec();result.extend(&m.bytes[output..output+2048]);
        fs::write(format!("{}/{}-{}-{:08x}.bin",dest,mode,count,xmod),result).unwrap();
        println!("{},{},{:08x},{},{},{},{:.6}",mode,count,xmod,cpu.regs[0],cpu.insn_count,m.ticks,m.ticks as f64/5760.);
    }}}
}
