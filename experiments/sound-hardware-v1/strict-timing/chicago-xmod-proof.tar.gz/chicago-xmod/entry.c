#include "original_runtime.h"
typedef int (*span_fn)(original_voice_gain *,original_oscillators *,const original_prepared_oscillators *,original_ramp *,uint32_t *,float,original_chicago_mp4 *,uint32_t *,uint32_t *,uint32_t);
int entry(span_fn span,original_runtime_part *owner,uint32_t *out,unsigned n) {
    original_chicago_backend *backend=&owner->dsp.chicago;
    original_chicago_voice *v=&backend->voice;
    return span(&v->gain,&v->pitch.oscillator,&v->prepared,&v->noise_gain,&v->noise,backend->controls.vco_gain,&v->filter,out,out+256,n);
}
