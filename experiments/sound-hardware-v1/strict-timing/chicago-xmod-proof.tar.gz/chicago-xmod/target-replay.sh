#!/bin/sh
set -eu
# Usage: this script BASELINE_TREE CANDIDATE_TREE JIELI_TOOLCHAIN FM1_RELEASE_DEPS NEW_OUTPUT
before=$(realpath "$1")
after=$(realpath "$2")
tc=$(realpath "$3")
deps=$(realpath "$4")
mkdir "$5"
out=$(realpath "$5")
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
"$tc/pi32v2/bin/clang" -target pi32v2 -mcpu=r3 -mfprev1 -fno-fast-math -ffp-contract=off -Oz -I"$before/firmware/src/app" -I"$before/firmware/src/dsp" -I"$before/experiments/original_synth" -I"$before/experiments/wobble" -idirafter "$tc/pi32v2/include" -c "$here/entry.c" -o "$out/entry.o"
"$tc/pi32v2/bin/objcopy" -O binary -j .text "$out/entry.o" "$out/entry.bin"
set -- "$deps"/libfm1_core-*.rlib
test "$#" -eq 1
rustc --edition=2021 -C opt-level=2 -C lto=fat -C embed-bitcode=yes -C codegen-units=1 -L "$deps" --extern "fm1_core=$1" "$here/target-run.rs" -o "$out/run"
for tree in "$before" "$after"; do
    if test "$tree" = "$before"; then name=baseline; else name=candidate; fi
    app="$tree/build/smk37-elite"
    span=$(nm -S "$app/x0x.elf" | awk '$4=="original_chicago_voice_span"{print $1}')
    owner=$(nm -S "$app/x0x.elf" | awk '$4=="original_bass"{print $1}')
    python3 - "$here/captured-owner.bin" "$out/$name.ram" "$owner" <<'PY'
from pathlib import Path
import sys
src=Path(sys.argv[1]).read_bytes()
assert len(src)==5184
start=int(sys.argv[3],16)-0x1c00000+5184
mem=bytearray(1024*1024)
mem[start:start+len(src)]=src
Path(sys.argv[2]).write_bytes(mem)
PY
    mkdir "$out/$name"
    "$out/run" "$app/x0x.bin" "$out/$name.ram" "$out/entry.bin" "$span" "$owner" "$out/$name" > "$out/$name.csv"
done
diff -qr "$out/baseline" "$out/candidate"
