"""Extend the baseline arbitrary-state differential with modulator and phase boundary cases."""
from pathlib import Path
import argparse
import subprocess
cli=argparse.ArgumentParser(description=__doc__)
cli.add_argument('fault_compare',type=Path)
cli.add_argument('baseline',type=Path)
cli.add_argument('candidate',type=Path)
cli.add_argument('out',type=Path)
a=cli.parse_args();out=a.out.resolve();out.mkdir(parents=True,exist_ok=False)
source=a.fault_compare.read_text()
source=source.replace('unsigned iteration=0;iteration<28000;++iteration','unsigned iteration=0;iteration<84000;++iteration')
addition='''
        static const uint32_t xms[]={0,0x80000000,1,0x3c800000,0x3e800000,0x3f000000,0x3f666666};
        static const uint32_t incs[]={1,2,127,0xffffff,0x1000000,0x1000001,0x1000003,0x4000001,0x7fffffc0,0x7fffffbf,0x7fffffff};
        p.controls.xmod=fp(xms[iteration%7]);
        for(int i=0;i<4;++i){
            p.controls.increment[i]=incs[(iteration/7+i*3)%11];
            if(iteration&2)base.gains.oscillator[i]=held(i==int_placeholder ? .3f : fp(iteration&4?0:0x80000000));
            if(iteration&8)base.gains.oscillator[i].delta=(i&1)?-.01f:.02f;
            if(iteration&32)base.osc.phase[i]=incs[(iteration+i)%11]^(i&1?0xffffffffu:0x80000000u);
        }
'''
source=source.replace('        base.gains.stereo[0]=held(.5f);',addition.replace('int_placeholder','(int)((iteration>>4)%4)')+'        base.gains.stereo[0]=held(.5f);')
(out/'cases.c').write_text(source)
for tree,name in [(a.baseline.resolve(),'baseline'),(a.candidate.resolve(),'candidate')]:
    orig=tree/'experiments/original_synth'
    subprocess.run(['cc','-O2','-std=c11','-fno-fast-math','-ffp-contract=off','-fPIC','-shared','-I'+str(orig),'-I'+str(tree/'firmware/src/app'),orig/'chicago_mp4.c','-lm','-o',out/(name+'.so')],check=True)
subprocess.run(['cc','-O2','-std=c11','-fno-fast-math','-ffp-contract=off','-I'+str(a.baseline.resolve()/'experiments/original_synth'),out/'cases.c','-ldl','-lm','-o',out/'test'],check=True)
subprocess.run([out/'test',out/'baseline.so',out/'candidate.so'],check=True)
