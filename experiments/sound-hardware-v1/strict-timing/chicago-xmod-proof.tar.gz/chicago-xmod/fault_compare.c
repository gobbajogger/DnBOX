/* Compare the actual baseline and reduced-check public span, including all
 * mutated state and every sentinel in the output, on first and mid-span faults. */
#include "chicago_mp4.h"
#include "voice_gain.h"
#include "oscillator_motion.h"
#include <assert.h>
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
enum { N = 16 };
typedef int (*render_fn)(original_voice_gain *, original_oscillators *,
    const original_prepared_oscillators *, original_ramp *, uint32_t *, float,
    original_chicago_mp4 *, uint32_t *, uint32_t *, uint32_t);
struct state {
    original_voice_gain gains;
    original_oscillators osc;
    original_ramp noise_gain;
    uint32_t noise;
    original_chicago_mp4 filter;
    uint32_t left[N], right[N];
};
static uint32_t seed=0xac117e5u;
static uint32_t word(void) {
    seed^=seed<<13; seed^=seed>>17; seed^=seed<<5; return seed;
}
static float fp(uint32_t bits) {float x; memcpy(&x,&bits,4);return x;}
static original_ramp held(float a) {original_ramp r={a,a,0.f};return r;}
static unsigned long passed,rejected,mid;
static void compare(render_fn old,render_fn latest,struct state a,original_prepared_oscillators *p) {
    struct state b=a;
    const float gain=1.25f;
    int rc1=old(&a.gains,&a.osc,p,&a.noise_gain,&a.noise,gain,&a.filter,a.left,a.right,N);
    int rc2=latest(&b.gains,&b.osc,p,&b.noise_gain,&b.noise,gain,&b.filter,b.left,b.right,N);
    if(rc1!=rc2||memcmp(&a,&b,sizeof(a))) {
        fprintf(stderr,"Return, state, PCM or failure-prefix mismatch at %lu\n",passed+rejected);
        exit(1);
    }
    if(rc1) ++passed;
    else { ++rejected; if(a.left[0]!=0xa3a3a3a3u) ++mid; }
}
int main(int argc,char **argv) {
    assert(argc==3);
    void *a=dlopen(argv[1],RTLD_LOCAL|RTLD_NOW),*b=dlopen(argv[2],RTLD_LOCAL|RTLD_NOW);
    if(!a||!b){fprintf(stderr,"dlopen %s\n",dlerror());return 2;}
    render_fn old=(render_fn)dlsym(a,"original_chicago_voice_span");
    render_fn latest=(render_fn)dlsym(b,"original_chicago_voice_span");
    assert(old && latest);
    const uint32_t special[]={0,0x80000000,1,0x80000001,0x00800000,0x80800000,0x3f000000,
        0x3f800000,0xbf800000,0x3f7fffff,0x7effffff,0x7f7fffff,0xff7fffff,0x7f800000,
        0xff800000,0x7fcab123,0xffc12345,0x7f812345,0xff812345};
    const int ns=(int)(sizeof(special)/sizeof(special[0]));
    for(unsigned iteration=0;iteration<28000;++iteration) {
        original_prepared_oscillators p={0}; p.ready=1;
        struct state base={0};base.filter.prepared=1;base.noise=word()|1;
        memset(base.left,0xa3,sizeof(base.left));memset(base.right,0x5c,sizeof(base.right));
        base.noise_gain=held(.0625f);
        for(int i=0;i<4;++i){
            base.gains.oscillator[i]=held(.3f);base.osc.phase[i]=word();
            p.controls.increment[i]=word()>>5;
            p.controls.width[i]=.32f;p.controls.shape[i]=word()%4;
            p.correction[i]=.71f;p.triangle[i]=.325f;
        }
        base.gains.stereo[0]=held(.5f);base.gains.stereo[1]=held(.85f);
        base.filter.a=held(fp(special[iteration%ns]));
        base.filter.e=held(fp(special[(iteration/ns)%ns]));
        base.filter.resonance=held((iteration%3)==0?.33f:fp(special[(iteration/ns/ns)%ns]));
        if(iteration&1){base.gains.stereo[1].target=.5f;base.gains.stereo[1].delta=-.002f;}
        for(int i=0;i<5;++i)base.filter.history[i]=(float)(int32_t)word()*0x1p-32f;
        for(int h=0;h<5;++h){
            struct state s=base;
            s.filter.history[h]=fp(special[(iteration+h*7)%ns]);
            compare(old,latest,s,&p);
            s.filter.history[(h+1)%5]=fp((iteration&2)?word():special[(iteration+3)%ns]);
            compare(old,latest,s,&p);
        }
    }
    printf("exact cases %lu; success %lu; rejected %lu; mid-span rejection with output prefix %lu\n",
           passed+rejected,passed,rejected,mid);
    assert(passed && rejected && mid);
}
