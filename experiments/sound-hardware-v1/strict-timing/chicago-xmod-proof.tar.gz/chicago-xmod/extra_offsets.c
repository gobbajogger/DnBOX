#include "original_runtime.h"
#include <stddef.h>
char noise_offset[1+offsetof(original_runtime_part,dsp.chicago.voice.noise_gain)];
