"""Verify source-level eligibility and exact native executable layout for a sequencer-only optimization."""
import hashlib,json,re,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
g=Path(sys.argv[1]).resolve()
stock=root/'native/final-init/build/smk37-elite/x0x.bin'
se=root/'s1-work/emu360/input/elite.elf'; ce=g/'images/elite.elf';cb=g/'images/elite.bin'
sha=lambda x:hashlib.sha256(x).hexdigest()
nm=lambda p:subprocess.check_output(['nm','-S',p],stderr=subprocess.DEVNULL).splitlines()
stock_syms=nm(se);new_syms=nm(ce)
assert stock_syms==new_syms, len(set(stock_syms)^set(new_syms))
f=next(l.split() for l in stock_syms if l.endswith(b' fire_drum'))
start=int(f[0],16); end=start+int(f[1],16)
a=stock.read_bytes();b=cb.read_bytes();base=0x02000120
assert sha(a)=='4c1fea5eb23ccaa8a5538c994b9552e8164d0fe2ea2b146d4e159ef38387e7cd'
assert len(a)==len(b)
diff=[i+base for i,(x,y) in enumerate(zip(a,b)) if x!=y]
assert len(diff)>0 and min(diff)>=start and max(diff)<end
excluded=sha(a[:start-base]+a[end-base:])
assert excluded==sha(b[:start-base]+b[end-base:])
out={'stock':{'app_sha256':sha(a),'elf_sha256':sha(se.read_bytes())},'candidate':{'app_sha256':sha(b),'elf_sha256':sha(ce.read_bytes())},
     'bytes':len(a),'identical_nm_S_rows_including_unsized':len(stock_syms),'identical_named_symbol_address_size_rows':sum(len(x.split())==4 for x in stock_syms),
     'nm_S_sha256':sha(b'\n'.join(stock_syms)+b'\n'),'fire_drum_entry_hex':hex(start),'fire_drum_bytes':end-start,
     'different_occupied_bytes':len(diff),'changed_addresses':[hex(v) for v in diff],'other_bytes':len(a)-(end-start),'other_bytes_sha256':excluded}
(g/'machine-eligibility.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out),flush=True)
