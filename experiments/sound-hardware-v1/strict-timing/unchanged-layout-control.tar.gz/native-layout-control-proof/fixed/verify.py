#!/usr/bin/env python3
import os,sys,shlex,struct,wave,math,hashlib,json,subprocess as sp
from pathlib import Path
root,closure,patch=(Path(x).resolve() for x in sys.argv[1:4])
out=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cmd(args,**kwargs):return sp.run(args,cwd=root,check=True,**kwargs)
base=root/'firmware/src/seq/sequencer.c'
candidate=out/'engine-a.c'
cmd(['patch','--batch','--silent',str(base),'-o',str(candidate),'-i',str(patch)])
hashgit=lambda p:cmd(['git','hash-object',str(p)],capture_output=True,text=True).stdout.strip()
assert digest(candidate)=='cd276a8234ee5663ba4a0581f6acc0186e7cd79e7c2e010aabfad179ea8a5ce1'
build=json.loads((closure/'build.json').read_text())
flags=build['flags'][:-1]+['-I'+str(closure), '-I'+str(root/'firmware/src/seq')]
objects=sorted(closure.glob('*.c.o'))
assert len(objects)==70
objects=[f for f in objects if 'sequencer.c' not in f.name]
assert len(objects)==69
objects.append(out/'unchanged-engine.o')
for k,v in build['inputs_sha256'].items():
 if k.startswith(('firmware/','experiments/','tests/','host/','tools/','build/gen/')):
  assert (root/k).is_file() and digest(root/k)==v,k
def compile(src,name):
 obj=out/(name+'.o');cmd(['cc',*flags,'-c',str(src),'-o',str(obj)]);return obj
compile(root/'firmware/src/app/engine.c','unchanged-engine')
fixture=root/'tests/host/audio_path_identity.c'; fixture_obj=compile(fixture,'fixture')
scenarios=['all','solo-mute','mix-sweeps','preset-fade',*[f'djf{m}-{s}' for m in (1,2,3) for s in ('static','sweep')],'limiter-off','comp','usb-full','usb-normal','dense','idle','mono']
wav_path=out/'input.wav'
with wave.open(str(wav_path),'wb') as wav:
 wav.setparams((1,2,22050,0,'NONE',''));wav.writeframes(b''.join(struct.pack('<h',int(10000*math.sin(2*math.pi*173*i/22050))) for i in range(44100)))
rows={}
for label,src in [('stock',base),('a',candidate)]:
 (out/label).mkdir(exist_ok=True)
 eng=compile(src,label+'-engine')
 exe=out/('identity-'+label)
 cmd(['cc',str(eng),str(fixture_obj),*[str(o) for o in objects],'-lm','-o',str(exe)])
 for sc in scenarios:
  dest=out/label/sc;dest.mkdir(exist_ok=True)
  cmd([str(exe),sc,str(dest),str(wav_path)],stdout=sp.DEVNULL)
  for path in sorted(dest.iterdir()):rows.setdefault(sc+'/'+path.name,{})[label]={'bytes':path.stat().st_size,'sha256':digest(path)}
bad=[k for k,v in rows.items() if v['stock']!=v['a']]
receipt=dict(scenes=scenarios,payloads=len(rows),fixture_sha256=digest(fixture),input_wav_sha256=digest(wav_path),closure_sha256=digest(closure/'build.json'),stock_engine_sha256=digest(base),candidate_engine_sha256=digest(candidate),candidate_src_git_blob=hashgit(candidate),patch_sha256=digest(patch),different=bad,rows=rows)
(out/'result.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(len(scenarios),len(rows),len(bad),bad,flush=True)
