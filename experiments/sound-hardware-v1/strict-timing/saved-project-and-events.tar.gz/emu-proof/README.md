# Strict 360 MHz audio sweep

The stock pair comes from DnBOX commit `fcf82f607cd35a263c9923071aaa25066ff6d60f`. Both production model packages receive the same 922 physical-control and MIDI events. The six trials add 0, 1, 2, 3, 4 or 5 ms uniformly to every timestamp. The first unshifted event is at 2,220 ms, the last at 7,944 ms. Each measurement covers the full 8,000 ms on the dual-core emulator, with the default LCD and USB services. No physical controller was flashed.

A passing row needs at least 648 completed halves, a maximum firmware block time of 10,909 µs or less, a raw late count of zero and zero extra lates after the warmed boot. The oscillator, filter and effects kinds used by the heavy scene are selected through the actual application. The stock image contains no optional BREAK sample pack. The separately recorded fixed-input host scene loads a generated sample when exercising that engine.

## Repeat a model

Provide the pinned `fm1-live` executable and model ELF/package pairs as `elite.elf`, `elite.fwsc`, `pro.elf` and `pro.fwsc` in an input folder. The scripts require Python 3, GNU nm and a fresh output directory. Each model receives a separate cold formatting run followed by its own two-second warmed boot. The prepared flash includes the model's package code. The later heavy shots each start from a fresh copy of that model's prepared flash.

```sh
bash scripts/qualify-one.sh /path/to/fm1-live /path/to/images /tmp/fm1-stock elite 0 1 2 3 4 5
bash scripts/qualify-one.sh /path/to/fm1-live /path/to/images /tmp/fm1-stock pro 0 1 2 3 4 5
python3 scripts/report.py /tmp/fm1-stock /tmp/fm1-results
```

The capture reads 13 little-endian words from the tested image's `x0x_dbg` ELF symbol. The capture validates the native magic. The report validates the run settings, scene SHA and PCM SHA, then records exact block counts and both late measures. The primary measurements use the native guest timer. Local host contention changes the recorded wall duration. The two independent unshifted Elite runs agreed on the timing counters and final RAM. One added the passive trace and DAC capture. The isolated PC sampler changed the unshifted measured maximum by 11 µs and is used only for hotspot attribution.

`inputs/pins.json` records the local emulator binary SHA-256, base source revision, observer source hashes, input pair and scene hashes. The source revision includes host-side observer edits. The binary digest identifies the exact build used. `inputs/gen_heavy.py` reproduced the recorded `inputs/heavy.keys` byte for byte. The native import receipts identify the separately linked packages.

## Physical dispatch and fixed-input PCM

Root-A's unshifted DAC first differs at stereo frame 160,324. The separate 4.45-second observer runs record 20 early panel audition hits in each image. The ordered voice and value bytes match throughout. The K22 press at 4,055 ms dispatches the closed 909 hi-hat (kit 0, voice 7) in DMA IRQ 312 on stock and 313 on root-A. The time difference is 11.628 ms. DMA edge 314 first outputs a changed sample 68 frames after its beginning. This edge reads the same half address rendered at IRQ 312. The first DIN MIDI event occurs at 4,910 ms and the first PLAY press at 4,934 ms.

The fixed-input regular-engine comparison rendered the 17 existing audio-identity scenarios through each engine and compared 50 audio, routed and control output files. Every byte matched. Raw PCM from the physical panel scene differs when the changed execution cost moves a polled press across a block boundary. This evidence covers the traced onset and the listed fixed-input cases.

To reproduce the control observation, use the capture arguments from the corresponding stock or candidate recording and add `--trace --panel --ms 4450`. Run `python3 scripts/panel_dispatch.py STOCK_TRACE_DIR CANDIDATE_TRACE_DIR`. `scripts/compare.py` compares completed 8-second DAC recordings at the same model and offset. Fixed-input proof used `scripts/fixed_input_root_a.py QUALIFIED_STOCK_SOURCE HOST_BUILD_CLOSURE inputs/root-a.patch` with the object closure identified in `receipts/root-a-fixed-input.json`.

The published historical d4088e60 unshifted comparator reported 11,406 µs Elite, 11,410 µs Pro, 648 halves, one raw startup late and zero scene lates. Three repeats agreed on both models. Source: Gobbajogger/DnBOX pull request 869, issue comment 6846592540. The owner's earlier shifted Elite measurement was 11,440 µs. Historical reruns belong to the separate historical evidence.

## Native project and sequencer events

The full Elite stock and initial combined runs have matching ordered event values through transport start for all 56 observed entries. The passive captures reproduce their corresponding primary firmware debug counters and DAC SHA-256. Following transport for the same 134,656 rendered frames, stock produces 299 observed logical entries and combined produces 297. Of these, 296 match at the exact frame relative to transport. The 909 mid tom moves from frame 74,088 to 79,380, the 909 clap at 79,380 disappears, and the 808 kick at 95,256 disappears. The final project differs in five of 36,420 bytes. The two changed 909 step-mask bytes and the 808 pattern length (18 on stock, 19 on combined) account for those drum events. The other two bytes are sound controls. The unchanged firmware itself acquires different final project bytes at different phase shifts.

`scripts/compare_project.py` reads the actual firmware project from ELF-verified RAM dumps. The complete project includes 32 patterns, five instrument tracks, settings, saved sound, song and motion arrangement. `scripts/project_layout.c` derives the section offsets from the production headers. Its total size matches the symbol size in each native ELF. `scripts/stock_variation.py` checks the same changed offsets across the unchanged stock sweep. The stock Elite sweep always stores byte 127 at project offset 2,777, while combined unshifted stores 191. This is the 909 mid-tom change.

Pass `--trace --behavior` to the capture for both firmware builds to observe drum triggers, bass sequence note and accent/slide flags, live bass key, control queue and transport. `scripts/compare_live_events.py STOCK_TRACE CANDIDATE_TRACE STOCK_PRIMARY CANDIDATE_PRIMARY` reconstructs exact musical frames. Every `render_sub` writes the segment length in `eng_job_arg`, and `seq_advance` dispatches events after that segment. The script rechecks the accumulated frame count against every completed native `eng_prof_frames` snapshot. It also requires matching primary debug counters and DAC hashes before comparing traces. The two traces therefore locate changes in events received by DSP separately from its fixed-input numerical behavior.

For the standard hit store, the linear voice index is `kit * 11 + voice`. Drum indices 0–10 are 909 voices and 11–21 are 808 voices. Frames start with the first generated engine segment. The 909 timeline shows all three toms at age 5,264 samples at the critical callback entry on both images, then all retriggering at offset 28 of the same 28 + 228 + 256 segment pattern.

## A genuine saved project on both packages

The supplemental Elite run replayed the full unshifted stock recipe, pressed SEQ PLAY to stop at 8,020 ms and BT/SAVE at 8,350 ms. The production save issued 36 flash erase/program operations. In the 1 MiB flash image, 4,855 bytes changed and all changes fell inside the documented store partition, [0x9d000,0xb0000). Each firmware's disposable test flash contains its own code plus that exact saved partition. A fresh two-second boot of each package loaded all 36,420 project bytes exactly as present in stock RAM after SAVE. The project also matched after playback.

A single physical PLAY at 2,300 ms, released at 2,400 ms, started playback in each 5,500 ms supplemental trial. The stock and exact-occupied parity builds emitted all 276 observed logical events at the same transport-relative frames over the 123,392 common rendered frames. Stock's maximum was 12,923 µs with 34 raw lates and parity's was 12,579 µs with six raw lates. Those results apply to this saved-project playback. Its load and duration differ from the original 8,000 ms timing recipe.

The earliest difference in the continuous transport-aligned DAC recording occurred at frame 1,536. The runs deliver different numbers of DMA underruns. For a direct numerical check, `scripts/eligible_pcm.py` selects shared 512-frame segments aligned to the same musical frame, with the producing callback completing before the next DMA edge on both packages. For each, it reads the produced half when the DAC next consumes the same address. All 207 common on-time segments were byte-identical across 105,984 stereo frames. The comparison includes every pair that satisfied its mapping checks.

To repeat the supplemental fixture, use the same model-specific prepared fresh flash as for the original sweep. Run `scripts/capture.py` with `--supplemental --scene inputs/stock-save.keys --ms 9200` on stock. Use `scripts/save_fixture.py STOCK_FRESH_FLASH STOCK_SAVED_FLASH OWN_FRESH_FLASH OUTPUT` for each build, then use each respective output as its `--seed`. Run a 2,000 ms warmed boot and a 5,500 ms `--trace --behavior` playback, always using `--supplemental --scene inputs/play-only.keys`. The report scripts use the directory names `stock-save`, `stock-boot`, `parity-boot`, `stock-play` and `parity-play`. The full per-trial commands, fixture SHA-256 and native-state receipts are under `receipts`.
