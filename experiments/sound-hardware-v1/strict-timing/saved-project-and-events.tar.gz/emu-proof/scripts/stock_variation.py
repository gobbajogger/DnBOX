#!/usr/bin/env python3
"""Compare end-of-trial native project data with the same model's unshifted stock image."""
import argparse
import json
from pathlib import Path
from compare_project import read_region, sha

p=argparse.ArgumentParser(description=__doc__)
p.add_argument("runs",type=Path)
p.add_argument("images",type=Path)
p.add_argument("candidate",type=Path)
p.add_argument("candidate_elf",type=Path)
args=p.parse_args()
can=read_region(args.candidate,args.candidate_elf,"proj")
results={}
for model in ("elite","pro"):
    elf=args.images/(model+".elf")
    trials=sorted((args.runs/("baseline-"+model)).glob("shift*"))
    reference=next(t for t in trials if t.name.startswith("shift0"))
    stock=read_region(reference,elf,"proj")
    fields=[i for i,(a,b) in enumerate(zip(stock,can)) if a!=b]
    results[model]={"offsets_different_from_combined_elite":fields,"trials":[],"observed_stock_values":{}}
    seen={i:set() for i in fields}
    for t in trials:
        config=json.loads((t/"result.json").read_bytes());v=read_region(t,elf,"proj")
        assert len(v)==len(stock)==len(can)==36420
        changed=[i for i,(a,b) in enumerate(zip(stock,v)) if a!=b]
        vals={i:v[i] for i in fields}
        for i in fields:seen[i].add(v[i])
        results[model]["trials"].append({"shift_ms":config["shift_ms"],"project_sha256":sha(v),
            "bytes_different_from_model_unshifted":len(changed),"changed_offsets":changed,
            "stock_values_at_compared_offsets":vals})
    results[model]["observed_stock_values"]={i:{"stock":sorted(seen[i]),"combined_elite":can[i],
        "combined_value_observed_on_stock":can[i] in seen[i]} for i in fields}
print(json.dumps(results,indent=2))
