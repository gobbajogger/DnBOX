#!/usr/bin/env python3
"""Freeze strict timing and DAC evidence using each tested firmware's RAM counters."""
import argparse
import array
import csv
import gzip
import hashlib
import json
import sys
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def shot_path(root, variant, model, offset):
    group = "baseline-" + model if variant == "stock" else variant + "/" + model
    shot = root / group / ("shift" + str(offset))
    if variant == "stock" and model == "elite" and offset == 0 and not shot.exists():
        shot = root / group / "shift0-trace"
    return shot


def receipt(shot, out, label):
    result = read_json(shot / "result.json")
    command = read_json(shot / "command.json")
    for field in ("model", "shift_ms", "emulator_sha256", "elf_sha256", "fwsc_sha256", "scene_sha256"):
        assert command[field] == result[field], field
    assert result["env"]["FM1_STRICT"] == "1"
    assert result["command"][result["command"].index("--mhz") + 1] == "360"
    assert result["shot_ms"] == 8000
    assert result["scene_events"] == 922
    assert digest(shot / "scene.keys") == result["scene_sha256"]
    pcm_file = shot / "stereo.s16le"
    assert digest(pcm_file) == result["pcm_sha256"]
    assert pcm_file.stat().st_size == result["pcm_bytes"]
    samples = array.array("h")
    samples.frombytes(pcm_file.read_bytes())
    if sys.byteorder != "little":
        samples.byteswap()
    dbg = result["debug"]
    raw_late = dbg["late"]
    late_after_boot = raw_late - result["boot_late"]
    assert result["late_during_test"] == late_after_boot
    us = dbg["max_us"]
    timing = us <= 10909 and raw_late == late_after_boot == 0 and dbg["halves"] >= 648
    files = {}
    for filename in ("ram.bin","core.csv","run.log","scene.keys","result.json","command.json","observer.map","stereo.s16le"):
        source = shot / filename
        if source.is_file():
            files[filename] = digest(source)
    out.mkdir(parents=True, exist_ok=True)
    write_json(out / (label+"-result.json"), result)
    write_json(out / (label+"-command.json"), command)
    for filename in ("core.csv","halves.csv"):
        source = shot / filename
        if source.is_file():
            (out / (label+"-"+filename+".gz")).write_bytes(gzip.compress(source.read_bytes(), mtime=0))
    return {
        "model": result["model"], "shift_ms": result["shift_ms"], "halves": dbg["halves"],
        "max_us": us, "headroom_to_11609_us": 11609 - us, "above_10909_us": max(0, us-10909),
        "raw_late": raw_late, "boot_late": result["boot_late"], "scene_late": late_after_boot,
        "audio_xruns": result["audio_xruns"], "strict_pass": timing,
        "eng_prof_frames": result["eng_prof_frames"], "raw_guest_prof": result["eng_prof"],
        "dac_stereo_frames": len(samples)//2, "peak_s16": max(map(abs,samples)),
        "rms_s16": (sum(s*s for s in samples)/len(samples))**0.5,
        "model_elf_sha256": result["elf_sha256"], "model_fwsc_sha256": result["fwsc_sha256"],
        "runner_sha256": result["emulator_sha256"], "initial_flash_sha256": result["initial_flash_sha256"],
        "final_flash_sha256": result["final_flash_sha256"], "raw_file_sha256": files,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_root", type=Path, help="Parent of baseline-elite/ and baseline-pro/ directories")
    parser.add_argument("out", type=Path)
    parser.add_argument("--variant", default="stock", help="stock, or a directory with model/shiftN children")
    args = parser.parse_args()
    rows = []
    missing = []
    for model in ("elite", "pro"):
        for offset in range(6):
            shot = shot_path(args.run_root, args.variant, model, offset)
            if not (shot / "result.json").is_file():
                missing.append({"model": model, "shift_ms": offset})
                continue
            row = receipt(shot, args.out / "runs", f"{args.variant}-{model}-{offset}ms")
            assert row["model"] == model and row["shift_ms"] == offset
            rows.append(row)
    out = {
        "variant": args.variant, "acceptance": {
            "model": ["elite","pro"], "uniform_scene_shift_ms": list(range(6)),
            "clock_mhz": 360, "fm1_strict": 1, "shot_ms": 8000, "minimum_halves": 648,
            "budget_us": 11609, "target_us": 10909, "raw_late": 0, "scene_late": 0,
        }, "complete": not missing, "missing": missing,
        "strict_pass": not missing and all(r["strict_pass"] for r in rows),
        "worst_observed_us": max((r["max_us"] for r in rows), default=None), "rows": rows,
    }
    args.out.mkdir(parents=True, exist_ok=True)
    write_json(args.out / (args.variant+"-sweep.json"), out)


if __name__ == "__main__":
    main()
