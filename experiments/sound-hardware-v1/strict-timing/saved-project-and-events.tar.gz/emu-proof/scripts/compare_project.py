#!/usr/bin/env python3
"""Read two native project objects from completed, same-scene firmware RAM dumps."""
import argparse
import hashlib
import json
import struct
import subprocess
from pathlib import Path


def read_region(run, elf, name):
    symbols = subprocess.check_output(["nm", "-S", str(elf)], text=True, stderr=subprocess.DEVNULL)
    row = next(line.split() for line in symbols.splitlines() if line.split()[-1] == name)
    address, size = (int(row[i], 16) for i in (0,1))
    ram = (run / "ram.bin").read_bytes()
    start = address - 0x01c00000
    assert 0 <= start <= len(ram)-size
    return ram[start:start+size]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def compare(section, start, a, b):
    different = [i for i,(x,y) in enumerate(zip(a,b)) if x!=y]
    return {"section":section, "project_offset":start, "bytes":len(a), "stock_sha256":sha(a),
            "candidate_sha256":sha(b), "different_bytes":len(different),
            "first_64_differences":[{"offset_in_section":i, "stock":a[i], "candidate":b[i]} for i in different[:64]]}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("stock",type=Path)
    p.add_argument("stock_elf",type=Path)
    p.add_argument("candidate",type=Path)
    p.add_argument("candidate_elf",type=Path)
    a=p.parse_args()
    commands = [json.loads((run/"command.json").read_bytes()) for run in (a.stock,a.candidate)]
    for k in ("shot_ms","model","scene_sha256","emulator_sha256","shift_ms"):
        assert commands[0][k]==commands[1][k],k
    for elf,command in zip((a.stock_elf,a.candidate_elf),commands):
        assert sha(elf.read_bytes())==command["elf_sha256"]
    x=read_region(a.stock,a.stock_elf,"proj")
    y=read_region(a.candidate,a.candidate_elf,"proj")
    layout=json.loads((Path(__file__).resolve().parents[1]/"inputs/project-layout.json").read_bytes())
    assert len(x)==len(y)==layout["bytes"]
    assert struct.unpack_from("<I",x)[0]==struct.unpack_from("<I",y)[0]==0x50305830
    bounds=[("settings",layout["settings"]),("sound",layout["sound"])]
    fields=[("909",layout["drum_offset"]),("808",layout["drum_offset"]+layout["drum_size"]),
            ("bass_a",layout["bass_offset"]),("bass_b",layout["bass_offset"]+layout["bass_size"]),
            ("break",layout["break_offset"]),("swing_reserved",layout["swing_offset"])]
    for i in range(layout["pattern_count"]):
        start=layout["patterns"]+i*layout["pattern_size"]
        bounds.extend((f"pattern_{i}_{name}",start+off) for name,off in fields)
    bounds.extend([("arrangement",layout["arrangement"]),("end",layout["bytes"])])
    rows=[compare(name,lo,x[lo:hi],y[lo:hi]) for (name,lo),(_,hi) in zip(bounds,bounds[1:])]
    print(json.dumps({"model":commands[0]["model"],"shift_ms":commands[0]["shift_ms"],
          "stock_elf_sha256":commands[0]["elf_sha256"],"candidate_elf_sha256":commands[1]["elf_sha256"],
          "bytes":len(x),"stock_project_sha256":sha(x),"candidate_project_sha256":sha(y),
          "equal":x==y,"pattern_count":layout["pattern_count"],"section_count":len(rows),
          "different_bytes":sum(row["different_bytes"] for row in rows),
          "different_sections":[row for row in rows if row["different_bytes"]]},indent=2))


if __name__=="__main__":
    main()
