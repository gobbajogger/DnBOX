#!/usr/bin/env python3
"""Measure panel dispatch, then compare logical note events on the frame grid after PLAY."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse(directory):
    ticks_per_ms = 5760000
    rendered = 0
    transport = None
    events = []
    on = None
    last = None
    acc = [0,0]
    slide = [0,0]
    for line in (directory/"trace.jsonl").open():
        r = json.loads(line)
        if r["event"]=="half":
            assert rendered == r["snapshot"]["eng_prof_frames"][0]
            last = r
            continue
        if r["event"]=="irq_enter":
            on = r["snapshot"]["scene_original_seq_note"].copy()
            continue
        if r["event"]!="store":
            continue
        name=r["name"]
        if name=="eng_job_arg":
            rendered+=(r["value"]&255) or 256
            continue
        if not name.startswith("scene_"):
            continue
        offset, value = r["offset"], r["value"]
        kind, part = None, offset
        if name=="scene_transport" and offset==0 and value==1:
            assert transport is None
            transport={"frame":rendered,"dma_irq":r["seq"],"ticks":r["cycle"],"ms":r["cycle"]/ticks_per_ms}
        elif name=="scene_eng_hit":
            kind="drum"
        elif name=="scene_bass_held":
            kind="bass_live_key"
        elif name=="scene_bass_accent":
            acc[offset]=value
        elif name=="scene_bass_slide":
            slide[offset]=value
        elif name=="scene_original_seq_note":
            on[offset]=value
            if offset%2==1:
                part=offset//2
                value=int.from_bytes(bytes(on[offset-1:offset+1]),"little",signed=True)
                kind="bass_seq"
        if kind:
            item={"kind":kind,"part":part,"value":value,"render_frame":rendered,"dma_irq":r["seq"],"ticks":r["cycle"]}
            if kind=="bass_seq" and value>=0:
                item.update(accent=acc[part],slide=slide[part])
            events.append(item)
    assert transport and last
    result=json.loads((directory/"result.json").read_bytes())
    assert last["snapshot"]["x0x_dbg"][1]==result["debug"]["halves"]
    return dict(transport=transport,events=events,completed_rendered_frames=last["snapshot"]["eng_prof_frames"][0],
                result=result,trace_sha256=sha(directory/"trace.jsonl"))


def relative_after(run,limit):
    events=[]
    clock=run["transport"]
    for e in run["events"]:
        offset=e["render_frame"]-clock["frame"]
        if e["ticks"]<clock["ticks"] or offset>limit:continue
        events.append((offset,e["kind"],e["part"],e["value"],e.get("accent"),e.get("slide")))
    return events


def side(run,normal):
    r=run["result"]
    primary=json.loads((normal/"result.json").read_text())
    assert r["debug"]==primary["debug"]
    assert r["pcm_sha256"]==primary["pcm_sha256"]
    return {"transport":run["transport"],"completed_rendered_frames":run["completed_rendered_frames"],
            "halves":r["debug"]["halves"],"max_us":r["debug"]["max_us"],"raw_late":r["debug"]["late"],
            "fwsc_sha256":r["fwsc_sha256"],"pcm_sha256":r["pcm_sha256"],"trace_sha256":run["trace_sha256"],
            "trace_agrees_with_primary_debug_and_pcm":True}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ("stock","candidate","stock_primary","candidate_primary"):p.add_argument(name,type=Path)
    a=p.parse_args()
    x,y=parse(a.stock),parse(a.candidate)
    common_frames=min(r["completed_rendered_frames"]-r["transport"]["frame"] for r in (x,y))
    post_x,post_y=(relative_after(r,common_frames) for r in (x,y))
    logical= lambda events:Counter(events)
    older,newer=logical(post_x),logical(post_y)
    misses=list((older-newer).elements()); extras=list((newer-older).elements())
    pre=lambda r:[e for e in r["events"] if e["ticks"]<r["transport"]["ticks"]]
    prx,pry=pre(x),pre(y)
    keys=lambda rows:[(e["kind"],e["part"],e["value"]) for e in rows]
    print(json.dumps({
        "stock":side(x,a.stock_primary),"candidate":side(y,a.candidate_primary),
        "common_post_play_frames":common_frames,"pre_play_stock":len(prx),"pre_play_candidate":len(pry),
        "pre_play_ordered_event_bytes_equal":keys(prx)==keys(pry),
        "pre_play_events_stock":prx,"pre_play_events_candidate":pry,
        "post_play_count_stock":len(post_x),"post_play_count_candidate":len(post_y),
        "post_play_ordered_rows_equal":post_x==post_y,
        "post_play_multiset_equal":older==newer,
        "post_play_shared_rows":sum((older&newer).values()),
        "post_play_columns":["frame_from_transport","kind","part_or_drum_linear_voice","value","accent","slide"],
        "stock_only_rows":misses,"candidate_only_rows":extras,
        "post_play_rows_stock":post_x,"post_play_rows_candidate":post_y
    },indent=2))


if __name__=="__main__":
    main()
