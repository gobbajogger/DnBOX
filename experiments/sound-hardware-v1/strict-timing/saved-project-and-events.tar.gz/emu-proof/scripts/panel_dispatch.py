#!/usr/bin/env python3
"""Join bounded FM1 observer hit stores to DAC PCM and the physical stimulus."""
import argparse
import array
import hashlib
import json
import sys
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def extract(directory):
    hits = []
    dma = {}
    trace = directory / "trace.jsonl"
    for line in trace.open():
        row = json.loads(line)
        if row["event"] == "store" and row["name"] == "scene_eng_hit":
            hits.append({k: row[k] for k in ("seq", "cycle", "offset", "width", "value")})
        if row["event"] == "dma":
            dma[row["seq"]] = {k: row[k] for k in ("half", "address", "scheduled_cycle")}
    pcm_file = directory / "stereo.s16le"
    pcm = array.array("h")
    pcm.frombytes(pcm_file.read_bytes())
    if sys.byteorder != "little":
        pcm.byteswap()
    cmd = json.loads((directory / "command.json").read_bytes())
    return hits, dma, pcm, {
        "firmware_sha256": cmd["fwsc_sha256"],
        "elf_sha256": cmd["elf_sha256"],
        "runner_sha256": cmd["emulator_sha256"],
        "keys_sha256": cmd["scene_sha256"],
        "observer_map_sha256": sha(directory / "observer.map"),
        "trace_sha256": sha(trace),
        "pcm_sha256": sha(pcm_file),
        "stereo_frames": len(pcm) // 2,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stock", type=Path)
    parser.add_argument("candidate", type=Path)
    args = parser.parse_args()
    a_hits, a_dma, a_pcm, stock = extract(args.stock)
    b_hits, b_dma, b_pcm, candidate = extract(args.candidate)
    assert stock["runner_sha256"] == candidate["runner_sha256"]
    assert stock["keys_sha256"] == candidate["keys_sha256"]
    first = next(i for i, (a, b) in enumerate(zip(a_pcm, b_pcm)) if a != b)
    frame = first // 2
    edge = frame // 512 + 1
    assert len(a_hits) == len(b_hits)
    matches = []
    for a, b in zip(a_hits, b_hits):
        assert (a["offset"], a["width"], a["value"]) == (b["offset"], b["width"], b["value"])
        row = {"voice_offset": a["offset"], "stored_value": a["value"], "stock_irq": a["seq"],
               "candidate_irq": b["seq"], "stock_ticks": a["cycle"], "candidate_ticks": b["cycle"]}
        if a["seq"] != b["seq"]:
            row.update(stock_ms=a["cycle"] / 5760000, candidate_ms=b["cycle"] / 5760000)
        matches.append(row)
    print(json.dumps({
        "scene_shot_ms": 4450, "ticks_per_ms": 5760000, "model": "elite",
        "stock": stock, "candidate": candidate, "ordered_hits": matches,
        "moved_hits": [r for r in matches if r["stock_irq"] != r["candidate_irq"]],
        "first_different_frame": frame, "dma_edge": edge, "offset_in_half_frames": frame % 512,
        "stock_dma_near_difference": {seq: a_dma[seq] for seq in range(edge-2,edge+2)},
        "candidate_dma_near_difference": {seq: b_dma[seq] for seq in range(edge-2,edge+2)},
        "scope": "Fixed physical-key timestamps. Before first DIN MIDI (4910 ms) or PLAY (4934 ms)."
    }, indent=2))


if __name__ == "__main__":
    main()
