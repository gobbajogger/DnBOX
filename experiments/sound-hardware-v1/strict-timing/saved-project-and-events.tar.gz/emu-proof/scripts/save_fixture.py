#!/usr/bin/env python3
"""Copy the native project store from a physical stock SAVE into disposable emulator fixtures."""
import argparse
import hashlib
import json
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
p.add_argument("donor_before",type=Path)
p.add_argument("donor_after",type=Path)
p.add_argument("own_model_seed",type=Path)
p.add_argument("output",type=Path)
a=p.parse_args()
lo=0x9d000
hi=0xb0000
before=a.donor_before.read_bytes()
donor=a.donor_after.read_bytes()
target=a.own_model_seed.read_bytes()
assert len(target)==len(before)==len(donor)==1048576
assert before[:lo]==donor[:lo] and before[hi:]==donor[hi:]
assert before[lo:hi]!=donor[lo:hi]
fixture=target[:lo]+donor[lo:hi]+target[hi:]
with a.output.open("xb") as f:f.write(fixture)
sha=lambda d:hashlib.sha256(d).hexdigest()
print(json.dumps({"protected_prefix_sha256":sha(fixture[:lo]),"project_store_sha256":sha(fixture[lo:hi]),
    "own_model_seed_sha256":sha(target),"donor_before_sha256":sha(before),"donor_after_sha256":sha(donor),
    "fixture_sha256":sha(fixture),"modified_only_documented_project_store":True},indent=2))
