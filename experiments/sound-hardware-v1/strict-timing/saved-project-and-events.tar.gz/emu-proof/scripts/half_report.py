#!/usr/bin/env python3
import csv,json,sys,collections
from pathlib import Path
p=Path(sys.argv[1])
rows=[]; prev=[0]*8;aborted=0;completed=0
with p.open() as f:
    for line in f:
        if not line.startswith('{"event":"half"') and not line.startswith('{"event":"finish"'):continue
        try:v=json.loads(line)
        except json.JSONDecodeError:continue
        if v['event']=='finish': completed=v['completed']; continue
        s=v['snapshot'];db=s['x0x_dbg']; prof=[(a-b)%2**32 for a,b in zip(s['eng_prof'],prev)];prev=s['eng_prof']
        rows.append(dict(half=db[1],dma_seq=v['seq'],start_ms=v['entry_cycle']/5760000,end_ms=v['completion_cycle']/5760000,us=v['last_us'],raw_late=db[5],eng_c1_mask=s['eng_c1_mask'][0],plan=s['eng_plan'][0],split_n=(s['eng_job_arg'][0]&255),break_nonzero=v['break_mix']['nonzero_writes'],prof=prof,job_cost=s['eng_job_cost']))
if len(sys.argv)>2:
 with Path(sys.argv[2]).open('w') as f:
    cols=list(rows[0]);w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(rows)
print(json.dumps(dict(halves=len(rows),observer_finished=completed,latest_ms=rows[-1]['end_ms'],nonzero_break_halves=sum(r['break_nonzero']>0 for r in rows),top=sorted(rows,key=lambda r:-r['us'])[:3]), indent=2))
