/* SPDX-License-Identifier: GPL-3.0-only */
#define main simulator_main
#include "host/x0x_host.c"
#undef main
#include <assert.h>

/* The physical note-contact transitions are identical. The second trial takes
 * one additional foreground snapshot while the SMK matrix scan is unfinished. */
int main(int argc, char **argv)
{
    assert(argc == 2);
    int intermediate = strcmp(argv[1], "split") == 0;
    uint32_t all = 0;
    for (int white = 0; white < 16; ++white)
        all |= 1u << WHITE_KEY[white];
    boot();
    ui.view = V_SEQ;
    ui.part = PART_909;
    ui.sel[PART_909] = 3;
    dpart_t *drum = &proj.pat[seq.ppat[PART_909]].drum[PART_909];
    drum->hit[3][0] = 0xffff;
    drum->hit[3][1] = 0;
    ui_input_only();
    now_ms = 2000;
    held_keys = all & ~(1u << WHITE_KEY[14]);
    if (intermediate)
        ui_input_only();
    now_ms = 2001;
    held_keys = all;
    ui_input_only();
    int owned = ui.hold_step;
    now_ms = 2040;
    held_keys = 0;
    ui_input_only();
    printf("{\"split_snapshot\":%d,\"last_held_step_1based\":%d,\"before\":65535,\"after\":%u}\n",
           intermediate, owned+1, drum->hit[3][0]);
    assert(drum->hit[3][0] == (0xffffu ^ (1u << (intermediate ? 14 : 15))));
    return 0;
}
