#!/usr/bin/env python3
"""Compare an authorized candidate against the same-model, same-offset authentic half capture."""
import argparse,array,json,hashlib,sys
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('baseline',type=Path)
p.add_argument('candidate',type=Path)
args=p.parse_args()
def get(run):return json.loads((run/'result.json').read_bytes())
ref,can=map(get,(args.baseline,args.candidate))
for k in ('model','shot_ms','shift_ms','scene_sha256','scene_events','emulator_sha256'):assert ref[k]==can[k],k
assert ref['debug']['halves']==can['debug']['halves']==648

a,b=((d/'stereo.s16le').read_bytes() for d in (args.baseline,args.candidate))
assert len(a)==len(b)==ref['pcm_bytes']==can['pcm_bytes']
def words(x):
 w=array.array('h');w.frombytes(x)
 if sys.byteorder!='little':w.byteswap()
 return w
x,y=words(a),words(b)
first=next((i for i,(l,r) in enumerate(zip(x,y)) if l!=r),None)
print(json.dumps(dict(model=can['model'],shift_ms=can['shift_ms'],baseline_fwsc_sha256=ref['fwsc_sha256'],candidate_fwsc_sha256=can['fwsc_sha256'],baseline_us=ref['debug']['max_us'],candidate_us=can['debug']['max_us'],delta_us=can['debug']['max_us']-ref['debug']['max_us'],baseline_raw_late=ref['debug']['late'],candidate_raw_late=can['debug']['late'],baseline_scene_late=ref['late_during_test'],candidate_scene_late=can['late_during_test'],pcm_identical=(a==b),first_different_stereo_frame=None if first is None else first//2,different_channel_words=sum(l!=r for l,r in zip(x,y)),peak_abs_delta_s16=max(abs(l-r) for l,r in zip(x,y)),baseline_peak=max(map(abs,x)),candidate_peak=max(map(abs,y))),indent=2))
