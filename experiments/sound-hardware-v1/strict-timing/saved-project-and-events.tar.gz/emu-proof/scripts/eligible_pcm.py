#!/usr/bin/env python3
"""Compare same played high-level frame on halves completed before the next DMA edge."""
from array import array
import argparse
import hashlib
import json
from pathlib import Path
import sys


def chunks(root):
    dsp={}
    event={}
    transport=None
    done=0
    for line in (root/"trace.jsonl").open():
        r=json.loads(line)
        tag=r["event"]
        if tag=="dma":
            event[r["seq"]]=r
        elif tag=="store":
            if r["name"]=="eng_job_arg":done+=(r["value"]&255) or 256
            if r["name"]=="scene_transport" and r["offset"]==0 and r["value"]==1:transport=done
        elif tag=="half":
            dma=r["seq"]
            assert done==r["snapshot"]["eng_prof_frames"][0]
            if transport is not None and done-512>=transport and r["dma_seq_at_completion"]==dma:
                dsp[done-transport-512]=(dma,r["completion_cycle"])
    source=(root/"stereo.s16le").read_bytes()
    output={}
    for frame,(edge,tick) in dsp.items():
        next_edge=edge+2
        if not all(s in event for s in (edge,edge+1,next_edge)):continue
        assert event[edge]["address"]==event[next_edge]["address"]
        assert event[edge]["address"]!=event[edge+1]["address"]
        assert tick<=event[edge+1]["observed_cycle"]
        start=(next_edge-1)*2048
        value=source[start:start+2048]
        assert len(value)==2048
        output[frame]=value
    return output


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("stock",type=Path);p.add_argument("candidate",type=Path)
    a=p.parse_args();x,y=chunks(a.stock),chunks(a.candidate)
    selected=sorted(x.keys()&y.keys())
    assert selected
    xb=b"".join(x[k] for k in selected);yb=b"".join(y[k] for k in selected)
    xa,ya=array("h"),array("h");xa.frombytes(xb);ya.frombytes(yb)
    if sys.byteorder!="little":xa.byteswap();ya.byteswap()
    i=next((j for j,(l,r) in enumerate(zip(xa,ya)) if l!=r),None)
    print(json.dumps({
        "criterion":"512 rendered frames start at the same transport-relative frame; each IRQ completes before the next DMA edge; same-address DAC consumption is at edge+2",
        "stock_eligible_blocks":len(x),"candidate_eligible_blocks":len(y),"compared_blocks":len(selected),
        "compared_frames":len(selected)*512,"stock_pcm_sha256":hashlib.sha256(xb).hexdigest(),
        "candidate_pcm_sha256":hashlib.sha256(yb).hexdigest(),"pcm_identical":xb==yb,
        "different_channel_words":sum(a!=b for a,b in zip(xa,ya)),"peak_absolute_delta_s16":max(abs(a-b) for a,b in zip(xa,ya)),
        "first_differing_transport_frame":None if i is None else selected[(i//2)//512]+(i//2)%512,
        "eligible_common_start_frames":selected},indent=2))


if __name__=="__main__":
    main()
