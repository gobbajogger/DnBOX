#!/usr/bin/env bash
set -eu
scripts=$(realpath "$(dirname "$0")")
runner=$(realpath "$1")
images=$(realpath "$2")
mkdir -p "$3"
dest=$(realpath "$3")
model=$4
shift 4
label=baseline-$model
run() { python3 "$scripts/capture.py" --runner "$runner" --image-dir "$images" --out "$dest" --model "$model" "$@"; }
run --name "$label/seed" --ms 2000 --cold
run --name "$label/boot" --ms 2000 --seed "$dest/$label/seed/flash.bin"
for offset in "$@"; do
  run --name "$label/shift$offset" --shift "$offset" --ms 8000 --seed "$dest/$label/seed/flash.bin" --boot "$dest/$label/boot/result.json"
done
