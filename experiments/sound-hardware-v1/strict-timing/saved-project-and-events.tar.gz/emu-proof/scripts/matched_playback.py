#!/usr/bin/env python3
"""Check genuine SAVE and boot-loaded project state, sequencer onsets and aligned DAC PCM."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import array
import sys
from compare_project import read_region
from compare_live_events import parse, relative_after


def sha(data):
    return hashlib.sha256(data).hexdigest()


def event_keys(data):
    return [(v["kind"],v["part"],v["value"]) for v in data["events"] if v["ticks"]<data["transport"]["ticks"]]


def audio_start(run,trace):
    tr=trace["transport"]
    at=None
    for line in (run/"trace.jsonl").open():
        obj=json.loads(line)
        if obj["event"]=="irq_enter" and obj["seq"]==tr["dma_irq"]:
            at=obj["snapshot"]["eng_prof_frames"][0];break
    assert at is not None
    # The buffer being consumed at event N is overwritten by that ISR for the next
    # same-address DMA read at N+2. Raw PCM starts at event 1.
    return (tr["dma_irq"]+1)*512+(tr["frame"]-at)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("root",type=Path)
    p.add_argument("stock_elf",type=Path)
    p.add_argument("candidate_elf",type=Path)
    a=p.parse_args()
    donor=read_region(a.root/"stock-save",a.stock_elf,"proj")
    traces=[]; streams=[]; receipts={}
    for name,elf in [("stock",a.stock_elf),("parity",a.candidate_elf)]:
        boot=a.root/(name+"-boot");run=a.root/(name+"-play")
        project0=read_region(boot,elf,"proj"); project1=read_region(run,elf,"proj")
        boot_res=json.loads((boot/"result.json").read_bytes());result=json.loads((run/"result.json").read_bytes())
        assert result["scene_sha256"]==boot_res["scene_sha256"] and result["scene_events"]==2 
        trace=parse(run);traces.append(trace)
        start=audio_start(run,trace)
        pcm=(run/"stereo.s16le").read_bytes()
        streams.append(pcm[4*start:])
        receipts[name]={"boot_project_sha256":sha(project0),"equals_donor_at_boot":donor==project0,
           "boot_donor_differences":[[i,x,y] for i,(x,y) in enumerate(zip(donor,project0)) if x!=y],
           "final_project_sha256":sha(project1),"equals_donor_after_playback":donor==project1,
           "final_project_differences":[[i,x,y] for i,(x,y) in enumerate(zip(donor,project1)) if x!=y],
           "fwsc_sha256":result["fwsc_sha256"],"elf_sha256":result["elf_sha256"],
           "trace_sha256":trace["trace_sha256"],"raw_pcm_sha256":sha(pcm),
           "transport":trace["transport"],"transport_dac_frame":start,"max_us":result["debug"]["max_us"],
           "raw_late":result["debug"]["late"],"scene_late":result["late_during_test"]}
    x,y=traces
    window=min(run["completed_rendered_frames"]-run["transport"]["frame"] for run in traces)
    rx,ry=(relative_after(run,window) for run in traces)
    ax,ay=streams
    frames=min(len(ax)//4,len(ay)//4,window)
    ax,ay=ax[:4*frames],ay[:4*frames]
    sx,sy=array.array("h"),array.array("h");sx.frombytes(ax);sy.frombytes(ay)
    if sys.byteorder!="little":sx.byteswap();sy.byteswap()
    first=next((i//2 for i,(a,b) in enumerate(zip(sx,sy)) if a!=b),None)
    report={"donor_project_bytes":len(donor),"donor_project_sha256":sha(donor),"images":receipts,
            "button_events":["2300:SEQ PLAY","2400:SEQ PLAY^"],"preplaying_keys":[event_keys(r) for r in traces],
            "common_post_transport_frames":window,"logical_count":[len(rx),len(ry)],"ordered_events_equal":rx==ry,
            "stock_only_rows":list((Counter(rx)-Counter(ry)).elements()),"candidate_only_rows":list((Counter(ry)-Counter(rx)).elements()),
            "aligned_dac_frames":frames,"aligned_stock_sha256":sha(ax),"aligned_candidate_sha256":sha(ay),
            "dac_exact":ax==ay,"first_different_stereo_frame_from_transport":first,
            "different_channel_words":sum(a!=b for a,b in zip(sx,sy)),
            "peak_absolute_delta_s16":max(abs(a-b) for a,b in zip(sx,sy))}
    print(json.dumps(report,indent=2))


if __name__=="__main__":
    main()
