#include <stddef.h>
#include <stdio.h>
#include "firmware/src/app/x0x.h"

int main(void)
{
    printf("{\"bytes\":%zu,\"settings\":%zu,\"sound\":%zu,\"patterns\":%zu,"
           "\"arrangement\":%zu,\"pattern_count\":%u,\"pattern_size\":%zu,"
           "\"drum_offset\":%zu,\"drum_size\":%zu,\"bass_offset\":%zu,\"bass_size\":%zu,"
           "\"break_offset\":%zu,\"break_size\":%zu,\"swing_offset\":%zu}\n",
        sizeof(project_t), offsetof(project_t, set), offsetof(project_t, sound),
        offsetof(project_t, pat), offsetof(project_t, arr), NPAT, sizeof(pattern_t),
        offsetof(pattern_t, drum), sizeof(dpart_t), offsetof(pattern_t, bass), sizeof(bpart_t),
        offsetof(pattern_t, brk), sizeof(brkpart_t), offsetof(pattern_t, swing));
    return 0;
}
