from pathlib import Path
import hashlib,json,sys
root=Path.cwd();sys.path.insert(0,str(root/'s1-work/emu-proof/scripts'));from compare_project import read_region
hs=lambda b:hashlib.sha256(b).hexdigest()
result=[]
for m in ['elite','pro']:
 standalone=root/f'sj6-work/edge-standalone/{m}-offset1';joint=root/f's1-work/emu360/placed-fusion/{m}/shift1'
 imgs=[root/f'sj6-work/edge-standalone/image/{m}.elf',root/f's1-work/placed/fusion-gate/images/{m}.elf']
 paths=[standalone,joint];settings=[json.loads((p/'result.json').read_text()) for p in paths]
 a,b=[(p/'stereo.s16le').read_bytes() for p in paths]
 x,y=[read_region(p,elf,'proj') for p,elf in zip(paths,imgs)]
 assert len(x)==len(y)==36420 and len(a)==len(b)
 ds=[i for i in range(0,len(a),4) if a[i:i+4]!=b[i:i+4]]
 g=[1+i//2048 for i in range(0,len(a),2048) if a[i:i+2048]!=b[i:i+2048]]
 result.append(dict(model=m,elf_sha256=[hs(z.read_bytes()) for z in imgs],scene=[z['scene_sha256'] for z in settings],stereo_sha256=[hs(z) for z in (a,b)],project_sha256=[hs(z) for z in (x,y)],different_project_bytes=sum(i!=j for i,j in zip(x,y)),physical_stereo_frames=len(a)//4,different_frames=len(ds),differing_halves=g,first_different_frame=ds[0]//4 if ds else None,peaks=[z['debug']['max_us'] for z in settings],raw_late=[z['debug']['late'] for z in settings]))
out=root/'sj6-work/admission-irq/clean-vs-hysteresis.json';out.write_text(json.dumps(result,indent=2)+'\n')
print([(r['model'],r['different_project_bytes'],r['different_frames'],r['first_different_frame'],len(r['differing_halves'])) for r in result])
