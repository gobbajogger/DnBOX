"""Use unchanged product images and the pinned runner's native USB and CPU fault devices."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os,json,sys,struct,shutil,subprocess,hashlib
r=Path('s1-work/emu360').resolve();sys.path.insert(0,str(r));from sweep import symbols,sha
out=Path('sj6-work/admission-irq').resolve()
images={'stock':(r/'input',r/'baseline-elite'/'shift1'), 'phase':(Path('sj6-work/phase-edge/image').resolve(),Path('sj6-work/phase-edge/elite-offset1').resolve())}
def run(test):
 name,mode=test;img,existing=images[name];directory=out/(name+'-'+mode+'-verified');directory.mkdir();(directory/'work').mkdir()
 seed=(r/'seed/fresh.flash') if name=='stock' else Path('sj6-work/phase-edge/elite-seed/flash.bin')
 shutil.copyfile(seed,directory/'flash.bin')
 sym=symbols(img/'elite.elf');p=directory/'ram.bin'
 env={k:v for k,v in os.environ.items() if not k.startswith('FM1_')}
 env.update(FM1_STRICT='1',FM1_BENCH_KEYS='@'+str(existing/'scene.keys'),FM1_DUMPRAM=str(p),FM1_DNBOX_PCM=str(directory/'dac.s16le'),FM1_CORE_LOAD=f"{sym['_c1_start'][0]:x}-{sym['_c1_end'][0]:x}",FM1_CORE_LOAD_CSV=str(directory/'core.csv'))
 args=[str(r/'bin/fm1-live'),'--fwsc',str(img/'elite.fwsc'),'--mhz','360','--shot','1600','--flash',str(directory/'flash.bin')]
 if mode=='usb':
  env.update(FM1_USB_WAV=str(directory/'capture.wav'),FM1_USB_RATE='44100');args+=['--usb']
 if mode=='worker-fault':args+=['--flaky-core1','1.0','--seed','1']
 with (directory/'run.log').open('w') as st:
  proc=subprocess.run(args,cwd=directory,env=env,stdout=st,stderr=subprocess.STDOUT,timeout=200)
 (directory/'process.json').write_text(json.dumps({'returncode':proc.returncode,'command':args},indent=2)+'\n')
 evidence={'mode':mode,'image':sha(img/'elite.fwsc'),'elf':sha(img/'elite.elf'),'warm_seed':sha(seed),'runner':sha(r/'bin/fm1-live'),'exit':proc.returncode}
 if p.exists():
  ram=p.read_bytes()
  fields=('magic','halves','max_us','nested','in_audio','late','timer_irqs','ui_frames','last_us','cpu_q8','boots','stage','crash_seen')
  def reg(n):
   a,z=sym[n];return ram[a-0x1c00000:a-0x1c00000+z]
  evidence['debug']=dict(zip(fields,struct.unpack('<13I',reg('x0x_dbg'))))
  evidence['scalars']={n:int.from_bytes(reg(n),'little') for n in ('fm1_c1_on','fm1_c1_gave_up','fm1_c1_was_on','audio_xruns','eng_prof_frames','audio_boot_phase') if n in sym}
  evidence['mailbox']=list(struct.unpack('<'+'I'*(len(reg('fm1_c1_mb'))//4),reg('fm1_c1_mb'))) if 'fm1_c1_mb' in sym else None
  if (directory/'dac.s16le').exists():
   aud=(directory/'dac.s16le').read_bytes();evidence['physical_frames']=len(aud)//4;evidence['physical_nonzero_channels']=sum(v[0]!=0 for v in struct.iter_unpack('<h',aud));evidence['pcm_sha256']=sha(directory/'dac.s16le')
  if (directory/'capture.wav').exists():
   raw=(directory/'capture.wav').read_bytes()
   assert len(raw)%4==0
   evidence['usb_capture']={'frames':len(raw)//4,'rate':44100,'channels':2,'format':'signed 16-bit little-endian interleaved stereo','pcm_sha256':hashlib.sha256(raw).hexdigest(),'nonzero_bytes':sum(v!=0 for v in raw)}
 evidence['io_log']=[l for l in (directory/'run.log').read_text().splitlines() if any(t in l.lower() for t in ('usb','flaky','misread','halt','exception','core 1','fault','error'))][-35:]
 (directory/'receipt.json').write_text(json.dumps(evidence,indent=2)+'\n')
 print(name,mode,evidence.get('debug'),evidence.get('scalars'),evidence.get('usb_capture'),flush=True)
with ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(run,[(i,m) for m in ['usb','worker-fault'] for i in images]))
