# Retained sequencer cost, sparse Chicago and first-block audio handoff

Apply candidate.patch to ca0c00a4e5863132de4a66f5d1c477c14d699be5 in a separate checkout. It combines the quantized per-owner note-release cost in existing owner storage, the one-moving-oscillator Chicago path with a shared general mixer, and audio-owned first-block staging. The stock loader is unchanged. Original platform-based safeguards, the normal sequencer and all four Chicago oscillator phases remain active. Run the ordinary Elite and Pro builds with the pinned toolchain. The adjacent startup, note-cost and Chicago packets contain separate control and fault-injection experiments.

The two native application images and complete firmware packages retain stock byte counts, and both loader files match stock byte for byte. receipts.json compares whole-project RAM and physical DAC at each completed 8,000 ms shot, using the stock physical inputs at that same offset. The scene uses 922 timed events. A raw late includes boot. Peak is the native RAM counter x0x_dbg.max_us. No emulator cycles were skipped. The stock flash here is an unmodified emulator fixture.

Use the normal capture.py and sweep.py in the strict-timing stock packet, with each model's own calibrated 2,000 ms flash seed and warm boot control. Runs left out of this receipt had not completed at its capture point.
