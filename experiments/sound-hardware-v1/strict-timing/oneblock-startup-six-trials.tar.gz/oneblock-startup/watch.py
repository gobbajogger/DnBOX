"""Observe writes to all 4,096 bytes of one startup DMA buffer or the staging block."""
import argparse
from pathlib import Path
import sys
parser=argparse.ArgumentParser(add_help=False)
parser.add_argument('--capture-root',type=Path,required=True)
parser.add_argument('--region',choices=('stage','dma0','dma1'),required=True)
opts,args=parser.parse_known_args()
capture=opts.capture_root.resolve()/'capture.py'
source=capture.read_text()
needle='    env.update(FM1_DNBOX_MAP='
assert source.count(needle)==1
s_offset={'stage':"s['cv_storage'][0]",'dma0':"s['abuf'][0]",'dma1':"s['abuf'][0] + 4096"}[opts.region]
append=f"""    base={s_offset}
    assert s['abuf'][1] == 8192 and s['cv_storage'][1] >= 4096
    with (dest/'observer.map').open('a') as fd:
        for start in range(0,4096,512):
            print(f"scene_audio_{{start}} {{base+start:x}} 512", file=fd)
"""
source=source.replace(needle,append+needle)
sys.path.insert(0,str(capture.parent))
sys.argv=[str(capture),*args]
exec(compile(source,str(capture),'exec'),{'__name__':'__main__','__file__':str(capture)})
