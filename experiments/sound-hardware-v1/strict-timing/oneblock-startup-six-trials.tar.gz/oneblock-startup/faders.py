"""Compare complete physical ADC, fader pickup and saved 909/808 level trajectories."""
import argparse, csv, gzip, hashlib, io, json, struct
from pathlib import Path
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('stock',type=Path);parser.add_argument('candidate',type=Path);parser.add_argument('dest',type=Path)
args=parser.parse_args();args.dest.mkdir(exist_ok=True)
def extract(folder,board):
    trace=folder/'trace.jsonl';out=[];changes=[];old=None; hist=None;switches=[]; prev_end=0
    for line in trace.open():
        if '"event":"half"' in line:
            raw=json.loads(line);prev_end=raw['completion_cycle']/5760000; continue
        if '"event":"irq_enter"' not in line:continue
        r=json.loads(line);a=r['snapshot'];ms=r['cycle']/5760000
        if ms<6700:continue
        vals=[a['scene_mix'+str(i)][0] for i in range(5)]
        snap=dict(ms=ms,earliest_foreground_update_ms=prev_end,seq=r['seq'],
          bank=a['scene_bank'][0],button=bool(a['scene_buttons'][0]&2),held=a['scene_held'][0],
          inputs=a['scene_adc'],raw=struct.unpack('<4H',bytes(a['scene_raw'])),acc=struct.unpack('<4H',bytes(a['scene_acc'])),
          last=a['scene_pickup'],intent=a['scene_intended'],level=vals)
        out.append(snap)
        if old is not None and vals[:2]!=old['level'][:2]:
            changes.append({'earliest_ms':prev_end,'latest_ms':ms,'old_levels':old['level'][:2],'new_levels':vals[:2],
              'pickup_last':snap['last'][:2],'actual_adc':snap['inputs'][:2],'bank':snap['bank'],'target_seen':snap['intent'][:2]})
        if old is not None and old['bank']!=snap['bank']:switches.append({'before':old,'after':snap})
        old=snap
    assert changes and switches
    (args.dest/(board+'-fader-trajectory.json.gz')).write_bytes(gzip.compress(json.dumps(out,separators=(',',':')).encode(),mtime=0))
    return {'trace_sha256':hashlib.sha256(trace.read_bytes()).hexdigest(),'starting_levels':out[0]['level'][:2],'final_levels':out[-1]['level'][:2],
            'sample_count':len(out),'bank_transitions':switches,'changed_level_intervals':changes}
summary={'stock':extract(args.stock,'stock'),'oneblock':extract(args.candidate,'oneblock')}
(args.dest/'fader-causality.json').write_text(json.dumps(summary,indent=2)+'\n')
for board,data in summary.items():
    print(board, data['final_levels'],'last two',data['changed_level_intervals'][-2:])
    for t in data['bank_transitions']:
        print('bank transition',t['before']['ms'],t['before']['bank'],t['after']['ms'],t['after']['bank'])
