"""Observe actual ADC, approved input history, bank and saved part levels on unmodified firmware."""
import argparse
from pathlib import Path
import sys
parser=argparse.ArgumentParser(add_help=False)
parser.add_argument('--capture-root',type=Path,required=True)
opts,args=parser.parse_known_args()
capture=opts.capture_root.resolve()/'capture.py'
source=capture.read_text()
needle='    env.update(FM1_DNBOX_MAP='
assert source.count(needle)==1
add="""    assert s['fm1_in'][1]==636 and s['proj'][1]==36420
    inputs=s['fm1_in'][0]
    rows=[('raw', inputs+598, 8), ('acc', inputs+576, 8), ('adc', inputs+584, 4),
          ('buttons', inputs+12, 4), ('bank', s['smk_fbank'][0], 1),
          ('pickup', s['smk_faders.last'][0], 4), ('held', s['smk_faders.held'][0], 1),
          ('intended', s['smk_mute_intended'][0], 4)]
    for voice in range(5):
        rows.append((f'mix{voice}',s['proj'][0]+40+(5*12+voice)*32,1))
    with (dest/'observer.map').open('a') as fd:
        for name,addr,size in rows:
            print(f'scene_{name} {addr:x} {size}',file=fd)
"""
source=source.replace(needle,add+needle)
sys.path.insert(0,str(capture.parent));sys.argv=[str(capture),*args]
exec(compile(source,str(capture),'exec'),{'__name__':'__main__','__file__':str(capture)})
