"""Build one measured application output block while the boot DMA carries silence."""
from pathlib import Path
import sys
root = Path(sys.argv[1])
def edit(name, before, after):
    path = root/name
    text = path.read_text()
    assert text.count(before) == 1, name
    path.write_text(text.replace(before,after))

edit("firmware/src/gfx.c", 'static uint16_t cv_px[CV_MAX] __attribute__((section(".pool")));', '''static union {
    uint16_t pixels[CV_MAX];
    int32_t boot_audio[1024];  /* one stereo output half, before the main screen owns the canvas */
} cv_storage __attribute__((section(".pool")));
#define cv_px cv_storage.pixels''')
app = "firmware/src/app/main_fm1.c"
edit(app,"void fm1_alnk0_irq(void)                            /* via",'''enum { AUDIO_RUN, AUDIO_BOOT_PREPARE, AUDIO_BOOT_SILENCE, AUDIO_BOOT_HANDOFF };
static volatile uint8_t audio_boot_phase;
_Static_assert(sizeof(cv_storage.boot_audio) == HALF_WORDS * sizeof(int32_t), "one DMA half");

void fm1_alnk0_irq(void)                            /* via''')
edit(app,'''        render_block(&abuf[half * HALF_WORDS]);
        fm1_audio_ack_half();''','''        int32_t *out = &abuf[half * HALF_WORDS];
        switch (audio_boot_phase) {
        case AUDIO_BOOT_PREPARE:
            render_block(cv_storage.boot_audio);
            audio_boot_phase = AUDIO_BOOT_SILENCE;
            break;
        case AUDIO_BOOT_SILENCE:
            /* Both physical halves still contain their verified initialization. */
            break;
        case AUDIO_BOOT_HANDOFF:
            memcpy(out, cv_storage.boot_audio, sizeof cv_storage.boot_audio);
            audio_boot_phase = AUDIO_RUN;
            break;
        default:
            render_block(out);
        }
        fm1_audio_ack_half();''')
timer="firmware/hal/fm1_timer.h"
edit(timer,'''FM1_INLINE void fm1_timer5_start(void (*isr)(void), uint32_t prio)''','''FM1_INLINE void fm1_timer5_prepare(void (*isr)(void), uint32_t prio)''')
edit(timer,'''    fm1_irq_attach(FM1_IRQ_TIMER5, isr, prio);
    FM1_T5_CON = 0x4019u;
}''','''    fm1_irq_attach(FM1_IRQ_TIMER5, isr, prio);
}
FM1_INLINE void fm1_timer5_enable(void)
{
    FM1_T5_CON = 0x4019u;
}
FM1_INLINE void fm1_timer5_start(void (*isr)(void), uint32_t prio)
{
    fm1_timer5_prepare(isr, prio);
    fm1_timer5_enable();
}''')
edit(app,'''    audio_init();
    usb_start();''','''    lcd_sync();                          /* release all display DMA ownership of cv_storage */
    audio_boot_phase = AUDIO_BOOT_PREPARE;
    audio_init();
    fm1_timer5_prepare(isr_timer5, 4);
    fm1_guard_lock_top();
    fm1_irq_enable_all();
    usb_start();''')
edit(app,'''    fm1_timer5_start(isr_timer5, 4);
    fm1_guard_lock_top();
    fm1_irq_enable_all();''','''    {
        uint32_t irq = fm1_irq_mask_save(FM1_IRQ_ALNK0);
        /* A very slow/missing audio clock may have supplied no free half yet. */
        audio_boot_phase = audio_boot_phase == AUDIO_BOOT_SILENCE ? AUDIO_BOOT_HANDOFF : AUDIO_RUN;
        fm1_irq_mask_restore(FM1_IRQ_ALNK0, irq);
    }
    fm1_timer5_enable();''')
edit("firmware/src/usb.c","    fm1_usb_reset();\n    fm1_delay_ms(25);\n    usb_attach_ready();",'''    fm1_usb_reset();
    uint32_t reset_at = fm1_ticks();
    while (fm1_ticks() - reset_at < 25000u * FM1_TICKS_PER_US) {}
    usb_attach_ready();''')
