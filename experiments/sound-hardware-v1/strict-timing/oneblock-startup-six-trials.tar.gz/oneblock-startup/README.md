# One measured startup block on the original audio clock

The original stock firmware ca0c00a4e5863132de4a66f5d1c477c14d699be5 leaves the first two DMA interrupts unserviced while USB resets. Its first actual render begins at edge 2 with 743.557 µs left, takes 3,919 µs and acknowledges after edge 3. Its next application render begins at edge 4. This isolated alternative positively services each hardware edge and keeps exactly one application render completed before edge 4. Every DSP kernel comes from the stock tree.

| Board | Offset ms | Complete application halves | Raw late | Peak µs | Different stock project bytes |
| --- | ---: | ---: | ---: | ---: | ---: |
| Elite | 0 | 648 | 0 | 11,300 | 2 |
| Elite | 1 | 648 | 0 | 11,308 | 12 |
| Elite | 3 | 648 | 0 | 11,350 | 4 |
| Pro | 0 | 648 | 0 | 11,443 | 5 |
| Pro | 1 | 648 | 0 | 11,327 | 4 |
| Pro | 3 | 648 | 0 | 11,329 | 6 |

The current timing target is 10,909 µs. Every trial differs from its genuine same-board, same-offset stock project. Unshifted Elite preserves every pattern, arrangement, and all sound data except the 909 and 808 levels. Elite +1 loses the 909 clap at step 16 and changes bass-B length. Elite +3 moves a kick step and changes bass-B length. Pro preserves its exact stock drum notes on all three offsets but changes bass flags, length or articulation and levels. The six native project receipts contain the entire per-byte comparison including hashes, and project-fields.json identifies the musical fields.

## Hardware and application ownership

The pipeline reserves the existing 4,096-byte output staging area in the 66,240-byte screen canvas only in early startup. It synchronizes any outstanding LCD DMA before audio initialization. At edge 1, during the genuine USB settle, the real render callback writes one full 512-frame application block into the staging area. The ordinary engine, CPU-load, peak, and application-frame counters record this work. Both physical buffers still contain their initialized silence. Edge 2 acknowledges the second certified silent buffer. On the first new free-half event after USB and UART are ready, edge 3 copies the staged output into the released half. Edge 4 and subsequent edges render ordinary contiguous application output. TIMER5 counting begins after USB and UART. Both vectors are installed and guarded before global IRQ enable.

The real 44.1 kHz DMA consumes four initialized silent halves. It consumes the first application block on physical edge 5, the second on 6, and so forth. This explicit stream start allows a potentially nonzero first block to be followed by its second block. Publishing that block for physical edge 4 at the original 744-µs deadline would instead require a second application render before edge 4 to populate edge 5 continuously, or an extra startup-silent half between the two application outputs. The exact stock first output in the recorded boot is zero. The handoff therefore preserves the observed output through the first 102,464 stereo frames of the full unshifted Elite comparisons.

The 8-second external observer records all 651 physical DMA edges and 650 completed audio IRQs. Of those IRQs, 648 performed actual counted application renders. A final IRQ remains in flight at cutoff. IRQ 1 spent 3,650 µs inside the original render measurement and 3,663.422 µs including its wrapper. IRQ 2 required 1.553 µs. The genuine 4,096-byte handoff at IRQ 3 required 18.869 µs. Every completed application charge appears in the raw external ledger. The observer confirms every initial staging byte was written exactly once and every handoff byte was copied to the released half, including zeros. The three matched 526-ms startup probes verify both alternating physical output ranges without altering guest firmware. The complete 8-second observer and an ordinary run return identical counters, physical output and project data.

The nonzero host ownership regression compiles the actual candidate IRQ, simulates zero through eight silent-settling edges and independently checks all 1,024 sample words at every emitted edge. It also injects a boundary crossing at every startup and steady IRQ. Every real crossing increments both raw late counters. This exercises 153 distinct scenarios and 2,506,752 output words. It verifies transfer ownership on tagged nonzero synthetic outputs. Authentic device-output comparison remains limited to the actual stock boot signal.

The Elite first DMA edge is 1.403 µs earlier than stock, and the scanner's median 16-column store phase is 345.767 µs versus stock's 343.673 µs over the first 3.4 seconds. Their periods and the final 75,212 matrix TIMER5 interrupts match. At the first physical input and PLAY, the real application engine has completed 76,800 and 196,608 frames in both images. The completed application counters match at 147 of 148 distinct input timestamps. At 7,160 ms stock has just returned from DMA 578 while the candidate remains in it. The complete gesture ledger records this distinction.

The known-good 44.1 kHz startup hands back the canvas at IRQ 3, well before the first possible regular display reuse after 30 ms. A stalled audio clock between the initial render and first handoff would require an explicit cancellation or separate staging lease before screen writes. This experiment only qualifies the observed working-clock startup. The code handles the case where no first edge at all arrives during USB settling by entering the ordinary renderer when service becomes available. The alternative loader changes by 10 bytes on Elite and 6 on Pro because its reset helper is shared. The actual application images remain exactly 546,516/546,508 bytes and retain the 780 B pool margin.

## Fader evidence

Under the unshifted Elite script, physical ADC channels 16–19 all execute the same sweep beginning at 6,800 ms. Stock initially stores 909/808 levels 75/112. Its acquired first level reaches 87, then both fader-history values and the physical ADC hold 113/115 when the saved pair becomes 113/115 by 7,048.105 ms. The candidate first acquires 95, then its ADC, pickup history and saved pair jointly reach 117/117 by 7,059.709 ms. Bank B becomes visible one half later than stock. After that transition the previous bank's levels remain untouched. The underlying source applies the measured ADC values through the normal pickup comparison and pref_set. The trace brackets the foreground writes between neighboring audio-IRQ snapshots. Matching unobserved DAC/diagnostic results validate that the observer did not affect this outcome. fader-causality.json records the full brackets and the compact trajectory files retain each interval.

## Replay

1. Apply oneblock.patch to the frozen ca0 source, or use python3 apply.py SOURCE. Verify each actual cold image with the appropriate native JSON. The source includes no emitted firmware, loader or package.
2. Use the capture drivers supplied in the companion stock-programming-and-priming archive. Use the pinned fm1-live and heavy.keys from its README. Prepare a distinct 2-second cold seed per model. Run the ordinary 8-second script at offsets 0, 1 and 3 for each model using that seed.
3. Run the standard full 8-second observer with the scan-watch.py script from the companion archive for stock and candidate. Run python3 edges.py STOCK_TRACE NEW_TRACE OUTPUT_DIR. The paired DMA CSVs cover every real output half and every completed IRQ. Verify oneblock.patch against actual compiled source before using the host test.
4. Run watch.py with the same capture arguments plus --capture-root and --region stage, dma0 or dma1 and --trace --ms 526. Feed the three directories named watch-stage, watch-dma0 and watch-dma1 into writes.py. Each region covers every one of its 4,096 bytes.
5. Use fader_watch.py for stock and candidate 8-second unshifted Elite and faders.py STOCK NEW OUTPUT_DIR for the causal trace. layout.c reproduces the exact original input-struct layout with the target PI32v2 R3 compiler using -target pi32v2 -integrated-as -mcpu=r3 -mfprev1. The stock pickup implementation is smk_faders in firmware/src/app/main_fm1.c.
6. Run python3 host.py SOURCE for the nonzero ownership and deadline-fault test. Run verify.py in this packet to check the stored physical ledgers, buffer writes and all six native results.

The stopped DSP is stock throughout these trials. Presentation of a separate playback-only optimization requires its own combined source identity, cold native pair, host/target parity, physical project comparison and strict timing evidence.
