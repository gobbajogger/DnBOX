"""Validate all physical ledgers, handoff writes, pickup and same-offset project results."""
import csv,gzip,hashlib,io,json
from pathlib import Path
base=Path(__file__).resolve().parent
def read(n):return json.loads((base/n).read_bytes())
def compressed(n):return gzip.decompress((base/n).read_bytes())
for name in ('stock','oneblock'):
    rows=list(csv.DictReader(io.StringIO(compressed(name+'-dma.csv.gz').decode())))
    assert len(rows)==651 and [int(x['edge']) for x in rows]==list(range(1,652))
    assert all(int(r['physical_half'])==(int(r['edge'])-1)%2 for r in rows)
    assert sum(int(r['render_last_us_writes'] or 0) for r in rows)==648
    assert all(int(r['pcm_nonzero_words'])==0 for r in rows[:4])
    assert all(r['pcm_sha256']==hashlib.sha256(bytes(2048)).hexdigest() for r in rows[:4])
    if name=='oneblock':
        assert [r['render_last_us_writes'] for r in rows[:4]]==['1','0','0','1']
        assert all(int(r['dma_at_completion'])==int(r['edge']) for r in rows if r['dma_at_completion'])
gestures=json.loads(compressed('gesture-timestamps.json.gz'));assert len(gestures)==148
miss=[r for r in gestures if r['stock'][:2]!=r['candidate'][:2]]
assert [r['ms'] for r in miss]==[7160]
for tag,want in [('stage',[1]),('dma0',[3,5]),('dma1',[4,6])]:
    data=list(csv.DictReader(io.StringIO(compressed(tag+'-startup-stores.csv.gz').decode())))
    assert sorted({int(r['edge']) for r in data})==want
    for edge in want:
        seq=[r for r in data if int(r['edge'])==edge]
        assert len(seq)==4096 and all(int(r['byte'])==0 for r in seq)
        assert sorted(int(r['offset']) for r in seq)==list(range(4096))
assert [r['project_bytes_different'] for r in read('six-strict-trials.json')]==[2,12,4,5,4,6]
for r in read('six-strict-trials.json'):
    assert r['debug']['halves']==648 and r['audio_xruns']==r['debug']['late']==0
    assert r['debug']['max_us']>10909
    project=read(f"{r['model']}-{r['shift_ms']}-project.json");assert r['project_bytes_different']==project['different_bytes']
for board,expected in [('stock',[113,115]),('oneblock',[117,117])]:
    r=read('fader-causality.json')[board]
    assert r['final_levels']==expected and r['changed_level_intervals'][-1]['actual_adc']==expected
    assert r['changed_level_intervals'][-1]['pickup_last']==expected
assert (base/'host.txt').read_text().startswith('153 startup sequences')
print('Verified all 1,302 physical DMA records, 20,480 observed startup writes, six native strict trials and both fader pickups.')
