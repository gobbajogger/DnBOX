typedef unsigned int uint32_t;typedef unsigned long long uint64_t;typedef unsigned short uint16_t;typedef signed short int16_t;typedef unsigned char uint8_t;
#define FM1_NCOL 16u
#define FM1_NBTN 18u
#define FM1_NKEY 37u
#define FM1_NENC 8u
#define SMK_NPAD 16u
static volatile struct {
    uint32_t notes;              /* bit n = note key n (0 = F3 .. 26 = G5): keybed keys 5..31 | the pads */
    uint32_t knotes, pnotes;     /* (the two sources of notes: keybed keys 5..31, pads as white keys) */
    uint32_t buttons;            /* debounced: bit i = button i (0..17) */
    uint32_t pressed, released;  /* button edges since the last fm1_input_edges() */
    uint32_t notes_pressed;      /* note-key press edges since the last fm1_input_note_edges() */
    uint64_t keys;               /* all 37 keybed keys: bit k = key k (0 = lowest C) */
    uint8_t key_vel[FM1_NKEY];   /* MIDI velocity 1..127 of each key's last press (a pad: its white key's) */
    uint8_t raw[FM1_NCOL];       /* last frame, rows packed, 1 = closed */
    uint8_t cnt[FM1_NBTN];       /* button debounce */
    uint8_t ks_last[FM1_NKEY], ks_stab[FM1_NKEY], ks_rel[FM1_NKEY];
    uint32_t ks_t1[FM1_NKEY];    /* fm1_ticks() when contact 1 closed */
    uint8_t enc_last[FM1_NENC], enc_hist[FM1_NENC];
    int16_t enc_cnt[FM1_NENC];   /* transitions, + = B leads */
    int16_t enc_steps[FM1_NENC];
    uint16_t pad_raw[SMK_NPAD], pad_base[SMK_NPAD], pad_peak[SMK_NPAD];
    uint8_t pad_st[SMK_NPAD];    /* 0 idle, 1..SMK_PAD_PEAKN collecting the peak, 0x80 on */
    uint8_t pad_low[SMK_NPAD];
    uint8_t pad_vel[SMK_NPAD];   /* last strike, separate from the overlapping keybed velocity */
    uint8_t pad_press[SMK_NPAD]; /* pressure 0..127 while on */
    uint16_t fad_acc[4];         /* faders: 0..1023 IIR */
    uint8_t fader[4];            /* 0..127 */
    uint16_t wheel[2], pedal, batt;   /* raw 0..1023 (mux C addresses 4, 5, 6, 7) */
    uint16_t wheel_mod_seq;          /* accepted mod ADC publications, not foreground polls */
    uint16_t fad_raw[4];         /* (debug: the last raw fader readings) */
    uint16_t fad_hist[4][2];     /* the two readings before: a median of 3 drops a lone spike */
    uint32_t adc_ok, adc_miss;   /* (debug: conversions read / not finished within a tick) */
    uint32_t frames;
} fm1_in;
const unsigned off[]={sizeof fm1_in,__builtin_offsetof(__typeof__(fm1_in),buttons),__builtin_offsetof(__typeof__(fm1_in),fad_acc),__builtin_offsetof(__typeof__(fm1_in),fader),__builtin_offsetof(__typeof__(fm1_in),fad_raw),__builtin_offsetof(__typeof__(fm1_in),fad_hist),__builtin_offsetof(__typeof__(fm1_in),frames)};
