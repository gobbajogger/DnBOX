"""Verify every startup handoff byte using three matched, read-only RAM watch trials."""
import argparse, collections, gzip, hashlib, json
from pathlib import Path
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument("runs",type=Path);parser.add_argument("out",type=Path)
args=parser.parse_args();out=args.out;out.mkdir(exist_ok=True)
results={};first=None
for name in ("stage","dma0","dma1"):
    folder=args.runs/("watch-"+name);trace=folder/"trace.jsonl";word_maps=collections.defaultdict(dict);counts=collections.Counter()
    meta=json.loads((folder/"result.json").read_text());identity=[meta[k] for k in ("debug","eng_prof_frames","fwsc_sha256","pcm_sha256","scene_sha256","initial_flash_sha256","emulator_sha256")]
    if first is None:first=identity
    else:assert first==identity
    rows=[]
    for line in trace.open():
        if '"name":"scene_audio_' not in line:continue
        row=json.loads(line);assert row['event']=='store' and row['width']==1
        offset=int(row["name"].split('_')[-1])+row["offset"];seq=row["seq"]
        assert 0<=offset<4096
        word_maps[seq][offset]=row["value"];counts[seq]+=1
        rows.append(f"{seq},{row['cycle']},{offset},{row['value']}\n")
    expected={'stage':{1},'dma0':{3,5},'dma1':{4,6}}[name]
    assert expected==set(word_maps)
    result=[]
    for seq,image in word_maps.items():
        assert set(image)==set(range(4096)) and counts[seq]==4096
        block=bytes(image[i] for i in range(4096));assert not any(block)
        result.append({'edge':seq,'all_bytes_written':counts[seq],'image_sha256':hashlib.sha256(block).hexdigest()})
    raw=('edge,observer_tick,offset,byte\n'+''.join(rows)).encode()
    (out/(name+'-startup-stores.csv.gz')).write_bytes(gzip.compress(raw,mtime=0))
    results[name]={'whole_raw_trace_sha256':hashlib.sha256(trace.read_bytes()).hexdigest(),'writes':result,'duration_ms':meta['shot_ms'],
     'physical_pcm_sha256':meta['pcm_sha256'],'final_debug':meta['debug']}
(out/'startup-word-coverage.json').write_text(json.dumps(results,indent=2)+'\n')
print('Verified every byte of the application staging block and both real DMA halves across three unaltered image runs.')
