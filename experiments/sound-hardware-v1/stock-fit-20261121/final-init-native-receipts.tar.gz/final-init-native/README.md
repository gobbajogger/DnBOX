## Production dry INIT on stock SMK-37

Both native images link, package and pass the stock RAM and application-area checks with shipped Juno and chorus, two independent synth owners, the normal development identity 900 and the default empty BREAK bank. The seven source and build-manifest changes overlay parent `933a6f40e8aca72607a258ab42ff21265489903d`. The independently replayed source tree is `39c6aea21022c93ee95de5a78236b3619b63bcdb`. The proof packet pins source, compiler, SDK packaging inputs and model output hashes. These measurements cover the final dry INIT filter, unity voice summation and retrigger/steal behavior.

| Physical build | Image (B) | Application XIP free (B) | Ordinary RAM used / capacity (B) | Pool used / capacity (B) | XPOOL used / capacity (B) |
| --- | ---: | ---: | ---: | ---: | ---: |
| SMK-37 Elite | 546,516 | 6,156 | 97,204 / 98,304 | 335,092 / 344,064 | 9,216 / 9,216 |
| SMK-37 Pro | 546,508 | 6,164 | 97,204 / 98,304 | 335,092 / 344,064 | 9,216 / 9,216 |

The application capacity is 552,672 bytes. Both builds retain 8,972 bytes of raw pool space, 780 above the 8,192-byte reserve and 268 beyond the additional 512-byte margin requirement. Static link measurements establish the physical image fit. On-device callback timing and stack high-water remain unmeasured.

| Engine | Selected backend per owner or fixed drum/BREAK state (B) | Named function flash (B) | Named constant flash (B) |
| --- | ---: | ---: | ---: |
| Chicago | 3,492 | 29,460 | 34,453 |
| Miami | 3,720 | 18,280 | 5,327 |
| Shipped Juno with chorus | 888 | 2,340 | 0 |
| Synth One dry INIT | 956 | 1,764 | 48 |
| 808 | 3,680 | 342 | 11 |
| 909 | 7,612 | 3,836 | 32 |
| BREAK | 6,772 | 1,646 | 0 |

The PI32v2 compiler produced the four melodic backend sizes. Each is an alternative member of a 3,720-byte union in a 5,184-byte owner. Both owner instances retain 10,368 bytes total. Two 5,120-byte workspaces occupy POOL and XPOOL respectively. For drums and BREAK, the table uses each final ELF's pool object size. The shared bus retains `fx` at 18,316 bytes and `dly_buf` at 158,400 bytes. `original_fx` retains 8,504 bytes for both selected inserts together.

Flash attribution unions disjoint nonzero ELF `.text` ranges with an engine-owned name, splitting function symbols from read-only data. Source-unique local symbols `pitch_hz`, `filter_substep` and `pitch_hz.octave_hz` belong to Synth One. Both models give the same engine figures. The remaining 448,977 bytes on Elite and 448,969 bytes on Pro include shared/inlined functions, anonymous constants, padding and the rest of the image. Per-engine flash totals therefore give lower bounds.

Eight actual original-engine dry scenes at 44.1 kHz, velocity 100 and cutoff/resonance 2,000 Hz/0.9 establish the output level. Each original two- and six-note chord matched the binary32 sum of its original single-note captures for all 88,192 frames, including release. A fixed divide-by-six failed all eight level checks. The production renderer at unity passed all eight, with worst absolute RMS error 0.020251 dB and maximum mean spectral error 0.330145 dB. Independent full original effects, complete preset/runtime coverage and target callback qualification remain open. S6 remains **FAIL**.

[Stock dry INIT native receipts](../../experiments/sound-hardware-v1/stock-dry/final-native-receipts.tar.gz) · [Original part-gain proof](../../experiments/sound-hardware-v1/stock-dry/part-gain-proof.tar.gz)

Run `sh replay-native-init.sh LOCAL_REPO JIELI_TOOLCHAIN AC79_SDK NEW_OUTPUT` after extracting the packet. A second fresh source reconstruction reproduced both models’ binary, ELF, package and physical linker-script hashes.
