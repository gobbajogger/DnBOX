#!/bin/sh
# Local stock build and RAM/flash readback for the pinned dry INIT source.
set -eu
if [ "$#" -ne 4 ]; then
  echo "Usage: sh replay-native-init.sh LOCAL_REPO JIELI_TOOLCHAIN AC79_SDK NEW_OUTPUT" >&2
  exit 2
fi
packet=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
repo=$(CDPATH= cd -- "$1" && pwd)
toolchain=$(CDPATH= cd -- "$2" && pwd)
sdk=$(CDPATH= cd -- "$3" && pwd)
mkdir -- "$4"
out=$(CDPATH= cd -- "$4" && pwd)
mkdir "$out/tree" "$out/home" "$out/tmp"
git -C "$repo" archive --format=tar --output="$out/base.tar" 933a6f40e8aca72607a258ab42ff21265489903d
tar -xf "$out/base.tar" -C "$out/tree"
cd "$out/tree"
git apply "$packet/init-on-933a6f40.patch"
sha256sum -c "$packet/build-inputs.sha256"
(cd "$sdk/cpu/wl82/tools" && sha256sum -c "$packet/sdk.sha256")
(cd "$toolchain" && sha256sum -c "$packet/toolchain.sha256")
"$toolchain/pi32v2/bin/clang" --version
for model in elite pro; do
  env -i HOME="$out/home" TMPDIR="$out/tmp" PATH="$PATH" PYTHON=python3 JIELI_DOCKER=0 X0X_JOBS=2 BOARD=smk37 MODEL="$model" JIELI_TOOLCHAIN="$toolchain" AC79_SDK="$sdk" sh build.sh > "$out/$model.log" 2>&1 || { cat "$out/$model.log" >&2; exit 1; }
  case "$model" in elite) target=smk37-elite;; pro) target=smk37;; esac
  "$toolchain/common/bin/objdump" -t -h "build/$target/x0x.elf" > "$out/$model.symbols-sections.txt"
  python3 "$packet/link_attribution.py" "$out/$model.symbols-sections.txt"
  sha256sum "build/$target/x0x.bin" "build/$target/x0x.elf" "build/x0x-$target.fwsc"
done
"$toolchain/pi32v2/bin/clang" -target pi32v2 -mcpu=r3 -mfprev1 -ffp-contract=off -fno-common -std=c99 -Ifirmware/src/app -Ifirmware/src/dsp -Iexperiments/original_synth -Iexperiments/wobble -idirafter "$toolchain/pi32v2/include" -c "$packet/abi_probe.c" -o "$out/abi.o"
"$toolchain/common/bin/objdump" -t "$out/abi.o" > "$out/target-abi.txt"
