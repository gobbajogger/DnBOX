#include "original_runtime.h"
#define MEASURE(label, member) char measured_##label[sizeof(member)]
MEASURE(chicago_backend, original_chicago_backend);
MEASURE(miami_backend, original_miami_backend);
MEASURE(juno_backend, ((original_runtime_part *)0)->dsp.juno);
MEASURE(s1_backend, s1_dry_part);
MEASURE(backend_union, original_runtime_backend);
MEASURE(one_owner, original_runtime_part);
MEASURE(chicago_workspace, ((original_runtime_workspace *)0)->chicago);
MEASURE(miami_workspace, ((original_runtime_workspace *)0)->miami);
MEASURE(workspace_union, original_runtime_workspace);
