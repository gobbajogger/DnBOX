"""Measure disjoint retained .text function and constant ranges with engine-owned names."""
import re
from pathlib import Path
import sys,json
from collections import defaultdict
patterns={
    'Chicago':('chicago_','original_chicago_'),
    'Miami':('miami_','original_miami_'),
    'Synth One':('s1_','dnbx_s1_'),
    'Juno backend':('juno6_','dnbx_'),
    '808':('drum808_',),
    '909':('drum909_',),
    'BREAK':('breaks_',)
}
local_symbols={
    'Synth One': {'pitch_hz', 'filter_substep', 'pitch_hz.octave_hz'},
    'Juno backend': {'params_valid.bounds', 'params_valid.field_range'},
}
def count_ranges(blocks):
    merged=[]
    for start,stop in sorted(blocks):
        if not merged or merged[-1][1]<start:
            merged.append([start,stop])
        else:
            merged[-1][1]=max(merged[-1][1],stop)
    return sum(stop-start for start,stop in merged)
def measure(path):
    rows=defaultdict(list)
    for line in path.read_text().splitlines():
        m=re.fullmatch(r'([a-f\d]+)\s+[lg]\s+(F|O)?\s*\.text\s+([a-f\d]+)\s+(\S+)',line)
        if not m:continue
        lo=int(m[1],16);size=int(m[3],16);symbol=m[4]
        if not size:continue
        for engine,prefixes in patterns.items():
            if symbol.startswith(prefixes) or symbol in local_symbols.get(engine, ()):
                rows[engine].append((lo,lo+size,symbol,'function' if m[2]=='F' else 'constant'))
                break
    assert rows.keys()==patterns.keys()
    total=[]
    counts={}
    for engine,records in rows.items():
        counts[engine]={}
        for kind in ('function','constant'):
            ranges={(lo,hi) for lo,hi,_,k in records if k==kind}
            counts[engine][kind+'_bytes']=count_ranges(ranges)
            total.extend(ranges)
    assert sum(sum(v.values()) for v in counts.values())==count_ranges(total), 'cross-engine aliases'
    return counts
if __name__=='__main__':
    for arg in sys.argv[1:]:print(json.dumps({arg:measure(Path(arg))},indent=2))
