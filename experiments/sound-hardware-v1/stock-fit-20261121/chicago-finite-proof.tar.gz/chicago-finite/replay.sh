#!/bin/sh
set -eu
base=$(cd "$1" && pwd)
candidate=$(cd "$2" && pwd)
mkdir "$3"
out=$(cd "$3" && pwd)
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
for tree in "$base" "$candidate"; do
  if [ "$tree" = "$base" ]; then name=before; else name=after; fi
  dir="$tree/experiments/original_synth"
  cc -std=c11 -O2 -fno-fast-math -ffp-contract=off -fPIC -shared -I"$dir" -I"$tree/firmware/src/app" "$dir/chicago_mp4.c" -lm -o "$out/$name.so"
done
cc -std=c11 -O2 -fno-fast-math -ffp-contract=off -I"$base/experiments/original_synth" "$here/fault_compare.c" -ldl -lm -o "$out/compare"
"$out/compare" "$out/before.so" "$out/after.so"
sh "$candidate/tests/host/chicago_span_hold_test.sh" "$out/stock-span"
