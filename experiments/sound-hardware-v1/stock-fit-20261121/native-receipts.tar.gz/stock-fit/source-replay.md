# Reproduce the measured code trees

Use a separate local checkout at `0cddaeb822458fdf4ed3b0b9035fcf22248fda10`. Apply each listed patch using `git apply --index` and compare `git write-tree` with the corresponding `source_tree` in results.json. Choose one sequence per checkout.

| Variant | Patch sequence |
| --- | --- |
| Shipped Juno with partial S1 | 01 |
| Compact original | 01, 02 |
| Compact original plus physical-range dictionary | 01, 02, 03a |
| Compact AMP2 | 01, 02, 03b |
| Compact AMP2 plus expanded range dictionary | 01, 02, 03b, 04 |

Build from a clean output directory with the pinned toolchain and SDK. Run `BOARD=smk37 MODEL=elite sh build.sh`, followed by `BOARD=smk37 MODEL=pro sh build.sh`. ELF outputs and packaging stay on the local machine. Test images are unqualified for device use.
