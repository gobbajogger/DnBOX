import numpy as np
def coefficients(hz, res):
    x=np.asarray(hz,dtype=np.float32)*np.float32(1/22050)
    k=x*(np.float32(1.56874466)+x*(np.float32(-1.73140822)+x*(np.float32(1.55879259)+x*(np.float32(-.711601815)+x*np.float32(.118475673)))))
    a=np.float32(1)-k
    fb=np.float32(res)*(np.float32(3.98720139)+x*(np.float32(3.68178143)-x*np.float32(3.93633599)))
    return a,fb
def radius(hz,res):
    a,fb=coefficients(hz,res)
    a,fb=np.atleast_1d(a).astype(float),np.atleast_1d(fb).astype(float)
    ident=np.eye(5);v=-.5*fb[:,None]*(ident[3]+ident[4])
    rows=[]
    for i in range(4):
        v=(1-a)[:,None]*v+a[:,None]*ident[i]
        rows.append(v)
    rows.append(np.broadcast_to(ident[3],v.shape))
    eigen=np.linalg.eigvals(np.stack(rows,axis=1))
    return np.max(np.abs(eigen),axis=1)**2
if __name__=='__main__':
    hz=np.linspace(64,22050,21987)
    for r in (0,.5,.9,.98):
        p=radius(hz,r);edge=np.flatnonzero(np.diff(p>=1))
        print(r,'maximum',hz[p.argmax()],p.max(),'boundaries',hz[edge], 'count',int((p>=1).sum()),'init2000',radius(2000,r)[0])
    for c in [64,2000,4000,6000,7000,8500,9000,10000,11025,12000,14000,16000,18000,20000,22050]:
        print(c,*[float(radius(c,r)[0]) for r in (.9,.98)])
