#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "s1_dry_voice.h"
static void run(float h1, float r1, int n1, float h2, float r2, int n2, unsigned blocks)
{
    s1_dry_voice v;
    s1_dry_controls c;
    s1_dry_reset(&v);
    s1_dry_frozen_controls(&c);
    c.cutoff_hz=h1;c.resonance=r1;
    int config=s1_dry_configure(&v,&c);
    int start=s1_dry_start(&v,261.625565f,100,0);
    if(config || start) abort();
    float peak=0,buf[64];unsigned n=0;
    for(unsigned i=0;i<blocks;++i) {
        int alt=(i&1)&&n2>0;
        c.cutoff_hz=alt?h2:h1;c.resonance=alt?r2:r1;
        if(s1_dry_configure(&v,&c)!=0) abort();
        int frames=alt?n2:n1;
        if(s1_dry_render(&v,buf,(unsigned)frames)!=0) abort();
        for(int j=0;j<frames;++j,++n) {
            if(!isfinite(buf[j])) {printf("%.8g,%.8g,%d,%.8g,%.8g,%d,%u,%.7g,nonfinite\n",h1,r1,n1,h2,r2,n2,n,peak);return;}
            if(fabsf(buf[j])>peak) peak=fabsf(buf[j]);
        }
    }
    printf("%.8g,%.8g,%d,%.8g,%.8g,%d,%u,%.7g,finite\n",h1,r1,n1,h2,r2,n2,n,peak);
}
int main(int argc,char **argv) {
    if(argc==8) {run(strtof(argv[1],0),strtof(argv[2],0),atoi(argv[3]),strtof(argv[4],0),strtof(argv[5],0),atoi(argv[6]),(unsigned)atoi(argv[7]));return 0;}
    const float hz[]={64.f,83.375f,112.f,201.8125f,783.2f,1637.f,2000.f,5003.125f,10463.4f,14785.6f,18912.5f,22049.25f,22050.f};
    const float r[]={0.f,.5f,.9f,.98f};
    for(unsigned k=0;k<sizeof(hz)/sizeof(*hz);++k)for(unsigned i=0;i<4;++i)run(hz[k],r[i],64,0,0,0,2048);
}
