import numpy as np
from poles import coefficients
h=np.unique(np.r_[np.geomspace(64,22050,40).round(),2000,4000,8000,10000,16000,20000])
N=len(h); ones=np.eye(5)
def output_matrix(h,r):
 a,fb=coefficients(h,r)
 a=a.astype(float);fb=fb.astype(float)
 v=-.5*fb[:,None]*(ones[3]+ones[4])
 rows=[]
 for i in range(4):
    v=(1-a[:,None])*v + a[:,None]*ones[i]; rows.append(v)
 rows.append(np.broadcast_to(ones[3],v.shape));m=np.stack(rows,axis=1)
 return m@m
def check(r):
    base=output_matrix(h,r)
    f=[1,2,3,4,8,16,32,64]
    mats=np.concatenate([np.linalg.matrix_power(base,p) for p in f])
    top=0;arg=None
    for i,m in enumerate(mats):
        v=np.max(abs(np.linalg.eigvals(m@mats)),axis=1)
        j=np.argmax(v)
        if v[j]>top:
            top=v[j];arg=(h[i%N],f[i//N],h[j%N],f[j//N])
    print(r,top,arg,flush=True)
if __name__=='__main__':
 for r in (.98,.9,.5):check(r)
